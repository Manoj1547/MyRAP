package com.walmartlabs.services.rdm;

/*import com.walmartlabs.services.rdm.config.AsyncConfig;
import com.walmartlabs.services.rdm.config.KafkaConfig;
import com.walmartlabs.services.rdm.config.ServiceConfig;*/
import com.walmartlabs.services.rdm.config.YamlPropertySourceFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;

@SpringBootApplication
/*@Import({
        ServiceConfig.class,
        AsyncConfig.class,
        KafkaConfig.class
})*/
@PropertySource(value = "classpath:sr.yaml", factory = YamlPropertySourceFactory.class)
public class RapRdmApplication {

    public static void main(String[] args) {
        SpringApplication.run(RapRdmApplication.class, args);
    }
}
