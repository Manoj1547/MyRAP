/*package com.walmartlabs.services.rdm.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

@Configuration
@ImportResource({
        "classpath:META-INF/spring/kafka-producer-context.xml",
        "classpath:META-INF/spring/kafka-consumer-context.xml"
})
public class KafkaConfig {
}*/
