# rap-rdm

<a alt="KITT pipeline status" href="https://concord.prod.walmart.com/#/org/strati/project/pipeline/process?meta.repoMetadata=WalmartLabs-Services/rap-rdm&limit=50">![KITT badge](https://kitt-badges.k8s.walmart.com/kittbadge?org=WalmartLabs-Services&repo=rap-rdm)</a>

