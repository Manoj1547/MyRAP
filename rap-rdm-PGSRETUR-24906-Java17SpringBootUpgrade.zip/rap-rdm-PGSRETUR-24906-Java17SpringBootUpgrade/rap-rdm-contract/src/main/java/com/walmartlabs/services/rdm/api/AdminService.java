package com.walmartlabs.services.rdm.api;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.MediaType;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmartlabs.services.rdm.domain.model.ProductTypeCategoryDO;
import com.walmartlabs.services.rdm.domain.model.SimulationVariableDO;

import java.io.FileNotFoundException;
import java.util.List;

/**
 *
 * @author Tim Jin
 *
 */
@RestController
@RequestMapping("/admin")
public interface AdminService {

    @GetMapping("/nodes")
    public Object getNodes(@RequestParam(value = "sellerType") String sellerType) throws ServiceException;

    @PostMapping("/nodes")
    public ServiceResponse<String> updateNodes(@RequestBody String json,
                                               @RequestParam(value = "sellerType") String sellerType)
            throws ServiceException, JsonProcessingException;

    @GetMapping("/variables")
    public ServiceResponse<List<SimulationVariableDO>> getVariables(@RequestParam(value = "sellerType") String sellerType)
            throws ServiceException;

    @PostMapping("/variables")
    public ServiceResponse<String> updateVariables(@RequestBody String request,
                                                   @RequestParam(value = "sellerType") String sellerType)
            throws ServiceException, JsonProcessingException;

    @PostMapping("/refresh")
    public Object refresh(@RequestBody String json) throws ServiceException;

    @GetMapping("/r2d2")
    public Object r2d2() throws ServiceException;

    @PostMapping("/r2d2")
    public Object updateR2d2(@RequestBody String json) throws ServiceException;

    @GetMapping("/productType")
    public ServiceResponse<List<ProductTypeCategoryDO>> getProductType() throws ServiceException;

    @PostMapping(path = "/productTypes", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ServiceResponse<String> updateProductType(@RequestParam("filePath") String filePath) throws ServiceException, FileNotFoundException;

    @PostMapping("/productType")
    public ServiceResponse<String> createAndUpdateProductTypeJson(@RequestBody String json) throws ServiceException, JsonProcessingException;

    @DeleteMapping("/productType")
    public ServiceResponse<String> deleteProductTypeJson(@RequestBody String json) throws ServiceException, JsonProcessingException;

    @PostMapping(path = "/r2d2/file", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Object updateR2d2(@RequestParam("file") String file, @RequestParam("category") String category) throws ServiceException;

    @PostMapping("/ro/event")
    public Object processROMessage(@RequestBody String json) throws ServiceException;

    @PostMapping("/iqs/cache")
    public Object updateIQSCache(@RequestBody String json,
                                 @RequestParam(value = "gtin") String gtin,
                                 @RequestParam(value = "sellerId") String sellerId ) throws ServiceException;
}