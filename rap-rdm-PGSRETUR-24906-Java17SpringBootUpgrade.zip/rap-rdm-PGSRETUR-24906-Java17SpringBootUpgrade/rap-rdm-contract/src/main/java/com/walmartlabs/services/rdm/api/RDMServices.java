package com.walmartlabs.services.rdm.api;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.MediaType;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmartlabs.services.rdm.dto.dispositionpaths.request.DispositionPathsRequestDTO;
import com.walmartlabs.services.rdm.dto.dispositionpaths.response.DispositionPathsResponseDTO;
import com.walmartlabs.services.rdm.dto.dispositionpaths.simulation.request.DispositionPathsSimulationRequestDTO;
import com.walmartlabs.services.rdm.dto.dispositionpaths.simulation.response.DispositionPathsSimulationResponseDTO;

/**
 *
 * @author Tim Jin
 *
 */
@RestController
@RequestMapping("/{version}")
public interface RDMServices {

    @PostMapping(
            path = "/dispositionPaths",
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE
    )
    public ServiceResponse

            <DispositionPathsResponseDTO> dispositionPaths(
            @RequestBody ServiceRequest

                    <DispositionPathsRequestDTO> request,
            @RequestHeader("Test") Boolean test
    ) throws ServiceException;

    @PostMapping(
            path = "/dispositionPaths/simulation",
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE
    )
    public ServiceResponse

            <DispositionPathsSimulationResponseDTO> dispositionPathsSimulation(
            @RequestBody ServiceRequest

                    <DispositionPathsSimulationRequestDTO> request,
            @RequestParam(value = "debug", required = false) Boolean debug
    ) throws ServiceException;
}