package com.walmartlabs.services.rdm.api;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.MediaType;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmartlabs.services.rdm.dto.healthcheck.HealthCheckResponseDTO;

/**
 *
 * @author Tim Jin
 *
 */
@RestController
@RequestMapping("/status")
public interface HealthCheck {

    @GetMapping(
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public HealthCheckResponseDTO status() throws ServiceException;

}