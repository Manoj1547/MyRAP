
package com.walmartlabs.services.rdm.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * @author Tim Jin
 *
 */
public class Quantity extends BaseRequest {

    @JsonProperty("unitOfMeasure")
    private String unitOfMeasure;

    @JsonProperty("measurementValue")
    private String measurementValue;

    @JsonProperty("measurementValueOriginal")
    private String measurementValueOriginal;

    public String getMeasurementValueOriginal() {
        return measurementValueOriginal;
    }

    public void setMeasurementValueOriginal(String measurementValueOriginal) {
        this.measurementValueOriginal = measurementValueOriginal;
    }

    public String getUnitOfMeasure() {
        return unitOfMeasure;
    }

    public void setUnitOfMeasure(String unitOfMeasure) {
        this.unitOfMeasure = unitOfMeasure;
    }

    public String getMeasurementValue() {
        return measurementValue;
    }

    public void setMeasurementValue(String measurementValue) {
        this.measurementValue = measurementValue;
    }

}
