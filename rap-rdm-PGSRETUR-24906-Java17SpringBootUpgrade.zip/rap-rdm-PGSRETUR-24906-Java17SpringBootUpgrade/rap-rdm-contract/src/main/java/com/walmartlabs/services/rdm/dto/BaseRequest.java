package com.walmartlabs.services.rdm.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 
 * @author Tim Jin
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public abstract class BaseRequest {

}
