package com.walmartlabs.services.rdm.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 
 * @author Tim Jin
 *
 */
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public abstract class BaseResponse {

}
