package com.walmartlabs.services.rdm.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.walmartlabs.services.rdm.model.SellerType;

/**
 * 
 * @author Tim Jin
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Node extends BaseRequest {

    private String     name;

    private String     description;

    private boolean    keyNode;

    private List<Node> children;

    private SellerType sellerType;

    public SellerType getSellerType() {
        return sellerType;
    }

    public void setSellerType(SellerType sellerType) {
        this.sellerType = sellerType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isKeyNode() {
        return keyNode;
    }

    public void setKeyNode(boolean keyNode) {
        this.keyNode = keyNode;
    }

    public List<Node> getChildren() {
        return children;
    }

    public void setChildren(List<Node> children) {
        this.children = children;
    }

    @Override
    public String toString() {
        return "Node{" +
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", keyNode=" + keyNode +
                ", children=" + children +
                ", sellerType=" + sellerType +
                '}';
    }
}