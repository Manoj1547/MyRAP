package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;


import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.component.ovt.model.response.OVTOmniItemPolicyDetails;
import com.walmartlabs.services.rdm.component.ovt.service.util.OVTOmniServiceHelper;
import com.walmartlabs.services.rdm.config.client.ConfigManager;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.Session;
import com.walmartlabs.services.rdm.util.BeanHelper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;

@RunWith(PowerMockRunner.class)
@PrepareForTest(BeanHelper.class)
public class ReturnCenterDispositionCheckTest {
    ReturnCenterDispositionCheck returnCenterDispositionCheck;
    RDMKeepItUtil rdmKeepItUtil;
    RDMKeepItConfig rdmKeepItConfig;
    KeepItRuleEngineContext keepItRuleEngineContext ;
    OVTOmniServiceHelper ovtOmniServiceHelper;
    CompletableFuture<OVTOmniItemPolicyDetails> ovtOmniItemPolicyDetailsCompletableFuture;
    OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails;

    @Before
    public void setUp(){
        returnCenterDispositionCheck = new ReturnCenterDispositionCheck();
        ovtOmniServiceHelper = Mockito.mock(OVTOmniServiceHelper.class);
        rdmKeepItUtil = new RDMKeepItUtil();
        rdmKeepItConfig = new RDMKeepItConfig();
        keepItRuleEngineContext = new KeepItRuleEngineContext();
        Session session = new Session();
        Map<String,Object> outputData = new HashMap<>();
        ovtOmniItemPolicyDetailsCompletableFuture = new CompletableFuture<>();
        outputData.put(FormulaConstants.INTERNAL_DATA_NAME_OVT_OMNI_FUTURE, ovtOmniItemPolicyDetailsCompletableFuture );
        session.setOutputData(outputData);
        keepItRuleEngineContext.setSession(session);

        PowerMockito.mockStatic(BeanHelper.class);
        PowerMockito.when(BeanHelper.getBean(OVTOmniServiceHelper.class)).thenReturn(ovtOmniServiceHelper);

    }

    @Test
    public void whenReturnCenterDispositionIsRCShip(){
        ovtOmniItemPolicyDetails = new OVTOmniItemPolicyDetails();
        ovtOmniItemPolicyDetails.setReturnCentreDisposition("RC_SHIP");
        PowerMockito.when(ovtOmniServiceHelper.getItemPolicyDetailsFromFutureObject(any())).thenReturn(ovtOmniItemPolicyDetails);
        assertTrue(returnCenterDispositionCheck.runCheck(keepItRuleEngineContext));

    }


    @Test
    public void whenReturnCenterDispositionIsNotRCShip(){
        ovtOmniItemPolicyDetails = new OVTOmniItemPolicyDetails();
        ovtOmniItemPolicyDetails.setReturnCentreDisposition("Return");
        PowerMockito.when(ovtOmniServiceHelper.getItemPolicyDetailsFromFutureObject(any())).thenReturn(ovtOmniItemPolicyDetails);
        assertFalse(returnCenterDispositionCheck.runCheck(keepItRuleEngineContext));

    }
}
