package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.dto.Quantity;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class PetVetFoodQtyCheckTest {

    PetVetFoodQtyCheck petVetFoodQtyCheck;
    RDMKeepItUtil rdmKeepItUtil;
    RDMKeepItConfig rdmKeepItConfig;
    KeepItRuleEngineContext keepItRuleEngineContext ;

    @Before
    public void setup(){
        petVetFoodQtyCheck = new PetVetFoodQtyCheck();
        rdmKeepItUtil = new RDMKeepItUtil();
        rdmKeepItConfig = new RDMKeepItConfig();
        keepItRuleEngineContext = new KeepItRuleEngineContext();
        rdmKeepItConfig.setThresholdForPetVetFoodQty(3);
        petVetFoodQtyCheck.setRdmKeepItUtil(rdmKeepItUtil);
        petVetFoodQtyCheck.setRdmKeepItConfig(rdmKeepItConfig);
    }


    @Test
    public void testGetKeepItCheckName() {
        assertEquals(RDMConstants.RULE_CHECK_NAME_PET_VET_FOOD_QUANTITY,petVetFoodQtyCheck.getKeepItCheckName());
    }

    @Test
    public void whenItemQuantityGreaterThanThreshold_ReturnFalse_testRunCheck() {
        keepItRuleEngineContext.setItem(getItem("4"));
        assertFalse(petVetFoodQtyCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenItemQuantityEqualToThreshold_ReturnTrue_testRunCheck() {
        keepItRuleEngineContext.setItem(getItem("3"));
        assertTrue(petVetFoodQtyCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenItemQuantityLessThanThreshold_ReturnTrue_testRunCheck() {
        keepItRuleEngineContext.setItem(getItem("2"));
        assertTrue(petVetFoodQtyCheck.runCheck(keepItRuleEngineContext));
    }

    private BaseItem getItem(String s) {
        BaseItem item = new BaseItem();
        Quantity quantity = new Quantity();
        quantity.setMeasurementValue(s);
        quantity.setUnitOfMeasure("EACH");
        item.setQuantity(quantity);
        return item;
    }
}