package com.walmartlabs.services.rdm.component;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmartlabs.services.rdm.BaseTest;
import com.walmartlabs.services.rdm.api.impl.RDMManagerImpl;
import com.walmartlabs.services.rdm.component.incentiveruleengine.util.RdmIncentiveUtil;
import com.walmartlabs.services.rdm.component.incentiveruleengine.util.ReturnIncentiveEngine;
import com.walmartlabs.services.rdm.config.client.ReturnIncentiveConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.model.dispositionpaths.Item;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.testng.Assert.*;

@RunWith(PowerMockRunner.class)
public class IncentiveEngineTest extends BaseTest {

    public static ReturnIncentiveConfig returnIncentiveConfig;
    Integer thresholdRecoveryValueDiff = 20;
    String recoveryValueDiffBuckets = "20-30=2;30-40=3;40-50=4";

    RDMManagerImpl rdmManagerTest;

    @Autowired
    RdmIncentiveUtil rdmIncentiveUtil;

    @Autowired
    ReturnIncentiveEngine returnIncentiveEngine;

    private ObjectMapper objectMapper;

    @Before
    public void setup()
    {
        setupTest();
        returnIncentiveConfig = mock(ReturnIncentiveConfig.class);
        when(returnIncentiveConfig.getRecoveryValueDiffBuckets()).thenReturn(recoveryValueDiffBuckets);
        when(returnIncentiveConfig.getLowerThresholdRecoveryValueDiff()).thenReturn(thresholdRecoveryValueDiff);

        objectMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
                .configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);

        rdmManagerTest = new RDMManagerImpl();
    }

    @Test
    public void testCalculateReturnIncentiveAllItems1()
    {
        //Test for Return Incentive Amount expected in response
        List<DispositionInfo> infoList = prepareIncentiveEligibleInfoList();
        List<Item> items = prepareIncentiveEligibleItemsList();
        Map<String, Map<String, Object>> itemIdVsOutputSessionDataMap = prepareIncentiveEligibilityIdVsOutputSessionDataMap();
        rdmManagerTest.calculateReturnIncentiveForAllItems(infoList,items,itemIdVsOutputSessionDataMap);

        DispositionInfo dispositionInfo = infoList.get(0);
        assertEquals(dispositionInfo.getDispositionPaths().get(0).getReturnIncentive(), 2);
    }

    private Map<String, Map<String, Object>> prepareIncentiveEligibilityIdVsOutputSessionDataMap() {
        Map<String, Map<String, Object>> itemIdVsOutputSessionDataMap = new HashMap<>();
        Map<String, Object> SessionOutputData = new HashMap<>();
        SessionOutputData.put(FormulaConstants.VARIABLE_DEPARTMENT_NUMBER,"40");
        itemIdVsOutputSessionDataMap.put("859704517",SessionOutputData);
        return itemIdVsOutputSessionDataMap;
    }

    private List<Item> prepareIncentiveEligibleItemsList() {
      List<Item> itemList = new ArrayList<>();

      Item item = new Item();
      item.setRdmApiCallerName("returnOptions");
      item.setTrustCustomerToIncentive(true);
      item.setWalmartPlusCustomer(true);
      item.setItemId("859704517");

      itemList.add(item);
      return itemList;
    }

    private List<DispositionInfo> prepareIncentiveEligibleInfoList() {
        List<DispositionInfo> infoList = new ArrayList<>();
        DispositionInfo dispositionInfo = new DispositionInfo();

        List<DispositionPath> dispositionPaths = new ArrayList<>();
        DispositionPath dispositionPath1 = new DispositionPath();
        dispositionPath1.setRank(1);
        dispositionPath1.setPath("STORE");
        dispositionPath1.setKeepIt(false);
        dispositionPath1.setValue(21d);

        DispositionPath dispositionPath2 = new DispositionPath();
        dispositionPath2.setRank(2);
        dispositionPath2.setPath("CARRIER_PICKUP");
        dispositionPath2.setKeepIt(false);
        dispositionPath2.setValue(1d);

        dispositionPaths.add(dispositionPath1);
        dispositionPaths.add(dispositionPath2);

        dispositionInfo.setDispositionPaths(dispositionPaths);
        dispositionInfo.setIsDefault(false);

        infoList.add(dispositionInfo);
        return  infoList;
    }

}
