package com.walmartlabs.services.rdm.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.jupiter.api.Test;

/**
 * 
 * @author Tim Jin
 *
 */
class DataContainerTest {

    @Test
    public void requestSetTest() throws InterruptedException {
        AtomicInteger counter = new AtomicInteger();

        DataContainer<String> container = new DataContainer<>();

        int size = 100;
        List<Callable<Void>> readTasks = new ArrayList<>();
        for(int i = 0; i < size; i++){
            readTasks.add(() -> {
                container.requestSet((old) -> {
                    try{
                        TimeUnit.MILLISECONDS.sleep(500);
                    }catch (InterruptedException e){
                        Thread.currentThread().interrupt();
                    }
                    counter.incrementAndGet();
                    return old;
                });
                return null;
            });
        }

        long t = System.currentTimeMillis();
        ExecutorService executor = Executors.newFixedThreadPool(size);
        executor.invokeAll(readTasks);
        await(executor);
        long span = System.currentTimeMillis() - t;

        assertTrue(span < 50, "Should take very little time");
        assertEquals(0, counter.get(), "Should have no actual updateWithStatus");
        Thread.sleep(500);
        assertEquals(1, counter.get(), "Should have only one actual updateWithStatus");
    }

    @Test
    public void requestSetBlockingTest() throws InterruptedException {
        AtomicInteger counter = new AtomicInteger();

        DataContainer<Integer> container = new DataContainer<>();

        int size = 100;
        List<Callable<Void>> readTasks = new ArrayList<>();
        for(int i = 0; i < size; i++){
            final int id = i;
            readTasks.add(() -> {
                container.requestSetBlocking((old) -> {
                    try{
                        TimeUnit.MILLISECONDS.sleep(500);
                    }catch (InterruptedException e){
                        Thread.currentThread().interrupt();
                    }
                    counter.incrementAndGet();
                    return id;
                });
                return null;
            });
        }

        long t = System.currentTimeMillis();
        ExecutorService executor = Executors.newFixedThreadPool(size);
        executor.invokeAll(readTasks);
        await(executor);
        long span = System.currentTimeMillis() - t;

        assertEquals(1, counter.get(), "Should have only one actual updateWithStatus");
        assertTrue(span > 500 && (span - 500) < 50, "Should takes slightly longer than 0.5s");
    }

    static void await(ExecutorService executor) {
        executor.shutdown();
        try{
            if(!executor.awaitTermination(1, TimeUnit.SECONDS)){
                executor.shutdownNow();
            }
        }catch (InterruptedException ex){
            executor.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}
