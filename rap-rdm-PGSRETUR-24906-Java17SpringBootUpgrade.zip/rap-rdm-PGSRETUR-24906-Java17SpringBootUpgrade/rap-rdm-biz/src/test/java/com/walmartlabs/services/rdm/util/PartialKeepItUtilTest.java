package com.walmartlabs.services.rdm.util;

import com.walmartlabs.services.rdm.dto.dispositionpaths.common.PartialKeepIt;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static com.walmartlabs.services.rdm.util.PartialKeepItUtil.*;
import static org.junit.Assert.*;

public class PartialKeepItUtilTest {

    DispositionInfo dispositionInfo;
    BaseItem item;

    @Before
    public void setUp() {
        dispositionInfo = new DispositionInfo();
        item = new BaseItem();
        PartialKeepIt partialKeepIt = new PartialKeepIt();
        partialKeepIt.setItemPartialKeepItEligibility(true);
        item.setPartialKeepIt(partialKeepIt);

    }
    @Test
    public void testPopulatePartialKeepItEligibility_whenEligibleItem_partialKeepItAsTrue() {
        //Arrange
        dispositionInfo.setDefault(false);
        List<DispositionPath> dispositionPaths = new ArrayList<>();
        DispositionPath dispositionPath1 = new DispositionPath();
        dispositionPath1.setRank(1);
        dispositionPath1.setPath(PARTIAL_KEEP_IT_DISPOSITION_PATH);
        DispositionPath dispositionPath2 = new DispositionPath();
        dispositionPath2.setRank(2);
        dispositionPath2.setPath("FEDEX_DROP");
        dispositionPath2.setKeepIt(false);

        dispositionPaths.add(dispositionPath1);
        dispositionPaths.add(dispositionPath2);

        dispositionInfo.setDispositionPaths(dispositionPaths);

        // Act
        populatePartialKeepItEligibility(dispositionInfo, item);

        // Assert
        assertTrue(item.getPartialKeepIt().getItemPartialKeepItEligibility());
    }

    @Test
    public void testPopulatePartialKeepItEligibility_whenPktRank2_partialKeepItAsFalse() {
        //Arrange
        dispositionInfo.setDefault(false);
        List<DispositionPath> dispositionPaths = new ArrayList<>();
        DispositionPath dispositionPath1 = new DispositionPath();
        dispositionPath1.setRank(2);
        dispositionPath1.setPath(PARTIAL_KEEP_IT_DISPOSITION_PATH);
        DispositionPath dispositionPath2 = new DispositionPath();
        dispositionPath2.setRank(1);
        dispositionPath2.setPath("FEDEX_DROP");
        dispositionPath2.setKeepIt(false);

        dispositionPaths.add(dispositionPath1);
        dispositionPaths.add(dispositionPath2);

        dispositionInfo.setDispositionPaths(dispositionPaths);

        // Act
        populatePartialKeepItEligibility(dispositionInfo, item);

        // Assert
        assertFalse(item.getPartialKeepIt().getItemPartialKeepItEligibility());
    }

    @Test
    public void testPopulatePartialKeepItEligibility_whenPktNotPresent_partialKeepItAsFalse() {
        //Arrange
        dispositionInfo.setDefault(false);
        List<DispositionPath> dispositionPaths = new ArrayList<>();
        DispositionPath dispositionPath1 = new DispositionPath();
        dispositionPath1.setRank(1);
        dispositionPath1.setPath("INHOME_PICKUP");
        DispositionPath dispositionPath2 = new DispositionPath();
        dispositionPath2.setRank(2);
        dispositionPath2.setPath("FEDEX_DROP");
        dispositionPath2.setKeepIt(false);

        dispositionPaths.add(dispositionPath1);
        dispositionPaths.add(dispositionPath2);

        dispositionInfo.setDispositionPaths(dispositionPaths);

        // Act
        populatePartialKeepItEligibility(dispositionInfo, item);

        // Assert
        assertFalse(item.getPartialKeepIt().getItemPartialKeepItEligibility());
    }

    @Test
    public void testPopulatePartialKeepItEligibility_whenkeepItPath_partialKeepItAsFalse() {
        //Arrange
        dispositionInfo.setDefault(false);
        List<DispositionPath> dispositionPaths = new ArrayList<>();

        DispositionPath dispositionPath1 = new DispositionPath();
        dispositionPath1.setRank(1);
        dispositionPath1.setPath(PARTIAL_KEEP_IT_DISPOSITION_PATH);
        DispositionPath dispositionPath2 = new DispositionPath();
        dispositionPath2.setRank(2);
        dispositionPath2.setPath("FEDEX_DROP");
        dispositionPath2.setKeepIt(true);

        dispositionPaths.add(dispositionPath1);
        dispositionPaths.add(dispositionPath2);

        dispositionInfo.setDispositionPaths(dispositionPaths);

        // Act
        populatePartialKeepItEligibility(dispositionInfo, item);

        // Assert
        assertFalse(item.getPartialKeepIt().getItemPartialKeepItEligibility());
    }

    @Test
    public void testPopulatePartialKeepItEligibility_whenOnlyPktIsPresent_partialKeepItAsFalse() {
        //Arrange
        dispositionInfo.setDefault(false);
        List<DispositionPath> dispositionPaths = new ArrayList<>();

        DispositionPath dispositionPath1 = new DispositionPath();
        dispositionPath1.setRank(1);
        dispositionPath1.setPath(PARTIAL_KEEP_IT_DISPOSITION_PATH);


        dispositionPaths.add(dispositionPath1);

        dispositionInfo.setDispositionPaths(dispositionPaths);

        // Act
        populatePartialKeepItEligibility(dispositionInfo, item);

        // Assert
        assertFalse(item.getPartialKeepIt().getItemPartialKeepItEligibility());
    }
    @Test
    public void testPopulatePartialKeepItEligibility_whenDispositionInfoEmpty_partialKeepItAsFalse() {

        // Act
        populatePartialKeepItEligibility(dispositionInfo, item);

        // Assert
        assertFalse(item.getPartialKeepIt().getItemPartialKeepItEligibility());
    }

    @Test
    public void testPopulatePartialKeepItEligibility_whenDispositionPathsNull_partialKeepItAsFalse() {
        //Arrange
        dispositionInfo.setDefault(false);

        // Act
        populatePartialKeepItEligibility(dispositionInfo, item);

        // Assert
        assertFalse(item.getPartialKeepIt().getItemPartialKeepItEligibility());
    }

    @Test
    public void testPopulatePartialKeepItEligibility_whenDispositionInfoNull_partialKeepItAsFalse() {
        //Arrange
        dispositionInfo = null;

        // Act
        populatePartialKeepItEligibility(dispositionInfo, item);

        // Assert
        assertFalse(item.getPartialKeepIt().getItemPartialKeepItEligibility());
    }

    @Test
    public void testRemovePartialKeepItFromResponse_whenPktPresent_removeFromThePaths() {
        dispositionInfo.setDefault(false);
        List<DispositionPath> dispositionPaths = new ArrayList<>();
        DispositionPath dispositionPath1 = new DispositionPath();
        dispositionPath1.setRank(1);
        dispositionPath1.setPath(PARTIAL_KEEP_IT_DISPOSITION_PATH);
        DispositionPath dispositionPath2 = new DispositionPath();
        dispositionPath2.setRank(2);
        dispositionPath2.setPath("FEDEX_DROP");
        dispositionPath2.setKeepIt(false);

        dispositionPaths.add(dispositionPath1);
        dispositionPaths.add(dispositionPath2);

        dispositionInfo.setDispositionPaths(dispositionPaths);

        removePartialKeepItFromDispositionPath(dispositionInfo);

        assertFalse(dispositionInfo.getDispositionPaths().contains(PARTIAL_KEEP_IT_DISPOSITION_PATH));

    }

    @Test
    public void testRemovePartialKeepItFromResponse_whenPktNotPresent_removeFromThePaths() {
        dispositionInfo.setDefault(false);
        List<DispositionPath> dispositionPaths = new ArrayList<>();
        DispositionPath dispositionPath2 = new DispositionPath();
        dispositionPath2.setRank(1);
        dispositionPath2.setPath("FEDEX_DROP");
        dispositionPath2.setKeepIt(false);

        dispositionPaths.add(dispositionPath2);

        dispositionInfo.setDispositionPaths(dispositionPaths);

        removePartialKeepItFromDispositionPath(dispositionInfo);

        assertFalse(dispositionInfo.getDispositionPaths().contains(PARTIAL_KEEP_IT_DISPOSITION_PATH));

    }

    @Test
    public void testRemovePartialKeepItFromResponse_whenDispositionPathsAreEmpty_removeFromThePaths() {
        dispositionInfo.setDefault(false);
        List<DispositionPath> dispositionPaths = new ArrayList<>();
        dispositionInfo.setDispositionPaths(dispositionPaths);

        removePartialKeepItFromDispositionPath(dispositionInfo);

        assertFalse(dispositionInfo.getDispositionPaths().contains(PARTIAL_KEEP_IT_DISPOSITION_PATH));

    }

}