package com.walmartlabs.services.rdm.rank.assigner.impl;

import com.walmartlabs.services.rdm.model.dispositionpaths.common.*;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;


class FinalizeRanksAndReturnMethodsTest {

    /*
     Input: RANK: 1. INHOME, 3. STORE, 4.MAIL, 6.FEDEX_DROP
     Output: RANK: 1. INHOME, 2. STORE, 3.MAIL, 4.FEDEX_DROP
     */

    @Test
    void whenSingleItemRequestDefaultFalse_arrangeInIncreasingOrder_testAssignRanks() {
        List<DispositionInfo> allItemsDispositionInfoList = new ArrayList<>();
        DispositionInfo dispositionInfo1 = new DispositionInfo();
        List<DispositionPath> dispositionPaths1 = dispositionInfo1.getDispositionPaths();

        DispositionPath inhome = new DispositionPath();
        inhome.setRank(1);
        inhome.setPath("INHOME_PICKUP");
        DispositionPath store = new DispositionPath();
        store.setRank(2);
        store.setPath("STORE");
        DispositionPath mail = new DispositionPath();
        mail.setRank(3);
        mail.setPath("MAIL");
        DispositionPath fedex_drop = new DispositionPath();
        fedex_drop.setRank(6);
        fedex_drop.setPath("FEDEX_DROP");
        dispositionPaths1.add(inhome);
        dispositionPaths1.add(store);
        dispositionPaths1.add(mail);
        dispositionPaths1.add(fedex_drop);

        dispositionInfo1.setDispositionPaths(dispositionPaths1);
        dispositionInfo1.setIsDefault(false);
        allItemsDispositionInfoList.add(dispositionInfo1);

        FinalizeRanksAndReturnMethods finalizeRanksAndReturnMethods = new FinalizeRanksAndReturnMethods();
        finalizeRanksAndReturnMethods.setAssignReturnMethodsForDefaultCase(new AssignReturnModesFromReturnEligibility());
        finalizeRanksAndReturnMethods.setAssignFinalRanksForNonDefaultCase(new AssignContinuousRank());
        finalizeRanksAndReturnMethods.assignRanks(allItemsDispositionInfoList);

        dispositionInfo1 = allItemsDispositionInfoList.get(0);
        Map<String,Integer> expectedOrderedListOfDispositionPaths = new HashMap<>();
        expectedOrderedListOfDispositionPaths.put("INHOME_PICKUP", 1);
        expectedOrderedListOfDispositionPaths.put("STORE",2);
        expectedOrderedListOfDispositionPaths.put("MAIL",3);
        expectedOrderedListOfDispositionPaths.put("FEDEX_DROP",4);

        for(DispositionPath dispositionPath:dispositionInfo1.getDispositionPaths()){
            assertEquals(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()),dispositionPath.getRank());
        }
    }

        /*
     Input: RANK:  3. STORE,1. INHOME, 4.MAIL, 6.FEDEX_DROP
     Output: RANK: 1. INHOME, 2. STORE, 3.MAIL, 4.FEDEX_DROP
     */

    @Test
    void whenSingleItemRequestDefaultFalseNonContinuous_arrangeInIncreasingOrder_testAssignRanks() {
        List<DispositionInfo> allItemsDispositionInfoList = new ArrayList<>();
        DispositionInfo dispositionInfo1 = new DispositionInfo();
        List<DispositionPath> dispositionPaths1 = dispositionInfo1.getDispositionPaths();

        DispositionPath inhome = new DispositionPath();
        inhome.setRank(1);
        inhome.setPath("INHOME_PICKUP");
        DispositionPath store = new DispositionPath();
        store.setRank(2);
        store.setPath("STORE");
        DispositionPath mail = new DispositionPath();
        mail.setRank(3);
        mail.setPath("MAIL");
        DispositionPath fedex_drop = new DispositionPath();
        fedex_drop.setRank(6);
        fedex_drop.setPath("FEDEX_DROP");
        dispositionPaths1.add(store);
        dispositionPaths1.add(inhome);
        dispositionPaths1.add(mail);
        dispositionPaths1.add(fedex_drop);

        dispositionInfo1.setDispositionPaths(dispositionPaths1);
        dispositionInfo1.setIsDefault(false);
        allItemsDispositionInfoList.add(dispositionInfo1);

        FinalizeRanksAndReturnMethods finalizeRanksAndReturnMethods = new FinalizeRanksAndReturnMethods();
        finalizeRanksAndReturnMethods.setAssignReturnMethodsForDefaultCase(new AssignReturnModesFromReturnEligibility());
        finalizeRanksAndReturnMethods.setAssignFinalRanksForNonDefaultCase(new AssignContinuousRank());
        finalizeRanksAndReturnMethods.assignRanks(allItemsDispositionInfoList);

        dispositionInfo1 = allItemsDispositionInfoList.get(0);

        Map<String,Integer> expectedOrderedListOfDispositionPaths = new HashMap<>();
        expectedOrderedListOfDispositionPaths.put("INHOME_PICKUP", 1);
        expectedOrderedListOfDispositionPaths.put("STORE",2);
        expectedOrderedListOfDispositionPaths.put("MAIL",3);
        expectedOrderedListOfDispositionPaths.put("FEDEX_DROP",4);

        for(DispositionPath dispositionPath:dispositionInfo1.getDispositionPaths()){
            assertEquals(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()),dispositionPath.getRank());
        }
    }

      /*
     Input: RANK:  1. STORE,1. INHOME, 1.MAIL, 1.FEDEX_DROP
     Output: RANK: 1. STORE,1. INHOME, 1.MAIL, 1.FEDEX_DROP
     */

   /* @Test
    void whenDefaultTrueReturnModesHasLessModes_arrangeInIncreasingOrder_testAssignRanks() {
        List<DispositionInfo> allItemsDispositionInfoList = new ArrayList<>();
        DispositionInfo dispositionInfo1 = new DispositionInfo();
        List<DispositionPath> dispositionPaths1 = dispositionInfo1.getDispositionPaths();

        DispositionPath inhome = new DispositionPath();
        inhome.setRank(1);
        inhome.setPath("INHOME_PICKUP");
        DispositionPath store = new DispositionPath();
        store.setRank(1);
        store.setPath("STORE");
        DispositionPath mail = new DispositionPath();
        mail.setRank(1);
        mail.setPath("MAIL");
        DispositionPath fedex_drop = new DispositionPath();
        fedex_drop.setRank(1);
        fedex_drop.setPath("FEDEX_DROP");
        dispositionPaths1.add(store);
        dispositionPaths1.add(inhome);
        dispositionPaths1.add(mail);
        dispositionPaths1.add(fedex_drop);

        dispositionInfo1.setDispositionPaths(dispositionPaths1);
        dispositionInfo1.setIsDefault(true);


        BaseItem item = new BaseItem();
        ReturnModesInfo returnModesInfo = new ReturnModesInfo();
        List<ReturnMode> returnModeList = getReturnModeList(new ArrayList<String>(Arrays.asList("STORE", "MAIL")));
        returnModesInfo.setReturnModes(returnModeList);
        item.setReturnModesInfo(returnModesInfo);
        dispositionInfo1.setItem(item);
        allItemsDispositionInfoList.add(dispositionInfo1);

        FinalizeRanksAndReturnMethods finalizeRanksAndReturnMethods = new FinalizeRanksAndReturnMethods();
        finalizeRanksAndReturnMethods.setAssignReturnMethodsForDefaultCase(new AssignReturnModesFromReturnEligibility());
        finalizeRanksAndReturnMethods.setAssignFinalRanksForNonDefaultCase(new AssignContinuousRank());
        finalizeRanksAndReturnMethods.assignRanks(allItemsDispositionInfoList);

        dispositionInfo1 = allItemsDispositionInfoList.get(0);

        Map<String,Integer> expectedOrderedListOfDispositionPaths = new HashMap<>();
        expectedOrderedListOfDispositionPaths.put("STORE",1);
        expectedOrderedListOfDispositionPaths.put("MAIL",2);

        for(DispositionPath dispositionPath:dispositionInfo1.getDispositionPaths()){
            assertEquals(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()),dispositionPath.getRank());
        }
    }*/

    private List<ReturnMode> getReturnModeList(ArrayList<String> returnModeNames) {
        List<ReturnMode> returnModeList = new ArrayList<>();
        for(String returnModeName: returnModeNames){
            ReturnMode returnMode = new ReturnMode();
            returnMode.setName(returnModeName);
            returnMode.setReturnAllowed(true);
            returnMode.setReplacementAllowed(true);

            returnModeList.add(returnMode);
        }

        return returnModeList;
    }
}