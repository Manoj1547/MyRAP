package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.config.client.ConfigManager;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.dto.Quantity;
import com.walmartlabs.services.rdm.model.dispositionpaths.Item;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ConfigManager.class})
public class TotalLineRefundAmountCheckTest {
    TotalLineRefundAmountCheck totalLineRefundAmountCheck;
    RDMKeepItUtil rdmKeepItUtil;
    RDMKeepItConfig rdmKeepItConfig;
    KeepItRuleEngineContext keepItRuleEngineContext ;
    ConfigManager configManager;
    Item item ;

    @Before
    public void setup(){
        totalLineRefundAmountCheck = new TotalLineRefundAmountCheck();
        rdmKeepItUtil = new RDMKeepItUtil();
        rdmKeepItConfig = new RDMKeepItConfig();
        keepItRuleEngineContext = new KeepItRuleEngineContext();
        rdmKeepItConfig.setTotalLineRefundCheckKeepItDisabled(false);
        rdmKeepItConfig.setKeepItLineRefundThresholdAmount(40.0);
        totalLineRefundAmountCheck.setRdmKeepItUtil(rdmKeepItUtil);

        configManager = mock(ConfigManager.class);
        PowerMockito.mockStatic(ConfigManager.class);
        PowerMockito.when(ConfigManager.getInstance()).thenReturn(configManager);

        when(ConfigManager.getRdmKeepItConfig()).thenReturn(rdmKeepItConfig);
        item = new Item();
    }


    @Test
    public void testGetKeepItCheckName() {
        assertEquals(RDMConstants.RULE_CHECK_NAME_TOTAL_LINE_REFUND_AMOUNT_CHECK,totalLineRefundAmountCheck.getKeepItCheckName());
    }

    @Test
    public void whenThresholdEqualsThanLineRefund_ReturnFalse_testItemTotalRefundCheck() {
        item.setLineRefundAmount(40.0);
        keepItRuleEngineContext.setItem(item);
        assertEquals(false,totalLineRefundAmountCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenThresholdGreaterThanLineRefund_ReturnFalse_testItemTotalRefundCheck() {
        item.setLineRefundAmount(25.0);
        keepItRuleEngineContext.setItem(item);
        assertEquals(false,totalLineRefundAmountCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenThresholdLessThanLineRefund_ReturnTrue_testItemTotalRefundCheck() {
        item.setLineRefundAmount(50.0);
        keepItRuleEngineContext.setItem(item);
        assertEquals(true,totalLineRefundAmountCheck.runCheck(keepItRuleEngineContext));
    }

}
