package com.walmartlabs.services.rdm.component.ovt.service.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmartlabs.services.rdm.BaseTest;
import com.walmartlabs.services.rdm.component.ovt.model.request.ItemPolicyDetailsRequest;
import com.walmartlabs.services.rdm.component.ovt.model.request.Payload;
import com.walmartlabs.services.rdm.component.ovt.model.request.ReturnTermFilter;
import com.walmartlabs.services.rdm.component.ovt.model.response.OVTOmniItemPolicyDetails;
import com.walmartlabs.services.rdm.config.client.OVTServiceConfig;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import com.walmartlabs.services.rdm.util.cache.CacheManager;
import com.walmartlabs.services.rdm.util.cache.CacheRole;
import org.apache.commons.codec.digest.DigestUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.modules.junit4.PowerMockRunner;

import java.io.File;
import java.io.IOException;
import java.util.*;

import static com.walmartlabs.services.rdm.RDMConstants.*;
import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.*;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertNull;

@RunWith(PowerMockRunner.class)
public class OVTOmniHttpClientTest extends BaseTest {

    public static OVTServiceConfig ovtServiceConfig;
    public CacheManager cacheManager = new CacheManager();
    private ObjectMapper objectMapper;

    @Before
    public void setup() {
        setupTest();
        ovtServiceConfig = mock(OVTServiceConfig.class);
        when(ovtServiceConfig.getOvtServiceCachingEnabled()).thenReturn(false);
        when(ovtServiceConfig.getTimeOut()).thenReturn(3000);
        when(ovtServiceConfig.getServiceEndpoint()).thenReturn("/ovt-services/v2/return-terms/omni");
        when(ovtServiceConfig.getServiceBaseHostUrl()).thenReturn("http://returns.ovt.stg.walmart.com");
        when(ovtServiceConfig.getServiceName()).thenReturn("rap-ovt-services");
        when(ovtServiceConfig.getServiceEnv()).thenReturn("stg");
        when(ovtServiceConfig.getAccept()).thenReturn("application/json");
        when(ovtServiceConfig.getDefaultRegion()).thenReturn("US");
        Set<String> returnTermTypes = new HashSet<>();
        returnTermTypes.add("RETURN_AGREEMENT");
        returnTermTypes.add("RECALL_AGREEMENT");
        when(ovtServiceConfig.getReturnTermTypes()).thenReturn(returnTermTypes);
        when(ovtServiceConfig.getServiceConsumerId()).thenReturn("025f5b71-9926-443f-9250-d3d325885b98");

        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        cacheManager = new CacheManager();

    }

    /**
     * {
     *     "payload": {
     *         "returnTermFilters": [
     *             {
     *                 "vendorNo": "538678",
     *                 "departmentNo": "79",
     *                 "contractNo": "0",
     *                 "tenantIds": [
     *                     "WM_OMNI",
     *                     "WM.COM"
     *                 ],
     *                 "region": "US",
     *                 "items": [
     *                     "241971909"
     *                 ],
     *                 "returnTermTypes": [
     *                     "RETURN_AGREEMENT",
     *                     "RECALL_AGREEMENT"
     *                 ]
     *             }
     *         ]
     *     }
     * }
     */
    @Test
    public void ovtOmniHttpClient_WhenWithoutCacheStoreRequest_GivesNonNullResponse() throws Exception {
        ItemPolicyDetailsRequest itemPolicyDetailsRequest = prepareItemPolicyDetailsRequest(false);

        OVTOmniHttpClient ovtOmniHttpClient = PowerMockito.spy(new OVTOmniHttpClient());
        String responseString = readTestFile().get("KEY1");
        PowerMockito.doReturn(responseString).when(ovtOmniHttpClient,"post", anyString(), anyString(), anyString(), anyMap(),
                anyInt(), any());


        ovtOmniHttpClient.setOvtServiceConfig(ovtServiceConfig);

        OVTOmniItemPolicyDetails itemPolicyDetailsResponse = ovtOmniHttpClient.getOVTOmniItemPolicyDetails(itemPolicyDetailsRequest);
        assertNotNull(itemPolicyDetailsResponse);
        assertNotNull(itemPolicyDetailsResponse.getClaimFiledBy());
        assertNotNull(itemPolicyDetailsResponse.getClaimPercent());
        assertNotNull(itemPolicyDetailsResponse.getHandlingFeeAmount());
        assertNotNull(itemPolicyDetailsResponse.getStoreDisposition());
    }


    @Test
    public void ovtOmniHttpClient_WhenWithCacheStoreRequest_GivesNonNullResponse() throws Exception {
        when(ovtServiceConfig.getOvtServiceCachingEnabled()).thenReturn(true);
        ItemPolicyDetailsRequest itemPolicyDetailsRequest = prepareItemPolicyDetailsRequest(false);

        OVTOmniHttpClient ovtOmniHttpClient = PowerMockito.spy(new OVTOmniHttpClient());
        String responseString = readTestFile().get("KEY1");
        PowerMockito.doReturn(responseString).when(ovtOmniHttpClient,"post",anyString(),anyString(),anyString(),anyMap(),
                anyInt(), any());

        cacheManager.put(DigestUtils.sha256Hex(objectMapper.writeValueAsString(itemPolicyDetailsRequest)), responseString, CacheRole.OVT);
        ovtOmniHttpClient.setOvtServiceConfig(ovtServiceConfig);
        ovtOmniHttpClient.setCacheManager(cacheManager);

        OVTOmniItemPolicyDetails itemPolicyDetailsResponse = ovtOmniHttpClient.getOVTOmniItemPolicyDetails(itemPolicyDetailsRequest);
        assertNotNull(itemPolicyDetailsResponse);
        assertNotNull(itemPolicyDetailsResponse.getClaimFiledBy());
        assertNotNull(itemPolicyDetailsResponse.getClaimPercent());
        assertNotNull(itemPolicyDetailsResponse.getHandlingFeeAmount());
        assertNotNull(itemPolicyDetailsResponse.getStoreDisposition());
    }

    @Test
    public void ovtOmniHttpClient_WhenWithCacheDotcomRequest_GivesNonNullResponse() throws Exception {
        when(ovtServiceConfig.getOvtServiceCachingEnabled()).thenReturn(true);
        ItemPolicyDetailsRequest itemPolicyDetailsRequest = prepareItemPolicyDetailsRequest(true);

        OVTOmniHttpClient ovtOmniHttpClient = PowerMockito.spy(new OVTOmniHttpClient());
        String responseString = readTestFile().get("KEY5");
        PowerMockito.doReturn(responseString).when(ovtOmniHttpClient,"post", anyString(), anyString(), anyString(), anyMap(),
                anyInt(), any());

        cacheManager.put(DigestUtils.sha256Hex(objectMapper.writeValueAsString(itemPolicyDetailsRequest)), responseString, CacheRole.OVT);
        ovtOmniHttpClient.setOvtServiceConfig(ovtServiceConfig);
        ovtOmniHttpClient.setCacheManager(cacheManager);
        OVTOmniItemPolicyDetails itemPolicyDetailsResponse = ovtOmniHttpClient.getOVTOmniItemPolicyDetails(itemPolicyDetailsRequest);
        assertNotNull(itemPolicyDetailsResponse);
        assertNotNull(itemPolicyDetailsResponse.getClaimFiledBy());
        assertNotNull(itemPolicyDetailsResponse.getClaimPercent());
        assertNotNull(itemPolicyDetailsResponse.getHandlingFeeAmount());
        assertNotNull(itemPolicyDetailsResponse.getStoreDisposition());
    }

    @Test
    public void ovtOmniHttpClient_WhenWithoutCacheDotcomRequest_GivesNonNullResponse() throws Exception {
        ItemPolicyDetailsRequest itemPolicyDetailsRequest = prepareItemPolicyDetailsRequest(true);

        OVTOmniHttpClient ovtOmniHttpClient = PowerMockito.spy(new OVTOmniHttpClient());
        String responseString = readTestFile().get("KEY5");
        PowerMockito.doReturn(responseString).when(ovtOmniHttpClient,"post", anyString(), anyString(), anyString(), anyMap(),
                anyInt(), any());

        ovtOmniHttpClient.setOvtServiceConfig(ovtServiceConfig);
        OVTOmniItemPolicyDetails itemPolicyDetailsResponse = ovtOmniHttpClient.getOVTOmniItemPolicyDetails(itemPolicyDetailsRequest);
        assertNotNull(itemPolicyDetailsResponse);
        assertNotNull(itemPolicyDetailsResponse.getClaimFiledBy());
        assertNotNull(itemPolicyDetailsResponse.getClaimPercent());
        assertNotNull(itemPolicyDetailsResponse.getHandlingFeeAmount());
        assertNotNull(itemPolicyDetailsResponse.getStoreDisposition());
    }

    @Test
    public void ovtOmniHttpClient_WhenWithoutCacheAllAttributesMissingInResponse_GivesNullAttributesInResponse() throws Exception {
        ItemPolicyDetailsRequest itemPolicyDetailsRequest = prepareItemPolicyDetailsRequest(true);

        OVTOmniHttpClient ovtOmniHttpClient = PowerMockito.spy(new OVTOmniHttpClient());
        Map<String,String> testCases = readTestFile();
        String responseString = testCases.get("KEY2");
        PowerMockito.doReturn(responseString).when(ovtOmniHttpClient,"post", anyString(), anyString(), anyString(), anyMap(),
                anyInt(), any());

        ovtOmniHttpClient.setOvtServiceConfig(ovtServiceConfig);
        OVTOmniItemPolicyDetails itemPolicyDetailsResponse = ovtOmniHttpClient.getOVTOmniItemPolicyDetails(itemPolicyDetailsRequest);
        assertNotNull(itemPolicyDetailsResponse);
        assertNull(itemPolicyDetailsResponse.getClaimFiledBy());
        assertNotNull(itemPolicyDetailsResponse.getClaimPercent());
        assertNotNull(itemPolicyDetailsResponse.getHandlingFeeAmount());
        assertNull(itemPolicyDetailsResponse.getStoreDisposition());
    }

    @Test
    public void ovtOmniHttpClient_WhenClientThrowsServiceException_MethodThrowsRdmException() throws Exception {
        ItemPolicyDetailsRequest itemPolicyDetailsRequest = prepareItemPolicyDetailsRequest(true);

        OVTOmniHttpClient ovtOmniHttpClient = PowerMockito.spy(new OVTOmniHttpClient());
        String msg = "";
        PowerMockito.doThrow(new ServiceException(msg)).when(ovtOmniHttpClient,"post", anyString(), anyString(), anyString(), anyMap(),
                anyInt(), any());

        ovtOmniHttpClient.setOvtServiceConfig(ovtServiceConfig);
        RDMException itemPolicyDetailsException = assertThrows(RDMException.class, () -> {
            ovtOmniHttpClient.getOVTOmniItemPolicyDetails(itemPolicyDetailsRequest);
        });
    }

    @Test
    public void ovtOmniHttpClient_WhenClientThrowsJsonProcessingException_MethodThrowsRdmException() throws Exception {
        ItemPolicyDetailsRequest itemPolicyDetailsRequest = prepareItemPolicyDetailsRequest(true);

        OVTOmniHttpClient ovtOmniHttpClient = PowerMockito.spy(new OVTOmniHttpClient());
        Map<String,String> testCases = readTestFile();
        String responseString = testCases.get("KEY4");
        PowerMockito.doReturn(responseString).when(ovtOmniHttpClient,"post", anyString(), anyString(), anyString(), anyMap(),
                anyInt(), any());

        ovtOmniHttpClient.setOvtServiceConfig(ovtServiceConfig);
        RDMException itemPolicyDetailsException = assertThrows(RDMException.class, () -> {
            ovtOmniHttpClient.getOVTOmniItemPolicyDetails(itemPolicyDetailsRequest);
        });
    }

    @Test
    public void ovtOmniHttpClient_WhenClientThrowsException_MethodThrowsRdmException() throws Exception {
        ItemPolicyDetailsRequest itemPolicyDetailsRequest = prepareItemPolicyDetailsRequest(true);

        OVTOmniHttpClient ovtOmniHttpClient = PowerMockito.spy(new OVTOmniHttpClient());

        ovtOmniHttpClient.setOvtServiceConfig(ovtServiceConfig);
        RDMException itemPolicyDetailsException = assertThrows(RDMException.class, () -> {
            ovtOmniHttpClient.getOVTOmniItemPolicyDetails(itemPolicyDetailsRequest);
        });
    }

    @Test
    public void ovtOmniHttpClient_WhenResponseIsNull_MethodThrowsRdmException() throws Exception {
        ItemPolicyDetailsRequest itemPolicyDetailsRequest = prepareItemPolicyDetailsRequest(true);

        OVTOmniHttpClient ovtOmniHttpClient = PowerMockito.spy(new OVTOmniHttpClient());
        String responseString = "{\"status\":\"OK\",\"header\":{\"headerAttributes\":{}},\"errors\":[]}";
        PowerMockito.doReturn(responseString).when(ovtOmniHttpClient,"post", anyString(), anyString(), anyString(), anyMap(),
                anyInt(), any());

        ovtOmniHttpClient.setOvtServiceConfig(ovtServiceConfig);
        RDMException itemPolicyDetailsException = assertThrows(RDMException.class, () -> {
            ovtOmniHttpClient.getOVTOmniItemPolicyDetails(itemPolicyDetailsRequest);
        });
    }

    private Map<String, String> readTestFile() throws IOException {
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("ovt_omni_response.json").getFile());
        return new ObjectMapper().readValue(file,new TypeReference<Map<String, String>>() {});
    }

    private ItemPolicyDetailsRequest prepareItemPolicyDetailsRequest(boolean isDotcomOrder) {
        ItemPolicyDetailsRequest itemPolicyDetailsRequest = new ItemPolicyDetailsRequest();
        Payload payload = new Payload();
        List<ReturnTermFilter> returnTermFilterList = new ArrayList<>();
        ReturnTermFilter returnTermFilter = new ReturnTermFilter();
        returnTermFilter.setContractNo("0");
        returnTermFilter.setRegion("US");
        returnTermFilter.setDepartmentNo("79");
        returnTermFilter.setVendorNo("538678");

        Set<String> itemIds = new HashSet<>();
        itemIds.add("241971909");
        returnTermFilter.setItems(itemIds);

        Set<String> tenantIds = new HashSet<>();
        tenantIds.add(TENANTID_OMNI);
        if(isDotcomOrder ? tenantIds.add(TENANTID_DOTCOM) : tenantIds.add(TENANTID_STORE));
        returnTermFilter.setTenantIds(tenantIds);

        Set<String> returnTermTypes = ovtServiceConfig.getReturnTermTypes();
        returnTermFilter.setReturnTermTypes(returnTermTypes);

        returnTermFilterList.add(returnTermFilter);
        payload.setReturnTermFilters(returnTermFilterList);
        itemPolicyDetailsRequest.setPayload(payload);
        return  itemPolicyDetailsRequest;
    }

}
