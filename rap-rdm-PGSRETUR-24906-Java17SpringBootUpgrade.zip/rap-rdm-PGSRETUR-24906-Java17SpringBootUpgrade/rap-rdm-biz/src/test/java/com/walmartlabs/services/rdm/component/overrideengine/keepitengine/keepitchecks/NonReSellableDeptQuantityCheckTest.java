package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.dto.Quantity;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class NonReSellableDeptQuantityCheckTest {

    NonReSellableDeptQuantityCheck nonReSellableDeptQuantityCheck = new NonReSellableDeptQuantityCheck();
    RDMKeepItUtil rdmKeepItUtil;
    RDMKeepItConfig rdmKeepItConfig;
    KeepItRuleEngineContext keepItRuleEngineContext ;

    @Before
    public void setup(){
        rdmKeepItUtil = new RDMKeepItUtil();
        rdmKeepItConfig = new RDMKeepItConfig();
        keepItRuleEngineContext = new KeepItRuleEngineContext();
        rdmKeepItConfig.setKeepItThresholdNonResellableCount(3);
        nonReSellableDeptQuantityCheck.setRdmKeepItUtil(rdmKeepItUtil);
        nonReSellableDeptQuantityCheck.setRdmKeepItConfig(rdmKeepItConfig);
    }


    @Test
    public void testGetKeepItCheckName() {
        assertEquals(RDMConstants.RULE_CHECK_NAME_NON_RESELLABLE_DEPT_QUANTITY_CHECK,nonReSellableDeptQuantityCheck.getKeepItCheckName());
    }

    @Test
    public void whenItemQuantityGreaterThanThreshold_ReturnFalse_testRunCheck() {
        keepItRuleEngineContext.setItem(getItem("4"));
        assertFalse(nonReSellableDeptQuantityCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenItemQuantityEqualToThreshold_ReturnTrue_testRunCheck() {
        keepItRuleEngineContext.setItem(getItem("3"));
        assertTrue(nonReSellableDeptQuantityCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenItemQuantityLessThanThreshold_ReturnTrue_testRunCheck() {
        keepItRuleEngineContext.setItem(getItem("2"));
        assertFalse(nonReSellableDeptQuantityCheck.runCheck(keepItRuleEngineContext));
    }

    private BaseItem getItem(String s) {
        BaseItem item = new BaseItem();
        Quantity quantity = new Quantity();
        quantity.setMeasurementValue(s);
        quantity.setUnitOfMeasure("EACH");
        item.setQuantity(quantity);
        return item;
    }
}