package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitrules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.dto.Quantity;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.KeepItInfo;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;


public class VisionRxItemRuleTest {

    VisionRxItemRule visionRxItemRule;
    KeepItRuleEngineContext keepItRuleEngineContext ;

    @Before
    public void setup(){
        visionRxItemRule = new VisionRxItemRule();
        keepItRuleEngineContext = new KeepItRuleEngineContext();
    }


    @Test
    public void testGetKeepItCheckName() {
        assertEquals(RDMConstants.RULE_NAME_VISION_RX_ITEM, visionRxItemRule.getRuleName());
    }

    @Test
    public void shouldUpdateKeepItFalseForEveryPath() {
        keepItRuleEngineContext.setDispositionInfo(getDispositionPathInfo());
        keepItRuleEngineContext.setItem(getItem("4",true));
        visionRxItemRule.applyRuleDecision(keepItRuleEngineContext);
        List<DispositionPath> dispositionPaths = keepItRuleEngineContext.getDispositionInfo().getDispositionPaths();
        for(DispositionPath dispositionPath: dispositionPaths){
            assertFalse(dispositionPath.getKeepIt());
        }
    }

    private BaseItem getItem(String s,boolean b) {
        BaseItem item = new BaseItem();
        Quantity quantity = new Quantity();
        quantity.setMeasurementValue(s);
        quantity.setUnitOfMeasure("EACH");
        item.setQuantity(quantity);
        item.setItemId("1234");
        KeepItInfo keepItInfo = new KeepItInfo();
        keepItInfo.setTrustCustomerToKeepIt(b);
        item.setKeepItInfo(keepItInfo);
        return item;
    }

    private DispositionInfo getDispositionPathInfo() {
        DispositionInfo dispositionInfo1 = new DispositionInfo();
        List<DispositionPath> dispositionPaths1 = dispositionInfo1.getDispositionPaths();

        DispositionPath inhome = new DispositionPath();
        inhome.setRank(2);
        inhome.setPath("INHOME_PICKUP");
        DispositionPath store = new DispositionPath();
        store.setRank(1);
        store.setPath("STORE");
        DispositionPath mail = new DispositionPath();
        mail.setRank(3);
        mail.setPath("MAIL");
        DispositionPath carrier_pickup = new DispositionPath();
        carrier_pickup.setRank(4);
        carrier_pickup.setPath("CARRIER_PICKUP");
        DispositionPath fedex_drop = new DispositionPath();
        fedex_drop.setRank(5);
        fedex_drop.setPath("FEDEX_DROP");
        dispositionPaths1.add(inhome);
        dispositionPaths1.add(store);
        dispositionPaths1.add(mail);
        dispositionPaths1.add(carrier_pickup);
        dispositionPaths1.add(fedex_drop);

        dispositionInfo1.setDispositionPaths(dispositionPaths1);
        dispositionInfo1.setIsDefault(false);
        return dispositionInfo1;
    }
}