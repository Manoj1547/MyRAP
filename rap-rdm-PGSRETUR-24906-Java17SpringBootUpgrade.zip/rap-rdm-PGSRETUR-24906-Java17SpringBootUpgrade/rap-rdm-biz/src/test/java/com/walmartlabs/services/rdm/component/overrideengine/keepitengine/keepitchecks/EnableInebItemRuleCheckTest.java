package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import org.junit.Before;
import org.junit.Test;
import org.testng.Assert;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class EnableInebItemRuleCheckTest {

    EnableInebItemRuleCheck enableInebItemRuleCheck = new EnableInebItemRuleCheck();
    RDMKeepItConfig rdmKeepItConfig;
    KeepItRuleEngineContext keepItRuleEngineContext ;

    @Before
    public void setUp() {
        rdmKeepItConfig = new RDMKeepItConfig();
        rdmKeepItConfig.setInebRuleCheck(true);
        keepItRuleEngineContext = new KeepItRuleEngineContext();
        enableInebItemRuleCheck.setRdmKeepItConfig(rdmKeepItConfig);
    }

    @Test
    public void testGetName() {
        Assert.assertEquals(enableInebItemRuleCheck.getKeepItCheckName(), RDMConstants.ENABLE_INEB_ITEM_RULE_CHECK);
    }

    @Test
    public void testRunCheck(){
        assertTrue(enableInebItemRuleCheck.runCheck(keepItRuleEngineContext));
    }
}