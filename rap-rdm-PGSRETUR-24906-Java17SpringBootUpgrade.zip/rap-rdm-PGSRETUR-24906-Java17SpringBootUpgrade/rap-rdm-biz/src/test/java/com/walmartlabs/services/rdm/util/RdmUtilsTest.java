package com.walmartlabs.services.rdm.util;

import com.walmartlabs.services.rdm.model.SellerType;
import com.walmartlabs.services.rdm.model.dispositionpaths.Item;
import org.junit.Before;
import org.junit.Test;

import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;

import static org.junit.Assert.*;

public class RdmUtilsTest {

    BaseItem item;
    @Before
    public void setUp() throws Exception {
        item = new Item();
    }

    @Test
    public void orderNoPresent_returnTrue_testIsDotcomOrder() {
        item.setOrderNo("1234");
        assertTrue(RdmUtils.isDotcomOrder(item));
    }

    @Test
    public void orderNoPresent_returnFalse_testIsDotcomOrder() {
        assertFalse(RdmUtils.isDotcomOrder(item));
    }

    @Test
    public void seller3P_return1PSeller_testGetSellerTypeFromRequest() {
        item.setSellerType(SellerType.MP);
        assertEquals(SellerType.WM,RdmUtils.getSellerTypeFromRequest(item));
    }

    @Test
    public void sellerWFS_returnWFSSeller_testGetSellerTypeFromRequest() {
        item.setSellerType(SellerType.WFS);
        assertEquals(SellerType.WFS,RdmUtils.getSellerTypeFromRequest(item));
    }

    @Test
    public void seller1P_return1PSeller_testGetSellerTypeFromRequest() {
        item.setSellerType(SellerType.WM);
        assertEquals(SellerType.WM,RdmUtils.getSellerTypeFromRequest(item));
    }

    @Test
    public void sellerNull_return1PSeller_testGetSellerTypeFromRequest() {
        assertEquals(SellerType.WM,RdmUtils.getSellerTypeFromRequest(item));
    }
}