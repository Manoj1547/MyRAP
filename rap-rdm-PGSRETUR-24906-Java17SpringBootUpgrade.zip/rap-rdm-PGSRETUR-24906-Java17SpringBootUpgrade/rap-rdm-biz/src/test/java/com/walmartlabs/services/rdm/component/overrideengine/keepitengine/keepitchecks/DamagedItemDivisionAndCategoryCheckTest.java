package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.iqs.model.response.*;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.dto.Quantity;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.Session;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import io.strati.libs.forklift.org.apache.solr.common.util.Hash;
import javolution.io.Struct;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.junit.Assert.*;

public class DamagedItemDivisionAndCategoryCheckTest {

    DamagedItemDivisionAndCategoryCheck damagedItemDivisionAndCategoryCheck;
    RDMKeepItUtil rdmKeepItUtil;
    RDMKeepItConfig rdmKeepItConfig;
    KeepItRuleEngineContext keepItRuleEngineContext ;
    ObjectMapper objectMapper;
    String divisionWiseKeepItRuleJson = "{\"division\":[{\"divisionName\":\"L0\",\"category\":[{\"categoryName\":\"HOME\",\"enabled\":true,\"threshold\":{\"price\":15,\"quantity\":4}},{\"categoryName\":\"HARDLINES\",\"enabled\":false,\"threshold\":{\"price\":10,\"quantity\":3}}]}]}";
    String derivedPath = "{\"L0\":{\"name\":\"HOME\",\"id\":\"50000\"},\"L1\":{\"name\":\"ELECTRONICS\",\"id\":\"50700\"},\"L2\":{\"name\":\"TVS AUDIO AND VIDEO\",\"id\":\"1050999\"},\"L3\":{\"name\":\"TVS AND PROJECTORS\",\"id\":\"1051086\"},\"L4\":{\"name\":\"VIZIO TVS\",\"id\":\"1051172\"}}";

    @Before
    public void setup(){
        damagedItemDivisionAndCategoryCheck = new DamagedItemDivisionAndCategoryCheck();
        keepItRuleEngineContext = new KeepItRuleEngineContext();
        objectMapper = new ObjectMapper();
        rdmKeepItConfig = new RDMKeepItConfig();
        rdmKeepItConfig.setEnableDamagedItemRule(true);
        rdmKeepItConfig.setIsConfigUpdated(Boolean.FALSE);
        rdmKeepItUtil = new RDMKeepItUtil();
        rdmKeepItUtil.setRdmKeepItConfig(rdmKeepItConfig);
        rdmKeepItUtil.setObjectMapper(objectMapper);
        damagedItemDivisionAndCategoryCheck.setRdmKeepItUtil(rdmKeepItUtil);
    }


    @Test
    public void testGetKeepItCheckName() {
        assertEquals(RDMConstants.RULE_CHECK_NAME_DAMAGED_ITEM_DIVISION_AND_CATEGORY,damagedItemDivisionAndCategoryCheck.getKeepItCheckName());
    }

    @Test
    public void whenCCMOnDivisionWiseRuleNotPresent_returnFalse_testRunCheck() {
        keepItRuleEngineContext.setDispositionInfo(getDispositionPathInfo());
        keepItRuleEngineContext.setItem(getItem(null));
        keepItRuleEngineContext.setSession(getSession(derivedPath));
        assertFalse( damagedItemDivisionAndCategoryCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenCCMOnDerivedAttributePathNotPresent_returnFalse_testRunCheck() {
        rdmKeepItConfig.setDamagedItemKeepItRuleDivisionWise(divisionWiseKeepItRuleJson);
        keepItRuleEngineContext.setDispositionInfo(getDispositionPathInfo());
        keepItRuleEngineContext.setItem(getItem(null));
        keepItRuleEngineContext.setSession(getSession(null));
        assertFalse( damagedItemDivisionAndCategoryCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenCCMAndDerivedAttributePathPresent_returnTrue_testRunCheck() {
        rdmKeepItConfig.setDamagedItemKeepItRuleDivisionWise(divisionWiseKeepItRuleJson);
        keepItRuleEngineContext.setDispositionInfo(getDispositionPathInfo());
        keepItRuleEngineContext.setItem(getItem(null));
        keepItRuleEngineContext.setSession(getSession(derivedPath));
        assertTrue( damagedItemDivisionAndCategoryCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenItemLevelNotPresentInDerivedPath_returnFalse_testRunCheck() {
        rdmKeepItConfig.setDamagedItemKeepItRuleDivisionWise(divisionWiseKeepItRuleJson);
        keepItRuleEngineContext.setDispositionInfo(getDispositionPathInfo());
        keepItRuleEngineContext.setItem(getItem(null));
        keepItRuleEngineContext.setSession(getSession("{\"L0\":{\"name\":\"HARDLINES\",\"id\":\"50000\"}}"));
        assertFalse(damagedItemDivisionAndCategoryCheck.runCheck(keepItRuleEngineContext));
    }

    private BaseItem getItem(String s) {
        BaseItem item = new BaseItem();
        Quantity quantity = new Quantity();
        quantity.setMeasurementValue("2");
        quantity.setUnitOfMeasure("EACH");
        item.setQuantity(quantity);
        item.setItemCondition(s);
        item.setItemId("1234");
        return item;
    }

    private DispositionInfo getDispositionPathInfo() {
        DispositionInfo dispositionInfo1 = new DispositionInfo();
        List<DispositionPath> dispositionPaths1 = dispositionInfo1.getDispositionPaths();

        DispositionPath inhome = new DispositionPath();
        inhome.setRank(2);
        inhome.setPath("INHOME_PICKUP");
        DispositionPath store = new DispositionPath();
        store.setRank(1);
        store.setPath("STORE");
        DispositionPath mail = new DispositionPath();
        mail.setRank(3);
        mail.setPath("MAIL");
        DispositionPath carrier_pickup = new DispositionPath();
        carrier_pickup.setRank(4);
        carrier_pickup.setPath("CARRIER_PICKUP");
        DispositionPath fedex_drop = new DispositionPath();
        fedex_drop.setRank(5);
        fedex_drop.setPath("FEDEX_DROP");
        dispositionPaths1.add(inhome);
        dispositionPaths1.add(store);
        dispositionPaths1.add(mail);
        dispositionPaths1.add(carrier_pickup);
        dispositionPaths1.add(fedex_drop);

        dispositionInfo1.setDispositionPaths(dispositionPaths1);
        dispositionInfo1.setIsDefault(false);
        return dispositionInfo1;
    }

    private Session getSession(String path) {
        GetItemDetailsResponse getItemDetailsResponse = new GetItemDetailsResponse();
        Product product = new Product();
        DerivedAttributes derivedAttributes = new DerivedAttributes();
        R2D2Hierarchy r2D2Hierarchy = new R2D2Hierarchy();
        Value value = new Value();
        value.setPath(path);
        List<Value> valueList = new ArrayList<>();
        valueList.add(value);
        r2D2Hierarchy.setValues(valueList);
        derivedAttributes.setR2D2Hierarchy(r2D2Hierarchy);
        product.setDerivedAttributes(derivedAttributes);
        getItemDetailsResponse.setProduct(product);
        CompletableFuture<GetItemDetailsResponse> itemDetailsResponse = CompletableFuture.completedFuture(getItemDetailsResponse);
        Map<String, Object> outputData = new HashMap<>();
        outputData.put(FormulaConstants.INTERNAL_DATA_NAME_IQSRDM_FUTURE, itemDetailsResponse);
        Session session = new Session();
        session.setOutputData(outputData);
        return session;
    }

}