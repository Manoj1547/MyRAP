package com.walmartlabs.services.rdm.formula.impl.java.eligibility;

import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.config.client.RestockEligibilityConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.formula.impl.java.productType.ProductTypeData;
import com.walmartlabs.services.rdm.model.CategoryType;
import com.walmartlabs.services.rdm.model.dispositionpaths.Item;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.SellerPreference;
import com.walmartlabs.services.rdm.model.formula.Formula;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.walmartlabs.services.rdm.RDMConstants.RESTOCK;
import static org.junit.Assert.*;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class WFSRestockEligibilityTest {
    WFSRestockEligibility wfsRestockEligibility;

    ProductTypeData productTypeData;
    @Before
    public void setUp(){
        wfsRestockEligibility = new WFSRestockEligibility();
        RDMKeepItConfig rdmKeepItConfig = new RDMKeepItConfig();
        rdmKeepItConfig.setNonResellableDeptList(new ArrayList<>());
        rdmKeepItConfig.getNonResellableDeptList().add("96");
        wfsRestockEligibility.setRdmKeepItConfig(rdmKeepItConfig);

        RestockEligibilityConfig restockEligibilityConfig = new RestockEligibilityConfig();
        restockEligibilityConfig.setRestrictedProductTypes(new ArrayList<>());
        restockEligibilityConfig.getRestrictedProductTypes().add("Alcohol");
        restockEligibilityConfig.setRetailThreshold(30);
        restockEligibilityConfig.setRestrictedItemConditions(new ArrayList<>());
        restockEligibilityConfig.getRestrictedItemConditions().add("Open");
        wfsRestockEligibility.setRestockEligibilityConfig(restockEligibilityConfig);

        productTypeData = mock(ProductTypeData.class);
        wfsRestockEligibility.setProductTypeData(productTypeData);
    }

    @Test
    public void nonResellableDept_restockNotEligible_testEval() throws VariableMissingException {
        Map<String, Object> inputData = new HashMap<>();
        BaseItem item = new Item();
        item.setDepartmentNo("96");
        inputData.put(FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM, item);
        assertFalse((Boolean) wfsRestockEligibility.eval(new Formula(), inputData));
    }

    @Test
    public void restrictedProductType_restockNotEligible_testEval() throws VariableMissingException {
        Map<String, Object> inputData = new HashMap<>();
        BaseItem item = new Item();
        item.setProductType("Alcohol");
        inputData.put(FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM, item);
        assertFalse((Boolean) wfsRestockEligibility.eval(new Formula(), inputData));
    }

    @Test
    public void sellerPreferenceNotRestock_restockNotEligible_testEval() throws VariableMissingException {
        Map<String, Object> inputData = new HashMap<>();
        BaseItem item = new Item();
        item.setSellerPreference(new SellerPreference());
        item.getSellerPreference().setSellableItemDisposition("RTV");
        inputData.put(FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM, item);
        assertFalse((Boolean) wfsRestockEligibility.eval(new Formula(), inputData));
    }

    @Test
    public void productCategoryA_restockNotEligible_testEval() throws VariableMissingException {
        Map<String, Object> inputData = new HashMap<>();
        BaseItem item = new Item();
        item.setSellerPreference(new SellerPreference());
        item.getSellerPreference().setSellableItemDisposition(RESTOCK);
        inputData.put(FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM, item);
        when(productTypeData.getProductTypeCategory(anyString())).thenReturn(CategoryType.A);
        assertFalse((Boolean) wfsRestockEligibility.eval(new Formula(), inputData));
    }

    @Test
    public void productCategoryB_restockNotEligible_testEval() throws VariableMissingException {
        Map<String, Object> inputData = new HashMap<>();
        BaseItem item = new Item();
        item.setSellerPreference(new SellerPreference());
        item.getSellerPreference().setSellableItemDisposition(RESTOCK);
        inputData.put(FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM, item);
        when(productTypeData.getProductTypeCategory(anyString())).thenReturn(CategoryType.B);
        assertFalse((Boolean) wfsRestockEligibility.eval(new Formula(), inputData));
    }

    @Test
    public void productCategoryC_restockEligible_testEval() throws VariableMissingException {
        Map<String, Object> inputData = new HashMap<>();
        BaseItem item = new Item();
        item.setSellerPreference(new SellerPreference());
        item.getSellerPreference().setSellableItemDisposition(RESTOCK);
        inputData.put(FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM, item);
        when(productTypeData.getProductTypeCategory(anyString())).thenReturn(CategoryType.C);
        assertTrue((Boolean) wfsRestockEligibility.eval(new Formula(), inputData));
    }

    @Test
    public void productCategoryNull_restockNotEligible_testEval() throws VariableMissingException {
        Map<String, Object> inputData = new HashMap<>();
        BaseItem item = new Item();
        item.setSellerPreference(new SellerPreference());
        item.getSellerPreference().setSellableItemDisposition(RESTOCK);
        inputData.put(FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM, item);
        when(productTypeData.getProductTypeCategory(anyString())).thenReturn(null);
        assertFalse((Boolean) wfsRestockEligibility.eval(new Formula(), inputData));
    }
}