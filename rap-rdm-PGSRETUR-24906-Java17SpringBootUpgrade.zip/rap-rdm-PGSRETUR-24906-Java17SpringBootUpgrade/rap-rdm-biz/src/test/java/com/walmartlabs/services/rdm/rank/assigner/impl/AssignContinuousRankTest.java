package com.walmartlabs.services.rdm.rank.assigner.impl;

import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class AssignContinuousRankTest {

   /*
     Input: RANK: 1. INHOME, 3. STORE, 4.MAIL, 6.FEDEX_DROP
     Output: RANK: 1. INHOME, 2. STORE, 3.MAIL, 4.FEDEX_DROP
     */

    @Test
    void whenIncreasingOrderDiscontinuous_arrangeInIncreasingOrder_testAssignFinalRanks() {
        DispositionInfo dispositionInfo = new DispositionInfo();
        List<DispositionPath> dispositionPaths = dispositionInfo.getDispositionPaths();

        DispositionPath inhome = new DispositionPath();
        inhome.setRank(1);
        inhome.setPath("INHOME_PICKUP");
        DispositionPath store = new DispositionPath();
        store.setRank(2);
        store.setPath("STORE");
        DispositionPath mail = new DispositionPath();
        mail.setRank(3);
        mail.setPath("MAIL");
        DispositionPath fedex_drop = new DispositionPath();
        fedex_drop.setRank(6);
        fedex_drop.setPath("FEDEX_DROP");
        dispositionPaths.add(inhome);
        dispositionPaths.add(store);
        dispositionPaths.add(mail);
        dispositionPaths.add(fedex_drop);

        dispositionInfo.setDispositionPaths(dispositionPaths);
        dispositionInfo.setIsDefault(false);

        AssignContinuousRank assignContinuousRank = new AssignContinuousRank();
        assignContinuousRank.assignFinalRanks(dispositionInfo);

        Map<String,Integer> expectedOrderedListOfDispositionPaths = new HashMap<>();
        expectedOrderedListOfDispositionPaths.put("INHOME_PICKUP", 1);
        expectedOrderedListOfDispositionPaths.put("STORE",2);
        expectedOrderedListOfDispositionPaths.put("MAIL",3);
        expectedOrderedListOfDispositionPaths.put("FEDEX_DROP",4);

        for(DispositionPath dispositionPath:dispositionInfo.getDispositionPaths()){
            assertEquals(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()),dispositionPath.getRank());
        }
    }

        /*
     Input: RANK:  3. STORE,1. INHOME, 4.MAIL, 6.FEDEX_DROP
     Output: RANK: 1. INHOME, 2. STORE, 3.MAIL, 4.FEDEX_DROP
     */

    @Test
    void whenNonIncreasingOrderDiscontinuous_arrangeInIncreasingOrder_testAssignFinalRanks() {
        DispositionInfo dispositionInfo = new DispositionInfo();
        List<DispositionPath> dispositionPaths = dispositionInfo.getDispositionPaths();

        DispositionPath inhome = new DispositionPath();
        inhome.setRank(1);
        inhome.setPath("INHOME_PICKUP");
        DispositionPath store = new DispositionPath();
        store.setRank(2);
        store.setPath("STORE");
        DispositionPath mail = new DispositionPath();
        mail.setRank(3);
        mail.setPath("MAIL");
        DispositionPath fedex_drop = new DispositionPath();
        fedex_drop.setRank(6);
        fedex_drop.setPath("FEDEX_DROP");
        dispositionPaths.add(store);
        dispositionPaths.add(inhome);
        dispositionPaths.add(mail);
        dispositionPaths.add(fedex_drop);

        dispositionInfo.setDispositionPaths(dispositionPaths);
        dispositionInfo.setIsDefault(false);

        AssignContinuousRank assignContinuousRank = new AssignContinuousRank();
        assignContinuousRank.assignFinalRanks(dispositionInfo);

        Map<String,Integer> expectedOrderedListOfDispositionPaths = new HashMap<>();
        expectedOrderedListOfDispositionPaths.put("INHOME_PICKUP", 1);
        expectedOrderedListOfDispositionPaths.put("STORE",2);
        expectedOrderedListOfDispositionPaths.put("MAIL",3);
        expectedOrderedListOfDispositionPaths.put("FEDEX_DROP",4);

        for(DispositionPath dispositionPath:dispositionInfo.getDispositionPaths()){
            assertEquals(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()),dispositionPath.getRank());
        }
    }

    @Test
    void whenDispositionPathsNull_doNothing_testAssignFinalRanks() {
        DispositionInfo dispositionInfo = new DispositionInfo();
        dispositionInfo.setDispositionPaths(null);
        dispositionInfo.setIsDefault(false);

        AssignContinuousRank assignContinuousRank = new AssignContinuousRank();
        assignContinuousRank.assignFinalRanks(dispositionInfo);

        assertNull(dispositionInfo.getDispositionPaths());
    }

    @Test
    void whenDispositionInfoNull_doNothing_testAssignFinalRanks() {
        DispositionInfo dispositionInfo = null;
        AssignContinuousRank assignContinuousRank = new AssignContinuousRank();
        assignContinuousRank.assignFinalRanks(dispositionInfo);

        assertNull(dispositionInfo);
    }
}