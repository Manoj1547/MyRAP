package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmart.services.common.model.money.CurrencyUnitEnum;
import com.walmart.services.common.model.money.MoneyType;
import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.Session;
import com.walmartlabs.services.rdm.model.dispositionpaths.Item;
import org.junit.Before;
import org.junit.Test;


import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;
import static org.junit.Assert.assertFalse;

public class PetVetFoodPriceThresholdCheckTest {

    PetVetFoodPriceThresholdCheck petVetFoodPriceThresholdCheck;
    RDMKeepItUtil rdmKeepItUtil;
    RDMKeepItConfig rdmKeepItConfig;
    KeepItRuleEngineContext keepItRuleEngineContext ;

    @Before
    public void setup(){
        petVetFoodPriceThresholdCheck = new PetVetFoodPriceThresholdCheck();
        rdmKeepItUtil = new RDMKeepItUtil();
        rdmKeepItConfig = new RDMKeepItConfig();
        keepItRuleEngineContext = new KeepItRuleEngineContext();
        Session session = new Session();
        Map<String,Object> outputData = new HashMap<>();
        outputData.put(FormulaConstants.VARIABLE_IS_DOTCOM, true);
        session.setOutputData(outputData);
        keepItRuleEngineContext.setSession(session);
        rdmKeepItConfig.setThresholdForPetVetPrice("3.5");
        rdmKeepItConfig.setKeepItItemDetailsFromRequestEnabled(true);
        petVetFoodPriceThresholdCheck.setRdmKeepItUtil(rdmKeepItUtil);
        petVetFoodPriceThresholdCheck.setRdmKeepItConfig(rdmKeepItConfig);
    }


    @Test
    public void getKeepItCheckName() {
        assertEquals(RDMConstants.RULE_CHECK_NAME_PET_VET_FOOD_PRICE,petVetFoodPriceThresholdCheck.getKeepItCheckName());
    }

    @Test
    public void whenItemQuantityGreaterThanThreshold_ReturnFalse_testRunCheck() {
        keepItRuleEngineContext.setItem(getItem(BigDecimal.valueOf(4.5)));
        assertFalse(petVetFoodPriceThresholdCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenItemQuantityEqualToThreshold_ReturnTrue_testRunCheck() {
        keepItRuleEngineContext.setItem(getItem(BigDecimal.valueOf(3.5)));
        assertTrue(petVetFoodPriceThresholdCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenItemQuantityLessThanThreshold_ReturnTrue_testRunCheck() {
        keepItRuleEngineContext.setItem(getItem(BigDecimal.valueOf(2.5)));
        assertTrue(petVetFoodPriceThresholdCheck.runCheck(keepItRuleEngineContext));
    }

    private Item getItem(BigDecimal b) {
        Item item = new Item();
        MoneyType unitPrice = new MoneyType(b,CurrencyUnitEnum.USD);
        item.setUnitPrice(unitPrice);
        return item;
    }
}