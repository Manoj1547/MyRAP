package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.KeepItInfo;
import org.junit.Before;
import org.junit.Test;
import org.testng.Assert;

import java.util.HashMap;
import java.util.Map;

public class PhotoItemCheckTest {
    PhotoItemCheck photoItemCheck = new PhotoItemCheck();
    RDMKeepItUtil rdmKeepItUtil;
    KeepItRuleEngineContext keepItRuleEngineContext;

    RDMKeepItConfig rdmKeepItConfig;

    @Before
    public void setUp() {
        rdmKeepItUtil = new RDMKeepItUtil();
        keepItRuleEngineContext = new KeepItRuleEngineContext();
        photoItemCheck.setRdmKeepItUtil(rdmKeepItUtil);
        rdmKeepItConfig = new RDMKeepItConfig();
        rdmKeepItConfig.setPhotoItemRuleEnabled(Boolean.TRUE);
        photoItemCheck.setRdmKeepItConfig(rdmKeepItConfig);
    }

    @Test
    public void testGetName() {
        Assert.assertEquals(photoItemCheck.getKeepItCheckName(),RDMConstants.RULE_CHECK_NAME_PHOTO_ITEM);
    }

    @Test
    public void testRunCheck() {
        BaseItem item = getItem();
        keepItRuleEngineContext.setItem(item);
        Assert.assertTrue( photoItemCheck.runCheck(keepItRuleEngineContext));
    }

    private BaseItem getItem() {
        BaseItem item = new BaseItem();
        Map<String,String> customAttributes = new HashMap<>();
        customAttributes.put(RDMConstants.IS_PHOTO_ORDER_LINE,RDMConstants.YES);
        KeepItInfo keepItInfo = new KeepItInfo();
        keepItInfo.setTrustCustomerToKeepIt(true);
        item.setKeepItInfo(keepItInfo);
        item.setItemCustomAttributes(customAttributes);
        return item;
    }
}
