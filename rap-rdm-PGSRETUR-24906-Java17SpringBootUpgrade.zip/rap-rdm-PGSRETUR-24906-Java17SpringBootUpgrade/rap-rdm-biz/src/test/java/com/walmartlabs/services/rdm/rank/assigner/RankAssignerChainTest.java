package com.walmartlabs.services.rdm.rank.assigner;

import com.walmartlabs.services.rdm.config.client.RankAssignerChainConfig;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import com.walmartlabs.services.rdm.rank.assigner.impl.FinalizeRanksAndReturnMethods;
import com.walmartlabs.services.rdm.rank.assigner.impl.EliminateOtherPickupForInhomeCustomers;
import com.walmartlabs.services.rdm.rank.assigner.impl.RankInhomeOneForInhomeCustomers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

@RunWith(MockitoJUnitRunner.class)
class RankAssignerChainTest {

    @Mock
    RankAssignerChainConfig rankAssignerChainConfig;
    RankAssigner rankAssigner;

    @BeforeEach
    void setup(){
        MockitoAnnotations.initMocks(this);
        Mockito.when(rankAssignerChainConfig.getRankAssignerChainInSequence()).thenReturn(Arrays.asList("rankInhomeOneForInhomeCustomers","eliminateOtherPickupForInhomeCustomers","assignContinuousRanks"));
        Mockito.when(rankAssignerChainConfig.getEliminatedPickupModesForInhome()).thenReturn(Arrays.asList("CARRIER_PICKUP","LMD"));

        rankAssigner = new RankInhomeOneForInhomeCustomers();
        EliminateOtherPickupForInhomeCustomers eliminateOtherPickupForInhomeCustomers = new EliminateOtherPickupForInhomeCustomers();
        eliminateOtherPickupForInhomeCustomers.setRankAssignerChainConfig(rankAssignerChainConfig);
        rankAssigner.setNextRankAssigner(eliminateOtherPickupForInhomeCustomers);
        RankAssigner rankAssigner2 = eliminateOtherPickupForInhomeCustomers;
        RankAssigner rankAssigner3 = new FinalizeRanksAndReturnMethods();
        rankAssigner2.setNextRankAssigner(rankAssigner3);
    }
    /*
   Input: RANK: 1. INHOME, 2. LMD, 3. STORE, 4.MAIL, 5.CARRIER_PICKUP, 6.FEDEX_DROP
   Output: RANK: 1. INHOME, 2. STORE, 3.MAIL, 4.FEDEX_DROP
  */
   /* @Test
    void whenSingleItemRequestContainsInhomeDefaultFalse_removeOtherPickupModesRanksInhomeOne_testExecuteRankAssigner() {
        List<DispositionInfo> allItemsDispositionInfoList = new ArrayList<>();
        DispositionInfo dispositionInfo1 = new DispositionInfo();
        List<DispositionPath> dispositionPaths1 = dispositionInfo1.getDispositionPaths();

        DispositionPath inhome = new DispositionPath();
        inhome.setRank(1);
        inhome.setPath("INHOME");
        DispositionPath lmd = new DispositionPath();
        lmd.setRank(2);
        lmd.setPath("LMD");
        DispositionPath store = new DispositionPath();
        store.setRank(3);
        store.setPath("STORE");
        DispositionPath mail = new DispositionPath();
        mail.setRank(4);
        mail.setPath("MAIL");
        DispositionPath carrier_pickup = new DispositionPath();
        carrier_pickup.setRank(5);
        carrier_pickup.setPath("CARRIER_PICKUP");
        DispositionPath fedex_drop = new DispositionPath();
        fedex_drop.setRank(6);
        fedex_drop.setPath("FEDEX_DROP");
        dispositionPaths1.add(inhome);
        dispositionPaths1.add(lmd);
        dispositionPaths1.add(store);
        dispositionPaths1.add(mail);
        dispositionPaths1.add(carrier_pickup);
        dispositionPaths1.add(fedex_drop);

        dispositionInfo1.setDispositionPaths(dispositionPaths1);
        dispositionInfo1.setIsDefault(false);
        allItemsDispositionInfoList.add(dispositionInfo1);

        rankAssigner.executeRankAssigner(allItemsDispositionInfoList);

        dispositionInfo1 = allItemsDispositionInfoList.get(0);

        Map<String,Integer> expectedOrderedListOfDispositionPaths = new HashMap<>();
        expectedOrderedListOfDispositionPaths.put("INHOME_PICKUP", 1);
        expectedOrderedListOfDispositionPaths.put("STORE",2);
        expectedOrderedListOfDispositionPaths.put("MAIL",3);
        expectedOrderedListOfDispositionPaths.put("FEDEX_DROP",4);

        for(DispositionPath dispositionPath:dispositionInfo1.getDispositionPaths()){
            assertEquals(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()),dispositionPath.getRank());
        }
    }*/


    /*
  Input: RANK: 1. INHOME, 2. LMD, 3. STORE, 4.MAIL, 5.CARRIER_PICKUP, 6.FEDEX_DROP
  Output: RANK: 1. INHOME, 2. STORE, 3.MAIL, 4.FEDEX_DROP
 */
/*    @Test
    void whenSingleItemRequestContainsInhomeDefaultFalse_removeOtherPickupModesRanksInhomeOne_testBuildChain() {
        List<DispositionInfo> allItemsDispositionInfoList = new ArrayList<>();
        DispositionInfo dispositionInfo1 = new DispositionInfo();
        List<DispositionPath> dispositionPaths1 = dispositionInfo1.getDispositionPaths();

        DispositionPath inhome = new DispositionPath();
        inhome.setRank(1);
        inhome.setPath("INHOME");
        DispositionPath lmd = new DispositionPath();
        lmd.setRank(2);
        lmd.setPath("LMD");
        DispositionPath store = new DispositionPath();
        store.setRank(3);
        store.setPath("STORE");
        DispositionPath mail = new DispositionPath();
        mail.setRank(4);
        mail.setPath("MAIL");
        DispositionPath carrier_pickup = new DispositionPath();
        carrier_pickup.setRank(5);
        carrier_pickup.setPath("CARRIER_PICKUP");
        DispositionPath fedex_drop = new DispositionPath();
        fedex_drop.setRank(6);
        fedex_drop.setPath("FEDEX_DROP");
        dispositionPaths1.add(inhome);
        dispositionPaths1.add(lmd);
        dispositionPaths1.add(store);
        dispositionPaths1.add(mail);
        dispositionPaths1.add(carrier_pickup);
        dispositionPaths1.add(fedex_drop);

        dispositionInfo1.setDispositionPaths(dispositionPaths1);
        dispositionInfo1.setIsDefault(false);
        allItemsDispositionInfoList.add(dispositionInfo1);

        RankAssignerChain rankAssignerChain = new RankAssignerChain();
        rankAssignerChain.executeRankAssigner(allItemsDispositionInfoList);

        dispositionInfo1 = allItemsDispositionInfoList.get(0);
        Map<String,Integer> expectedOrderedListOfDispositionPaths = new HashMap<>();
        expectedOrderedListOfDispositionPaths.put("INHOME_PICKUP", 1);
        expectedOrderedListOfDispositionPaths.put("STORE",2);
        expectedOrderedListOfDispositionPaths.put("MAIL",3);
        expectedOrderedListOfDispositionPaths.put("FEDEX_DROP",4);

        for(DispositionPath dispositionPath:dispositionInfo1.getDispositionPaths()){
            assertEquals(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()),dispositionPath.getRank());
        }
    }*/
}