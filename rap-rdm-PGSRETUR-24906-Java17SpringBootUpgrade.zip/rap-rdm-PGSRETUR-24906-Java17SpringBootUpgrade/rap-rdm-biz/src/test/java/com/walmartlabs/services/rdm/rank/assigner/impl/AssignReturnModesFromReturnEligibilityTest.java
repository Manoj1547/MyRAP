package com.walmartlabs.services.rdm.rank.assigner.impl;

import com.walmartlabs.services.rdm.config.client.RankAssignerChainConfig;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.*;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class AssignReturnModesFromReturnEligibilityTest {

    private RankAssignerChainConfig rankAssignerChainConfig = new RankAssignerChainConfig();

    @Test
    void whenDispositionPathsIsNull_thenDoNothing_assignFinalReturnModes() {
        DispositionInfo dispositionInfo = new DispositionInfo();
        BaseItem item = new BaseItem();
        List<ReturnMode> returnModeList = getReturnModeList(new ArrayList<String>(Arrays.asList("STORE", "MAIL")));
        ReturnModesInfo returnModesInfo = new ReturnModesInfo();

        returnModesInfo.setReturnModes(returnModeList);
        item.setReturnModesInfo(returnModesInfo);
        dispositionInfo.setDispositionPaths(null);
        dispositionInfo.setItem(item);

        AssignReturnModesFromReturnEligibility assignReturnModesFromReturnEligibility = new AssignReturnModesFromReturnEligibility();
        assignReturnModesFromReturnEligibility.assignFinalReturnModes(dispositionInfo);
        assertNull(dispositionInfo.getDispositionPaths());
    }

    @Test
    void whenReturnModesListIsNull_thenDoNothing_assignFinalReturnModes() {
        DispositionInfo dispositionInfo = new DispositionInfo();
        List<DispositionPath> dispositionPaths = new ArrayList<>();
        BaseItem item = new BaseItem();
        ReturnModesInfo returnModesInfo = new ReturnModesInfo();
        DispositionPath store = new DispositionPath();
        store.setRank(1);
        store.setPath("STORE");
        dispositionPaths.add(store);

        returnModesInfo.setReturnModes(null);
        item.setReturnModesInfo(returnModesInfo);
        dispositionInfo.setDispositionPaths(dispositionPaths);
        dispositionInfo.setItem(item);

        AssignReturnModesFromReturnEligibility assignReturnModesFromReturnEligibility = new AssignReturnModesFromReturnEligibility();
        assignReturnModesFromReturnEligibility.assignFinalReturnModes(dispositionInfo);

        Map<String,Integer> expectedOrderedListOfDispositionPaths = new HashMap<>();
        expectedOrderedListOfDispositionPaths.put("STORE",1);


        for(DispositionPath dispositionPath:dispositionInfo.getDispositionPaths()){
            assertEquals(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()),dispositionPath.getRank());
        }

    }

    @Test
    void whenReturnModesInfoIsNull_thenDoNothing_assignFinalReturnModes() {
        DispositionInfo dispositionInfo = new DispositionInfo();
        List<DispositionPath> dispositionPaths = new ArrayList<>();
        BaseItem item = new BaseItem();

        DispositionPath store = new DispositionPath();
        store.setRank(1);
        store.setPath("STORE");
        dispositionPaths.add(store);

        item.setReturnModesInfo(null);
        dispositionInfo.setDispositionPaths(dispositionPaths);
        dispositionInfo.setItem(item);

        AssignReturnModesFromReturnEligibility assignReturnModesFromReturnEligibility = new AssignReturnModesFromReturnEligibility();
        assignReturnModesFromReturnEligibility.assignFinalReturnModes(dispositionInfo);
        Map<String,Integer> expectedOrderedListOfDispositionPaths = new HashMap<>();
        expectedOrderedListOfDispositionPaths.put("STORE",1);

        for(DispositionPath dispositionPath:dispositionInfo.getDispositionPaths()){
            assertEquals(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()),dispositionPath.getRank());
        }

    }

    @Test
    void whenItemIsNull_thenDoNothing_assignFinalReturnModes() {
        DispositionInfo dispositionInfo = new DispositionInfo();
        List<DispositionPath> dispositionPaths = new ArrayList<>();

        DispositionPath store = new DispositionPath();
        store.setRank(1);
        store.setPath("STORE");
        DispositionPath mail = new DispositionPath();
        mail.setRank(1);
        mail.setPath("MAIL");
        dispositionPaths.add(store);
        dispositionPaths.add(mail);

        dispositionInfo.setDispositionPaths(dispositionPaths);

        AssignReturnModesFromReturnEligibility assignReturnModesFromReturnEligibility = new AssignReturnModesFromReturnEligibility();
        assignReturnModesFromReturnEligibility.assignFinalReturnModes(dispositionInfo);

        Map<String,Integer> expectedOrderedListOfDispositionPaths = new HashMap<>();
        expectedOrderedListOfDispositionPaths.put("STORE",1);
        expectedOrderedListOfDispositionPaths.put("MAIL",1);

        for(DispositionPath dispositionPath:dispositionInfo.getDispositionPaths()){
            assertEquals(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()),dispositionPath.getRank());
        }

    }


    /*@Test
    void whenReturnModesEligibleAreMore_thenDoNothing_assignFinalReturnModes() {
        DispositionInfo dispositionInfo = new DispositionInfo();
        List<DispositionPath> dispositionPaths = new ArrayList<>();
        BaseItem item = new BaseItem();
        ReturnModesInfo returnModesInfo = new ReturnModesInfo();
        List<ReturnMode> returnModeList = getReturnModeList(new ArrayList<String>(Arrays.asList("STORE", "MAIL")));

        DispositionPath store = new DispositionPath();
        store.setRank(1);
        store.setPath("STORE");
        dispositionPaths.add(store);

        returnModesInfo.setReturnModes(returnModeList);
        item.setReturnModesInfo(returnModesInfo);
        dispositionInfo.setDispositionPaths(dispositionPaths);
        dispositionInfo.setItem(item);

        AssignReturnModesFromReturnEligibility assignReturnModesFromReturnEligibility = new AssignReturnModesFromReturnEligibility();
        assignReturnModesFromReturnEligibility.assignFinalReturnModes(dispositionInfo);

        Map<String,Integer> expectedOrderedListOfDispositionPaths = new HashMap<>();
        expectedOrderedListOfDispositionPaths.put("STORE",1);

        for(DispositionPath dispositionPath:dispositionInfo.getDispositionPaths()){
            assertEquals(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()),dispositionPath.getRank());
        }

    }*/

    /*@Test
    void whenReturnModesEligibleAreSame_thenDoNothing_assignFinalReturnModes() {
        DispositionInfo dispositionInfo = new DispositionInfo();
        List<DispositionPath> dispositionPaths = new ArrayList<>();
        BaseItem item = new BaseItem();
        ReturnModesInfo returnModesInfo = new ReturnModesInfo();
        List<ReturnMode> returnModeList = getReturnModeList(new ArrayList<String>(Arrays.asList("STORE", "MAIL")));

        DispositionPath store = new DispositionPath();
        store.setRank(1);
        store.setPath("STORE");
        DispositionPath mail = new DispositionPath();
        mail.setRank(1);
        mail.setPath("MAIL");
        dispositionPaths.add(store);
        dispositionPaths.add(mail);

        returnModesInfo.setReturnModes(returnModeList);
        item.setReturnModesInfo(returnModesInfo);
        dispositionInfo.setDispositionPaths(dispositionPaths);
        dispositionInfo.setItem(item);

        AssignReturnModesFromReturnEligibility assignReturnModesFromReturnEligibility = new AssignReturnModesFromReturnEligibility();
        assignReturnModesFromReturnEligibility.assignFinalReturnModes(dispositionInfo);

        Map<String,Integer> expectedOrderedListOfDispositionPaths = new HashMap<>();
        expectedOrderedListOfDispositionPaths.put("STORE",1);
        expectedOrderedListOfDispositionPaths.put("MAIL",1);

        for(DispositionPath dispositionPath:dispositionInfo.getDispositionPaths()){
            assertEquals(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()),dispositionPath.getRank());
        }

    }*/

    @Test
    void whenReturnModesEligibleAreLess_thenRemoveNonEligibleReturnModes_assignFinalReturnModes() {
        DispositionInfo dispositionInfo = new DispositionInfo();
        List<DispositionPath> dispositionPaths = new ArrayList<>();
        BaseItem item = new BaseItem();
        ReturnModesInfo returnModesInfo = new ReturnModesInfo();
        List<ReturnMode> returnModeList = getReturnModeList(new ArrayList<String>(Arrays.asList("STORE", "MAIL")));

        DispositionPath store = new DispositionPath();
        store.setRank(1);
        store.setPath("STORE");
        DispositionPath carrier_pickup = new DispositionPath();
        carrier_pickup.setRank(1);
        carrier_pickup.setPath("CARRIER_PICKUP");
        DispositionPath mail = new DispositionPath();
        mail.setRank(1);
        mail.setPath("MAIL");
        dispositionPaths.add(store);
        dispositionPaths.add(carrier_pickup);
        dispositionPaths.add(mail);


        AssignReturnModesFromReturnEligibility assignReturnModesFromReturnEligibility = new AssignReturnModesFromReturnEligibility();
        assignReturnModesFromReturnEligibility.assignFinalReturnModes(dispositionInfo);

        returnModesInfo.setReturnModes(returnModeList);
        item.setReturnModesInfo(returnModesInfo);
        dispositionInfo.setDispositionPaths(dispositionPaths);
        dispositionInfo.setItem(item);

        Map<String,Integer> expectedOrderedListOfDispositionPaths = new HashMap<>();
        expectedOrderedListOfDispositionPaths.put("STORE",1);
        expectedOrderedListOfDispositionPaths.put("MAIL",1);
        expectedOrderedListOfDispositionPaths.put("CARRIER_PICKUP",1);

        for(DispositionPath dispositionPath:dispositionInfo.getDispositionPaths()){
            assertEquals(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()),dispositionPath.getRank());
        }
    }


    @Test
    void whenReturnModesEligibleAreLessForReturnOptions_thenRemoveNonEligibleReturnModes_assignFinalReturnModes() {
        DispositionInfo dispositionInfo = new DispositionInfo();
        List<DispositionPath> dispositionPaths = new ArrayList<>();
        BaseItem item = new BaseItem();
        ReturnModesInfo returnModesInfo = new ReturnModesInfo();
        List<ReturnMode> returnModeList = getReturnModeList(new ArrayList<String>(Arrays.asList("STORE", "MAIL")));

        DispositionPath store = new DispositionPath();
        store.setRank(1);
        store.setPath("returnToStore");
        DispositionPath carrier_pickup = new DispositionPath();
        carrier_pickup.setRank(1);
        carrier_pickup.setPath("CARRIER_PICKUP");
        DispositionPath mail = new DispositionPath();
        mail.setRank(1);
        mail.setPath("mailBack");
        dispositionPaths.add(store);
        dispositionPaths.add(carrier_pickup);
        dispositionPaths.add(mail);

        returnModesInfo.setReturnModes(returnModeList);
        item.setReturnModesInfo(returnModesInfo);
        item.setRdmApiCallerName("returnOptions");
        dispositionInfo.setDispositionPaths(dispositionPaths);
        dispositionInfo.setItem(item);

        AssignReturnModesFromReturnEligibility assignReturnModesFromReturnEligibility = new AssignReturnModesFromReturnEligibility();
        rankAssignerChainConfig.setEligibleReturnModesForReturnOptions(Arrays.asList(new String[]{"mailBack", "returnToStore"}));
        rankAssignerChainConfig.setEligibleChannelsForDefaultReturnEligibilityResponse(Arrays.asList(new String[]{"CCA-Returns", "MYACCOUNT"}));
        assignReturnModesFromReturnEligibility.setRankAssignerChainConfig(rankAssignerChainConfig);
        assignReturnModesFromReturnEligibility.assignFinalReturnModes(dispositionInfo);

        Map<String,Integer> expectedOrderedListOfDispositionPaths = new HashMap<>();
        expectedOrderedListOfDispositionPaths.put("returnToStore",1);
        expectedOrderedListOfDispositionPaths.put("mailBack",1);

        for(DispositionPath dispositionPath:dispositionInfo.getDispositionPaths()){
            assertEquals(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()),dispositionPath.getRank());
        }

    }

    @Test
    void whenReturnModesEligibleAreLessForeReturnOptions_thenRemoveNonEligibleReturnModes_assignFinalReturnModes() {
        DispositionInfo dispositionInfo = new DispositionInfo();
        List<DispositionPath> dispositionPaths = new ArrayList<>();
        BaseItem item = new BaseItem();
        ReturnModesInfo returnModesInfo = new ReturnModesInfo();
        List<ReturnMode> returnModeList = getReturnModeList(new ArrayList<String>(Arrays.asList("STORE", "MAIL")));

        DispositionPath store = new DispositionPath();
        store.setRank(1);
        store.setPath("returnToStore");
        DispositionPath carrier_pickup = new DispositionPath();
        carrier_pickup.setRank(1);
        carrier_pickup.setPath("CARRIER_PICKUP");
        DispositionPath mail = new DispositionPath();
        mail.setRank(1);
        mail.setPath("MAIL");
        dispositionPaths.add(store);
        dispositionPaths.add(carrier_pickup);
        dispositionPaths.add(mail);

        returnModesInfo.setReturnModes(returnModeList);
        item.setReturnModesInfo(returnModesInfo);
        item.setRdmApiCallerName("dispositionPaths");
        item.setChannelName("CCA-Returns");
        dispositionInfo.setDispositionPaths(dispositionPaths);
        dispositionInfo.setItem(item);


        AssignReturnModesFromReturnEligibility assignReturnModesFromReturnEligibility = new AssignReturnModesFromReturnEligibility();
        rankAssignerChainConfig.setEligibleReturnModesForReturnOptions(Arrays.asList(new String[]{"mailBack", "returnToStore"}));
        rankAssignerChainConfig.setEligibleChannelsForDefaultReturnEligibilityResponse(Arrays.asList(new String[]{"CCA-Returns", "MYACCOUNT"}));
        assignReturnModesFromReturnEligibility.setRankAssignerChainConfig(rankAssignerChainConfig);
        assignReturnModesFromReturnEligibility.assignFinalReturnModes(dispositionInfo);

        Map<String,Integer> expectedOrderedListOfDispositionPaths = new HashMap<>();
        expectedOrderedListOfDispositionPaths.put("MAIL",1);
        for(DispositionPath dispositionPath:dispositionInfo.getDispositionPaths()){
            assertEquals(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()),dispositionPath.getRank());
        }
    }

    private List<ReturnMode> getReturnModeList(ArrayList<String> returnModeNames) {
        List<ReturnMode> returnModeList = new ArrayList<>();
        for(String returnModeName: returnModeNames){
            ReturnMode returnMode = new ReturnMode();
            returnMode.setName(returnModeName);
            returnMode.setReturnAllowed(true);
            returnMode.setReplacementAllowed(true);

            returnModeList.add(returnMode);
        }

        return returnModeList;
    }
}