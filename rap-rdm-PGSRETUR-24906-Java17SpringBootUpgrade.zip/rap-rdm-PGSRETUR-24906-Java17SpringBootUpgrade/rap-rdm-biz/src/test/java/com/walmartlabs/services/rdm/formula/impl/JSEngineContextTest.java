package com.walmartlabs.services.rdm.formula.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;

/**
 * 
 * @author Tim Jin
 *
 */
/*class JSEngineContextTest {

    private Set<String> s(String... values) {
        return Stream.of(values).collect(Collectors.toSet());
    }

    private Set<String> i(String eval) {
        return new JSEngine().getContext(eval).getInputVariables();
    }

    private Set<String> o(String eval) {
        return new JSEngine().getContext(eval).getOutputVariables();
    }

    @Test
    void basic() {
        assertNull(i(null));
        assertNull(i(" "));
        assertNull(i("1"));
        //assertNull(i("2"));
        assertNull(i("1+2;"));

        assertEquals(s("a"), i("a"));
        assertEquals(s("a"), i("a+1"));
        assertEquals(s("a"), i("a+\"1\""));

        assertEquals(s("a", "b"), i("a==b"));
        assertEquals(s("a", "b"), i("a===b"));
        assertEquals(s("a", "b"), i("a+b"));

        assertEquals(s("a", "b", "c"), i("a==b+c"));
        assertEquals(s("a", "b", "c"), i("a+b+c*2"));

    }

    @Test
    void advanced() {
        //we know there is a function f but the parameters can't not be determined
        assertNull(i("function f(a){\"return a + 1;\"}"));
        assertEquals(s("f"), o("function f(a){\"return a + 1;\"}"));
        assertEquals(s("b"), i("a=b"));
    }

    @Test
    void advanced2() {
        //TODO due to the nature of js it's not possible to collect all variables.
        assertNotEquals(s("a", "b", "c"), i("a?b:c"));
        assertNotEquals(s("a", "b", "c"), i("a=2?b:c"));

    }

    @Test
    void notSupported() {
        assertThrows(RuntimeException.class, () -> {
            i("alert()");
        });

        assertThrows(RuntimeException.class, () -> {
            i("alert(a)");
        });

        assertThrows(RuntimeException.class, () -> {
            i("console.log(a)");
        });

        assertThrows(RuntimeException.class, () -> {
            i("throw 'error'");
        });
    }

}*/
