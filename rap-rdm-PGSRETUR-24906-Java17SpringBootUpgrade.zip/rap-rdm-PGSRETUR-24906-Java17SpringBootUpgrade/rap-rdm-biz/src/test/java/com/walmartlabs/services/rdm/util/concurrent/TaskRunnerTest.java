package com.walmartlabs.services.rdm.util.concurrent;

import java.util.Random;

import org.junit.jupiter.api.Test;

import com.walmartlabs.services.rdm.util.concurrent.Task;
import com.walmartlabs.services.rdm.util.concurrent.TaskRunner;

class TaskRunnerTest {
    static Object call(String name, int low, int high) {
        try{
            Thread.sleep(new Random().nextInt(high - low) + low);
        }catch (InterruptedException e){
            Thread.currentThread().interrupt();
        }
        return name;
    }

    @Test
    void test() {

        Task a = new Task(() -> {
            long t = System.currentTimeMillis();
            Object response = call("A", 20, 1000);
            System.out.println(response + " " + System.currentTimeMillis() + " " + (System.currentTimeMillis() - t));
        });

        Task b = new Task(() -> {
            long t = System.currentTimeMillis();
            Object response = call("B", 200, 600);
            System.out.println(response + " " + System.currentTimeMillis() + " " + (System.currentTimeMillis() - t));
        });
        Task c = new Task(() -> {
            long t = System.currentTimeMillis();
            Object response = call("C", 10, 50);
            System.out.println(response + " " + System.currentTimeMillis() + " " + (System.currentTimeMillis() - t));
        });
        Task d = new Task(() -> {
            long t = System.currentTimeMillis();
            Object response = call("D", 50, 100);
            System.out.println(response + " " + System.currentTimeMillis() + " " + (System.currentTimeMillis() - t));
        });
        Task e = new Task(() -> {
            long t = System.currentTimeMillis();
            Object response = call("E", 100, 500);
            System.out.println(response + " " + System.currentTimeMillis() + " " + (System.currentTimeMillis() - t));
        });
        Task f = new Task(() -> {
            long t = System.currentTimeMillis();
            Object response = call("F", 100, 300);
            System.out.println(response + " " + System.currentTimeMillis() + " " + (System.currentTimeMillis() - t));
        });
        Task g = new Task(() -> {
            long t = System.currentTimeMillis();
            Object response = call("G", 10, 100);
            System.out.println(response + " " + System.currentTimeMillis() + " " + (System.currentTimeMillis() - t));
        });

        b.getDependents().add(a);
        g.getDependents().add(e);
        g.getDependents().add(f);
        g.setDependantType(Task.DependantType.ANY);

        e.getDependents().add(c);
        e.getDependents().add(d);

        TaskRunner.run(1000, g, b);
    }

}
