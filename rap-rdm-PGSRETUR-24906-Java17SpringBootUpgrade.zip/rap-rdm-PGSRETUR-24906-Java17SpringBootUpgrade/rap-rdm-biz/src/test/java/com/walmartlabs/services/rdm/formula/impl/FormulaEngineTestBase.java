package com.walmartlabs.services.rdm.formula.impl;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.FormulaException;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.Formula;
import com.walmartlabs.services.rdm.model.formula.FormulaType;
import com.walmartlabs.services.rdm.model.formula.ValueType;

/**
 * 
 * @author Tim Jin
 *
 */
public class FormulaEngineTestBase {

    protected Object eval(FormulaType engineType, String eval, ValueType type, Object... input) {
        Map<String, Object> session = new HashMap<>();
        for(int i = 0; i < input.length; i += 2){
            session.put(input[i].toString(), input[i + 1]);
        }

        Formula f = formula(engineType, eval, type);

        while(true){
            try{
                return getEngine(engineType).eval(f, session);
            }catch (VariableMissingException e){
                if(session.containsKey(e.getVariable())){
                    f.getInputVariables().add(e.getVariable());
                }else throw new FormulaException(MessageFormat.format("{0} is not defined", e.getVariable()), e);
            }
        }
    }

    protected Object eval(FormulaType engineType, String eval, ValueType type) throws VariableMissingException {
        return getEngine(engineType).eval(formula(engineType, eval, type), new HashMap<>());
    }

    private Formula formula(FormulaType engineType, String eval, ValueType type) {
        Formula f = new Formula();
        f.setFormula(eval);
        f.setValueType(type);
        f.setInputVariables(getEngine(engineType).getContext(eval).getInputVariables());
        return f;
    }

    private FormulaEngine getEngine(FormulaType engineType) {
        switch (engineType) {
            case JS:
                return new JSEngine();
            case JSONP:
                return new JsonPEngine();
            default:
                return null;
        }
    }

}
