package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.dto.Quantity;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class PhotoItemTotalLineRefundCheckTest {
    PhotoItemTotalLineRefundCheck photoItemTotalLineRefundCheck = new PhotoItemTotalLineRefundCheck();
    RDMKeepItUtil rdmKeepItUtil;

    RDMKeepItConfig rdmKeepItConfig;
    KeepItRuleEngineContext keepItRuleEngineContext;

    @Before
    public void setUp() {
        rdmKeepItUtil = new RDMKeepItUtil();
        rdmKeepItConfig = new RDMKeepItConfig();
        rdmKeepItConfig.setThresholdForPhotoItemTotalRefundAmount(3.0);
        keepItRuleEngineContext = new KeepItRuleEngineContext();
        photoItemTotalLineRefundCheck.setRdmKeepItUtil(rdmKeepItUtil);
        photoItemTotalLineRefundCheck.setRdmKeepItConfig(rdmKeepItConfig);
    }

    @Test
    public void testGetName() {
        org.testng.Assert.assertEquals(photoItemTotalLineRefundCheck.getKeepItCheckName(), RDMConstants.RULE_CHECK_NAME_PHOTO_ITEM_TOTAL_LINE_REFUND);
    }

    @Test
    public void testRunCheck_Greater() {
        BaseItem item = getItem("4");
        keepItRuleEngineContext.setItem(item);
        Assert.assertFalse(photoItemTotalLineRefundCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void testRunCheck_Equal() {
        BaseItem item = getItem("3");
        keepItRuleEngineContext.setItem(item);
        Assert.assertFalse(photoItemTotalLineRefundCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void testRunCheck_Lesser() {
        BaseItem item = getItem("2");
        keepItRuleEngineContext.setItem(item);
        Assert.assertTrue(photoItemTotalLineRefundCheck.runCheck(keepItRuleEngineContext));
    }

    private BaseItem getItem(String s) {
        BaseItem item = new BaseItem();
        item.setLineRefundAmount(Double.parseDouble(s));
        return item;
    }
}
