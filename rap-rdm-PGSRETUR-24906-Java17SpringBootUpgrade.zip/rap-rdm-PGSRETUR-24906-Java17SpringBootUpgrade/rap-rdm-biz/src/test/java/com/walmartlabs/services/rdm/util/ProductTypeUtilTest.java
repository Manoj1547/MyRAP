package com.walmartlabs.services.rdm.util;

import com.walmartlabs.services.rdm.domain.model.ProductTypeCategoryDO;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.util.List;

import static org.junit.Assert.*;

public class ProductTypeUtilTest {

    @Test()
    public void whenAllRowsAreContinuous_testReadFile() throws FileNotFoundException {
        List<ProductTypeCategoryDO> result =
                ProductTypeUtil.readFile(getClass().getClassLoader().getResource("readProductTypeFile_input1.xlsx").getPath());

        assertEquals(result.size(),5687);
    }

    @Test(expected = Exception.class)
    public void whenInvalidRow_testReadFile() throws FileNotFoundException {
        List<ProductTypeCategoryDO> result =
                ProductTypeUtil.readFile(getClass().getClassLoader().getResource("readProductTypeFile_input2.xlsx").getPath());
    }

    @Test()
    public void whenAllRowsAreNotContinuous_testReadFile() throws FileNotFoundException {
        List<ProductTypeCategoryDO> result =
                ProductTypeUtil.readFile(getClass().getClassLoader().getResource("readProductTypeFile_input3.xlsx").getPath());

        assertEquals(result.size(),5688);
    }
}