package com.walmartlabs.services.rdm.rank.assigner.impl;

import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class PreferenceRankingForCurbsideStoreTest {

    /*
  Input: RANK: 1. INHOME, 2. LMD , 3.STORE, 4.CURBSIDE, 5.MAIL, 6.FEDEX_DROP
  Output: RANK: 1. INHOME, 2. LMD , 3.STORE, 4.CURBSIDE , 5.MAIL, 6.FEDEX_DROP
 */
    @Test
    void whenRequestContainsCurbsideGreaterThanStore_rankWillRemainSame_testAssignRanks() {
        List<DispositionInfo> allItemsDispositionInfoList = new ArrayList<>();
        DispositionInfo dispositionInfo1 = new DispositionInfo();
        List<DispositionPath> dispositionPaths1 = dispositionInfo1.getDispositionPaths();

        DispositionPath inhome = new DispositionPath();
        inhome.setRank(1);
        inhome.setPath("INHOME_PICKUP");
        DispositionPath lmd = new DispositionPath();
        lmd.setRank(2);
        lmd.setPath("LMD");
        lmd.setValue(Double.valueOf(30));
        DispositionPath store = new DispositionPath();
        store.setRank(3);
        store.setPath("STORE");
        DispositionPath mail = new DispositionPath();
        mail.setRank(5);
        mail.setPath("MAIL");
        DispositionPath curbside = new DispositionPath();
        curbside.setRank(4);
        curbside.setPath("CURB_SIDE");
        curbside.setValue(Double.valueOf(30));
        DispositionPath fedex_drop = new DispositionPath();
        fedex_drop.setRank(6);
        fedex_drop.setPath("FEDEX_DROP");
        dispositionPaths1.add(inhome);
        dispositionPaths1.add(lmd);
        dispositionPaths1.add(store);
        dispositionPaths1.add(mail);
        dispositionPaths1.add(curbside);
        dispositionPaths1.add(fedex_drop);

        dispositionInfo1.setDispositionPaths(dispositionPaths1);
        dispositionInfo1.setIsDefault(false);
        allItemsDispositionInfoList.add(dispositionInfo1);

        PreferenceRankingForCurbsideStore preferenceRankingForCurbsideStore = new PreferenceRankingForCurbsideStore();
        preferenceRankingForCurbsideStore.assignRanks(allItemsDispositionInfoList);

        dispositionInfo1 = allItemsDispositionInfoList.get(0);

        Map<String,Integer> expectedOrderedListOfDispositionPaths = new HashMap<>();
        expectedOrderedListOfDispositionPaths.put("INHOME_PICKUP", 1);
        expectedOrderedListOfDispositionPaths.put("LMD",2);
        expectedOrderedListOfDispositionPaths.put("STORE",3);
        expectedOrderedListOfDispositionPaths.put("MAIL",5);
        expectedOrderedListOfDispositionPaths.put("CURB_SIDE",4);
        expectedOrderedListOfDispositionPaths.put("FEDEX_DROP",6);

        for(DispositionPath dispositionPath:dispositionInfo1.getDispositionPaths()){
            assertEquals(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()),dispositionPath.getRank());
        }
    }


    /*
 Input: RANK: 1. INHOME, 2.CARRIER_PICKUP, 3.STORE, 4.MAIL, 5.FEDEX_DROP
 Output: RANK: 1. INHOME, 2.CARRIER_PICKUP, 3.STORE, 4.MAIL, 5.FEDEX_DROP
*/
    @Test
    void whenRequestContainsOnlyStore_rankWillRemainSame_testAssignRanks() {
        List<DispositionInfo> allItemsDispositionInfoList = new ArrayList<>();
        DispositionInfo dispositionInfo1 = new DispositionInfo();
        List<DispositionPath> dispositionPaths1 = dispositionInfo1.getDispositionPaths();

        DispositionPath inhome = new DispositionPath();
        inhome.setRank(1);
        inhome.setPath("INHOME_PICKUP");
        DispositionPath lmd = new DispositionPath();
        lmd.setRank(2);
        lmd.setPath("LMD");
        lmd.setValue(Double.valueOf(30));
        DispositionPath store = new DispositionPath();
        store.setRank(4);
        store.setPath("STORE");
        DispositionPath mail = new DispositionPath();
        mail.setRank(5);
        mail.setPath("MAIL");
        DispositionPath carrier_pickup = new DispositionPath();
        carrier_pickup.setRank(3);
        carrier_pickup.setPath("CARRIER_PICKUP");
        carrier_pickup.setValue(Double.valueOf(30));
        DispositionPath fedex_drop = new DispositionPath();
        fedex_drop.setRank(6);
        fedex_drop.setPath("FEDEX_DROP");
        dispositionPaths1.add(inhome);
        dispositionPaths1.add(store);
        dispositionPaths1.add(mail);
        dispositionPaths1.add(carrier_pickup);
        dispositionPaths1.add(fedex_drop);

        dispositionInfo1.setDispositionPaths(dispositionPaths1);
        dispositionInfo1.setIsDefault(false);
        allItemsDispositionInfoList.add(dispositionInfo1);

        PreferenceRankingForCurbsideStore preferenceRankingForCurbsideStore = new PreferenceRankingForCurbsideStore();
        preferenceRankingForCurbsideStore.assignRanks(allItemsDispositionInfoList);

        dispositionInfo1 = allItemsDispositionInfoList.get(0);

        Map<String,Integer> expectedOrderedListOfDispositionPaths = new HashMap<>();
        expectedOrderedListOfDispositionPaths.put("INHOME_PICKUP", 1);
        expectedOrderedListOfDispositionPaths.put("STORE",4);
        expectedOrderedListOfDispositionPaths.put("MAIL",5);
        expectedOrderedListOfDispositionPaths.put("CARRIER_PICKUP",3);
        expectedOrderedListOfDispositionPaths.put("FEDEX_DROP",6);

        for(DispositionPath dispositionPath:dispositionInfo1.getDispositionPaths()){
            System.out.println(dispositionPath.getPath());
            System.out.println(dispositionPath.getRank());
            System.out.println(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()));
            assertEquals(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()),dispositionPath.getRank());
        }
    }

    /*
    Input: RANK: 1. INHOME, 2. LMD,  4.STORE, 5.MAIL, 6.FEDEX_DROP
    Output: RANK: 1. INHOME, 2. LMD, 4.STORE, 5.MAIL, 6.FEDEX_DROP
   */
    @Test
    void whenRequestContainsOnlyCurbside_rankWillRemainSame_testAssignRanks() {
        List<DispositionInfo> allItemsDispositionInfoList = new ArrayList<>();
        DispositionInfo dispositionInfo1 = new DispositionInfo();
        List<DispositionPath> dispositionPaths1 = dispositionInfo1.getDispositionPaths();

        DispositionPath inhome = new DispositionPath();
        inhome.setRank(1);
        inhome.setPath("INHOME_PICKUP");
        DispositionPath lmd = new DispositionPath();
        lmd.setRank(2);
        lmd.setPath("LMD");
        lmd.setValue(Double.valueOf(30));
        DispositionPath curbside = new DispositionPath();
        curbside.setRank(4);
        curbside.setPath("CURB_SIDE");
        DispositionPath mail = new DispositionPath();
        mail.setRank(5);
        mail.setPath("MAIL");
        DispositionPath carrier_pickup = new DispositionPath();
        carrier_pickup.setRank(3);
        carrier_pickup.setPath("CARRIER_PICKUP");
        carrier_pickup.setValue(Double.valueOf(30));
        DispositionPath fedex_drop = new DispositionPath();
        fedex_drop.setRank(6);
        fedex_drop.setPath("FEDEX_DROP");
        dispositionPaths1.add(inhome);
        dispositionPaths1.add(lmd);
        dispositionPaths1.add(curbside);
        dispositionPaths1.add(mail);
        dispositionPaths1.add(fedex_drop);

        dispositionInfo1.setDispositionPaths(dispositionPaths1);
        dispositionInfo1.setIsDefault(false);
        allItemsDispositionInfoList.add(dispositionInfo1);

        PreferenceRankingForCurbsideStore preferenceRankingForCurbsideStore = new PreferenceRankingForCurbsideStore();
        preferenceRankingForCurbsideStore.assignRanks(allItemsDispositionInfoList);

        dispositionInfo1 = allItemsDispositionInfoList.get(0);
        Map<String,Integer> expectedOrderedListOfDispositionPaths = new HashMap<>();
        expectedOrderedListOfDispositionPaths.put("INHOME_PICKUP", 1);
        expectedOrderedListOfDispositionPaths.put("CURB_SIDE",4);
        expectedOrderedListOfDispositionPaths.put("MAIL",5);
        expectedOrderedListOfDispositionPaths.put("LMD",2);
        expectedOrderedListOfDispositionPaths.put("FEDEX_DROP",6);

        for(DispositionPath dispositionPath:dispositionInfo1.getDispositionPaths()){
            assertEquals(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()),dispositionPath.getRank());
        }
    }

    /*
  Input: RANK: 1. INHOME, 3. LMD,  2.CARRIER_PICKUP, 4.CURBSIDE, 5.STORE, , 6.FEDEX_DROP
  Output: RANK: 1. INHOME, 3. LMD, , 2.CARRIER_PICKUP, 4.STORE, 5.CURBSIDE, 6.FEDEX_DROP
 */
    @Test
    void whenRequestContainsStoreGreaterThanCurbside_rankWillBeSwapped_testAssignRanks() {
        List<DispositionInfo> allItemsDispositionInfoList = new ArrayList<>();
        DispositionInfo dispositionInfo1 = new DispositionInfo();
        List<DispositionPath> dispositionPaths1 = dispositionInfo1.getDispositionPaths();

        DispositionPath inhome = new DispositionPath();
        inhome.setRank(1);
        inhome.setPath("INHOME_PICKUP");
        DispositionPath lmd = new DispositionPath();
        lmd.setRank(3);
        lmd.setPath("LMD");
        lmd.setValue(Double.valueOf(30));
        DispositionPath curbside = new DispositionPath();
        curbside.setRank(4);
        curbside.setPath("CURB_SIDE");
        curbside.setValue(Double.valueOf(30));
        DispositionPath store = new DispositionPath();
        store.setRank(5);
        store.setPath("STORE");
        store.setValue(Double.valueOf(30));
        DispositionPath carrier_pickup = new DispositionPath();
        carrier_pickup.setRank(2);
        carrier_pickup.setPath("CARRIER_PICKUP");
        carrier_pickup.setValue(Double.valueOf(30));
        DispositionPath fedex_drop = new DispositionPath();
        fedex_drop.setRank(6);
        fedex_drop.setPath("FEDEX_DROP");
        dispositionPaths1.add(inhome);
        dispositionPaths1.add(lmd);
        dispositionPaths1.add(store);
        dispositionPaths1.add(curbside);
        dispositionPaths1.add(carrier_pickup);
        dispositionPaths1.add(fedex_drop);

        dispositionInfo1.setDispositionPaths(dispositionPaths1);
        dispositionInfo1.setIsDefault(false);
        dispositionInfo1.setItem(getItem("123","1234","MYACCOUNT"));

        allItemsDispositionInfoList.add(dispositionInfo1);

        PreferenceRankingForCurbsideStore preferenceRankingForCurbsideStore = new PreferenceRankingForCurbsideStore();
        preferenceRankingForCurbsideStore.assignRanks(allItemsDispositionInfoList);

        dispositionInfo1 = allItemsDispositionInfoList.get(0);

        Map<String,Integer> expectedOrderedListOfDispositionPaths = new HashMap<>();
        expectedOrderedListOfDispositionPaths.put("INHOME_PICKUP", 1);
        expectedOrderedListOfDispositionPaths.put("CURB_SIDE",5);
        expectedOrderedListOfDispositionPaths.put("MAIL",5);
        expectedOrderedListOfDispositionPaths.put("LMD",3);
        expectedOrderedListOfDispositionPaths.put("FEDEX_DROP",6);
        expectedOrderedListOfDispositionPaths.put("STORE",4);
        expectedOrderedListOfDispositionPaths.put("CARRIER_PICKUP",2);

        for(DispositionPath dispositionPath:dispositionInfo1.getDispositionPaths()){
            assertEquals(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()),dispositionPath.getRank());
        }
    }

    private BaseItem getItem(String orderNo, String itemId, String channelName) {

        BaseItem item = new BaseItem();
        item.setChannelName(channelName);
        item.setOrderNo(orderNo);
        item.setItemId(itemId);
        return item;
    }
}