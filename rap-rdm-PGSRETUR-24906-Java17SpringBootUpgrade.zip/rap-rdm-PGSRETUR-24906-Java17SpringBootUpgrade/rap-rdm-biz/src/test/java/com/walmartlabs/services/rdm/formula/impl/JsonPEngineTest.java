package com.walmartlabs.services.rdm.formula.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.FormulaType;
import com.walmartlabs.services.rdm.model.formula.ValueType;

import org.apache.commons.lang.BooleanUtils;

class JsonPEngineTest extends FormulaEngineTestBase {
   /* protected Object eval(String eval, ValueType type, Object... input) {
        return eval(FormulaType.JSONP, eval, type, input);
    }

    protected Object eval(String eval, ValueType type) throws VariableMissingException {
        return eval(FormulaType.JSONP, eval, type);
    }

    @Test
    void testSIROPR() throws IOException {
        URL nodesJson = JsonPEngineTest.class.getResource("/siro_pr.json");
        try (BufferedReader in = new BufferedReader(new InputStreamReader(nodesJson.openStream(), "UTF-8"))){
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

            List<Object> rst = mapper.readValue(in, new TypeReference<List<Object>>() {});

            testDefectiveAgreement(rst.get(0), "N", 1);
            testDefectiveAgreement(rst.get(1), "D", 0);
        }
    }

    void testDefectiveAgreement(Object data, String expectedFiledBy, double expectedFee) {
        Object item = eval("_SIRO_PR:defectiveAgreement.itemExcpDefectAgmt[0]", ValueType.OBJECT, "_SIRO_PR", data);
        Object dept = eval("_SIRO_PR:defectiveAgreement.supDeptDefectAgmt[0]", ValueType.OBJECT, "_SIRO_PR", data);
        Object defect = eval(FormulaType.JS, "item?item:dept", ValueType.OBJECT, "item", item, "dept", dept);

        Object filedBy = eval(FormulaType.JSONP, "defect:claimFiledBy", ValueType.STRING, "defect", defect);
        assertEquals(expectedFiledBy, filedBy);

        Object code = eval(FormulaType.JSONP, "defect:vndrShpmtOrigCd", ValueType.STRING, "defect", defect);
        Object fee_ = eval(FormulaType.JSONP, "defect:handlingFeeAmt", ValueType.DOUBLE, "defect", defect);
        Object fee = eval(FormulaType.JS, "code == 'R' ? 0 : fee_", ValueType.DOUBLE, "code", code, "fee_", fee_);
        assertEquals(expectedFee, fee);

    }

    @Test
    void testISQIndigo() throws IOException {
        URL nodesJson = JsonPEngineTest.class.getResource("/iqs_indigo.json");
        try (BufferedReader in = new BufferedReader(new InputStreamReader(nodesJson.openStream(), "UTF-8"))){
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

            Object rst = mapper.readValue(in, Object.class);

            Object items = eval("_SIRO_PR:payload.sivItems.content[*].attributes.activeItem", ValueType.OBJECT, "_SIRO_PR", rst);
            Object item = eval("items:[0]", ValueType.STRING, "items", items);
            assertEquals("551050766", item);
        }
    }

    @Test
    void a() throws IOException {
        Map<String, Object> m = new HashMap<>();
        m.put("null", null);
        m.put("t", Boolean.TRUE);
        m.put("t1", false);
        
        assertEquals(false, BooleanUtils.isTrue((Boolean) m.get("a")));
        assertEquals(false, BooleanUtils.isTrue((Boolean) m.get("null")));
        assertEquals(true, BooleanUtils.isTrue((Boolean) m.get("t")));
        assertEquals(false, BooleanUtils.isTrue((Boolean) m.get("t1")));
    }*/
}
