package com.walmartlabs.services.rdm.formula.impl.java;

import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.Formula;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.Collections;

@RunWith(PowerMockRunner.class)
@PrepareForTest({FormulaEngine.class})
public class DonatePreferenceResolverTest {

    private DonatePreferenceResolver donatePreferenceResolver;
    private RDMSwitches rdmSwitches;

    @Before
    public void setUp() {
        donatePreferenceResolver = new DonatePreferenceResolver();
        rdmSwitches = new RDMSwitches();
        rdmSwitches.setDonatePreferenceEnabled(true);
        rdmSwitches.setSupplementalDonateValue("5.0");
        donatePreferenceResolver.setSwitches(rdmSwitches);
        PowerMockito.mockStatic(FormulaEngine.class);
    }

    @Test
    public void eval_whenDonatePreferenceIsDisabled_thenReturnFalse() throws VariableMissingException {
        rdmSwitches.setDonatePreferenceEnabled(false);
        Boolean isDonatePreferred = donatePreferenceResolver.eval(new Formula(), Collections.emptyMap());
        Assertions.assertFalse(isDonatePreferred);
    }

    @Test
    public void eval_whenDonateIsGreaterThanDispose_thenReturnFalse() throws VariableMissingException {
        PowerMockito.when(FormulaEngine.getInput(Mockito.any(), Mockito.anyMap(), Mockito.anyString())).thenReturn(0.523, 0.673);
        Boolean isDonatePreferred = donatePreferenceResolver.eval(new Formula(), Collections.emptyMap());
        Assertions.assertFalse(isDonatePreferred);
    }

    @Test
    public void eval_whenDonateIsEqualToDispose_thenReturnTrue() throws VariableMissingException {
        PowerMockito.when(FormulaEngine.getInput(Mockito.any(), Mockito.anyMap(), Mockito.anyString())).thenReturn(0.523, 0.523);
        Boolean isDonatePreferred = donatePreferenceResolver.eval(new Formula(), Collections.emptyMap());
        Assertions.assertTrue(isDonatePreferred);
    }

    @Test
    public void eval_whenDisposeMinusDonateIsGreaterThanFive_thenReturnFalse() throws VariableMissingException {
        PowerMockito.when(FormulaEngine.getInput(Mockito.any(), Mockito.anyMap(), Mockito.anyString())).thenReturn(8.0, 2.345);
        Boolean isDonatePreferred = donatePreferenceResolver.eval(new Formula(), Collections.emptyMap());
        Assertions.assertFalse(isDonatePreferred);
    }

    @Test
    public void eval_whenDisposeMinusDonateIsEqualToFive_thenReturnFalse() throws VariableMissingException {
        PowerMockito.when(FormulaEngine.getInput(Mockito.any(), Mockito.anyMap(), Mockito.anyString())).thenReturn(8.0, 3.0);
        Boolean isDonatePreferred = donatePreferenceResolver.eval(new Formula(), Collections.emptyMap());
        Assertions.assertFalse(isDonatePreferred);
    }

    @Test
    public void eval_whenDisposeMinusDonateIsLessThanFive_thenReturnTrue() throws VariableMissingException {
        PowerMockito.when(FormulaEngine.getInput(Mockito.any(), Mockito.anyMap(), Mockito.anyString())).thenReturn(8.0, 3.01);
        Boolean isDonatePreferred = donatePreferenceResolver.eval(new Formula(), Collections.emptyMap());
        Assertions.assertTrue(isDonatePreferred);
    }

}
