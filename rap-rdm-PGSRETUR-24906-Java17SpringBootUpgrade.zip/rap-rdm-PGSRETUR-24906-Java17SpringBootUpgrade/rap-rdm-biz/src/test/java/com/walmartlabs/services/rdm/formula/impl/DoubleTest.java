package com.walmartlabs.services.rdm.formula.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;

class DoubleTest extends FormulaEngineTestBase {

    @Test
    void a() throws IOException {
        double d = 1.03 - 0.41;
        System.out.println(d);

        BigDecimal bd = BigDecimal.valueOf(d);
        bd = bd.setScale(2, RoundingMode.HALF_UP);
        System.out.println(bd.doubleValue());

        d = 0.62;
        System.out.println(d);

    }
}
