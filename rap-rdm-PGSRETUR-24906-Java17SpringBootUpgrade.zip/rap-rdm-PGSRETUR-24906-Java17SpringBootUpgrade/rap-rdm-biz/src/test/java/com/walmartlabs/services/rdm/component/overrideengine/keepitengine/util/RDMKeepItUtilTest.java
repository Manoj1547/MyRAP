package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util;
import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.KeepItInfo;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import static org.mockito.Mockito.when;

import static org.junit.Assert.*;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.config.client.ConfigManager;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.model.dispositionpaths.Item;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.Mockito.mock;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ConfigManager.class})
public class RDMKeepItUtilTest {
    RDMKeepItUtil rdmKeepItUtil ;
    KeepItRuleEngineContext keepItRuleEngineContext ;
    Item item ;
    ConfigManager configManager;

    @Before
    public void setup(){
        rdmKeepItUtil = new RDMKeepItUtil();
        keepItRuleEngineContext = new KeepItRuleEngineContext();
        item = new Item();

        configManager = mock(ConfigManager.class);
        PowerMockito.mockStatic(ConfigManager.class);
        PowerMockito.when(ConfigManager.getInstance()).thenReturn(configManager);

        RDMKeepItConfig rdmKeepItConfig = new RDMKeepItConfig();
        rdmKeepItConfig.setKeepItLineRefundThresholdAmount(Double.valueOf(40));
        rdmKeepItConfig.setTotalLineRefundCheckKeepItDisabled(false);

        when(ConfigManager.getRdmKeepItConfig()).thenReturn(rdmKeepItConfig);
    }

    @Test
    public void whenThresholdGreaterThanCount_ReturnTrue_testIsItemCountEligibleForKeepIt() {
        assertEquals(true,rdmKeepItUtil.isItemCountEligibleForKeepIt(3,2));
    }

    @Test
    public void whenThresholdLessThanCount_ReturnFalse_testIsItemCountEligibleForKeepIt() {
        assertEquals(false,rdmKeepItUtil.isItemCountEligibleForKeepIt(2,3));
    }

    @Test
    public void whenThresholdEqualsToCount_ReturnTrue_testIsItemCountEligibleForKeepIt() {
        assertEquals(true,rdmKeepItUtil.isItemCountEligibleForKeepIt(3,3));
    }

    @Test
    public void whenThresholdEqualsThanLineRefund_ReturnFalse_testItemTotalRefundCheck() {
        item.setLineRefundAmount(Double.valueOf(40));
        keepItRuleEngineContext.setItem(item);
        assertEquals(false,rdmKeepItUtil.itemTotalRefundCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenThresholdGreaterThanLineRefund_ReturnFalse_testItemTotalRefundCheck() {
        item.setLineRefundAmount(Double.valueOf(25));
        keepItRuleEngineContext.setItem(item);
        assertEquals(false,rdmKeepItUtil.itemTotalRefundCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenThresholdLessThanLineRefund_ReturnTrue_testItemTotalRefundCheck() {
        item.setLineRefundAmount(Double.valueOf(50));
        keepItRuleEngineContext.setItem(item);
        assertEquals(true,rdmKeepItUtil.itemTotalRefundCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenLineRefundIsNull_ReturnFalse_testItemTotalRefundCheck() {
        item.setLineRefundAmount(null);
        keepItRuleEngineContext.setItem(item);
        assertEquals(false,rdmKeepItUtil.itemTotalRefundCheck(keepItRuleEngineContext));
    }

    @Test
    public void testIsPhotoOrderLine() {
        Map<String,String> customAttributes = new HashMap<>();
        customAttributes.put(RDMConstants.IS_PHOTO_ORDER_LINE,RDMConstants.YES);
        item.setItemCustomAttributes(customAttributes);
        assertTrue(rdmKeepItUtil.isPhotoOrderLine(item));
    }

    @Test
    public void testIsCustomerTrustedForKeepIt() {
        KeepItInfo keepItInfo = new KeepItInfo();
        keepItInfo.setTrustCustomerToKeepIt(true);
        item.setKeepItInfo(keepItInfo);
        assertTrue(rdmKeepItUtil.isCustomerTrustedForKeepIt(item));
    }
    @Test
    public void testIsINEBItemtest() {
        Map<String,String> customAttributes = new HashMap<>();
        customAttributes.put(RDMConstants.IS_INEB,RDMConstants.TRUE);
        item.setItemCustomAttributes(customAttributes);
        assertTrue(rdmKeepItUtil.isINEBItem(item));
    }

}