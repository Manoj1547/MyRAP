package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.BaseTest;
import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.config.client.ConfigManager;
import com.walmartlabs.services.rdm.config.client.OVTServiceConfig;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.Session;
import com.walmartlabs.services.rdm.model.dispositionpaths.Item;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
@RunWith(PowerMockRunner.class)
@PrepareForTest(ConfigManager.class)
public class ResalableDeptCheckTest  extends BaseTest{


    ResellableDeptCheck resellableDeptCheck = new ResellableDeptCheck();
    RDMKeepItUtil rdmKeepItUtil;

    RDMKeepItConfig rdmKeepItConfig;
    KeepItRuleEngineContext keepItRuleEngineContext ;
    OVTServiceConfig ovtServiceConfig;
    ConfigManager configManager;
    @Before
    public void setup(){
        setupTest();
        rdmKeepItUtil = new RDMKeepItUtil();
        rdmKeepItConfig = new RDMKeepItConfig();
        keepItRuleEngineContext = new KeepItRuleEngineContext();
        Session session = new Session();
        Map<String,Object> outputData = new HashMap<>();
        outputData.put(FormulaConstants.VARIABLE_IS_DOTCOM, true);
        session.setOutputData(outputData);
        keepItRuleEngineContext.setSession(session);
        List<String> nonResellableDept = new ArrayList<>();
        nonResellableDept.add("3");
        nonResellableDept.add("5");
        rdmKeepItConfig.setNonResellableDeptList(nonResellableDept);
        rdmKeepItConfig.setDepartmentNoFromRequestEnabled(true);
        resellableDeptCheck.setRdmKeepItConfig(rdmKeepItConfig);
        ovtServiceConfig = new OVTServiceConfig();
        ovtServiceConfig.setEnableOmniAPILogicForRecall(true);
        configManager = mock(ConfigManager.class);
        PowerMockito.mockStatic(ConfigManager.class);
        PowerMockito.when(ConfigManager.getInstance()).thenReturn(configManager);

        when(ConfigManager.getOvtServiceConfig()).thenReturn(ovtServiceConfig);
    }

    @Test
    public void testGetKeepItCheckName() {
        assertEquals(RDMConstants.RULE_CHECK_NAME_RESELLABLE_DEPT_CHECK,resellableDeptCheck.getKeepItCheckName());
    }

    @Test
    public void whenDeptNoIsInNonResellableListreturnFalse(){
        keepItRuleEngineContext.setItem(getItem("3"));
        assertFalse(resellableDeptCheck.runCheck(keepItRuleEngineContext));

    }

    @Test
    public void whenDeptNoIsInNonResellableListreturnTrue(){
        keepItRuleEngineContext.setItem(getItem("40"));
        assertTrue(resellableDeptCheck.runCheck(keepItRuleEngineContext));

    }


    private Item getItem(String s) {
        Item item = new Item();
        item.setDepartmentNo(s);
        return item;
    }

}
