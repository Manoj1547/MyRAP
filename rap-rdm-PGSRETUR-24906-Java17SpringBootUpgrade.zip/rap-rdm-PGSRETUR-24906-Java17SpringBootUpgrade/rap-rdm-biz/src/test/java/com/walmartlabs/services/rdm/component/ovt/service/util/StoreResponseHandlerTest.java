package com.walmartlabs.services.rdm.component.ovt.service.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmartlabs.services.rdm.component.ovt.model.response.ItemPolicyDetailsResponse;
import com.walmartlabs.services.rdm.component.ovt.model.response.OVTOmniItemPolicyDetails;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static org.junit.Assert.*;

public class StoreResponseHandlerTest {

    private static ObjectMapper objectMapper;
    private String vendorNo = "538678";
    private Set<String> itemIds = new HashSet<>();

    @Before
    public void setup()
    {
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    @Test
    public void testHandleResponse_whenAllAttributesPresentStoreDisposition_getAllAttributesInFilteredObject() throws IOException {
        ItemPolicyDetailsResponse itemPolicyDetailsResponse = prepareItemPolicyDetailsResponse2();
        StoreResponseHandler storeResponseHandler = new StoreResponseHandler();
        itemIds.add("241971909");
        OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails = storeResponseHandler.handleResponse(itemPolicyDetailsResponse, vendorNo, itemIds);

        assertEquals(Double.valueOf(0),ovtOmniItemPolicyDetails.getClaimPercent());
        assertEquals(Double.valueOf(0),ovtOmniItemPolicyDetails.getHandlingFeeAmount());
        assertEquals("L",ovtOmniItemPolicyDetails.getReturnCentreDisposition());
        assertNull(ovtOmniItemPolicyDetails.getStoreDisposition());
        assertEquals("N",ovtOmniItemPolicyDetails.getClaimFiledBy());
        assertEquals(false, ovtOmniItemPolicyDetails.getWalmartDiscretion());
    }

    @Test
    public void testHandleResponse_whenAllAttributesPresentRCDispositionNull_getAllAttributesInFilteredObject() throws IOException {
        ItemPolicyDetailsResponse itemPolicyDetailsResponse = prepareItemPolicyDetailsResponse1();
        StoreResponseHandler storeResponseHandler = new StoreResponseHandler();
        itemIds.add("241971909");
        OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails = storeResponseHandler.handleResponse(itemPolicyDetailsResponse, vendorNo, itemIds);

        assertEquals(Double.valueOf(0),ovtOmniItemPolicyDetails.getClaimPercent());
        assertEquals(Double.valueOf(0),ovtOmniItemPolicyDetails.getHandlingFeeAmount());
        assertNull(ovtOmniItemPolicyDetails.getReturnCentreDisposition());
        assertEquals("R",ovtOmniItemPolicyDetails.getStoreDisposition());
        assertEquals("N",ovtOmniItemPolicyDetails.getClaimFiledBy());
        assertEquals(false, ovtOmniItemPolicyDetails.getWalmartDiscretion());
    }

    @Test
    public void testHandleResponse_whenAllAttributesPresentExceptionItem_getAllAttributesInFilteredObject() throws IOException {
        ItemPolicyDetailsResponse itemPolicyDetailsResponse = prepareItemPolicyDetailsResponse3();
        StoreResponseHandler storeResponseHandler = new StoreResponseHandler();
        itemIds.add("241971909");
        OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails = storeResponseHandler.handleResponse(itemPolicyDetailsResponse, vendorNo, itemIds);

        assertEquals(Double.valueOf(0),ovtOmniItemPolicyDetails.getClaimPercent());
        assertEquals(Double.valueOf(0),ovtOmniItemPolicyDetails.getHandlingFeeAmount());
        assertEquals("",ovtOmniItemPolicyDetails.getReturnCentreDisposition());
        assertEquals("D",ovtOmniItemPolicyDetails.getStoreDisposition());
        assertEquals("N",ovtOmniItemPolicyDetails.getClaimFiledBy());
        assertEquals(false, ovtOmniItemPolicyDetails.getWalmartDiscretion());
    }


    @Test
    public void testHandleResponse_whenAttributesMissing_getMissingAttributesNullInFilteredObject() throws IOException {
        ItemPolicyDetailsResponse itemPolicyDetailsResponse = prepareItemPolicyDetailsResponseWithMissingAttributes();
        StoreResponseHandler storeResponseHandler = new StoreResponseHandler();
        itemIds.add("241971909");
        RDMException itemPolicyDetailsException = assertThrows(RDMException.class, () -> {
            storeResponseHandler.handleResponse(itemPolicyDetailsResponse, vendorNo, itemIds);
        });
    }

    private ItemPolicyDetailsResponse prepareItemPolicyDetailsResponseWithMissingAttributes() throws IOException {
        ServiceResponse<ItemPolicyDetailsResponse> serviceResponse = objectMapper.readValue(readTestFile().get("KEY8"),
                new TypeReference<ServiceResponse<ItemPolicyDetailsResponse>>() {
                });

        return serviceResponse.getPayload();
    }

    private ItemPolicyDetailsResponse prepareItemPolicyDetailsResponse1() throws IOException {
        ServiceResponse<ItemPolicyDetailsResponse> serviceResponse = objectMapper.readValue(readTestFile().get("KEY7"),
                new TypeReference<ServiceResponse<ItemPolicyDetailsResponse>>() {
                });

        return serviceResponse.getPayload();
    }

    private ItemPolicyDetailsResponse prepareItemPolicyDetailsResponse2() throws IOException {
        ServiceResponse<ItemPolicyDetailsResponse> serviceResponse = objectMapper.readValue(readTestFile().get("KEY9"),
                new TypeReference<ServiceResponse<ItemPolicyDetailsResponse>>() {
                });

        return serviceResponse.getPayload();
    }

    private ItemPolicyDetailsResponse prepareItemPolicyDetailsResponse3() throws IOException {
        ServiceResponse<ItemPolicyDetailsResponse> serviceResponse = objectMapper.readValue(readTestFile().get("KEY10"),
                new TypeReference<ServiceResponse<ItemPolicyDetailsResponse>>() {
                });

        return serviceResponse.getPayload();
    }

    private Map<String, String> readTestFile() throws IOException {
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("ovt_omni_response.json").getFile());
        return new ObjectMapper().readValue(file,new TypeReference<Map<String, String>>() {});
    }
}
