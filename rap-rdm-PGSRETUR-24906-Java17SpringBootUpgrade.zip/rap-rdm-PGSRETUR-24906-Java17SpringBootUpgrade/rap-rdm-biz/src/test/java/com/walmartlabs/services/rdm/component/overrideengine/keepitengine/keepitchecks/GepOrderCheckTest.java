package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;
import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.model.dispositionpaths.Item;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class GepOrderCheckTest {
    GepOrderCheck gepOrderCheck;
    KeepItRuleEngineContext keepItRuleEngineContext;
    RDMKeepItConfig rdmKeepItConfig;

    @Before
    public void setup(){
        gepOrderCheck = new GepOrderCheck();
        keepItRuleEngineContext = new KeepItRuleEngineContext();
    }

    @Test
    public void testGetKeepItCheckName() {
        assertEquals(RDMConstants.RULE_CHECK_NAME_GEP_ORDER,gepOrderCheck.getKeepItCheckName());
    }

    @Test
    public void whenGepFlagCCMEnabled_ReturnTrue_testRunCheck() {
        rdmKeepItConfig = new RDMKeepItConfig();
        rdmKeepItConfig.setGepPilotEnabled(true);
        gepOrderCheck.setRdmKeepItConfig(rdmKeepItConfig);
        keepItRuleEngineContext.setItem(getItem(true));
        assertTrue(gepOrderCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenGepFlagCCMDisabled_ReturnFalse_testRunCheck() {
        rdmKeepItConfig = new RDMKeepItConfig();
        rdmKeepItConfig.setGepPilotEnabled(false);
        gepOrderCheck.setRdmKeepItConfig(rdmKeepItConfig);
        keepItRuleEngineContext.setItem(getItem(false));
        assertFalse(gepOrderCheck.runCheck(keepItRuleEngineContext));
    }

    private BaseItem getItem(boolean t) {
        Item item = new Item();
        item.setGep(t);
        return item;
    }
}
