package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.dto.Quantity;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class DamagedItemConditionCheckTest {

    DamagedItemConditionCheck damagedItemConditionCheck;
    RDMKeepItConfig rdmKeepItConfig;
    KeepItRuleEngineContext keepItRuleEngineContext ;
    @Before
    public void setup(){
        damagedItemConditionCheck = new DamagedItemConditionCheck();
        keepItRuleEngineContext = new KeepItRuleEngineContext();
        rdmKeepItConfig = new RDMKeepItConfig();
        rdmKeepItConfig.setEnableDamagedItemRule(true);
        damagedItemConditionCheck.setRdmKeepItConfig(rdmKeepItConfig);
    }


    @Test
    public void testGetKeepItCheckName() {
        assertEquals(RDMConstants.RULE_CHECK_NAME_DAMAGED_ITEM,damagedItemConditionCheck.getKeepItCheckName());
    }

    @Test
    public void whenCCMOnItemConditionNotPresent_returnFalse_testRunCheck() {
        keepItRuleEngineContext.setDispositionInfo(getDispositionPathInfo());
        keepItRuleEngineContext.setItem(getItem(null));
        assertFalse( damagedItemConditionCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenCCMOnItemConditionNotDamaged_returnFalse_testRunCheck() {
        keepItRuleEngineContext.setDispositionInfo(getDispositionPathInfo());
        keepItRuleEngineContext.setItem(getItem("UnOpened"));
        assertFalse( damagedItemConditionCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenCCMOnItemConditionDamaged_returnTrue_testRunCheck() {
        keepItRuleEngineContext.setDispositionInfo(getDispositionPathInfo());
        keepItRuleEngineContext.setItem(getItem("Damaged"));
        assertTrue( damagedItemConditionCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenCCMOnItemConditionDAMAGED_returnTrue_testRunCheck() {
        keepItRuleEngineContext.setDispositionInfo(getDispositionPathInfo());
        keepItRuleEngineContext.setItem(getItem("DAMAGED"));
        assertTrue( damagedItemConditionCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenCCMOffItemConditionDAMAGED_returnFalse_testRunCheck() {
        rdmKeepItConfig = new RDMKeepItConfig();
        rdmKeepItConfig.setEnableDamagedItemRule(false);
        damagedItemConditionCheck.setRdmKeepItConfig(rdmKeepItConfig);
        keepItRuleEngineContext.setDispositionInfo(getDispositionPathInfo());
        keepItRuleEngineContext.setItem(getItem("DAMAGED"));
        assertFalse( damagedItemConditionCheck.runCheck(keepItRuleEngineContext));
    }



    private BaseItem getItem(String s) {
        BaseItem item = new BaseItem();
        Quantity quantity = new Quantity();
        quantity.setMeasurementValue("2");
        quantity.setUnitOfMeasure("EACH");
        item.setQuantity(quantity);
        item.setItemCondition(s);
        item.setItemId("1234");
        return item;
    }

    private DispositionInfo getDispositionPathInfo() {
        DispositionInfo dispositionInfo1 = new DispositionInfo();
        List<DispositionPath> dispositionPaths1 = dispositionInfo1.getDispositionPaths();

        DispositionPath inhome = new DispositionPath();
        inhome.setRank(2);
        inhome.setPath("INHOME_PICKUP");
        DispositionPath store = new DispositionPath();
        store.setRank(1);
        store.setPath("STORE");
        DispositionPath mail = new DispositionPath();
        mail.setRank(3);
        mail.setPath("MAIL");
        DispositionPath carrier_pickup = new DispositionPath();
        carrier_pickup.setRank(4);
        carrier_pickup.setPath("CARRIER_PICKUP");
        DispositionPath fedex_drop = new DispositionPath();
        fedex_drop.setRank(5);
        fedex_drop.setPath("FEDEX_DROP");
        dispositionPaths1.add(inhome);
        dispositionPaths1.add(store);
        dispositionPaths1.add(mail);
        dispositionPaths1.add(carrier_pickup);
        dispositionPaths1.add(fedex_drop);

        dispositionInfo1.setDispositionPaths(dispositionPaths1);
        dispositionInfo1.setIsDefault(false);
        return dispositionInfo1;
    }
}