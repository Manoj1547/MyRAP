package com.walmartlabs.services.rdm.component.ovt.service.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmartlabs.services.rdm.BaseTest;
import com.walmartlabs.services.rdm.NameableThreadFactory;
import com.walmartlabs.services.rdm.component.ovt.model.response.OVTOmniItemPolicyDetails;
import com.walmartlabs.services.rdm.config.client.OVTServiceConfig;
import com.walmartlabs.services.rdm.executors.RdmExecutorService;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.impl.java.OVTOmniDataResolver;
import com.walmartlabs.services.rdm.model.formula.Formula;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import org.junit.Before;
import org.junit.Test;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.*;
import static org.testng.Assert.assertNotNull;

@PrepareForTest({RdmExecutorService.class})
public class OVTOmniDataResolverTest extends BaseTest {
    public static OVTServiceConfig ovtServiceConfig;
    public static OVTOmniServiceHelper ovtOmniServiceHelper;
    public static ExecutorService executor;
    public static RdmExecutorService rdmExecutorService;
    OVTOmniHttpClient ovtOmniHttpClient;

    String testCaseFilePath = "/Users/v0h01q5/rap-rdm/rap-rdm-biz/src/test/resources/ovt_omni_response.json";

    @Before
    public void setup() throws Exception {
        setupTest();
        ovtServiceConfig = mock(OVTServiceConfig.class);
        when(ovtServiceConfig.getOvtServiceCachingEnabled()).thenReturn(false);
        when(ovtServiceConfig.getTimeOut()).thenReturn(300000);
        when(ovtServiceConfig.getServiceEndpoint()).thenReturn("/ovt-services/v2/return-terms/omni");
        when(ovtServiceConfig.getServiceBaseHostUrl()).thenReturn("http://returns.ovt.stg.walmart.com");
        when(ovtServiceConfig.getServiceName()).thenReturn("rap-ovt-services");
        when(ovtServiceConfig.getServiceEnv()).thenReturn("stg");
        when(ovtServiceConfig.getAccept()).thenReturn("application/json");
        when(ovtServiceConfig.getDefaultRegion()).thenReturn("US");
        Set<String> returnTermTypes = new HashSet<>();
        returnTermTypes.add("RETURN_AGREEMENT");
        returnTermTypes.add("RECALL_AGREEMENT");
        when(ovtServiceConfig.getReturnTermTypes()).thenReturn(returnTermTypes);
        when(ovtServiceConfig.getServiceConsumerId()).thenReturn("025f5b71-9926-443f-9250-d3d325885b98");
        ovtOmniServiceHelper = new OVTOmniServiceHelper();
        ovtOmniServiceHelper.setOvtServiceConfig(ovtServiceConfig);
        ovtOmniHttpClient = PowerMockito.spy(new OVTOmniHttpClient());
        ovtOmniHttpClient.setOvtServiceConfig(ovtServiceConfig);
        ovtOmniServiceHelper.setOvtOmniHttpClient(ovtOmniHttpClient);

    }

    @Test
    public void testOVTOmniDataResolver1() throws Exception {
        Formula formula = new Formula();
        Map<String, Object> inputData = prepareInputDataMap();

        OVTOmniDataResolver ovtOmniDataResolver = new OVTOmniDataResolver();
        ovtOmniDataResolver.setOvtServiceConfig(ovtServiceConfig);
        ovtOmniDataResolver.setOvtOmniServiceHelper(ovtOmniServiceHelper);
        ThreadFactory threadFactory = new NameableThreadFactory("rdmExecutorService");
        executor = Executors.newFixedThreadPool(2,threadFactory);

        PowerMockito.mockStatic(RdmExecutorService.class);
        when(rdmExecutorService.getExecutor()).thenReturn(executor);

        Map<String,String> testCases = readTestFile();
        String responseString = testCases.get("KEY1");
        PowerMockito.doReturn(responseString).when(ovtOmniHttpClient,"post", anyString(), anyString(), anyString(), anyMap(),
                anyInt(), any());

        OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails = (OVTOmniItemPolicyDetails) ovtOmniDataResolver.eval(formula,inputData);
        assertNotNull(ovtOmniItemPolicyDetails);
    }

    private Map<String, String> readTestFile() throws IOException {
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("ovt_omni_response.json").getFile());
        return new ObjectMapper().readValue(file,new TypeReference<Map<String, String>>() {});
    }

    @Test
    public void testOVTOmniDataResolverException1() throws Exception {
        Formula formula = new Formula();
        Map<String, Object> inputData = prepareInputDataMap();

        OVTOmniDataResolver ovtOmniDataResolver = new OVTOmniDataResolver();
        ovtOmniDataResolver.setOvtServiceConfig(ovtServiceConfig);
        ovtOmniDataResolver.setOvtOmniServiceHelper(ovtOmniServiceHelper);
        ThreadFactory threadFactory = new NameableThreadFactory("rdmExecutorService");
        executor = Executors.newFixedThreadPool(2,threadFactory);

        PowerMockito.mockStatic(RdmExecutorService.class);
        when(rdmExecutorService.getExecutor()).thenReturn(executor);

        RDMException itemPolicyDetailsException = assertThrows(RDMException.class, () -> {
            OVTOmniItemPolicyDetails eval = (OVTOmniItemPolicyDetails) ovtOmniDataResolver.eval(formula, inputData);
        });
    }

    private Map<String, Object> prepareInputDataMap() {
        Map<String, Object> inputData = new HashMap<>();
        inputData.put(FormulaConstants.VARIABLE_VENDOR_NMUBER,538678);
        inputData.put(FormulaConstants.VARIABLE_DEPARTMENT_NUMBER,79);
        inputData.put(FormulaConstants.VARIABLE_CONTRACT_NUMBER,0);
        inputData.put(FormulaConstants.VARIABLE_DOTCOM_ITEM,false);
        inputData.put(FormulaConstants.INTERNAL_DATA_NAME_ITEM_ID,"241971909");
        return inputData;
    }
}
