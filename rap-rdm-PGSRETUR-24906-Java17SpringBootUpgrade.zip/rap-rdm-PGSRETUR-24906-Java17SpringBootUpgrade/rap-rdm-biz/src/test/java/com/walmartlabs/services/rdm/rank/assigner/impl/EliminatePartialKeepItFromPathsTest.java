package com.walmartlabs.services.rdm.rank.assigner.impl;

import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static com.walmartlabs.services.rdm.util.PartialKeepItUtil.PARTIAL_KEEP_IT_DISPOSITION_PATH;
import static org.junit.Assert.*;

public class EliminatePartialKeepItFromPathsTest {

    List<DispositionInfo> allItemsDispositionInfoList;

    EliminatePartialKeepItFromPaths eliminatePartialKeepItFromPaths;
    @Before
    public void setUp() throws Exception {
        eliminatePartialKeepItFromPaths = new EliminatePartialKeepItFromPaths();

        allItemsDispositionInfoList = new ArrayList<>();
        DispositionInfo dispositionInfo1 = new DispositionInfo();
        List<DispositionPath> dispositionPaths1 = dispositionInfo1.getDispositionPaths();

        DispositionPath partialKeepIt = new DispositionPath();
        partialKeepIt.setRank(1);
        partialKeepIt.setPath(PARTIAL_KEEP_IT_DISPOSITION_PATH);
        DispositionPath lmd = new DispositionPath();
        lmd.setRank(2);
        lmd.setPath("LMD");
        lmd.setValue(Double.valueOf(30));
        DispositionPath store = new DispositionPath();
        store.setRank(3);
        store.setPath("STORE");
        DispositionPath mail = new DispositionPath();
        mail.setRank(5);
        mail.setPath("MAIL");
        DispositionPath curbside = new DispositionPath();
        curbside.setRank(4);
        curbside.setPath("CURB_SIDE");
        curbside.setValue(Double.valueOf(30));
        DispositionPath fedex_drop = new DispositionPath();
        fedex_drop.setRank(6);
        fedex_drop.setPath("FEDEX_DROP");
        dispositionPaths1.add(partialKeepIt);
        dispositionPaths1.add(lmd);
        dispositionPaths1.add(store);
        dispositionPaths1.add(mail);
        dispositionPaths1.add(curbside);
        dispositionPaths1.add(fedex_drop);

        dispositionInfo1.setDispositionPaths(dispositionPaths1);
        dispositionInfo1.setIsDefault(false);
        allItemsDispositionInfoList.add(dispositionInfo1);

    }

    @Test
    public void testAssignRanks_whenPktPresent_removeFromThePaths() {
        eliminatePartialKeepItFromPaths.assignRanks(allItemsDispositionInfoList);

        for (DispositionInfo dispositionInfo : allItemsDispositionInfoList) {
            assertFalse(dispositionInfo.getDispositionPaths().contains(PARTIAL_KEEP_IT_DISPOSITION_PATH));
        }
    }

    @Test
    public void testAssignRanks_whenDispositionPathsIsEmpty_removeFromThePaths() {
        allItemsDispositionInfoList.get(0).getDispositionPaths().clear();
        eliminatePartialKeepItFromPaths.assignRanks(allItemsDispositionInfoList);

        for (DispositionInfo dispositionInfo : allItemsDispositionInfoList) {
            assertFalse(dispositionInfo.getDispositionPaths().contains(PARTIAL_KEEP_IT_DISPOSITION_PATH));
        }
    }
}