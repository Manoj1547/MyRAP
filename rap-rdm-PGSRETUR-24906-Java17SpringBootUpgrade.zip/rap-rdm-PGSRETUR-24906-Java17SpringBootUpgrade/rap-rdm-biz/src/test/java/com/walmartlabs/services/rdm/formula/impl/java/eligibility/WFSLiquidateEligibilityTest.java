package com.walmartlabs.services.rdm.formula.impl.java.eligibility;

import com.walmartlabs.services.rdm.config.client.RestockEligibilityConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.Base;
import com.walmartlabs.services.rdm.model.dispositionpaths.Item;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.formula.Formula;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

public class WFSLiquidateEligibilityTest {

    WFSLiquidateEligibility wfsLiquidateEligibility;
    @Before
    public void setUp() throws Exception {
        wfsLiquidateEligibility = new WFSLiquidateEligibility();
        RestockEligibilityConfig restockEligibilityConfig = new RestockEligibilityConfig();
        restockEligibilityConfig.setRestrictedProductTypes(new ArrayList<>());
        restockEligibilityConfig.getRestrictedProductTypes().add("Alcohol");
        wfsLiquidateEligibility.setRestockEligibilityConfig(restockEligibilityConfig);
    }

    @Test
    public void productTypeIsNotRestricted_returnTrue_testEval() throws VariableMissingException {
        Map<String, Object> inputData = new HashMap<>();
        BaseItem item = new Item();
        item.setProductType("ABC");
        inputData.put(FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM, item);
        assertTrue((Boolean) wfsLiquidateEligibility.eval(new Formula(), inputData));
    }

    @Test
    public void productTypeIsRestricted_returnFalse_testEval() throws VariableMissingException {
        Map<String, Object> inputData = new HashMap<>();
        BaseItem item = new Item();
        item.setProductType("Alcohol");
        inputData.put(FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM, item);
        assertFalse((Boolean) wfsLiquidateEligibility.eval(new Formula(), inputData));
    }

    @Test
    public void productTypeIsNull_returnFalse_testEval() throws VariableMissingException {
        Map<String, Object> inputData = new HashMap<>();
        BaseItem item = new Item();
        inputData.put(FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM, item);
        assertFalse((Boolean) wfsLiquidateEligibility.eval(new Formula(), inputData));
    }
}