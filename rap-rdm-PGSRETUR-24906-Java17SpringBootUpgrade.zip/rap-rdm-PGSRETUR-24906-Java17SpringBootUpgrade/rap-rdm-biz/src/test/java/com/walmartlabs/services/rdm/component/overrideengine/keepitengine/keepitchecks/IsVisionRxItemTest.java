package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import org.junit.Before;
import org.junit.Test;


import java.util.HashMap;
import java.util.Map;

import static com.walmartlabs.services.rdm.RDMConstants.CONFIG_BUNDLE_VISION_RX;
import static org.junit.Assert.*;
import static org.junit.Assert.assertFalse;

public class IsVisionRxItemTest {

    IsVisionRxItem isVisionRxItem;
    KeepItRuleEngineContext keepItRuleEngineContext;


    @Before
    public void setup(){
        isVisionRxItem = new IsVisionRxItem();
        keepItRuleEngineContext = new KeepItRuleEngineContext();
    }


    @Test
    public void testGetKeepItCheckName() {
        assertEquals(RDMConstants.RULE_CHECK_NAME_IS_VISION_RX_ITEM, isVisionRxItem.getKeepItCheckName());
    }

    @Test
    public void shouldReturnTrueWhenVisionRxCustomAttributeValueIsTrue() {
        keepItRuleEngineContext.setItem(getItem("true"));
        assertTrue(isVisionRxItem.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void shouldReturnFalseWhenVisionRxCustomAttributeValueIsFalse() {
        keepItRuleEngineContext.setItem(getItem("false"));
        assertFalse(isVisionRxItem.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void shouldReturnFalseWhenVisionRxCustomAttributeNotPresent() {
        BaseItem item = new BaseItem();
        Map<String,String> itemCustomAttributes = new HashMap<>();
        item.setItemCustomAttributes(itemCustomAttributes);
        keepItRuleEngineContext.setItem(item);
        assertFalse(isVisionRxItem.runCheck(keepItRuleEngineContext));
    }


    private BaseItem getItem(String s) {
        BaseItem item = new BaseItem();
        Map<String,String> itemCustomAttributes = new HashMap<>();
        itemCustomAttributes.put(CONFIG_BUNDLE_VISION_RX,s);
        item.setItemCustomAttributes(itemCustomAttributes);
        return item;
    }
}