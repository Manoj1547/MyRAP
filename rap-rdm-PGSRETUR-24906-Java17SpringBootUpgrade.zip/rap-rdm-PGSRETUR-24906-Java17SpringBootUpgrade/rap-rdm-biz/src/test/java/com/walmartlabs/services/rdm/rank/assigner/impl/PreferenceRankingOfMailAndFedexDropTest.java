package com.walmartlabs.services.rdm.rank.assigner.impl;

import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PreferenceRankingOfMailAndFedexDropTest {

    PreferenceRankingOfMailAndFedexDrop preferenceRankingOfMailAndFedexDrop = new PreferenceRankingOfMailAndFedexDrop();

    @Test
    void whenRequestContainsMailGreaterThanFedex_rankWillRemainSame_testAssignRanks() {
        List<DispositionInfo> allItemsDispositionInfoList = new ArrayList<>();
        DispositionInfo dispositionInfo1 = new DispositionInfo();
        List<DispositionPath> dispositionPaths1 = dispositionInfo1.getDispositionPaths();

        DispositionPath inhome = new DispositionPath();
        inhome.setRank(1);
        inhome.setPath("INHOME_PICKUP");
        inhome.setValue(50.0);
        DispositionPath carrier_pickup = new DispositionPath();
        carrier_pickup.setRank(2);
        carrier_pickup.setPath("CARRIER_PICKUP");
        carrier_pickup.setValue(40.0);
        DispositionPath lmd = new DispositionPath();
        lmd.setRank(3);
        lmd.setPath("LMD");
        lmd.setValue(30.0);
        DispositionPath curbside = new DispositionPath();
        curbside.setRank(4);
        curbside.setPath("CURB_SIDE");
        curbside.setValue(20.0);
        DispositionPath store = new DispositionPath();
        store.setRank(5);
        store.setPath("STORE");
        store.setValue(15.0);
        DispositionPath mail = new DispositionPath();
        mail.setRank(6);
        mail.setPath("MAIL");
        mail.setValue(12.0);
        DispositionPath fedex_drop = new DispositionPath();
        fedex_drop.setRank(7);
        fedex_drop.setPath("FEDEX_DROP");
        fedex_drop.setValue(10.0);
        dispositionPaths1.add(inhome);
        dispositionPaths1.add(lmd);
        dispositionPaths1.add(store);
        dispositionPaths1.add(curbside);
        dispositionPaths1.add(carrier_pickup);
        dispositionPaths1.add(mail);
        dispositionPaths1.add(fedex_drop);

        dispositionInfo1.setDispositionPaths(dispositionPaths1);
        dispositionInfo1.setIsDefault(false);
        dispositionInfo1.setItem(getItem("123","1234","MYACCOUNT"));

        allItemsDispositionInfoList.add(dispositionInfo1);

        preferenceRankingOfMailAndFedexDrop.assignRanks(allItemsDispositionInfoList);

        dispositionInfo1 = allItemsDispositionInfoList.get(0);

        Map<String,Integer> map = new HashMap<>();
        map.put("INHOME_PICKUP",1);
        map.put("CARRIER_PICKUP",2);
        map.put("LMD", 3);
        map.put("CURB_SIDE",4);
        map.put("STORE",5);
        map.put("MAIL",6);
        map.put("FEDEX_DROP",7);


        for(DispositionPath dispositionPath : dispositionInfo1.getDispositionPaths()){
            assertEquals(map.get(dispositionPath.getPath()), dispositionPath.getRank());
        }
    }

    @Test
    void whenRequestContainsOnlyFedex_rankWillRemainSame_testAssignRanks() {
        List<DispositionInfo> allItemsDispositionInfoList = new ArrayList<>();
        DispositionInfo dispositionInfo1 = new DispositionInfo();
        List<DispositionPath> dispositionPaths1 = dispositionInfo1.getDispositionPaths();

        DispositionPath inhome = new DispositionPath();
        inhome.setRank(1);
        inhome.setPath("INHOME_PICKUP");
        inhome.setValue(50.0);
        DispositionPath carrier_pickup = new DispositionPath();
        carrier_pickup.setRank(2);
        carrier_pickup.setPath("CARRIER_PICKUP");
        carrier_pickup.setValue(40.0);
        DispositionPath lmd = new DispositionPath();
        lmd.setRank(3);
        lmd.setPath("LMD");
        lmd.setValue(30.0);
        DispositionPath curbside = new DispositionPath();
        curbside.setRank(4);
        curbside.setPath("CURB_SIDE");
        curbside.setValue(20.0);
        DispositionPath store = new DispositionPath();
        store.setRank(5);
        store.setPath("STORE");
        store.setValue(15.0);
        DispositionPath fedex_drop = new DispositionPath();
        fedex_drop.setRank(6);
        fedex_drop.setPath("FEDEX_DROP");
        fedex_drop.setValue(10.0);
        dispositionPaths1.add(inhome);
        dispositionPaths1.add(lmd);
        dispositionPaths1.add(store);
        dispositionPaths1.add(curbside);
        dispositionPaths1.add(carrier_pickup);
        dispositionPaths1.add(fedex_drop);

        dispositionInfo1.setDispositionPaths(dispositionPaths1);
        dispositionInfo1.setIsDefault(false);
        dispositionInfo1.setItem(getItem("123","1234","MYACCOUNT"));

        allItemsDispositionInfoList.add(dispositionInfo1);

        preferenceRankingOfMailAndFedexDrop.assignRanks(allItemsDispositionInfoList);

        dispositionInfo1 = allItemsDispositionInfoList.get(0);

        Map<String,Integer> map = new HashMap<>();
        map.put("INHOME_PICKUP",1);
        map.put("CARRIER_PICKUP",2);
        map.put("LMD", 3);
        map.put("CURB_SIDE",4);
        map.put("STORE",5);
        map.put("FEDEX_DROP",6);


        for(DispositionPath dispositionPath : dispositionInfo1.getDispositionPaths()){
            assertEquals(map.get(dispositionPath.getPath()), dispositionPath.getRank());
        }
    }

    @Test
    void whenRequestContainsOnlyMail_rankWillRemainSame_testAssignRanks() {
        List<DispositionInfo> allItemsDispositionInfoList = new ArrayList<>();
        DispositionInfo dispositionInfo1 = new DispositionInfo();
        List<DispositionPath> dispositionPaths1 = dispositionInfo1.getDispositionPaths();

        DispositionPath inhome = new DispositionPath();
        inhome.setRank(1);
        inhome.setPath("INHOME_PICKUP");
        inhome.setValue(50.0);
        DispositionPath carrier_pickup = new DispositionPath();
        carrier_pickup.setRank(2);
        carrier_pickup.setPath("CARRIER_PICKUP");
        carrier_pickup.setValue(40.0);
        DispositionPath lmd = new DispositionPath();
        lmd.setRank(3);
        lmd.setPath("LMD");
        lmd.setValue(30.0);
        DispositionPath curbside = new DispositionPath();
        curbside.setRank(4);
        curbside.setPath("CURB_SIDE");
        curbside.setValue(20.0);
        DispositionPath store = new DispositionPath();
        store.setRank(5);
        store.setPath("STORE");
        store.setValue(15.0);
        DispositionPath mail = new DispositionPath();
        mail.setRank(6);
        mail.setPath("MAIL");
        mail.setValue(10.0);
        dispositionPaths1.add(inhome);
        dispositionPaths1.add(lmd);
        dispositionPaths1.add(store);
        dispositionPaths1.add(curbside);
        dispositionPaths1.add(carrier_pickup);
        dispositionPaths1.add(mail);

        dispositionInfo1.setDispositionPaths(dispositionPaths1);
        dispositionInfo1.setIsDefault(false);
        dispositionInfo1.setItem(getItem("123","1234","MYACCOUNT"));

        allItemsDispositionInfoList.add(dispositionInfo1);

        preferenceRankingOfMailAndFedexDrop.assignRanks(allItemsDispositionInfoList);

        dispositionInfo1 = allItemsDispositionInfoList.get(0);

        Map<String,Integer> map = new HashMap<>();
        map.put("INHOME_PICKUP",1);
        map.put("CARRIER_PICKUP",2);
        map.put("LMD", 3);
        map.put("CURB_SIDE",4);
        map.put("STORE",5);
        map.put("MAIL",6);


        for(DispositionPath dispositionPath : dispositionInfo1.getDispositionPaths()){
            assertEquals(map.get(dispositionPath.getPath()), dispositionPath.getRank());
        }

    }

    @Test
    void whenRequestContainsFedexGreaterThanMail_rankWillBeSwapped_testAssignRanks() {
        List<DispositionInfo> allItemsDispositionInfoList = new ArrayList<>();
        DispositionInfo dispositionInfo1 = new DispositionInfo();
        List<DispositionPath> dispositionPaths1 = dispositionInfo1.getDispositionPaths();

        DispositionPath inhome = new DispositionPath();
        inhome.setRank(1);
        inhome.setPath("INHOME_PICKUP");
        inhome.setValue(50.0);
        DispositionPath carrier_pickup = new DispositionPath();
        carrier_pickup.setRank(2);
        carrier_pickup.setPath("CARRIER_PICKUP");
        carrier_pickup.setValue(40.0);
        DispositionPath lmd = new DispositionPath();
        lmd.setRank(3);
        lmd.setPath("LMD");
        lmd.setValue(30.0);
        DispositionPath curbside = new DispositionPath();
        curbside.setRank(4);
        curbside.setPath("CURB_SIDE");
        curbside.setValue(20.0);
        DispositionPath store = new DispositionPath();
        store.setRank(5);
        store.setPath("STORE");
        store.setValue(15.0);
        DispositionPath mail = new DispositionPath();
        mail.setRank(6);
        mail.setPath("MAIL");
        mail.setValue(10.0);
        DispositionPath fedex_drop = new DispositionPath();
        fedex_drop.setRank(7);
        fedex_drop.setPath("FEDEX_DROP");
        fedex_drop.setValue(10.0);
        dispositionPaths1.add(inhome);
        dispositionPaths1.add(lmd);
        dispositionPaths1.add(store);
        dispositionPaths1.add(curbside);
        dispositionPaths1.add(carrier_pickup);
        dispositionPaths1.add(mail);
        dispositionPaths1.add(fedex_drop);

        dispositionInfo1.setDispositionPaths(dispositionPaths1);
        dispositionInfo1.setIsDefault(false);
        dispositionInfo1.setItem(getItem("123","1234","MYACCOUNT"));

        allItemsDispositionInfoList.add(dispositionInfo1);

        preferenceRankingOfMailAndFedexDrop.assignRanks(allItemsDispositionInfoList);

        dispositionInfo1 = allItemsDispositionInfoList.get(0);

        Map<String,Integer> map = new HashMap<>();
        map.put("INHOME_PICKUP",1);
        map.put("CARRIER_PICKUP",2);
        map.put("LMD", 3);
        map.put("CURB_SIDE",4);
        map.put("STORE",5);
        map.put("MAIL",7);
        map.put("FEDEX_DROP",6);


        for(DispositionPath dispositionPath : dispositionInfo1.getDispositionPaths()){
            assertEquals(map.get(dispositionPath.getPath()), dispositionPath.getRank());
        }
    }

    private BaseItem getItem(String orderNo, String itemId, String channelName) {

        BaseItem item = new BaseItem();
        item.setChannelName(channelName);
        item.setOrderNo(orderNo);
        item.setItemId(itemId);
        return item;
    }
}