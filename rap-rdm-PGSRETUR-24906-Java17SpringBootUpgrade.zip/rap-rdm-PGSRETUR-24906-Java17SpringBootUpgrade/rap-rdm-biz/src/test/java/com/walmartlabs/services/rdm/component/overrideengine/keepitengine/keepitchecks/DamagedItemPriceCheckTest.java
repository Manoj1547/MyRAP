package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.services.common.model.money.CurrencyUnitEnum;
import com.walmart.services.common.model.money.MoneyType;
import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.iqs.model.response.*;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.Session;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.junit.Assert.*;

public class DamagedItemPriceCheckTest {
    DamagedItemPriceCheck damagedItemPriceCheck;
    RDMKeepItUtil rdmKeepItUtil;
    RDMKeepItConfig rdmKeepItConfig;
    KeepItRuleEngineContext keepItRuleEngineContext ;
    ObjectMapper objectMapper;
    String divisionWiseKeepItRuleJson = "{\"division\":[{\"divisionName\":\"L0\",\"category\":[{\"categoryName\":\"HOME\",\"enabled\":true,\"threshold\":{\"price\":15,\"quantity\":4}},{\"categoryName\":\"HARDLINES\",\"enabled\":false,\"threshold\":{\"price\":10,\"quantity\":3}}]}]}";
    String derivedPath = "{\"L0\":{\"name\":\"HOME\",\"id\":\"50000\"},\"L1\":{\"name\":\"ELECTRONICS\",\"id\":\"50700\"},\"L2\":{\"name\":\"TVS AUDIO AND VIDEO\",\"id\":\"1050999\"},\"L3\":{\"name\":\"TVS AND PROJECTORS\",\"id\":\"1051086\"},\"L4\":{\"name\":\"VIZIO TVS\",\"id\":\"1051172\"}}";

    @Before
    public void setup(){
        damagedItemPriceCheck = new DamagedItemPriceCheck();
        keepItRuleEngineContext = new KeepItRuleEngineContext();
//        rdmKeepItConfig.setThresholdForDamagedItemPrice(4d);
//        damagedItemPriceCheck.setRdmKeepItConfig(rdmKeepItConfig);
        objectMapper = new ObjectMapper();
        rdmKeepItConfig = new RDMKeepItConfig();
        rdmKeepItConfig.setIsConfigUpdated(Boolean.FALSE);
        rdmKeepItConfig.setDamagedItemKeepItRuleDivisionWise(divisionWiseKeepItRuleJson);
        rdmKeepItUtil = new RDMKeepItUtil();
        rdmKeepItUtil.setRdmKeepItConfig(rdmKeepItConfig);
        rdmKeepItUtil.setObjectMapper(objectMapper);
        damagedItemPriceCheck.setRdmKeepItUtil(rdmKeepItUtil);
//        Session session = new Session();
//        session.setOutputData(new HashMap<>());
//        keepItRuleEngineContext.setSession(session);
//        session.getOutputData().put(FormulaConstants.VARIABLE_IS_DOTCOM, true);
    }


    @Test
    public void testGetKeepItCheckName() {
        assertEquals(RDMConstants.RULE_CHECK_NAME_DAMAGED_ITEM_PRICE, damagedItemPriceCheck.getKeepItCheckName());
    }

    @Test
    public void whenPriceMoreThanThreshold_returnFalse_testRunCheck() {
        keepItRuleEngineContext.setDispositionInfo(getDispositionPathInfo());
        keepItRuleEngineContext.setItem(getItem(BigDecimal.valueOf(25)));
        keepItRuleEngineContext.setSession(getSession(derivedPath));
        assertFalse(damagedItemPriceCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenPriceLessThanThreshold_returnTrue_testRunCheck() {
        keepItRuleEngineContext.setDispositionInfo(getDispositionPathInfo());
        keepItRuleEngineContext.setItem(getItem(BigDecimal.ONE));
        keepItRuleEngineContext.setSession(getSession(derivedPath));
        assertTrue( damagedItemPriceCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenPriceEqualsToThreshold_returnFalse_testRunCheck() {
        keepItRuleEngineContext.setDispositionInfo(getDispositionPathInfo());
        keepItRuleEngineContext.setItem(getItem(BigDecimal.valueOf(15)));
        keepItRuleEngineContext.setSession(getSession(derivedPath));
        assertFalse(damagedItemPriceCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenPriceNotPresent_returnFalse_testRunCheck() {
        keepItRuleEngineContext.setDispositionInfo(getDispositionPathInfo());
        keepItRuleEngineContext.setItem(getItem(BigDecimal.valueOf(15)));
        keepItRuleEngineContext.setSession(getSession("{\"L0\":{\"name\":\"HARDLINES\",\"id\":\"50000\"}}"));
        assertFalse(damagedItemPriceCheck.runCheck(keepItRuleEngineContext));
    }

    private BaseItem getItem(BigDecimal d) {
        BaseItem item = new BaseItem();
        MoneyType moneyType = new MoneyType(d, CurrencyUnitEnum.USD);
        item.setUnitPrice(moneyType);
        item.setItemId("1234");
        return item;
    }

    private DispositionInfo getDispositionPathInfo() {
        DispositionInfo dispositionInfo1 = new DispositionInfo();
        List<DispositionPath> dispositionPaths1 = dispositionInfo1.getDispositionPaths();

        DispositionPath inhome = new DispositionPath();
        inhome.setRank(2);
        inhome.setPath("INHOME_PICKUP");
        DispositionPath store = new DispositionPath();
        store.setRank(1);
        store.setPath("STORE");
        DispositionPath mail = new DispositionPath();
        mail.setRank(3);
        mail.setPath("MAIL");
        DispositionPath carrier_pickup = new DispositionPath();
        carrier_pickup.setRank(4);
        carrier_pickup.setPath("CARRIER_PICKUP");
        DispositionPath fedex_drop = new DispositionPath();
        fedex_drop.setRank(5);
        fedex_drop.setPath("FEDEX_DROP");
        dispositionPaths1.add(inhome);
        dispositionPaths1.add(store);
        dispositionPaths1.add(mail);
        dispositionPaths1.add(carrier_pickup);
        dispositionPaths1.add(fedex_drop);

        dispositionInfo1.setDispositionPaths(dispositionPaths1);
        dispositionInfo1.setIsDefault(false);
        return dispositionInfo1;
    }

    private Session getSession(String path) {
        GetItemDetailsResponse getItemDetailsResponse = new GetItemDetailsResponse();
        Product product = new Product();
        DerivedAttributes derivedAttributes = new DerivedAttributes();
        R2D2Hierarchy r2D2Hierarchy = new R2D2Hierarchy();
        Value value = new Value();
        value.setPath(path);
        List<Value> valueList = new ArrayList<>();
        valueList.add(value);
        r2D2Hierarchy.setValues(valueList);
        derivedAttributes.setR2D2Hierarchy(r2D2Hierarchy);
        product.setDerivedAttributes(derivedAttributes);
        getItemDetailsResponse.setProduct(product);
        CompletableFuture<GetItemDetailsResponse> itemDetailsResponse = CompletableFuture.completedFuture(getItemDetailsResponse);
        Map<String, Object> outputData = new HashMap<>();
        outputData.put(FormulaConstants.INTERNAL_DATA_NAME_IQSRDM_FUTURE, itemDetailsResponse);
        outputData.put(FormulaConstants.VARIABLE_IS_DOTCOM, true);
        Session session = new Session();
        session.setOutputData(outputData);
        return session;
    }
}