package com.walmartlabs.services.rdm.formula.impl.java;

import com.walmartlabs.services.rdm.BaseTest;
import com.walmartlabs.services.rdm.NameableThreadFactory;
import com.walmartlabs.services.rdm.component.ovt.model.response.OVTOmniItemPolicyDetails;
import com.walmartlabs.services.rdm.component.ovt.service.util.OVTOmniHttpClient;
import com.walmartlabs.services.rdm.component.ovt.service.util.OVTOmniServiceHelper;
import com.walmartlabs.services.rdm.config.client.OVTServiceConfig;
import com.walmartlabs.services.rdm.executors.RdmExecutorService;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.model.formula.Formula;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import org.junit.Before;
import org.junit.Test;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;

import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.*;
import static org.testng.Assert.assertNotNull;

@PrepareForTest({RdmExecutorService.class})
public class OVTOmniDataResolverTest extends BaseTest {
    public static OVTServiceConfig ovtServiceConfig;
    public static OVTOmniServiceHelper ovtOmniServiceHelper;
    public static ExecutorService executor;
    public static RdmExecutorService rdmExecutorService;
    OVTOmniHttpClient ovtOmniHttpClient;
    @Before
    public void setup() throws Exception {
        setupTest();
        ovtServiceConfig = mock(OVTServiceConfig.class);
        when(ovtServiceConfig.getOvtServiceCachingEnabled()).thenReturn(false);
        when(ovtServiceConfig.getTimeOut()).thenReturn(300000);
        when(ovtServiceConfig.getServiceEndpoint()).thenReturn("/ovt-services/v2/return-terms/omni");
        when(ovtServiceConfig.getServiceBaseHostUrl()).thenReturn("http://returns.ovt.stg.walmart.com");
        when(ovtServiceConfig.getServiceName()).thenReturn("rap-ovt-services");
        when(ovtServiceConfig.getServiceEnv()).thenReturn("stg");
        when(ovtServiceConfig.getAccept()).thenReturn("application/json");
        when(ovtServiceConfig.getDefaultRegion()).thenReturn("US");
        Set<String> returnTermTypes = new HashSet<>();
        returnTermTypes.add("RETURN_AGREEMENT");
        returnTermTypes.add("RECALL_AGREEMENT");
        when(ovtServiceConfig.getReturnTermTypes()).thenReturn(returnTermTypes);
        when(ovtServiceConfig.getServiceConsumerId()).thenReturn("025f5b71-9926-443f-9250-d3d325885b98");
        ovtOmniServiceHelper = new OVTOmniServiceHelper();
        ovtOmniServiceHelper.setOvtServiceConfig(ovtServiceConfig);
        ovtOmniHttpClient = PowerMockito.spy(new OVTOmniHttpClient());
        ovtOmniHttpClient.setOvtServiceConfig(ovtServiceConfig);
        ovtOmniServiceHelper.setOvtOmniHttpClient(ovtOmniHttpClient);

    }

    @Test
    public void ovtOmniDataResolver_WhenClientGivesNonNullResponse_GivesNonNullResponse() throws Exception {
        Formula formula = new Formula();
        Map<String, Object> inputData = prepareInputDataMap();

        OVTOmniDataResolver ovtOmniDataResolver = new OVTOmniDataResolver();
        ovtOmniDataResolver.ovtServiceConfig = ovtServiceConfig;
        ovtOmniDataResolver.ovtOmniServiceHelper = ovtOmniServiceHelper;
        ThreadFactory threadFactory = new NameableThreadFactory("rdmExecutorService");
        executor = Executors.newFixedThreadPool(2,threadFactory);

        PowerMockito.mockStatic(RdmExecutorService.class);
        when(rdmExecutorService.getExecutor()).thenReturn(executor);

        String responseString = "{\"status\":\"OK\",\"header\":{\"headerAttributes\":{}},\"errors\":[],\"payload\":{\"returnTerms\":[{\"vendorNo\":\"538678\",\"departmentNo\":\"79\",\"contractNo\":\"0\",\"tenantId\":\"WM.COM\",\"region\":\"US\",\"ovtId\":\"9CAttmuQ\",\"modifyUserId\":\"DUMMY_USER\",\"modifyTs\":\"2019-08-29T07:42:41.000+00:00\",\"startDate\":\"2019-08-29\",\"agreementStatus\":\"A\",\"returnTermType\":\"RETURN_AGREEMENT\",\"returnTermPolicies\":[{\"policyType\":\"RA_ADDRESS_POLICY\",\"keyTemplate\":\"/addressType/addressGroupNo\",\"policies\":[{\"policyKey\":\"/dmb/all\",\"attributeList\":[{\"name\":\"state\",\"value\":\"\",\"unit\":\"String\"},{\"name\":\"addressLine2\",\"value\":\"\",\"unit\":\"String\"},{\"name\":\"addressLine1\",\"value\":\"\",\"unit\":\"String\"},{\"name\":\"zip\",\"value\":\"\",\"unit\":\"String\"},{\"name\":\"country\",\"value\":\"\",\"unit\":\"String\"},{\"name\":\"city\",\"value\":\"\",\"unit\":\"String\"}]},{\"policyKey\":\"/rc/1\",\"attributeList\":[{\"name\":\"addressLine1\",\"value\":\"\",\"unit\":\"String\"},{\"name\":\"country\",\"value\":\"\",\"unit\":\"String\"},{\"name\":\"city\",\"value\":\"\",\"unit\":\"String\"},{\"name\":\"attentionName\",\"value\":\"\",\"unit\":\"String\"},{\"name\":\"faxNo\",\"value\":\"\",\"unit\":\"String\"},{\"name\":\"phoneNo\",\"value\":\"\",\"unit\":\"String\"},{\"name\":\"state\",\"value\":\"\",\"unit\":\"String\"},{\"name\":\"email\",\"value\":\"\",\"unit\":\"String\"},{\"name\":\"faxCountryCode\",\"value\":\"1\",\"unit\":\"String\"},{\"name\":\"addressLine2\",\"value\":\"\",\"unit\":\"String\"},{\"name\":\"phoneCountryCode\",\"value\":\"1\",\"unit\":\"String\"},{\"name\":\"zip\",\"value\":\"\",\"unit\":\"String\"}]},{\"policyKey\":\"/all/all\",\"attributeList\":[{\"name\":\"isSupplierReturnAddressForRC\",\"value\":\"false\",\"unit\":\"Boolean\"},{\"name\":\"isDMBEnabled\",\"value\":\"false\",\"unit\":\"Boolean\"}]}]},{\"policyType\":\"RA_AUTHORIZATION_POLICY\",\"keyTemplate\":\"/authorizationType\",\"policies\":[{\"policyKey\":\"/all\",\"attributeList\":[{\"name\":\"rarMode\",\"value\":\"N\",\"unit\":\"String\"},{\"name\":\"rptRaNum\",\"value\":\"\",\"unit\":\"String\"}]},{\"policyKey\":\"/auth\",\"attributeList\":[{\"name\":\"email\",\"value\":\"\",\"unit\":\"String\"},{\"name\":\"faxNo\",\"value\":\"\",\"unit\":\"String\"},{\"name\":\"authorizedBy\",\"value\":\"\",\"unit\":\"String\"},{\"name\":\"phoneNo\",\"value\":\"\",\"unit\":\"String\"}]}]},{\"policyType\":\"RA_BASE_AGREEMENT_POLICY\",\"keyTemplate\":\"/returnAgreement\",\"policies\":[{\"policyKey\":\"/all\",\"attributeList\":[{\"name\":\"distributorNumber\",\"value\":\"\",\"unit\":\"String\"},{\"name\":\"agreementNo\",\"value\":\"538678-79-0\",\"unit\":\"String\"},{\"name\":\"departmentName\",\"value\":\"INFANT CONSUMABLE HARDLINES\",\"unit\":\"String\"},{\"name\":\"agreementType\",\"value\":\"\",\"unit\":\"String\"},{\"name\":\"rptWoCntrct\",\"value\":\"false\",\"unit\":\"Boolean\"},{\"name\":\"vendorName\",\"value\":\"VARIOUS-REACT\",\"unit\":\"String\"},{\"name\":\"statusChangeReason\",\"value\":\"\",\"unit\":\"String\"}]}]},{\"policyType\":\"RA_CLAIM_POLICY\",\"keyTemplate\":\"/returnAgreement\",\"policies\":[{\"policyKey\":\"/all\",\"attributeList\":[{\"name\":\"apCode\",\"value\":\"AP\",\"unit\":\"String\"},{\"name\":\"supplierHandlingFee\",\"value\":\"0\",\"unit\":\"Double\"},{\"name\":\"creditPercent\",\"value\":\"100.00\",\"unit\":\"Double\"},{\"name\":\"isClaimable\",\"value\":\"true\",\"unit\":\"Boolean\"}]}]},{\"policyType\":\"RA_DISPOSITION_POLICY\",\"keyTemplate\":\"/returnAgreement\",\"policies\":[{\"policyKey\":\"/all\",\"attributeList\":[{\"name\":\"rptDestination\",\"value\":\"SL\",\"unit\":\"String\"},{\"name\":\"returnCentreDisposition\",\"value\":\"L\",\"unit\":\"String\"},{\"name\":\"restockableAtStore\",\"value\":\"true\",\"unit\":\"Boolean\"},{\"name\":\"cvpEligibleAtStore\",\"value\":\"true\",\"unit\":\"Boolean\"}]}]},{\"policyType\":\"RA_FREIGHT_POLICY\",\"keyTemplate\":\"/freightType\",\"policies\":[{\"policyKey\":\"/primary\",\"attributeList\":[{\"name\":\"carrierScac\",\"value\":\"\",\"unit\":\"String\"},{\"name\":\"carrier\",\"value\":\"\",\"unit\":\"String\"}]},{\"policyKey\":\"/all\",\"attributeList\":[{\"name\":\"freightPolicy\",\"value\":\"\",\"unit\":\"String\"}]}]},{\"policyType\":\"RA_NOTES_POLICY\",\"keyTemplate\":\"/returnAgreement\",\"policies\":[{\"policyKey\":\"/all\",\"attributeList\":[{\"name\":\"internalNotes\",\"value\":\"\",\"unit\":\"String\"}]}]}]}]}}";
        PowerMockito.doReturn(responseString).when(ovtOmniHttpClient,"post", anyString(), anyString(), anyString(), anyMap(),
                anyInt(), any());
        assertNotNull(ovtOmniDataResolver.eval(formula,inputData));
    }

    @Test
    public void ovtOmniDataResolver_WhenClientGivesException_ThrowsRdmException() throws Exception {
        Formula formula = new Formula();
        Map<String, Object> inputData = prepareInputDataMap();

        OVTOmniDataResolver ovtOmniDataResolver = new OVTOmniDataResolver();
        ovtOmniDataResolver.ovtServiceConfig = ovtServiceConfig;
        ovtOmniDataResolver.ovtOmniServiceHelper = ovtOmniServiceHelper;
        ThreadFactory threadFactory = new NameableThreadFactory("rdmExecutorService");
        executor = Executors.newFixedThreadPool(2,threadFactory);

        PowerMockito.mockStatic(RdmExecutorService.class);
        when(rdmExecutorService.getExecutor()).thenReturn(executor);

        RDMException itemPolicyDetailsException = assertThrows(RDMException.class, () -> {
            OVTOmniItemPolicyDetails eval = (OVTOmniItemPolicyDetails) ovtOmniDataResolver.eval(formula, inputData);
        });
    }

    private Map<String, Object> prepareInputDataMap() {
        Map<String, Object> inputData = new HashMap<>();
        inputData.put(FormulaConstants.VARIABLE_VENDOR_NMUBER,538678);
        inputData.put(FormulaConstants.VARIABLE_DEPARTMENT_NUMBER,79);
        inputData.put(FormulaConstants.VARIABLE_CONTRACT_NUMBER,0);
        inputData.put(FormulaConstants.VARIABLE_DOTCOM_ITEM,false);
        inputData.put(FormulaConstants.INTERNAL_DATA_NAME_ITEM_ID,"241971909");
        return inputData;
    }
}
