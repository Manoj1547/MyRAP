package com.walmartlabs.services.rdm.formula.impl.java;

import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.Formula;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.Collections;

@RunWith(PowerMockRunner.class)
@PrepareForTest({FormulaEngine.class})
public class CvpProbabilityOfSaleResolverTest {

    private CvpProbabilityOfSaleResolver cvpProbabilityOfSaleResolver;
    private RDMSwitches rdmSwitches;

    @Before
    public void setUp() {
        cvpProbabilityOfSaleResolver = new CvpProbabilityOfSaleResolver();
        rdmSwitches = new RDMSwitches();
        rdmSwitches.setFixedProbabilityOfSale("1.0");
        rdmSwitches.setDefaultProbabilityOfSale("0.6334");
        rdmSwitches.setProbabilityOfSaleEnabled(true);
        cvpProbabilityOfSaleResolver.setSwitches(rdmSwitches);
        PowerMockito.mockStatic(FormulaEngine.class);
    }

    @Test
    public void eval_whenProbOfSaleDisabled_thenReturnFalse() throws VariableMissingException {

        rdmSwitches.setProbabilityOfSaleEnabled(false);
        Double probabilityOfSale = cvpProbabilityOfSaleResolver.eval(new Formula(), Collections.emptyMap());
        Assertions.assertEquals(1.0, probabilityOfSale);
    }

    @Test
    public void eval_whenPosItemIsNotNull_thenReturnValue() throws VariableMissingException {
        rdmSwitches.setProbabilityOfSaleEnabled(true);
        PowerMockito.when(FormulaEngine.getInput(Mockito.any(), Mockito.anyMap(), Mockito.anyString())).thenReturn(0.523);
        Double probabilityOfSale = cvpProbabilityOfSaleResolver.eval(new Formula(), Collections.emptyMap());
        Assertions.assertEquals(0.523, probabilityOfSale);
    }

    @Test
    public void eval_whenPosItemIsNull_thenExecutePosDept() throws VariableMissingException {
        rdmSwitches.setProbabilityOfSaleEnabled(true);
        PowerMockito.when(FormulaEngine.getInput(Mockito.any(), Mockito.anyMap(), Mockito.anyString())).thenReturn(null, 0.523);
        Double probabilityOfSale = cvpProbabilityOfSaleResolver.eval(new Formula(), Collections.emptyMap());
        Assertions.assertEquals(0.523, probabilityOfSale);
    }

    @Test
    public void eval_whenPosItemIsMinusOne_thenExecutePosDept() throws VariableMissingException {
        rdmSwitches.setProbabilityOfSaleEnabled(true);
        PowerMockito.when(FormulaEngine.getInput(Mockito.any(), Mockito.anyMap(), Mockito.anyString())).thenReturn(-1.0, 0.523);
        Double probabilityOfSale = cvpProbabilityOfSaleResolver.eval(new Formula(), Collections.emptyMap());
        Assertions.assertEquals(0.523, probabilityOfSale);
    }

    @Test
    public void eval_whenPosItemAndPosDeptIsNull_thenReturnDefault() throws VariableMissingException {
        rdmSwitches.setProbabilityOfSaleEnabled(true);
        PowerMockito.when(FormulaEngine.getInput(Mockito.any(), Mockito.anyMap(), Mockito.anyString())).thenReturn(null, null);
        Double probabilityOfSale = cvpProbabilityOfSaleResolver.eval(new Formula(), Collections.emptyMap());
        Assertions.assertEquals(0.6334, probabilityOfSale);

    }

    @Test
    public void eval_whenPosItemIsMinusOneAndPosDeptIsNull_thenReturnDefault() throws VariableMissingException {
        rdmSwitches.setProbabilityOfSaleEnabled(true);
        PowerMockito.when(FormulaEngine.getInput(Mockito.any(), Mockito.anyMap(), Mockito.anyString())).thenReturn(null, null);
        Double probabilityOfSale = cvpProbabilityOfSaleResolver.eval(new Formula(), Collections.emptyMap());
        Assertions.assertEquals(0.6334, probabilityOfSale);
    }

}
