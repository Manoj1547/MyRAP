package com.walmartlabs.services.rdm.rank.assigner.impl;

import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

public class RankOnCommonAggregatedValueTest {

    RankOnCommonAggregatedValue rankOnCommonAggregatedValue = new RankOnCommonAggregatedValue();

    ObjectMapper objectMapper = new ObjectMapper();

    @Test
    void testAssignRanks_segregate_wfs_onep() throws IOException {
        TypeReference<List<DispositionInfo>> typeRef = new TypeReference<List<DispositionInfo>>() {
        };
        List<DispositionInfo> allItemsDispositionInfoList = objectMapper.readValue(getClass().getClassLoader().getResource("rankOnCommonAggregatedValue_input1.json"), typeRef);
        rankOnCommonAggregatedValue.assignRanks(allItemsDispositionInfoList);


        DispositionInfo dispositionInfo = allItemsDispositionInfoList.get(1);
        dispositionInfo.getDispositionPaths().size();
        assertEquals(4, dispositionInfo.getDispositionPaths().size());

        DispositionInfo dispositionInfo1 = allItemsDispositionInfoList.get(2);
        dispositionInfo1.getDispositionPaths().size();
        assertEquals(4, dispositionInfo1.getDispositionPaths().size());

        DispositionInfo dispositionInfo2 = allItemsDispositionInfoList.get(0);
        dispositionInfo2.getDispositionPaths().size();
        assertEquals(5, dispositionInfo2.getDispositionPaths().size());

        Map<String, Integer> map = new HashMap<>();
        map.put("CURB_SIDE", 1);
        map.put("MAIL", 2);
        map.put("CARRIER_PICKUP", 3);
        map.put("FEDEX_DROP", 4);

        for (DispositionPath dispositionPath : dispositionInfo.getDispositionPaths()) {
            assertEquals(map.get(dispositionPath.getPath()), dispositionPath.getRank());
        }

        Map<String, Integer> map1 = new HashMap<>();
        map1.put("CURB_SIDE", 1);
        map1.put("MAIL", 2);
        map1.put("CARRIER_PICKUP", 3);
        map1.put("STORE", 4);

        for (DispositionPath dispositionPath : dispositionInfo1.getDispositionPaths()) {
            assertEquals(map1.get(dispositionPath.getPath()), dispositionPath.getRank());
        }

        Map<String, Integer> map2 = new HashMap<>();
        map2.put("STORE", 1);
        map2.put("CURB_SIDE", 2);
        map2.put("MAIL", 3);
        map2.put("FEDEX_DROP", 4);
        map2.put("CARRIER_PICKUP", 5);

        for (DispositionPath dispositionPath : dispositionInfo2.getDispositionPaths()) {
            System.out.println(dispositionPath.getPath() + ": " + dispositionPath.getRank());
            assertNotEquals(map2.get(dispositionPath.getPath()), dispositionPath.getRank());
        }
    }


   /* @Test
    void testAssignRanks_segregate_wfs_onep_with_default() throws IOException {
        TypeReference<List<DispositionInfo>> typeRef = new TypeReference<List<DispositionInfo>>() {
        };
        List<DispositionInfo> allItemsDispositionInfoList = objectMapper.readValue(getClass().getClassLoader().getResource("rankOnCommonAggregatedValue_input2.json"), typeRef);
        rankOnCommonAggregatedValue.assignRanks(allItemsDispositionInfoList);


        DispositionInfo dispositionInfo = allItemsDispositionInfoList.get(1);
        dispositionInfo.getDispositionPaths().size();
        assertEquals(4, dispositionInfo.getDispositionPaths().size());

        DispositionInfo dispositionInfo1 = allItemsDispositionInfoList.get(2);
        dispositionInfo1.getDispositionPaths().size();
        assertEquals(4, dispositionInfo1.getDispositionPaths().size());

        DispositionInfo dispositionInfo2 = allItemsDispositionInfoList.get(0);
        dispositionInfo2.getDispositionPaths().size();
        assertEquals(5, dispositionInfo2.getDispositionPaths().size());

        Map<String, Integer> map = new HashMap<>();
        map.put("CURB_SIDE", 1);
        map.put("MAIL", 1);
        map.put("FEDEX_DROP", 1);
        map.put("CARRIER_PICKUP", 1);

        for (DispositionPath dispositionPath : dispositionInfo.getDispositionPaths()) {
            assertEquals(map.get(dispositionPath.getPath()), dispositionPath.getRank());
        }

        Map<String, Integer> map1 = new HashMap<>();
        map1.put("STORE", 1);
        map1.put("CURB_SIDE", 2);
        map1.put("MAIL", 3);
        map1.put("CARRIER_PICKUP", 4);

        for (DispositionPath dispositionPath : dispositionInfo1.getDispositionPaths()) {
            assertEquals(map1.get(dispositionPath.getPath()), dispositionPath.getRank());
        }

        Map<String, Integer> map2 = new HashMap<>();
        map2.put("STORE", 1);
        map2.put("CURB_SIDE", 2);
        map2.put("MAIL", 3);
        map2.put("FEDEX_DROP", 4);
        map2.put("CARRIER_PICKUP", 5);

        for (DispositionPath dispositionPath : dispositionInfo2.getDispositionPaths()) {
            System.out.println(dispositionPath.getPath() + ": " + dispositionPath.getRank());
            assertEquals(map2.get(dispositionPath.getPath()), dispositionPath.getRank());
        }
    }*/


    @Test
    void testAssignRanks_segregate_wfs_onep_non_common() throws IOException {
        TypeReference<List<DispositionInfo>> typeRef = new TypeReference<List<DispositionInfo>>() {
        };
        List<DispositionInfo> allItemsDispositionInfoList = objectMapper.readValue(getClass().getClassLoader().getResource("rankOnCommonAggregatedValue_input3.json"), typeRef);
        rankOnCommonAggregatedValue.assignRanks(allItemsDispositionInfoList);


        DispositionInfo dispositionInfo = allItemsDispositionInfoList.get(1);
        dispositionInfo.getDispositionPaths().size();
        assertEquals(2, dispositionInfo.getDispositionPaths().size());

        DispositionInfo dispositionInfo1 = allItemsDispositionInfoList.get(2);
        dispositionInfo1.getDispositionPaths().size();
        assertEquals(2, dispositionInfo1.getDispositionPaths().size());

        DispositionInfo dispositionInfo2 = allItemsDispositionInfoList.get(0);
        dispositionInfo2.getDispositionPaths().size();
        assertEquals(5, dispositionInfo2.getDispositionPaths().size());

        Map<String, Integer> map = new HashMap<>();
        map.put("CURB_SIDE", 1);
        map.put("MAIL", 2);

        for (DispositionPath dispositionPath : dispositionInfo.getDispositionPaths()) {
            assertEquals(map.get(dispositionPath.getPath()), dispositionPath.getRank());
        }

        Map<String, Integer> map1 = new HashMap<>();
        map1.put("STORE", 1);
        map1.put("CARRIER_PICKUP", 2);

        for (DispositionPath dispositionPath : dispositionInfo1.getDispositionPaths()) {
            assertEquals(map1.get(dispositionPath.getPath()), dispositionPath.getRank());
        }

        Map<String, Integer> map2 = new HashMap<>();
        map2.put("STORE", 1);
        map2.put("CURB_SIDE", 2);
        map2.put("MAIL", 3);
        map2.put("FEDEX_DROP", 4);
        map2.put("CARRIER_PICKUP", 5);

        for (DispositionPath dispositionPath : dispositionInfo2.getDispositionPaths()) {
            assertEquals(map2.get(dispositionPath.getPath()), dispositionPath.getRank());
        }
    }

    @Test
    void testAssignRanks_segregate_wfs_onep_without_sellerType() throws IOException {
        TypeReference<List<DispositionInfo>> typeRef = new TypeReference<List<DispositionInfo>>() {
        };
        List<DispositionInfo> allItemsDispositionInfoList = objectMapper.readValue(getClass().getClassLoader().getResource("rankOnCommonAggregatedValue_input4.json"), typeRef);
        rankOnCommonAggregatedValue.assignRanks(allItemsDispositionInfoList);


        DispositionInfo dispositionInfo = allItemsDispositionInfoList.get(1);
        dispositionInfo.getDispositionPaths().size();
        assertEquals(4, dispositionInfo.getDispositionPaths().size());

        DispositionInfo dispositionInfo1 = allItemsDispositionInfoList.get(2);
        dispositionInfo1.getDispositionPaths().size();
        assertEquals(4, dispositionInfo1.getDispositionPaths().size());

        DispositionInfo dispositionInfo2 = allItemsDispositionInfoList.get(0);

        System.out.println(dispositionInfo2.toString());

        dispositionInfo2.getDispositionPaths().size();
        assertEquals(5, dispositionInfo2.getDispositionPaths().size());

        Map<String, Integer> map = new HashMap<>();
        map.put("CURB_SIDE", 1);
        map.put("MAIL", 2);
        map.put("FEDEX_DROP", 3);
        map.put("CARRIER_PICKUP", 4);

        for (DispositionPath dispositionPath : dispositionInfo.getDispositionPaths()) {
            assertEquals(map.get(dispositionPath.getPath()), dispositionPath.getRank());
        }

        Map<String, Integer> map1 = new HashMap<>();
        map1.put("STORE", 1);
        map1.put("CURB_SIDE", 2);
        map1.put("MAIL", 3);
        map1.put("CARRIER_PICKUP", 4);

        for (DispositionPath dispositionPath : dispositionInfo1.getDispositionPaths()) {
            assertEquals(map1.get(dispositionPath.getPath()), dispositionPath.getRank());
        }

        Map<String, Integer> map2 = new HashMap<>();
        map2.put("STORE", 1);
        map2.put("CURB_SIDE", 2);
        map2.put("MAIL", 3);
        map2.put("FEDEX_DROP", 5);
        map2.put("CARRIER_PICKUP", 4);

        for (DispositionPath dispositionPath : dispositionInfo2.getDispositionPaths()) {
            assertEquals(map2.get(dispositionPath.getPath()), dispositionPath.getRank());
        }
    }


}
