package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.KeepItInfo;
import org.junit.Before;
import org.junit.Test;
import org.testng.Assert;

import java.util.HashMap;
import java.util.Map;

public class InebItemCheckTest {
    InebItemCheck inebItemCheck = new InebItemCheck();
    RDMKeepItUtil rdmKeepItUtil;
    KeepItRuleEngineContext keepItRuleEngineContext;

    @Before
    public void setUp() {
        rdmKeepItUtil = new RDMKeepItUtil();
        keepItRuleEngineContext = new KeepItRuleEngineContext();
        inebItemCheck.setRdmKeepItUtil(rdmKeepItUtil);
    }

    @Test
    public void testGetName() {
        Assert.assertEquals(inebItemCheck.getKeepItCheckName(), RDMConstants.RULE_CHECK_NAME_IS_INEB_ITEM);
    }

    @Test
    public void testRunCheck() {
        BaseItem item = getItem();
        keepItRuleEngineContext.setItem(item);
        Assert.assertTrue(inebItemCheck.runCheck(keepItRuleEngineContext));
    }

    private BaseItem getItem() {
        BaseItem item = new BaseItem();
        Map<String,String> customAttributes = new HashMap<>();
        customAttributes.put(RDMConstants.IS_INEB,RDMConstants.TRUE);
        KeepItInfo keepItInfo = new KeepItInfo();
        keepItInfo.setTrustCustomerToKeepIt(true);
        item.setKeepItInfo(keepItInfo);
        item.setItemCustomAttributes(customAttributes);
        return item;
    }
}