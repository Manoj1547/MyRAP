package com.walmartlabs.services.rdm;

import com.walmart.platform.txnmarking.impl.TransactionImpl;
import com.walmart.platform.txnmarking.impl.service.DefaultTransactionMarkingService;
import com.walmart.services.rap.common.BeanHelper;
import com.walmartlabs.services.rdm.config.client.ConfigManager;
import io.strati.txnmarking.TransactionMarkingService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeClass;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.when;
import org.powermock.modules.junit4.PowerMockRunner;


@RunWith(PowerMockRunner.class)
@PrepareForTest( {LoggerFactory.class,ConfigManager.class, BeanHelper.class, TransactionImpl.class, LogFactory.class})
public class BaseTest {
  public static ConfigManager configManager;
  public static TransactionMarkingService TMS;
  public static TransactionImpl transaction;

  @BeforeClass
  public static void setupTest(){
    Logger logger = mock(Logger.class);
    PowerMockito.mockStatic(LoggerFactory.class);
    PowerMockito.when(LoggerFactory.getLogger(any(Class.class))).thenReturn(logger);

    Log log = mock(Log.class);
    PowerMockito.mockStatic(LogFactory.class);
    PowerMockito.when(LogFactory.getLog((any(Class.class)))).thenReturn(log);

    configManager = mock(ConfigManager.class);
    PowerMockito.mockStatic(ConfigManager.class);
    PowerMockito.when(ConfigManager.getInstance()).thenReturn(configManager);


    PowerMockito.mockStatic(BeanHelper.class);

    TMS = mock(DefaultTransactionMarkingService.class);
    transaction = PowerMockito.mock(TransactionImpl.class);
    when(TMS.topTransaction(anyString(),anyString())).thenReturn(transaction);
    when(TMS.transaction(anyString(),anyString())).thenReturn(transaction);
    when(transaction.start()).thenReturn(null);
    when(transaction.end()).thenReturn(null);
  }

}
