package com.walmartlabs.services.rdm.rank.assigner.impl;

import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import org.junit.jupiter.api.Test;


import java.util.ArrayList;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class RankInhomeOneForInhomeCustomersTest {

   /*
     Input: RANK: 1. STORE, 2. INHOME, 3.MAIL, 4.CARRIER_PICKUP
     Output: RANK: 1. INHOME, 2. STORE, 3.MAIL, 4.CARRIER_PICKUP
    */
    @Test
    void whenSingleItemRequestContainsInhomeRank2_rankInhomeAs1_testAssignRanks() {
        List<DispositionInfo> allItemsDispositionInfoList = new ArrayList<>();
        DispositionInfo dispositionInfo1 = new DispositionInfo();
        List<DispositionPath> dispositionPaths1 = dispositionInfo1.getDispositionPaths();

        DispositionPath inhome = new DispositionPath();
        inhome.setRank(2);
        inhome.setPath("INHOME_PICKUP");
        DispositionPath store = new DispositionPath();
        store.setRank(1);
        store.setPath("STORE");
        DispositionPath mail = new DispositionPath();
        mail.setRank(3);
        mail.setPath("MAIL");
        DispositionPath carrier_pickup = new DispositionPath();
        carrier_pickup.setRank(4);
        carrier_pickup.setPath("CARRIER_PICKUP");
        DispositionPath fedex_drop = new DispositionPath();
        fedex_drop.setRank(5);
        fedex_drop.setPath("FEDEX_DROP");
        dispositionPaths1.add(inhome);
        dispositionPaths1.add(store);
        dispositionPaths1.add(mail);
        dispositionPaths1.add(carrier_pickup);
        dispositionPaths1.add(fedex_drop);

        dispositionInfo1.setDispositionPaths(dispositionPaths1);
        dispositionInfo1.setIsDefault(false);
        dispositionInfo1.setItem(getItem("123","1234","MYACCOUNT"));

        allItemsDispositionInfoList.add(dispositionInfo1);

        RankInhomeOneForInhomeCustomers rankInhomeOneForInhomeCustomers = new RankInhomeOneForInhomeCustomers();
        rankInhomeOneForInhomeCustomers.assignRanks(allItemsDispositionInfoList);

        dispositionInfo1 = allItemsDispositionInfoList.get(0);
        Map<String,Integer> expectedOrderedListOfDispositionPaths = new HashMap<>();
        expectedOrderedListOfDispositionPaths.put("INHOME_PICKUP", 1);
        expectedOrderedListOfDispositionPaths.put("STORE",2);
        expectedOrderedListOfDispositionPaths.put("MAIL",3);
        expectedOrderedListOfDispositionPaths.put("CARRIER_PICKUP",4);
        expectedOrderedListOfDispositionPaths.put("FEDEX_DROP",5);

        for(DispositionPath dispositionPath:dispositionInfo1.getDispositionPaths()){
            assertEquals(expectedOrderedListOfDispositionPaths.get(dispositionPath.getPath()),dispositionPath.getRank());
        }
    }

    private BaseItem getItem(String orderNo, String itemId, String channelName) {

        BaseItem item = new BaseItem();
        item.setChannelName(channelName);
        item.setOrderNo(orderNo);
        item.setItemId(itemId);
        return item;
    }
}