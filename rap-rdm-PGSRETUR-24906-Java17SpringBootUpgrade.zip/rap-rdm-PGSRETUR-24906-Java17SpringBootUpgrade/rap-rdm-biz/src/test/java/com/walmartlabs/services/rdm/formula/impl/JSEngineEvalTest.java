package com.walmartlabs.services.rdm.formula.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import com.walmartlabs.services.rdm.formula.FormulaException;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.FormulaType;
import com.walmartlabs.services.rdm.model.formula.ValueType;

/**
 * 
 * @author Tim Jin
 *
 */
public class JSEngineEvalTest extends FormulaEngineTestBase {

 /*   protected Object eval(String eval, ValueType type, Object... input) {
        return eval(FormulaType.JS, eval, type, input);
    }

    protected Object eval(String eval, ValueType type) throws VariableMissingException {
        return eval(FormulaType.JS, eval, type);
    }

    @Test
    void basic() throws VariableMissingException {
        assertNull(eval("", ValueType.INTEGER));
        assertNull(eval("", ValueType.STRING));
        assertNull(eval("", ValueType.BOOLEAN));
        assertNull(eval("", ValueType.DOUBLE));

        assertNull(eval("null", ValueType.INTEGER));
        assertNull(eval("null", ValueType.STRING));
        assertNull(eval("null", ValueType.BOOLEAN));
        assertNull(eval("null", ValueType.DOUBLE));

        assertThrows(VariableMissingException.class, () -> {
            eval("NULL", null);
        });
        assertThrows(VariableMissingException.class, () -> {
            eval("a+1", null);
        });

        assertEquals(1, eval("1", ValueType.INTEGER));
        assertEquals("1", eval("1", ValueType.STRING));
        assertEquals(true, eval("1", ValueType.BOOLEAN));
        assertEquals(1.0, eval("1", ValueType.DOUBLE));

        assertEquals(1, eval("\"1\"", ValueType.INTEGER));
        assertEquals("1", eval("\"1\"", ValueType.STRING));
        assertEquals(true, eval("\"1\"", ValueType.BOOLEAN));
        assertEquals(1.0, eval("\"1\"", ValueType.DOUBLE));

        assertEquals(1, eval("Number(1)", ValueType.INTEGER));
        assertEquals("1.0", eval("Number(1)", ValueType.STRING));
        assertEquals(null, eval("Number(1)", ValueType.BOOLEAN));
        assertEquals(1.0, eval("Number(1)", ValueType.DOUBLE));

        assertEquals(Double.NaN, eval("Number.NaN", ValueType.DOUBLE));
        assertEquals(Double.NaN, eval("Number.NaN*2", ValueType.DOUBLE));

        assertEquals(.0, eval("0//comments", ValueType.DOUBLE));
    }

    @Test
    void advanced() throws VariableMissingException {
        assertEquals(2, eval("false?1:2", ValueType.INTEGER));
        assertEquals(2, eval("if(false) 1; else 2", ValueType.INTEGER));
        assertEquals(2, eval("if(false){1;}else 2", ValueType.INTEGER));
        assertNull(eval("false?1:false?2:null", ValueType.INTEGER));

        //assertEquals(eval("Number(null+1)", ValueType.INTEGER), 1); TODO
        assertEquals(3, eval("if(false)1 ;else if(false) 2 ;else 3", ValueType.INTEGER));

        String rc_sort = "if(cube<.11) 'conv'; else if(cube>=.11 && cube <=4.11) 'mix'; else 'non-con';";
        assertEquals("conv", eval(rc_sort, ValueType.STRING, "cube", 0.10));
        assertEquals("mix", eval(rc_sort, ValueType.STRING, "cube", 0.11));
        assertEquals("mix", eval(rc_sort, ValueType.STRING, "cube", 0.12));
        assertEquals("non-con", eval(rc_sort, ValueType.STRING, "cube", 4.12));

        assertEquals(3.45, eval("dotcom?(3.45*unit):cube", ValueType.DOUBLE, "unit", 1, "store", false, "dotcom", true));

        assertThrows(FormulaException.class, () -> {
            eval("dotcom?(3.45*unit):cube", ValueType.DOUBLE, "unit", 1, "store", false, "dotcom", false);
        });

        assertEquals(3.45, eval("dotcom?3.45*unit:cube", ValueType.DOUBLE, "unit", 1, "store", false, "dotcom", true));

        //@formatter:off
        String c5 =  
                "(dotcom ? 3.45 : (store ? (\n" + 
                "    rc_sort == 'conv' ? (claim ? .57 : .68) :\n" + 
                "    rc_sort == 'mix' ? (claim ? .75 : .89) :\n" + 
                "    claim ? 1.74 : 2.03\n" + 
                ") : Number.NaN)) * unit";
        //@formatter:on
        assertEquals(.345, (double) eval(c5, ValueType.DOUBLE, "unit", .1, "store", false, "dotcom", true, "rc_sort", "conv", "claim", true), 1e-10);
        assertEquals(.057, (double) eval(c5, ValueType.DOUBLE, "unit", .1, "store", true, "dotcom", false, "rc_sort", "conv", "claim", true), 1e-10);
        assertEquals(.068, (double) eval(c5, ValueType.DOUBLE, "unit", .1, "store", true, "dotcom", false, "rc_sort", "conv", "claim", false), 1e-10);
        assertEquals(.075, (double) eval(c5, ValueType.DOUBLE, "unit", .1, "store", true, "dotcom", false, "rc_sort", "mix", "claim", true), 1e-10);
        assertEquals(.089, (double) eval(c5, ValueType.DOUBLE, "unit", .1, "store", true, "dotcom", false, "rc_sort", "mix", "claim", false), 1e-10);
        assertEquals(.174, (double) eval(c5, ValueType.DOUBLE, "unit", .1, "store", true, "dotcom", false, "rc_sort", "others", "claim", true), 1e-10);
        assertEquals(.203, (double) eval(c5, ValueType.DOUBLE, "unit", .1, "store", true, "dotcom", false, "rc_sort", "others", "claim", false), 1e-10);
        assertEquals(Double.NaN, eval(c5, ValueType.DOUBLE, "unit", .1, "store", false, "dotcom", false, "rc_sort", "others", "claim", false));

    }

    @Test
    void withInput() throws VariableMissingException {
        assertEquals(eval("a+1", ValueType.INTEGER, "a", 1), 2);
        assertEquals(eval("a==1", ValueType.BOOLEAN, "a", 1), true);

        assertThrows(FormulaException.class, () -> {
            eval("a==1", ValueType.INTEGER, "a", 1);
        });

        assertThrows(VariableMissingException.class, () -> {
            eval("a+1", null);
        });
    }

    @Test
    void dotcomClaimInd() {
        String ind = "_rcp_claimable ? rpt_desc != 'RC_SHIP' && rpt_desc != 'RC_DISPOSE\\\\RECYCLE' ? true : false : false";
        String ind_rtv = "_rcp_claimable ? rpt_desc != 'RC_SHIP' && rpt_desc != 'RC_DISPOSE\\\\RECYCLE' ? true : rpt_desc == 'RC_SHIP' ? true : false : false";
        String ind_dispose = "_rcp_claimable ? rpt_desc != 'RC_SHIP' && rpt_desc != 'RC_DISPOSE\\\\RECYCLE' ? true : rpt_desc == 'RC_DISPOSE\\\\RECYCLE' ? true : false : false";

        assertEquals(false, eval(ind, ValueType.BOOLEAN, "_rcp_claimable", false));
        assertEquals(false, eval(ind_rtv, ValueType.BOOLEAN, "_rcp_claimable", false));
        assertEquals(false, eval(ind_dispose, ValueType.BOOLEAN, "_rcp_claimable", false));

        assertEquals(true, eval(ind, ValueType.BOOLEAN, "_rcp_claimable", true, "rpt_desc", "OTHER"));
        assertEquals(true, eval(ind_rtv, ValueType.BOOLEAN, "_rcp_claimable", true, "rpt_desc", "OTHER"));
        assertEquals(true, eval(ind_dispose, ValueType.BOOLEAN, "_rcp_claimable", true, "rpt_desc", "OTHER"));
        assertEquals(true, eval(ind_rtv, ValueType.BOOLEAN, "_rcp_claimable", true, "rpt_desc", null));

        assertEquals(false, eval(ind, ValueType.BOOLEAN, "_rcp_claimable", true, "rpt_desc", "RC_SHIP"));
        assertEquals(true, eval(ind_rtv, ValueType.BOOLEAN, "_rcp_claimable", true, "rpt_desc", "RC_SHIP"));
        assertEquals(false, eval(ind_dispose, ValueType.BOOLEAN, "_rcp_claimable", true, "rpt_desc", "RC_SHIP"));

        assertEquals(false, eval(ind, ValueType.BOOLEAN, "_rcp_claimable", true, "rpt_desc", "RC_DISPOSE\\RECYCLE"));
        assertEquals(false, eval(ind_rtv, ValueType.BOOLEAN, "_rcp_claimable", true, "rpt_desc", "RC_DISPOSE\\RECYCLE"));
        assertEquals(true, eval(ind_dispose, ValueType.BOOLEAN, "_rcp_claimable", true, "rpt_desc", "RC_DISPOSE\\RECYCLE"));
    }

    @Test
    void quantityUOM() {
        assertEquals(true, eval("_v_quantity_uom == null", ValueType.BOOLEAN, "_v_quantity_uom", null));

        String v = "_v_quantity_uom != null && (String.prototype.toUpperCase.apply(_v_quantity_uom) == 'EA' || String.prototype.toUpperCase.apply(_v_quantity_uom) == 'EACH')";

        assertEquals(false, eval(v, ValueType.BOOLEAN, "_v_quantity_uom", null));
        assertEquals(false, eval(v, ValueType.BOOLEAN, "_v_quantity_uom", "E"));
        assertEquals(true, eval(v, ValueType.BOOLEAN, "_v_quantity_uom", "EA"));
        assertEquals(true, eval(v, ValueType.BOOLEAN, "_v_quantity_uom", "EACH"));
        assertEquals(true, eval(v, ValueType.BOOLEAN, "_v_quantity_uom", "Each"));

    }*/
}
