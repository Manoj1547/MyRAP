package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.model.dispositionpaths.Item;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class WMPlusCustomerCheckTest {


    WMPlusCustomerCheck wmPlusCustomerCheck;
    KeepItRuleEngineContext keepItRuleEngineContext;
    RDMKeepItConfig rdmKeepItConfig;

    @Before
    public void setup(){
        wmPlusCustomerCheck = new WMPlusCustomerCheck();
        keepItRuleEngineContext = new KeepItRuleEngineContext();
    }


    @Test
    public void testGetKeepItCheckName() {
        assertEquals(RDMConstants.RULE_CHECK_NAME_WM_PLUS_CUSTOMER,wmPlusCustomerCheck.getKeepItCheckName());
    }

    @Test
    public void whenWmPlusCustomerCCMEnabled_ReturnTrue_testRunCheck() {
        rdmKeepItConfig = new RDMKeepItConfig();
        rdmKeepItConfig.setDisableWmPlusCustomerCheck(true);
        wmPlusCustomerCheck.setRdmKeepItConfig(rdmKeepItConfig);
        keepItRuleEngineContext.setItem(getItem(true));
        assertTrue(wmPlusCustomerCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenWmPlusCustomerCCMDisabled_ReturnTrue_testRunCheck() {
        rdmKeepItConfig = new RDMKeepItConfig();
        rdmKeepItConfig.setDisableWmPlusCustomerCheck(false);
        wmPlusCustomerCheck.setRdmKeepItConfig(rdmKeepItConfig);
        keepItRuleEngineContext.setItem(getItem(true));
        assertTrue(wmPlusCustomerCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenNonWmPlusCustomerCCMDisabled_ReturnFalse_testRunCheck() {
        rdmKeepItConfig = new RDMKeepItConfig();
        rdmKeepItConfig.setDisableWmPlusCustomerCheck(false);
        wmPlusCustomerCheck.setRdmKeepItConfig(rdmKeepItConfig);
        keepItRuleEngineContext.setItem(getItem(false));
        assertFalse(wmPlusCustomerCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenNonWmPlusCustomerCCMEnabled_ReturnTrue_testRunCheck() {
        rdmKeepItConfig = new RDMKeepItConfig();
        rdmKeepItConfig.setDisableWmPlusCustomerCheck(true);
        wmPlusCustomerCheck.setRdmKeepItConfig(rdmKeepItConfig);
        keepItRuleEngineContext.setItem(getItem(false));
        assertTrue(wmPlusCustomerCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenNonWmPlusCustomerCCMNull_ReturnFalse_testRunCheck() {
        rdmKeepItConfig = new RDMKeepItConfig();
        wmPlusCustomerCheck.setRdmKeepItConfig(rdmKeepItConfig);
        keepItRuleEngineContext.setItem(getItem(false));
        assertFalse(wmPlusCustomerCheck.runCheck(keepItRuleEngineContext));
    }

    private BaseItem getItem(boolean t) {
        Item item = new Item();
        item.setWalmartPlusCustomer(t);
        return item;
    }
}