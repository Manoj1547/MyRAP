package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.model.dispositionpaths.Item;
import org.junit.Before;
import org.junit.Test;

import java.util.*;

import static org.junit.Assert.*;

public class NonCompliantDepartmentRuleCheckTest {

    NonCompliantDepartmentRuleCheck nonCompliantDepartmentRuleCheck = new NonCompliantDepartmentRuleCheck();
    RDMKeepItConfig rdmKeepItConfig;
    KeepItRuleEngineContext keepItRuleEngineContext ;

    @Before
    public void setup(){
        rdmKeepItConfig = new RDMKeepItConfig();
        keepItRuleEngineContext = new KeepItRuleEngineContext();
        List<String> nonComplaintDeptList =  new ArrayList<>();
        nonComplaintDeptList.add("40");
        nonComplaintDeptList.add("30");
        rdmKeepItConfig.setNonComplaintDeptList(nonComplaintDeptList);
        nonCompliantDepartmentRuleCheck.setRdmKeepItConfig(rdmKeepItConfig);
    }


    @Test
    public void testGetKeepItCheckName() {
        assertEquals(RDMConstants.RULE_CHECK_NAME_COMPLIANCE_DEPT_CHECK,nonCompliantDepartmentRuleCheck.getKeepItCheckName());
    }

    @Test
    public void whenItemDoesNotHaveNonComplaintDept_ReturnFalse_testRunCheck() {
        keepItRuleEngineContext.setItem(getItem("42"));
        assertFalse(nonCompliantDepartmentRuleCheck.runCheck(keepItRuleEngineContext));
    }


    @Test
    public void whenItemHasNonComplaintDept_ReturnTrue_testRunCheck() {
        keepItRuleEngineContext.setItem(getItem("40"));
        assertTrue(nonCompliantDepartmentRuleCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenItemHasNullDept_ReturnFalse_testRunCheck() {
        keepItRuleEngineContext.setItem(getItem(null));
        assertFalse(nonCompliantDepartmentRuleCheck.runCheck(keepItRuleEngineContext));
    }


    private Item getItem(String s) {
        Item item = new Item();
        item.setDepartmentNo(s);
        return item;
    }

}