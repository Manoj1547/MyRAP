package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import org.junit.Before;
import org.junit.Test;


import java.util.HashMap;
import java.util.Map;

import static com.walmartlabs.services.rdm.RDMConstants.PET_VET_FOOD_ITEM;
import static org.junit.Assert.*;
import static org.junit.Assert.assertFalse;

public class IsPetVetFoodItemTest {

    IsPetVetFoodItem isPetVetFoodItem;
    KeepItRuleEngineContext keepItRuleEngineContext;
    RDMKeepItConfig rdmKeepItConfig;

    @Before
    public void setup(){
        isPetVetFoodItem = new IsPetVetFoodItem();
        keepItRuleEngineContext = new KeepItRuleEngineContext();
        rdmKeepItConfig = new RDMKeepItConfig();
        rdmKeepItConfig.setRuleForPetVetFoodEnabled(true);
        isPetVetFoodItem.setRdmKeepItConfig(rdmKeepItConfig);
    }


    @Test
    public void testGetKeepItCheckName() {
        assertEquals(RDMConstants.RULE_CHECK_NAME_IS_PET_VET_FOOD_ITEM,isPetVetFoodItem.getKeepItCheckName());
    }

    @Test
    public void whenVetApprovalRequired_ReturnTrue_testRunCheck() {
        keepItRuleEngineContext.setItem(getItem("Y"));
        assertTrue(isPetVetFoodItem.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenVetApprovalNotRequired_ReturnFalse_testRunCheck() {
        keepItRuleEngineContext.setItem(getItem("N"));
        assertFalse(isPetVetFoodItem.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenVetApprovalNotPresent_ReturnFalse_testRunCheck() {
        BaseItem item = new BaseItem();
        Map<String,String> itemCustomAttributes = new HashMap<>();
        item.setItemCustomAttributes(itemCustomAttributes);
        keepItRuleEngineContext.setItem(item);
        assertFalse(isPetVetFoodItem.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenVetApprovalNotRequiredIsNULL_ReturnFalse_testRunCheck() {
        keepItRuleEngineContext.setItem(getItem(null));
        assertFalse(isPetVetFoodItem.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void whenItemCustomAttributesIsNULL_ReturnFalse_testRunCheck() {
        keepItRuleEngineContext.setItem(new BaseItem());
        assertFalse(isPetVetFoodItem.runCheck(keepItRuleEngineContext));
    }

    private BaseItem getItem(String s) {
        BaseItem item = new BaseItem();
        Map<String,String> itemCustomAttributes = new HashMap<>();
        itemCustomAttributes.put(PET_VET_FOOD_ITEM,s);
        item.setItemCustomAttributes(itemCustomAttributes);
        return item;
    }
}