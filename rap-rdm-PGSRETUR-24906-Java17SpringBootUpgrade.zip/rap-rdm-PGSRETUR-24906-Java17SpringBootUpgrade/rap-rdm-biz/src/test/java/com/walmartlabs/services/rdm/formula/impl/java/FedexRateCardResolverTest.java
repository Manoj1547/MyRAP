package com.walmartlabs.services.rdm.formula.impl.java;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaException;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.fedexratecard.FedexRateCard;

/**
 * 
 * @author Tim Jin
 *
 */
class FedexRateCardResolverTest {

    @Test
    void test() throws IOException, VariableMissingException {
        FedexRateCardResolver r = new FedexRateCardResolver();
        URL nodesJson = FedexRateCardResolverTest.class.getResource("/fedex_rate_card.json");
        try (BufferedReader in = new BufferedReader(new InputStreamReader(nodesJson.openStream(), "UTF-8"))){
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

            List<FedexRateCard> rst = mapper.readValue(in, new TypeReference<List<FedexRateCard>>() {});

            r.init(rst);
        }

        assertEquals(FormulaConstants.INVALID_VALUE, r.getRate(null));
        assertEquals(FormulaConstants.INVALID_VALUE, r.getRate(Double.NaN));

        assertEquals(FormulaConstants.INVALID_VALUE, r.getRate(-1.));
        assertEquals(FormulaConstants.INVALID_VALUE, r.getRate(0.));

        assertEquals(3., (Double) r.getRate(.01), 1e-2);
        assertEquals(4.87, (Double) r.getRate(1.), 1e-2);
        assertEquals(4.87, (Double) r.getRate(2.), 1e-2);
        assertEquals(4.87, (Double) r.getRate(5.), 1e-2);

        assertEquals(5.65, (Double) r.getRate(5.01), 1e-2);
        assertEquals(5.65, (Double) r.getRate(10.), 1e-2);

        assertEquals(6.84, (Double) r.getRate(10.02), 1e-2);
        assertEquals(6.84, (Double) r.getRate(15.), 1e-2);

        assertEquals(28.17, (Double) r.getRate(96.), 1e-2);

        assertEquals(40.3, (Double) r.getRate(140.), 1e-2);
        assertEquals(41.76, (Double) r.getRate(141.), 1e-2);
        assertEquals(43.39, (Double) r.getRate(145.01), 1e-2);
        assertEquals(43.39, (Double) r.getRate(150.), 1e-2);

        assertEquals(FormulaConstants.INVALID_VALUE, r.getRate(0.0));
        assertEquals(FormulaConstants.INVALID_VALUE, r.getRate(150.01));

        //this ideally should be false
        assertEquals(FormulaConstants.INVALID_VALUE, FormulaConstants.INVALID_VALUE);
        assertEquals(FormulaConstants.INVALID_VALUE, 0. / 0);

        assertThrows(VariableMissingException.class, () -> {
            r.eval(null, new HashMap<>());
        });

        assertThrows(FormulaException.class, () -> {
            Map<String, Object> inputData = new HashMap<>();
            inputData.put(FormulaConstants.VARIABLE_WEIGHT_LB, "a");
            r.eval(null, inputData);
        });

        Map<String, Object> inputData = new HashMap<>();
        inputData.put(FormulaConstants.VARIABLE_WEIGHT_LB, "142");
        assertEquals(41.76, (Double) r.eval(null, inputData), 1e-2);
    }

}
