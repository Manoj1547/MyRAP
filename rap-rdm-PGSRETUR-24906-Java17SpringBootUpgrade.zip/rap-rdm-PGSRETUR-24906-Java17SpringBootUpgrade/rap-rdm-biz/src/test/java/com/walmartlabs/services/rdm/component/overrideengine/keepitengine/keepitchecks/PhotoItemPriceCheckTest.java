package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmart.services.common.model.money.CurrencyUnitEnum;
import com.walmart.services.common.model.money.MoneyType;
import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.Session;
import com.walmartlabs.services.rdm.model.dispositionpaths.Item;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class PhotoItemPriceCheckTest {
    PhotoItemPriceCheck photoItemPriceCheck = new PhotoItemPriceCheck();
    RDMKeepItUtil rdmKeepItUtil;

    RDMKeepItConfig rdmKeepItConfig;
    KeepItRuleEngineContext keepItRuleEngineContext;

    @Before
    public void setUp() {
        rdmKeepItUtil = new RDMKeepItUtil();
        rdmKeepItConfig = new RDMKeepItConfig();
        rdmKeepItConfig.setThresholdForPhotoItemPrice(Double.valueOf("1"));
        keepItRuleEngineContext = new KeepItRuleEngineContext();
        photoItemPriceCheck.setRdmKeepItUtil(rdmKeepItUtil);
        photoItemPriceCheck.setRdmKeepItConfig(rdmKeepItConfig);
    }

    @Test
    public void testGetName() {
        org.testng.Assert.assertEquals(photoItemPriceCheck.getKeepItCheckName(), RDMConstants.RULE_CHECK_NAME_PHOTO_ITEM_PRICE);
    }

    @Test
    public void testRunCheck_Greater() {
        BaseItem item = getItem(BigDecimal.TEN);
        Session session = getSession();
        keepItRuleEngineContext.setSession(session);
        keepItRuleEngineContext.setItem(item);
        Assert.assertFalse(photoItemPriceCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void testRunCheck_Equal() {
        BaseItem item = getItem(BigDecimal.ONE);
        Session session = getSession();
        keepItRuleEngineContext.setSession(session);
        keepItRuleEngineContext.setItem(item);
        Assert.assertTrue(photoItemPriceCheck.runCheck(keepItRuleEngineContext));
    }

    @Test
    public void testRunCheck_Lesser() {
        BaseItem item = getItem(BigDecimal.ZERO);
        Session session = getSession();
        keepItRuleEngineContext.setSession(session);
        keepItRuleEngineContext.setItem(item);
        Assert.assertTrue(photoItemPriceCheck.runCheck(keepItRuleEngineContext));
    }

    private Item getItem(BigDecimal b) {
        Item item = new Item();
        MoneyType unitPrice = new MoneyType(b, CurrencyUnitEnum.USD);
        item.setUnitPrice(unitPrice);
        return item;
    }

    private Session getSession() {
        Session session = new Session();
        Map<String, Object> outputData = new HashMap<>();
        outputData.put(FormulaConstants.VARIABLE_IS_DOTCOM,true);
        session.setOutputData(outputData);
        return session;
    }
}
