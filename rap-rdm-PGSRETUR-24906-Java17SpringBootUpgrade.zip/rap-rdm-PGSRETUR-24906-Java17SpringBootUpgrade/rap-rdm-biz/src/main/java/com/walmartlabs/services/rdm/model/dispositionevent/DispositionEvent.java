package com.walmartlabs.services.rdm.model.dispositionevent;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * @author Tim Jin
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DispositionEvent {

    @JsonProperty("storeId")
    private String           storeId;

    @JsonProperty("smartLabelId")
    private String           smartLabelId;

    @JsonProperty("finalDisposition")
    private FinalDisposition finalDisposition;

    @JsonProperty("rdmDisposeNoHazValue")
    private Double           rdmDisposeNoHazValue;

    @JsonProperty("rdmDonateValue")
    private Double           rdmDonateValue;

    @JsonProperty("rdmSellInStoreValue")
    private Double           rdmSellInStoreValue;

    @JsonProperty("rdmLiquidateBlendValue")
    private Double           rdmLiquidateBlendValue;

    @JsonProperty("rdmFinancialFlowEnabled")
    private Boolean          rdmFinancialFlowEnabled;

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getSmartLabelId() {
        return smartLabelId;
    }

    public void setSmartLabelId(String smartLabelId) {
        this.smartLabelId = smartLabelId;
    }

    public FinalDisposition getFinalDisposition() {
        return finalDisposition;
    }

    public void setFinalDisposition(FinalDisposition finalDisposition) {
        this.finalDisposition = finalDisposition;
    }

    public Double getRdmDisposeNoHazValue() {
        return rdmDisposeNoHazValue;
    }

    public void setRdmDisposeNoHazValue(Double rdmDisposeNoHazValue) {
        this.rdmDisposeNoHazValue = rdmDisposeNoHazValue;
    }

    public Double getRdmDonateValue() {
        return rdmDonateValue;
    }

    public void setRdmDonateValue(Double rdmDonateValue) {
        this.rdmDonateValue = rdmDonateValue;
    }

    public Double getRdmSellInStoreValue() {
        return rdmSellInStoreValue;
    }

    public void setRdmSellInStoreValue(Double rdmSellInStoreValue) {
        this.rdmSellInStoreValue = rdmSellInStoreValue;
    }

    public Double getRdmLiquidateBlendValue() {
        return rdmLiquidateBlendValue;
    }

    public void setRdmLiquidateBlendValue(Double rdmLiquidateBlendValue) {
        this.rdmLiquidateBlendValue = rdmLiquidateBlendValue;
    }

    public Boolean getRdmFinancialFlowEnabled() {
        return rdmFinancialFlowEnabled;
    }

    public void setRdmFinancialFlowEnabled(Boolean rdmFinancialFlowEnabled) {
        this.rdmFinancialFlowEnabled = rdmFinancialFlowEnabled;
    }

}
