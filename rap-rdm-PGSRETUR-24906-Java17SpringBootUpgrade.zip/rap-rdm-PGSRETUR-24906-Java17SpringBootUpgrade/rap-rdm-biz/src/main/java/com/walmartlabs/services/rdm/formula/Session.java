package com.walmartlabs.services.rdm.formula;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 
 * @author Tim Jin
 *
 */
public class Session {
    
    private Map<String, Object> inputData  = new ConcurrentHashMap<>();

    private Map<String, Object> outputData = new ConcurrentHashMap<>();

    public Map<String, Object> getInputData() {
        return inputData;
    }

    public void setInputData(Map<String, Object> inputData) {
        this.inputData = inputData;
    }

    public Map<String, Object> getOutputData() {
        return outputData;
    }

    public void setOutputData(Map<String, Object> outputData) {
        this.outputData = outputData;
    }

}