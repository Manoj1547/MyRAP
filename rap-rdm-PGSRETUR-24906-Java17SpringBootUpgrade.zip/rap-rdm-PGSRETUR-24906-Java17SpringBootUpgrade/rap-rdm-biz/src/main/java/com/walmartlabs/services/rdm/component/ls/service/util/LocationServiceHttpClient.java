package com.walmartlabs.services.rdm.component.ls.service.util;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmart.platform.txnmarking.impl.NullTransactionImpl;
import com.walmart.platform.txnmarking.impl.TransactionImpl;
import com.walmartlabs.services.rdm.component.ls.model.newls.PrefStoreResponse;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import io.strati.StratiServiceProvider;
import io.strati.txnmarking.TransactionMarkingService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmartlabs.services.rdm.component.ls.model.GetPrefStoreRequest;
import com.walmartlabs.services.rdm.component.ls.model.GetPrefStoreResponse;
import com.walmartlabs.services.rdm.config.client.LocationServiceConfig;
import com.walmartlabs.services.rdm.util.BaseHTTPClient;
import com.walmartlabs.services.rdm.util.HeaderElements;
import com.walmartlabs.services.rdm.util.SignatureGenerator;

import io.strati.configuration.annotation.ManagedConfiguration;

@Component
public class LocationServiceHttpClient extends BaseHTTPClient {

    private static final Logger LOG = LoggerFactory.getLogger(LocationServiceHttpClient.class);

    private TransactionMarkingService TMS;

    private ObjectMapper objectMapper;

    private String lsRequestPayload;

    @Resource
    @ManagedConfiguration LocationServiceConfig locationServiceConfig;

    private TypeReference<ServiceResponse<GetPrefStoreResponse>> typeReferenceGetPrefStore;

    private TypeReference<ServiceResponse<PrefStoreResponse>> typeReferencePrefStoreResponse;

    @PostConstruct
    private void init() {
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        typeReferenceGetPrefStore = new TypeReference<ServiceResponse<GetPrefStoreResponse>>() {
        };

        //Type ref for new LS
        typeReferencePrefStoreResponse = new TypeReference<ServiceResponse<PrefStoreResponse>>() {
        };
        lsRequestPayload = "{\"payload\":{}}"; //Dummy empty payload for LS post call

    }
    private LocationServiceHttpClient() {
        TMS = StratiServiceProvider.getInstance().getTransactionMarkingService().get();
    }

    public GetPrefStoreResponse getPrefStore(GetPrefStoreRequest request) {

        TransactionImpl top;
        if(TMS.currentTransaction() instanceof NullTransactionImpl) {
            top = (TransactionImpl) TMS.topTransaction("PrefStore", "PrefStore");
        }else {
            top = (TransactionImpl) TMS.transaction("PrefStore", "PrefStore");
        }
        top.start();

        String baseUrl = locationServiceConfig.getServiceBaseHostUrl();
        String pathUrl = locationServiceConfig.getServiceEndpoint();
        pathUrl = pathUrl.replaceAll("\\{customer_account_id\\}", request.getCustomerId());
        int apiTimeout = locationServiceConfig.getApiTimeout();
        Map<String, String> headerParams = getHeaderParams(locationServiceConfig);

        GetPrefStoreResponse response = null;

        try {
            LOG.info(MessageFormat.format("Invoking pref store service. URL:{0}{1}", baseUrl, pathUrl));
            String responseString = get(baseUrl, pathUrl, headerParams, apiTimeout, String.class);
            LOG.info(MessageFormat.format("Pref store service response: {0}", responseString));

            ServiceResponse<GetPrefStoreResponse> serviceResponse = objectMapper.readValue(responseString,
                    typeReferenceGetPrefStore);
            response = serviceResponse.getPayload();

            top.end();
        } catch (ServiceException e) {
            String errorMsg;
            if (e.getMessage().contains("STORE_NOT_FOUND")) {
                errorMsg = MessageFormat.format("No preferred store configured by the customer [{0}]. " +
                                                        "Detailed Message [{1}].", request.getCustomerId(), e.getMessage());
                LOG.error(errorMsg);
                top.logException(e);
                top.endWithFailure(e.getMessage());
            } else {
                errorMsg = MessageFormat.format("Pref Store Service Exception for customer {0}: {1}",
                        request.getCustomerId(), e.getMessage());
                LOG.error(errorMsg);
                top.logException(e);
                top.endWithFailure(e.getMessage());
            }
        } catch (Exception e) {
            LOG.error(e.getMessage());
            top.logException(e);
            top.endWithFailure(e.getMessage());
        }

        return response;
    }


    private Map<String, String> getHeaderParams(LocationServiceConfig config) {
        HashMap<String, String> headers = new HashMap<>();
        long inTimestamp = System.currentTimeMillis();
        SignatureGenerator signGenerator = new SignatureGenerator();
        String signature = signGenerator.generateSignatureHeader(inTimestamp, config.getServiceConsumerId(),
                config.getPrivateKeyVersion(), config.getPrivateKey());

        addHeaderParam(headers, HeaderElements.SERVICE_VERSION, config.getServiceVersion());
        addHeaderParam(headers, HeaderElements.SERVICE_ENV, config.getServiceEnv());
        addHeaderParam(headers, HeaderElements.SERVICE_NAME, config.getServiceName());
        addHeaderParam(headers, HeaderElements.CONSUMER_ID, config.getServiceConsumerId());
        addHeaderParam(headers, HeaderElements.CORRELATION_ID, config.getCorrelationId());
        addHeaderParam(headers, HeaderElements.CONSUMER_TENANT_ID, config.getTenantId());
        addHeaderParam(headers, HeaderElements.CONTENT_TYPE, config.getContentType());
        addHeaderParam(headers, HeaderElements.CONSUMER_PRIVATE_KEY_VERSION, config.getPrivateKeyVersion());
        addHeaderParam(headers, HeaderElements.CONSUMER_IN_TIMESTAMP, String.valueOf(inTimestamp));
        addHeaderParam(headers, HeaderElements.CONSUMER_AUTH_SIGNATURE, signature);
        return headers;
    }

    private void addHeaderParam(HashMap<String, String> headers, String name, String value) {
        if (StringUtils.isNotBlank(value))
            headers.put(name, value);
    }

    public PrefStoreResponse getPrefStoreWithNewLS(GetPrefStoreRequest request) {

        if(locationServiceConfig.getLsMockEnabled()){
            try {
                ServiceResponse<PrefStoreResponse> mockServiceResponse = objectMapper.readValue(locationServiceConfig.getLsMockResponse(),
                        typeReferencePrefStoreResponse);
                return mockServiceResponse.getPayload();
            }catch (Exception e){
                String errorMsg = "Location Service Mock Http call Execution failed";
                String errorMsgLog = MessageFormat.format(errorMsg + " consumerId {1}, exceptionMsg {2}" +
                        ", response {3}", request.getCustomerId(), e.getMessage(), locationServiceConfig.getLsMockResponse());
                LOG.error(errorMsgLog, e);
                throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                        ErrorCodeMapping.LS_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
            }
        }

        TransactionImpl top;
        if(TMS.currentTransaction() instanceof NullTransactionImpl) {
            top = (TransactionImpl) TMS.topTransaction("PrefStore", "PrefStore");
        }else {
            top = (TransactionImpl) TMS.transaction("PrefStore", "PrefStore");
        }
        top.start();

        String baseUrl = locationServiceConfig.getServiceBaseHostUrl();
        String pathUrl = locationServiceConfig.getServiceEndpoint();
        pathUrl = pathUrl.replaceAll("\\{customer_account_id\\}", request.getCustomerId());
        int apiTimeout = locationServiceConfig.getApiTimeout();
        Map<String, String> headerParams = getHeaderParamsForNewLSService(locationServiceConfig);

        String responseString = null;
        try {
            LOG.info(MessageFormat.format("Invoking pref store service. URL:{0}{1}", baseUrl, pathUrl));
            responseString = post(baseUrl, pathUrl, lsRequestPayload, headerParams, apiTimeout, String.class);
            ServiceResponse<PrefStoreResponse> serviceResponse = objectMapper.readValue(responseString,
                    typeReferencePrefStoreResponse);
            PrefStoreResponse response = serviceResponse.getPayload();

            //LS has very big response, just log the required data
            LOG.info(MessageFormat.format("Pref store service response : {0} for customerId : {1}", response.toString(), request.getCustomerId()));

            top.end();
            return response;
        } catch (Exception e) {
            String errorMsg = "Location Service Http call Execution failed";
            String errorMsgLog = MessageFormat.format(errorMsg + " consumerId {1}, exceptionMsg {2}" +
                            ", response {3}", request.getCustomerId(), e.getMessage(), responseString);
            LOG.error(errorMsgLog, e);
            top.logException(e);
            top.endWithFailure(e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.LS_HTTP_CLIENT_EXECUTION_FAILED, "Location Service Http call Execution failed", e);
        }
    }

    private Map<String, String> getHeaderParamsForNewLSService(LocationServiceConfig config) {
        HashMap<String, String> headers = new HashMap<>();
        long inTimestamp = System.currentTimeMillis();
        SignatureGenerator signGenerator = new SignatureGenerator();
        String signature = signGenerator.generateSignatureHeader(inTimestamp, config.getServiceConsumerId(),
                config.getPrivateKeyVersion(), config.getPrivateKey());

        addHeaderParam(headers, HeaderElements.SERVICE_VERSION, config.getServiceVersion());
        addHeaderParam(headers, HeaderElements.SERVICE_ENV, config.getServiceEnv());
        addHeaderParam(headers, HeaderElements.SERVICE_NAME, config.getServiceName());
        addHeaderParam(headers, HeaderElements.CONSUMER_ID, config.getServiceConsumerId());
        addHeaderParam(headers, HeaderElements.CORRELATION_ID, config.getCorrelationId());
        addHeaderParam(headers, HeaderElements.CONSUMER_TENANT_ID, config.getTenantId());
        addHeaderParam(headers, HeaderElements.CONTENT_TYPE, config.getContentType());
        addHeaderParam(headers, HeaderElements.CONSUMER_PRIVATE_KEY_VERSION, config.getPrivateKeyVersion());
        addHeaderParam(headers, HeaderElements.CONSUMER_IN_TIMESTAMP, String.valueOf(inTimestamp));
        addHeaderParam(headers, HeaderElements.CONSUMER_AUTH_SIGNATURE, signature);
        addHeaderParam(headers, HeaderElements.USER_IP, config.getServiceUserIP());
        return headers;
    }

}
