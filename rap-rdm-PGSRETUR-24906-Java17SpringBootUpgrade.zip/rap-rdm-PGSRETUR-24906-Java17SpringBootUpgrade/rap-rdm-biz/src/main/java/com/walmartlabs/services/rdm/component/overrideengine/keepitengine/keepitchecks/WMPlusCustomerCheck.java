package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.stereotype.Component;

/**
 * It will check if customer is walmart plus. As part of PGSRETUR-18693 ticket we have added a ccm to pass this check
 * for both w+ and non-w+ member
 */
@Component("wmPlusCustomerCheck")
public class WMPlusCustomerCheck implements IRDMKeepItRuleCheck {

    public void setRdmKeepItConfig(RDMKeepItConfig rdmKeepItConfig) {
        this.rdmKeepItConfig = rdmKeepItConfig;
    }

    @ManagedConfiguration
    RDMKeepItConfig rdmKeepItConfig;

    @Override
    public String getKeepItCheckName() {
        return RDMConstants.RULE_CHECK_NAME_WM_PLUS_CUSTOMER;
    }

    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {
        return keepItRuleEngineContext.getItem().isWalmartPlusCustomer() ||
                Boolean.TRUE.equals(rdmKeepItConfig.getDisableWmPlusCustomerCheck());
    }
}
