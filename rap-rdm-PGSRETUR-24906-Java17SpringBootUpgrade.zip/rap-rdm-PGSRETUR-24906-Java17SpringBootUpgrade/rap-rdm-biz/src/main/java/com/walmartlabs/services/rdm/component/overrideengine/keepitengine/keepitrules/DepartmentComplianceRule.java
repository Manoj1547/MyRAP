package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitrules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.common.IRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("departmentComplianceRule")
public class DepartmentComplianceRule extends AbstractRDMKeepItRule{

    private static final Logger LOG = LoggerFactory.getLogger(DepartmentComplianceRule.class);

    @Autowired
    private RDMKeepItUtil rdmKeepItUtil;

    public void setRdmKeepItUtil(RDMKeepItUtil rdmKeepItUtil) {
        this.rdmKeepItUtil = rdmKeepItUtil;
    }

    @Override
    public void applyRuleDecision(IRuleEngineContext ruleEngineContext) {
       rdmKeepItUtil.updateKeepItForAllPaths((KeepItRuleEngineContext) ruleEngineContext, false);
       LOG.info("{}.applyRuleDecision() exited for itemId :{}",this.getRuleName(),((KeepItRuleEngineContext) ruleEngineContext).getItem().getItemId());
    }

    @Override
    public String getRuleName() {
        return RDMConstants.RULE_NAME_COMPLIANCE_DEPARTMENT;
    }
}
