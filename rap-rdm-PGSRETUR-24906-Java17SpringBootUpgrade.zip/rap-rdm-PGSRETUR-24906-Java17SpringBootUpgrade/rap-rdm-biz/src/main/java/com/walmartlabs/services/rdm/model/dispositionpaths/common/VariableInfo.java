
package com.walmartlabs.services.rdm.model.dispositionpaths.common;

import com.walmartlabs.services.rdm.model.Base;
import com.walmartlabs.services.rdm.model.SellerType;

/**
 * 
 * @author Tim Jin
 *
 */
public class VariableInfo extends Base {
    public static enum VariableCategory {
        COST, RECOVERY, BUSINESSRULE, INTERMEDIATE
    }

    private String           channelName;

    private String           name;

    private String           internalName;

    private String           description;

    private VariableCategory category;

    private SellerType sellerType;

    public SellerType getSellerType() {
        return sellerType;
    }

    public void setSellerType(SellerType sellerType) {
        this.sellerType = sellerType;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInternalName() {
        return internalName;
    }

    public void setInternalName(String internalName) {
        this.internalName = internalName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public VariableCategory getCategory() {
        return category;
    }

    public void setCategory(VariableCategory category) {
        this.category = category;
    }

}
