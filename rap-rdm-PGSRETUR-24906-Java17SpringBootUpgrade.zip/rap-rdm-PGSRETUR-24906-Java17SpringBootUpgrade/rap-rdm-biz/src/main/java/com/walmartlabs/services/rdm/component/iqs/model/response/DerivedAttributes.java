package com.walmartlabs.services.rdm.component.iqs.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DerivedAttributes {
    @JsonProperty("r2d2")
    private R2D2Hierarchy r2D2Hierarchy;

    @JsonProperty("r2d2_future")
    private R2D2Hierarchy r2D2HierarchyFuture;

    public R2D2Hierarchy getR2D2Hierarchy() {
        return r2D2Hierarchy;
    }

    public void setR2D2Hierarchy(R2D2Hierarchy r2D2Hierarchy) {
        this.r2D2Hierarchy = r2D2Hierarchy;
    }

    public R2D2Hierarchy getR2D2HierarchyFuture() {
        return r2D2HierarchyFuture;
    }

    public void setR2D2HierarchyFuture(R2D2Hierarchy r2D2HierarchyFuture) {
        this.r2D2HierarchyFuture = r2D2HierarchyFuture;
    }
}
