 package com.walmartlabs.services.rdm.component.ovt.service.util;

import com.walmart.pangaea.payment.util.StringUtil;
import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmartlabs.services.rdm.component.ovt.model.response.*;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import static com.walmartlabs.services.rdm.component.ovt.constants.OVTOmniConstant.*;


import java.text.MessageFormat;
import java.util.List;
import java.util.Set;

 @Component("dotcomResponseHandler")
public class DotcomResponseHandler extends AbstractResponseHandler {

    @Override
    public OVTOmniItemPolicyDetails handleResponse(ItemPolicyDetailsResponse itemPolicyDetailsResponse, String vendorNo, Set<String> itemIds) {
        OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails = new OVTOmniItemPolicyDetails();
        List<ReturnTerm> returnTermsList = itemPolicyDetailsResponse.getReturnTerms();
        for (ReturnTerm returnTerm : returnTermsList) {
                if (RETURN_AGREEMENT.equals(returnTerm.getReturnTermType()) && ACTIVE.equals(returnTerm.getAgreementStatus())) {
                    updateRequiredAttributesFromReturnAgreement(ovtOmniItemPolicyDetails, returnTerm);
                } else if (RECALL_AGREEMENT.equals(returnTerm.getReturnTermType()) && ACTIVE.equals(returnTerm.getAgreementStatus())) {
                    updateRequiredAttributesFromRecallAgreement(ovtOmniItemPolicyDetails, returnTerm);
                }
        }

        validateResponse(ovtOmniItemPolicyDetails, itemIds, vendorNo);

        return ovtOmniItemPolicyDetails;
    }

    @Override
    void validateResponse(OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails, Set<String> itemIds, String vendorNo) {
        if (null == ovtOmniItemPolicyDetails.getReturnCentreDisposition() || null == ovtOmniItemPolicyDetails.getDmbEligible()
                || null == ovtOmniItemPolicyDetails.getDispositionDiscretion() || null == ovtOmniItemPolicyDetails.getClaimable()) {
            String errorMsg = MessageFormat.format("OVT-HTTP response validation failed as mandatory attribute in response is null for vendorNo :{0} and itemId :{1}"
                    , vendorNo, itemIds.toString());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.OVT_HTTP_CLIENT_EXECUTION_FAILED, errorMsg);
        }
    }

    private void updateRequiredAttributesFromReturnAgreement(OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails, ReturnTerm returnTerm) {
        List<ReturnTermPolicy> returnTermPolicies = returnTerm.getReturnTermPolicies();
        boolean gotRAClaimPolicy = false;
        boolean gotRADispositionPolicy = false;
        boolean gotRAAddressPolicy = false;
        if (CollectionUtils.isEmpty(returnTermPolicies)) {
            return;
        }
        for (ReturnTermPolicy returnTermPolicy : returnTermPolicies) {
            if(RA_EXCEPTION_ATTRIBUTE_POLICY.equals(returnTermPolicy.getPolicyType())){
                updateRequiredAttributesFromExceptionPolicy(ovtOmniItemPolicyDetails,returnTermPolicy);
                return;
            }
            if (RA_CLAIM_POLICY.equals(returnTermPolicy.getPolicyType())) {
                updateRequiredAttributesFromClaimPolicy(ovtOmniItemPolicyDetails, returnTermPolicy);
                gotRAClaimPolicy = true;
            } else if (RA_DISPOSITION_POLICY.equals(returnTermPolicy.getPolicyType())) {
                updateRequiredAttributesFromDispositionPolicy(ovtOmniItemPolicyDetails, returnTermPolicy);
                gotRADispositionPolicy = true;
            } else if (RA_ADDRESS_POLICY.equals(returnTermPolicy.getPolicyType())) {
                updateRequiredAttributesFromAddressPolicy(ovtOmniItemPolicyDetails, returnTermPolicy);
                gotRAAddressPolicy = true;
            }
            if(gotRAClaimPolicy && gotRADispositionPolicy && gotRAAddressPolicy){
                return;
            }
        }
    }

     private void updateRequiredAttributesFromExceptionPolicy(OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails, ReturnTermPolicy returnTermPolicy) {
         List<Policy> policies = returnTermPolicy.getPolicies();
         if (CollectionUtils.isEmpty(policies)) {
             return;
         }
         boolean gotRAClaimPolicy = false;
         boolean gotRADispositionPolicy = false;
         boolean gotRAAddressPolicy = false;
         for(Policy policy: policies){
             if(!StringUtil.isNullOrEmpty(policy.getPolicyKey())) {
                 //  /NOCLAIM_STORE_DISPOSE$0/RA_FREIGHT_POLICY/all
                 String policyKey = getPolicyKeyNames(policy.getPolicyKey());
                 if (RA_CLAIM_POLICY.equals(policyKey)) {
                     updateClaimPolicyAttributesFromAttributeList(ovtOmniItemPolicyDetails, policy.getAttributeList());
                     gotRAClaimPolicy = true;
                 } else if (RA_DISPOSITION_POLICY.equals(policyKey)) {
                     updateDispositionPolicyAttributesFromAttributeList(ovtOmniItemPolicyDetails, policy.getAttributeList());
                     gotRADispositionPolicy = true;
                 } else if (RA_ADDRESS_POLICY.equals(policyKey)) {
                     updateAddressPolicyPolicyAttributesFromAttributeList(ovtOmniItemPolicyDetails, policy.getAttributeList());
                     gotRAAddressPolicy = true;
                 }
                 if(gotRAClaimPolicy && gotRADispositionPolicy && gotRAAddressPolicy){
                     return;
                 }
             }
         }
     }

     private void updateAddressPolicyPolicyAttributesFromAttributeList(OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails, List<Attribute> attributeList) {
         if (CollectionUtils.isEmpty(attributeList)) {
             return;
         }
         for (Attribute attribute : attributeList) {
             if (DMB_ELIGIBLE.equals(attribute.getName())) {
                 ovtOmniItemPolicyDetails.setDmbEligible(Boolean.valueOf(attribute.getValue()));
                 return;
             }
         }
     }

     private void updateRequiredAttributesFromAddressPolicy(OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails, ReturnTermPolicy returnTermPolicy) {
        List<Policy> policies = returnTermPolicy.getPolicies();
        if (CollectionUtils.isEmpty(policies)) {
            return;
        }

        for (Policy policy : policies) {
            if (POLICY_KEY_ALL_ALL.equals(policy.getPolicyKey())) {
                updateAddressPolicyPolicyAttributesFromAttributeList(ovtOmniItemPolicyDetails,policy.getAttributeList());
            }
        }
    }
}
