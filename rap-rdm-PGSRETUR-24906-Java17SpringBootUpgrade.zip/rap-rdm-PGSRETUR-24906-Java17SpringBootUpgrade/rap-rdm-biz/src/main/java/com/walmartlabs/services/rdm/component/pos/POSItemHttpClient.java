package com.walmartlabs.services.rdm.component.pos;

import org.springframework.stereotype.Service;

import com.walmartlabs.services.rdm.component.pos.model.Request;
import com.walmartlabs.services.rdm.config.ConfigConstants;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public class POSItemHttpClient extends POSHttpClient {

    @Override
    protected String getServiceName() {
        return "pos.item";
    }

    @Override
    protected String getCCMName() {
        return ConfigConstants.CONFIG_NAME_POS_SERVICE;
    }

    public String getItemPos(String utc, String gtin, String storeId) {
        Request r = new Request();
        if(gtin != null){
            r.setGtin(gtin);
            r.setUpc(-9999L);
        }else{
            r.setUpc(fromString(utc));
            r.setGtin("");
        }
        r.setStoreId(fromString(storeId));
        return call(this.getPayload(r));
    }
}
