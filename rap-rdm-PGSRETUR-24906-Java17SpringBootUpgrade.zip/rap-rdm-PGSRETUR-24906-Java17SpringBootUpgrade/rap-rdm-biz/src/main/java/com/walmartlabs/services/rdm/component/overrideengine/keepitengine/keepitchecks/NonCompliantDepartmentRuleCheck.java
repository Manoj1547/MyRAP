package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.ovt.model.response.OVTOmniItemPolicyDetails;
import com.walmartlabs.services.rdm.component.ovt.service.util.OVTOmniServiceHelper;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.util.RdmUtils;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

import java.util.concurrent.CompletableFuture;

import static com.walmartlabs.services.rdm.formula.FormulaConstants.VARIABLE_DEPARTMENT_NUMBER;

@Component("nonCompliantDepartmentRuleCheck")
public class NonCompliantDepartmentRuleCheck implements IRDMKeepItRuleCheck {
    @Override
    public String getKeepItCheckName() {
        return RDMConstants.RULE_CHECK_NAME_COMPLIANCE_DEPT_CHECK;
    }

    @Autowired
    private OVTOmniServiceHelper ovtOmniServiceHelper;

    @ManagedConfiguration
    private RDMKeepItConfig rdmKeepItConfig;

    public void setRdmKeepItConfig(RDMKeepItConfig rdmKeepItConfig) {
        this.rdmKeepItConfig = rdmKeepItConfig;
    }

    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {
        String departmentNo = keepItRuleEngineContext.getItem().getDepartmentNo();

        String sellerType = null;
        if (keepItRuleEngineContext.getItem().getSellerType() != null) {
            sellerType = keepItRuleEngineContext.getItem().getSellerType().name();
        }

        return (rdmKeepItConfig.getNonComplaintDeptList().contains(departmentNo)
                || (RdmUtils.isOvtCallApplicable(sellerType, rdmKeepItConfig) && isRecalledItem(keepItRuleEngineContext)));
    }

    private boolean isRecalledItem(KeepItRuleEngineContext keepItRuleEngineContext){
        OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails =
                ovtOmniServiceHelper.getItemPolicyDetailsFromFutureObject((CompletableFuture<OVTOmniItemPolicyDetails>)
                keepItRuleEngineContext.getSession().getOutputData().get(FormulaConstants.INTERNAL_DATA_NAME_OVT_OMNI_FUTURE));
        return null != ovtOmniItemPolicyDetails && Boolean.TRUE.equals(ovtOmniItemPolicyDetails.getRecall());
    }
}
