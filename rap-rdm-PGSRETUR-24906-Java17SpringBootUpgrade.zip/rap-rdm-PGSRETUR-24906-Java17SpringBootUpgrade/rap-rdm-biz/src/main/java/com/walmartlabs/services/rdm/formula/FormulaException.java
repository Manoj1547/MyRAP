package com.walmartlabs.services.rdm.formula;

public class FormulaException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = 862727115188289610L;

    public FormulaException(Exception e) {
        super(e);
    }

    public FormulaException(String msg, Exception e) {
        super(msg, e);
    }

    public FormulaException(String msg) {
        super(msg);
    }

}
