package com.walmartlabs.services.rdm.model;

import com.walmartlabs.services.rdm.domain.model.BaseDO;

/**
 * 
 * @author Tim Jin
 *
 */
public abstract class ID extends Base {

    protected String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String toString() {
        return BaseDO.toString(this);
    }

}
