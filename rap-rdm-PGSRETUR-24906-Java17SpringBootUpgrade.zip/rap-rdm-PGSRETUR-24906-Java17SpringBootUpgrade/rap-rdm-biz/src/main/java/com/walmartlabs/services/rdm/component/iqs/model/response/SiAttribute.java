package com.walmartlabs.services.rdm.component.iqs.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SiAttribute {
    @JsonProperty("itemNumber")
    private Integer itemNumber;

    @JsonProperty("validityTypeCode")
    private String validityTypeCode;

    @JsonProperty("poExistsInd")
    private Boolean poExistsInd;

    @JsonProperty("isReplenishableInd")
    private Boolean isReplenishableInd;

    public Integer getItemNumber() { return itemNumber; }

    public void setItemNumber(Integer itemNumber) { this.itemNumber = itemNumber; }

    public String getValidityTypeCode() { return validityTypeCode; }

    public void setValidityTypeCode(String validityTypeCode) { this.validityTypeCode = validityTypeCode; }

    public Boolean getPoExistsInd() { return poExistsInd; }

    public void setPoExistsInd(Boolean poExistsInd) { this.poExistsInd = poExistsInd; }

    public Boolean getIsReplenishableInd() { return isReplenishableInd; }

    public void setIsReplenishableInd(Boolean isReplenishableInd) { this.isReplenishableInd = isReplenishableInd; }
}
