package com.walmartlabs.services.rdm.util;

public final class HeaderElements {

    public static final String SERVICE_NAME = "WM_SVC.NAME";
    public static final String SERVICE_VERSION = "WM_SVC.VERSION";
    public static final String SERVICE_ENV = "WM_SVC.ENV";

    public static final String CONSUMER_ID = "WM_CONSUMER.ID";
    public static final String CONSUMER_TENANT_ID = "WM_CONSUMER.TENANT_ID";
    public static final String CONSUMER_IN_TIMESTAMP = "WM_CONSUMER.INTIMESTAMP";

    public static final String CONSUMER_AUTH_SIGNATURE = "WM_SEC.AUTH_SIGNATURE";
    public static final String CONSUMER_PRIVATE_KEY_VERSION = "WM_SEC.KEY_VERSION";

    public static final String CORRELATION_ID = "WM_QOS.CORRELATION_ID";

    public static final String CONTENT_TYPE = "Content-Type";
    public static final String ACCEPT = "Accept";
    public static final String BU_ID = "WM_BU_ID";
    public static final String MART_ID = "WM_MART_ID";
    public static final String TENAT_ID = "WM_TENANT_ID";
    public static final String RESPONSE_GROUP = "ResponseGroup";
    public static final String USER_ID = "WM_USER.ID";
    public static final String CLAIMS_APP_VERSION = "App-Version";
    public static final String CLAIMS_USER_ID = "user-id";
    public static final String CLAIMS_SOURCE_ID = "source-id";
    public static final String USER_IP = "WM_ID.USER_IP";

    public static final String WM_REQUEST_SOURCE = "WM_REQUEST_SOURCE";
}
