package com.walmartlabs.services.rdm.component.pos;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmartlabs.services.rdm.component.common.CommonCCMHttpClient;
import com.walmartlabs.services.rdm.component.pos.model.Request;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;

/**
 * 
 * @author Tim Jin
 *
 */
public abstract class POSHttpClient extends CommonCCMHttpClient {

    private static final Logger LOG = LoggerFactory.getLogger(POSHttpClient.class);

    protected ObjectWriter      writer;

    POSHttpClient() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        writer = mapper.writerFor(new TypeReference<Request>() {});
    }

    protected Long fromString(String s) {
        if(s == null) return null;
        return Long.valueOf(s);
    }

    protected String getPayload(Request r) {
        try{
            String payload = writer.writeValueAsString(r);
            return payload;
        }catch (JsonProcessingException e){
            LOG.info("Prepare payload failed. {}", e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.UNEXPECTED_ERROR, e.getMessage(), e);
        }
    }
}
