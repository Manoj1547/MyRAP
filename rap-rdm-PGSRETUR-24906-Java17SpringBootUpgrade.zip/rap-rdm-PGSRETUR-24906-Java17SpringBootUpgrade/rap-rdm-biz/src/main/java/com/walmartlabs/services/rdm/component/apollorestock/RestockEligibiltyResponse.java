package com.walmartlabs.services.rdm.component.apollorestock;

public class RestockEligibiltyResponse {

    boolean isRestockAtStoreEligible = true;
    boolean isCvpAtStoreEligible = true;
    boolean isDisposeAtStoreEligible = true;
    boolean isDonateAtStoreEligible = true;
    boolean isReturnToRCDisposeEligible = true;
    boolean isReturnToRCDonateEligible = true;
    boolean isReturnToRCLiquidateEligible = true;
    boolean isReturnToRCRTVFiniteEligible = true;
    boolean isReturnToRCRTVInFiniteEligible = true;

    public boolean isRestockAtStoreEligible() {
        return isRestockAtStoreEligible;
    }

    public void setRestockAtStoreEligible(boolean restockAtStoreEligible) {
        isRestockAtStoreEligible = restockAtStoreEligible;
    }

    public boolean isCvpAtStoreEligible() {
        return isCvpAtStoreEligible;
    }

    public void setCvpAtStoreEligible(boolean cvpAtStoreEligible) {
        isCvpAtStoreEligible = cvpAtStoreEligible;
    }

    public boolean isDisposeAtStoreEligible() {
        return isDisposeAtStoreEligible;
    }

    public void setDisposeAtStoreEligible(boolean disposeAtStoreEligible) {
        isDisposeAtStoreEligible = disposeAtStoreEligible;
    }

    public boolean isDonateAtStoreEligible() {
        return isDonateAtStoreEligible;
    }

    public void setDonateAtStoreEligible(boolean donateAtStoreEligible) {
        isDonateAtStoreEligible = donateAtStoreEligible;
    }

    public boolean isReturnToRCDisposeEligible() {
        return isReturnToRCDisposeEligible;
    }

    public void setReturnToRCDisposeEligible(boolean returnToRCDisposeEligible) {
        isReturnToRCDisposeEligible = returnToRCDisposeEligible;
    }

    public boolean isReturnToRCDonateEligible() {
        return isReturnToRCDonateEligible;
    }

    public void setReturnToRCDonateEligible(boolean returnToRCDonateEligible) {
        isReturnToRCDonateEligible = returnToRCDonateEligible;
    }

    public boolean isReturnToRCLiquidateEligible() {
        return isReturnToRCLiquidateEligible;
    }

    public void setReturnToRCLiquidateEligible(boolean returnToRCLiquidateEligible) {
        isReturnToRCLiquidateEligible = returnToRCLiquidateEligible;
    }

    public boolean isReturnToRCRTVFiniteEligible() {
        return isReturnToRCRTVFiniteEligible;
    }

    public void setReturnToRCRTVFiniteEligible(boolean returnToRCRTVFiniteEligible) {
        isReturnToRCRTVFiniteEligible = returnToRCRTVFiniteEligible;
    }

    public boolean isReturnToRCRTVInFiniteEligible() {
        return isReturnToRCRTVInFiniteEligible;
    }

    public void setReturnToRCRTVInFiniteEligible(boolean returnToRCRTVInFiniteEligible) {
        isReturnToRCRTVInFiniteEligible = returnToRCRTVInFiniteEligible;
    }
}
