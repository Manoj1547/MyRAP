package com.walmartlabs.services.rdm.component.incentiveruleengine.util;

import com.walmartlabs.services.rdm.component.incentiveruleengine.model.ReturnIncentiveEngineContext;
import com.walmartlabs.services.rdm.component.incentiveruleengine.jsonmodel.Rule;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author: v0h01q5
 */
@Component
public class ReturnIncentiveEngine {

    private static final Logger LOG  = LoggerFactory.getLogger(ReturnIncentiveEngine.class);

    /**
     * Get all rules from cache for a particular channel and sequentially run all rules.
     * If any rule is not eligible for an item stop the rule engine and return,
     * @param returnIncentiveEngineContext
     */
    public void runReturnIncentiveRuleEngine(ReturnIncentiveEngineContext returnIncentiveEngineContext) {
        BaseItem item = returnIncentiveEngineContext.getItem();
        LOG.info("ReturnIncentiveEngine.runReturnIncentiveRuleEngine started for gtin," + item.getGtin());

        List<Rule> allReturnIncentiveRules = ReturnIncentiveRulesFactory.getReturnIncentiveRules(item.getChannelName());

        boolean ruleResult = true;
        for(Rule returnIncentiveRule : allReturnIncentiveRules){
            AbstractReturnIncentiveRule returnIncentiveRuleBean = ReturnIncentiveRulesFactory.getReturnIncentiveRule(returnIncentiveRule.getRuleName());
            if(returnIncentiveRule != null) {
                ruleResult = returnIncentiveRuleBean.runReturnIncentiveRule(returnIncentiveEngineContext);
                if(ruleResult == false){
                    LOG.info("Item not eligible for return incentive because of rule: {}, gtin: {},",returnIncentiveRuleBean.getRuleName(),item.getGtin());
                    break;
                }
            }else {
                LOG.info("Rule Bean for rule:{} wasn't fetched properly", returnIncentiveRule.getRuleName());
            }
        }

        LOG.info("ReturnIncentiveEngine.runReturnIncentiveRuleEngine exited for gtin," + item.getGtin());
    }
}
