package com.walmartlabs.services.rdm.component.apollorestock;

import com.walmartlabs.services.rdm.component.apollorestock.restockrules.RestockRuleEngine;
import com.walmartlabs.services.rdm.util.RDMTransactionLogger;
import io.strati.txnmarking.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RestockEligibilityEvaluator {


    @Autowired
    RestockRuleEngine restockRuleEngine;

    public RestockEligibiltyResponse evaluateRestockEligibilty(RestockEligibilityContext restockEligibilityContext){


        // Run Conjuction rules and store result in context
        restockRuleEngine.runConjuctionRules(restockEligibilityContext);

        RestockEligibiltyResponse restockEligibiltyResponse = restockEligibilityContext.getRestockEligibiltyResponse();

        return restockEligibiltyResponse;
    }
}
