package com.walmartlabs.services.rdm.component.ovt.service.util;

import com.walmart.pangaea.payment.util.StringUtil;
import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmartlabs.services.rdm.component.ovt.model.response.*;
import com.walmartlabs.services.rdm.config.client.ConfigManager;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import static com.walmartlabs.services.rdm.component.ovt.constants.OVTOmniConstant.*;

import java.text.MessageFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

@Component("storeResponseHandler")
public class StoreResponseHandler extends AbstractResponseHandler {

    @Override
    public OVTOmniItemPolicyDetails handleResponse(ItemPolicyDetailsResponse itemPolicyDetailsResponse, String vendorNo, Set<String> itemIds) {
        OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails = new OVTOmniItemPolicyDetails();
        List<ReturnTerm> returnTermsList = itemPolicyDetailsResponse.getReturnTerms();

        for (ReturnTerm returnTerm : returnTermsList) {
                if (RETURN_AGREEMENT.equals(returnTerm.getReturnTermType()) && ACTIVE.equals(returnTerm.getAgreementStatus())) {
                    updateRequiredAttributesFromReturnAgreement(ovtOmniItemPolicyDetails, returnTerm);
                } else if (ConfigManager.getOvtServiceConfig().getEnableOmniAPILogicForRecall() && RECALL_AGREEMENT.equals(returnTerm.getReturnTermType()) && ACTIVE.equals(returnTerm.getAgreementStatus())) {
                    updateRequiredAttributesFromRecallAgreement(ovtOmniItemPolicyDetails, returnTerm);
                }
        }

        validateResponse(ovtOmniItemPolicyDetails, itemIds, vendorNo);
        return ovtOmniItemPolicyDetails;
    }

    @Override
    void validateResponse(OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails, Set<String> itemIds, String vendorNo) {
        if (null == ovtOmniItemPolicyDetails.getWalmartDiscretion()
                || null == ovtOmniItemPolicyDetails.getClaimFiledBy()) {
            String errorMsg = MessageFormat.format("OVT-HTTP response validation failed as mandatory attribute in response is null for vendorNo :{0} and itemId :{1}"
                    , vendorNo, itemIds.toString());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.OVT_HTTP_CLIENT_EXECUTION_FAILED, errorMsg);
        }
    }

    private void updateRequiredAttributesFromReturnAgreement(OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails, ReturnTerm returnTerm) {
        List<ReturnTermPolicy> returnTermPolicies = returnTerm.getReturnTermPolicies();
        boolean gotRAClaimPolicy = false;
        boolean gotRADispositionPolicy = false;
        if (CollectionUtils.isEmpty(returnTermPolicies)) {
            return;
        }
        for (ReturnTermPolicy returnTermPolicy : returnTermPolicies) {
            if(RA_EXCEPTION_ATTRIBUTE_POLICY.equals(returnTermPolicy.getPolicyType())){
                updateRequiredAttributesFromExceptionPolicy(ovtOmniItemPolicyDetails,returnTermPolicy);
                return;
            }
            if (RA_CLAIM_POLICY.equals(returnTermPolicy.getPolicyType())) {
                updateRequiredAttributesFromClaimPolicy(ovtOmniItemPolicyDetails, returnTermPolicy);
                gotRAClaimPolicy = true;
            } else if (RA_DISPOSITION_POLICY.equals(returnTermPolicy.getPolicyType())) {
                updateRequiredAttributesFromDispositionPolicy(ovtOmniItemPolicyDetails, returnTermPolicy);
                gotRADispositionPolicy = true;
            }
            if (gotRAClaimPolicy && gotRADispositionPolicy) {
                return;
            }
        }
    }

    private void updateRequiredAttributesFromExceptionPolicy(OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails, ReturnTermPolicy returnTermPolicy) {
        List<Policy> policies = returnTermPolicy.getPolicies();
        if (CollectionUtils.isEmpty(policies)) {
            return;
        }
        boolean gotRAClaimPolicy = false;
        boolean gotRADispositionPolicy = false;
        for(Policy policy: policies){
            if(!StringUtil.isNullOrEmpty(policy.getPolicyKey())) {
                //  /NOCLAIM_STORE_DISPOSE$0/RA_FREIGHT_POLICY/all
                // "", NOCLAIM_STORE_DISPOSE$0, RA_FREIGHT_POLICY
                     String policyKey = getPolicyKeyNames(policy.getPolicyKey());
                    if (RA_CLAIM_POLICY.equals(policyKey)) {
                        updateClaimPolicyAttributesFromAttributeList(ovtOmniItemPolicyDetails, policy.getAttributeList());
                        gotRAClaimPolicy = true;
                    } else if (RA_DISPOSITION_POLICY.equals(policyKey)) {
                        updateDispositionPolicyAttributesFromAttributeList(ovtOmniItemPolicyDetails, policy.getAttributeList());
                        gotRADispositionPolicy = true;
                    }
                    if (gotRAClaimPolicy && gotRADispositionPolicy) {
                        return;
                    }
            }
        }
    }


}
