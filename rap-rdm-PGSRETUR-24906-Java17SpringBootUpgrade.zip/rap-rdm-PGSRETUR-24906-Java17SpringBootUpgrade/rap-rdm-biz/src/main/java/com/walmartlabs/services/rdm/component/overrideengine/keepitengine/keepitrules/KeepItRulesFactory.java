package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitrules;

import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.exception.KeepItRuleEngineException;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.jsonmodel.*;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks.IRDMKeepItRuleCheck;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import io.strati.libs.google.gson.Gson;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

@Service
public class KeepItRulesFactory {

    private static final Logger LOGGER = LoggerFactory.getLogger(KeepItRulesFactory.class);
    private static final String DEFAULT_JSON_SCHEMA_FILE = "RdmKeepItRulesConfig.json";

    @Autowired
    List<AbstractRDMKeepItRule> allKeepItRules;

    @Autowired
    RDMKeepItConfig rdmKeepItConfig;

    @Autowired
    List<IRDMKeepItRuleCheck> allKeepItRulesCheck;

    static Map<String, List<AbstractRDMKeepItRule>> keepItRulesCache = new HashMap<>();
    static Map<String, List<IRDMKeepItRuleCheck>> keepItRulesCheckCache = new HashMap<>();

    @PostConstruct
    void initCache() {

        initFromFile();


    }

    private void initFromFile() {
        RDMKeepItJsonRoot rdmKeepItRulesJsonRoot = parseRuleJsonFile();

        Map<String, AbstractRDMKeepItRule> ruleNameVsRuleBean = new HashMap<>();
        for(AbstractRDMKeepItRule rdmKeepItRule : allKeepItRules){
            ruleNameVsRuleBean.put(rdmKeepItRule.getRuleName(), rdmKeepItRule);
        }

        Map<String, IRDMKeepItRuleCheck> ruleCheckNameVsRuleCheckBean = new HashMap<>();
        for(IRDMKeepItRuleCheck rdmKeepItRuleCheck : allKeepItRulesCheck){
            ruleCheckNameVsRuleCheckBean.put(rdmKeepItRuleCheck.getKeepItCheckName(), rdmKeepItRuleCheck);
        }

        Map<String,List<String>> inactiveKeepItRules = parseExcludedKeepItRules(rdmKeepItConfig.getInactiveKeepItRules());
        Map<String,List<String>> inactiveKeepItRuleChecks = parseExcludedKeepItRules(rdmKeepItConfig.getInactiveKeepItRuleChecks());

        for(KeepItRules keepItRules : rdmKeepItRulesJsonRoot.getKeepItRules()){

            String channelName = keepItRules.getChannel();
            List<String> inactiveRulesChannelWise = null != inactiveKeepItRules ? inactiveKeepItRules.get(channelName): null;
            List<String> inactiveRuleChecksChannelWise = null != inactiveKeepItRuleChecks ? inactiveKeepItRuleChecks.get(channelName): null;

            //sort the rules List based on priority
            Collections.sort(keepItRules.getRules());

            for(Rule rule : keepItRules.getRules()) {

                if (rule.isActive() && !isExcludedRule(inactiveRulesChannelWise, rule.getRuleName())) {
                    //Prepare Rules Cache
                    if (!keepItRulesCache.containsKey(channelName)) {
                        keepItRulesCache.put(channelName, new ArrayList<>());
                    }
                    keepItRulesCache.get(channelName).add(ruleNameVsRuleBean.get(rule.getRuleName()));


                    //Prepare Rule Checks Cache
                    for (RuleCheck ruleCheck : rule.getRuleChecks()) {

                        if(ruleCheck.isActive() && !isExcludedRule(inactiveRuleChecksChannelWise, rule.getRuleName())) {
                            if (!keepItRulesCheckCache.containsKey(rule.getRuleName())) {
                                keepItRulesCheckCache.put(rule.getRuleName(), new ArrayList<>());
                            }
                            if (!keepItRulesCheckCache.get(rule.getRuleName()).contains(ruleCheckNameVsRuleCheckBean.get(ruleCheck.getCheckName()))) {
                                keepItRulesCheckCache.get(rule.getRuleName()).add(ruleCheckNameVsRuleCheckBean.get(ruleCheck.getCheckName()));
                            }
                        }
                    }
                }

            }
        }

    }

    private boolean isExcludedRule(List<String> inactiveRuleChecksChannelWise, String ruleName) {
        return null != inactiveRuleChecksChannelWise && inactiveRuleChecksChannelWise.contains(ruleName);
    }

    private Map<String, List<String>> parseExcludedKeepItRules(String inactiveKeepItRules) {
        Gson gson = new Gson();
        Map<String, List<String>> inactiveKeepItRuleJson = gson.fromJson(inactiveKeepItRules, Map.class);
        return  inactiveKeepItRuleJson;
    }


    private RDMKeepItJsonRoot parseRuleJsonFile() {

        RDMKeepItJsonRoot RDMKeepItJsonRoot = null;
        try {
            ClassLoader classLoader = KeepItRulesFactory.class.getClassLoader();
            InputStream inputStream = classLoader.getResourceAsStream(DEFAULT_JSON_SCHEMA_FILE);
            String content = IOUtils.toString(inputStream, System.getProperty("file.encoding"));

            Gson gson = new Gson();
            RDMKeepItJsonRoot = gson.fromJson(content, RDMKeepItJsonRoot.class);
        } catch (IOException e) {
            String errorMsg = "Unable to parse RDMKeepItRules config file-" + DEFAULT_JSON_SCHEMA_FILE;
            throw new RuntimeException(errorMsg, e);
        }

        return RDMKeepItJsonRoot;
    }


    public static List<AbstractRDMKeepItRule> getAllKeepItRules(KeepItRuleEngineContext keeptItRuleEngineContext){
        String key = keeptItRuleEngineContext.getItem().getChannelName();
        if(keepItRulesCache.containsKey(key)){
            return keepItRulesCache.get(key);
        }
        String errorMsg = "KeepIt rules are not configured for key, " + key;
        LOGGER.error(errorMsg);
        throw new KeepItRuleEngineException(ApplicationLayer.BUSINESS_LAYER,
                ErrorCodeMapping.KEEP_IT_RULE_ENGINE_EXECUTION_FAILED, errorMsg);
    }

    public static List<IRDMKeepItRuleCheck> getAllKeepItRuleChecks(String ruleName){

        if(keepItRulesCheckCache.containsKey(ruleName)){
            return keepItRulesCheckCache.get(ruleName);
        }
        String errorMsg = "KeepIt rule checks are not configured for RuleName, " + ruleName;
        LOGGER.error(errorMsg);
        throw new KeepItRuleEngineException(ApplicationLayer.BUSINESS_LAYER,
                ErrorCodeMapping.KEEP_IT_RULE_ENGINE_EXECUTION_FAILED, errorMsg);
    }

}
