package com.walmartlabs.services.rdm.component.ovt.constants;

public interface OVTOmniConstant {

    String RETURN_AGREEMENT = "RETURN_AGREEMENT";
    String RECALL_AGREEMENT = "RECALL_AGREEMENT";
    String RA_CLAIM_POLICY = "RA_CLAIM_POLICY";
    String RA_DISPOSITION_POLICY = "RA_DISPOSITION_POLICY";
    String RA_ADDRESS_POLICY = "RA_ADDRESS_POLICY";
    String RC_BASE_AGREEMENT_POLICY = "RC_BASE_AGREEMENT_POLICY";
    String RA_BASE_AGREEMENT_POLICY = "RA_BASE_AGREEMENT_POLICY";
    String RA_EXCEPTION_ITEM_POLICY = "RA_EXCEPTION_ITEM_POLICY";
    String RA_EXCEPTION_ATTRIBUTE_POLICY = "RA_EXCEPTION_ATTRIBUTE_POLICY";
    String CREDIT_PERCENT = "creditPercent";
    String HANDLING_FEE = "supplierHandlingFee";
    String CLAIM_METHOD = "claimMethod";
    String IS_SUPPLIER_RETURN_ADDRESS_TO_RC = "isSupplierReturnAddressForRC";
    String RETURN_CENTRE_DISPOSITION = "returnCentreDisposition";
    String STORE_DISPOSITION = "storeDisposition";
    String CVP_ELIGIBLE_AT_STORE = "cvpEligibleAtStore";
    String WALMART_DISCRETION = "isWalmartDiscretion";
    String DISPOSITION_DISCRETION = "isDispositionDiscretion";
    String CLAIMABLE = "isClaimable";
    String DMB_ELIGIBLE = "isDMBEnabled";
    String REASON_FOR_REMOVAL = "reasonForRemoval";
    String RECALL = "R";
    String UNDEFINED = "U";
    String POLICY_KEY_ALL = "/all";
    String POLICY_KEY_ALL_ALL = "/all/all";
    String ACTIVE = "A";
    String VENDOR_SHIPMENT_ORIGIN_CODE_RC = "R";
    String VENDOR_SHIPMENT_ORIGIN_CODE_STORE = "S";
    String TRUE = "true";
}
