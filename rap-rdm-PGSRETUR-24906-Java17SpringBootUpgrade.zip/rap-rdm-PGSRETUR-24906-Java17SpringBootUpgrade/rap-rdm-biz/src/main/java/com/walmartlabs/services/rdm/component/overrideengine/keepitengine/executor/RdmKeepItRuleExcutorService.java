package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.executor;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


/**
 * @author v0s00g0
 *
 */
@Component("rdmKeepItRuleExcutorService")
public class RdmKeepItRuleExcutorService {

    private static final Logger LOG = LoggerFactory.getLogger(RdmKeepItRuleExcutorService.class);

    private ExecutorService executor;

    @Resource
    @ManagedConfiguration
    RDMKeepItConfig rdmKeepItConfig;

    @PostConstruct
    public void init() {
        LOG.info("Initializing rdmKeepItRuleExcutorService...");
        int threadCount = rdmKeepItConfig.getKeepItExecutorThreadCount();
        executor = Executors.newFixedThreadPool(threadCount);
        LOG.info("rdmKeepItRuleExcutorService initialized with thread count = " + threadCount);
    }

    @PreDestroy
    public void shutdown() {
        LOG.info("Shutting down rdmKeepItRuleExcutorService...");
        executor.shutdown();
        try {
            if (!executor.awaitTermination(5000, TimeUnit.MILLISECONDS)) {
                executor.shutdownNow();
            }
        } catch (final InterruptedException ie) {
            executor.shutdownNow();
        }
        LOG.info("RdmKeepItRuleExcutorService Shutdown completed...");
    }

    public ExecutorService getExecutor() {
        return executor;
    }

}