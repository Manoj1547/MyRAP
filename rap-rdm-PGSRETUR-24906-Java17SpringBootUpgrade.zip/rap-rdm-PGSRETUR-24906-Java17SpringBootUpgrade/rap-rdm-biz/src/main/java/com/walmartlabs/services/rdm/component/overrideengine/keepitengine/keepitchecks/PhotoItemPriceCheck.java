package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * Rule Check added as a part of PGSRETUR-20059.
 * Checks whether the price is under the threshold
 */
@Component("photoItemPriceCheck")
public class PhotoItemPriceCheck implements IRDMKeepItRuleCheck{

    @Autowired
    RDMKeepItUtil rdmKeepItUtil;

    @ManagedConfiguration
    private RDMKeepItConfig rdmKeepItConfig;

    @Autowired
    public void setRdmKeepItUtil(RDMKeepItUtil rdmKeepItUtil) {
        this.rdmKeepItUtil = rdmKeepItUtil;
    }

    public void setRdmKeepItConfig(RDMKeepItConfig rdmKeepItConfig) {
        this.rdmKeepItConfig = rdmKeepItConfig;
    }
    @Override
    public String getKeepItCheckName() {
        return RDMConstants.RULE_CHECK_NAME_PHOTO_ITEM_PRICE;
    }

    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {
        Double itemRetailPrice = rdmKeepItUtil.getItemPriceFromRequest(keepItRuleEngineContext).doubleValue();

        return rdmKeepItUtil.isPhotoItemPriceEligible(rdmKeepItConfig.getThresholdForPhotoItemPrice(),itemRetailPrice);
    }
}
