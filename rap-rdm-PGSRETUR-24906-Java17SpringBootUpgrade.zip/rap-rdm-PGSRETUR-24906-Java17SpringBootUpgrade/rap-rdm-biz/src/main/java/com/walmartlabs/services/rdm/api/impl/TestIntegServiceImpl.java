package com.walmartlabs.services.rdm.api.impl;

import javax.annotation.Resource;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmartlabs.services.rdm.api.TestIntegService;
import com.walmartlabs.services.rdm.component.iqs.model.request.GetItemDetailsRequest;
import com.walmartlabs.services.rdm.component.iqs.model.response.GetItemDetailsResponse;
import com.walmartlabs.services.rdm.component.iqs.service.utl.IQSHttpClient;
import com.walmartlabs.services.rdm.component.ls.model.GetPrefStoreRequest;
import com.walmartlabs.services.rdm.component.ls.model.GetPrefStoreResponse;
import com.walmartlabs.services.rdm.component.ls.service.util.LocationServiceHttpClient;
import com.walmartlabs.services.rdm.component.rap.model.request.GetReturnEligibilityRequest;
import com.walmartlabs.services.rdm.component.rap.model.response.GetReturnEligibilityResponse;
import com.walmartlabs.services.rdm.component.rap.service.util.ReturnEligibilityServiceHttpClient;
import com.walmartlabs.services.rdm.component.rcp.model.request.GetItemDispositionDetailsRequest;
import com.walmartlabs.services.rdm.component.rcp.model.response.GetItemDispositionDetailsResponse;
import com.walmartlabs.services.rdm.component.rcp.service.util.RCPHttpClient;
import com.walmartlabs.services.rdm.component.restock.service.util.RestockHttpClient;
import com.walmartlabs.services.rdm.component.siro.model.request.GetStoreItemRequest;
import com.walmartlabs.services.rdm.component.siro.model.response.GetStoreItemResponse;
import com.walmartlabs.services.rdm.component.siro.service.util.SIROHttpClient;
import com.walmartlabs.services.rdm.component.restock.model.request.GetRestockItemDetailsRequest;
import com.walmartlabs.services.rdm.component.restock.model.response.GetRestockItemDetailsResponse;

public class TestIntegServiceImpl implements TestIntegService {

    @Resource
    LocationServiceHttpClient lsClient;

    @Resource
    IQSHttpClient             iqsClient;

    @Resource
    RCPHttpClient rcpClient;

    @Resource
    SIROHttpClient siroClient;

    @Resource
    RestockHttpClient restockClient;

    @Resource
    ReturnEligibilityServiceHttpClient returnEligibilityServiceHttpClient;

    @Override
    public GetPrefStoreResponse getPrefStore(String customerId) throws ServiceException {
        GetPrefStoreRequest request = new GetPrefStoreRequest();
        request.setCustomerId(customerId);
        return lsClient.getPrefStore(request);
    }

    @Override
    public GetItemDetailsResponse getItemDetails(String id) {
        GetItemDetailsRequest request = new GetItemDetailsRequest();
        request.setId(id);
        return iqsClient.getItemDetails(request);
    }

    @Override
    public GetItemDispositionDetailsResponse getRcpItemDispositionPolicyDetails(GetItemDispositionDetailsRequest request) throws ServiceException {
        return rcpClient.getRcpItemDispositionPolicyDetails(request);
    }

    @Override
    public GetStoreItemResponse getStoreItemDetails(String gtin, String store, String country, String gtinType) throws ServiceException {
        GetStoreItemRequest request = new GetStoreItemRequest();
        request.setGtin(gtin);
        request.setStore(store);
        request.setCountry(country);
        request.setGtinType(gtinType);
        return siroClient.getStoreItemDetails(request);
    }

    @Override
    public GetRestockItemDetailsResponse getRestockItemDetails(String storeId, String orderNo, String upc, Boolean pristineCondition) throws ServiceException {
        GetRestockItemDetailsRequest request = new GetRestockItemDetailsRequest();
        request.setStoreId(storeId);
        request.setOrderNo(orderNo);
        request.setUpc(upc);
        request.setPristineCondition(pristineCondition);
        return restockClient.getRestockItemDetails(request);
    }

    @Override
    public GetReturnEligibilityResponse getReturnEligibility(String orderId) throws ServiceException {
        GetReturnEligibilityRequest request = new GetReturnEligibilityRequest();
        request.setOrderId(orderId);
        return returnEligibilityServiceHttpClient.getReturnEligibility(request);
    }

}
