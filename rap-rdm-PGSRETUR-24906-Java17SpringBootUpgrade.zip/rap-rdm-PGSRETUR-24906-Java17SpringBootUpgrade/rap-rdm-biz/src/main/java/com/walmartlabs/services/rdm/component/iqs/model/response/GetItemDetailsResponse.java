package com.walmartlabs.services.rdm.component.iqs.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetItemDetailsResponse {
    @JsonProperty("gtins")
    private List<String> gtins;

    @JsonProperty("itemId")
    private String itemId;

    @JsonProperty("tenantId")
    private String tenantId;

    @JsonProperty("product")
    private Product product;

    @JsonProperty("offers")
    private List<OfferInfo> offers;

    @JsonProperty("supplyTradeItems")
    private List<SupplyTradeItem> supplyTradeItems;

    public List<String> getGtins() { return gtins; }

    public void setGtins(List<String> gtins) { this.gtins = gtins; }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public List<OfferInfo> getOffers() {
        return offers;
    }

    public void setOffers(List<OfferInfo> offers) {
        this.offers = offers;
    }

    public List<SupplyTradeItem> getSupplyTradeItems() {
        return supplyTradeItems;
    }

    public void setSupplyTradeItems(List<SupplyTradeItem> supplyTradeItems) {
        this.supplyTradeItems = supplyTradeItems;
    }
}
