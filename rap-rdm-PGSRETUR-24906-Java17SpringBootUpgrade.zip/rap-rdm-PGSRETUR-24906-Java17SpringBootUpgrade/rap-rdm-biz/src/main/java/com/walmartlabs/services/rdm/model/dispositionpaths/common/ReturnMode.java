package com.walmartlabs.services.rdm.model.dispositionpaths.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReturnMode{

    @JsonProperty("name")
    public String name;

    @JsonProperty("returnAllowed")
    public boolean returnAllowed;

    @JsonProperty("replacementAllowed")
    public boolean replacementAllowed;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isReturnAllowed() {
        return returnAllowed;
    }

    public void setReturnAllowed(boolean returnAllowed) {
        this.returnAllowed = returnAllowed;
    }

    public boolean isReplacementAllowed() {
        return replacementAllowed;
    }

    public void setReplacementAllowed(boolean replacementAllowed) {
        this.replacementAllowed = replacementAllowed;
    }
}
