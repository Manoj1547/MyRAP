package com.walmartlabs.services.rdm.component.dsim.model.config.summary.request;


import java.time.OffsetDateTime;
import java.util.Date;

/***
 *   *curl -X GET "https://stage.cvp-us-calculation-service.prod.walmart.com/suggestPrice
 *      * /percent/item/
 *      * 9401350/store/
 *      * 100/iteration/1?
 *      * countryCode=US&
 *      * department=12&expiresDays=-1
 *      * &originalPrice=23&
 *      * quantity=1&
 *      * timestamp=2021-06-15T14%3A28%3A55-05%3A00" -H "accept: "
 */
public class MarkDownRequestContext {
    private String itemNumber;
    private String storeId;
    private String iteration;
    private String countryCode;
    private String departmentNo;
    private String expiresDays;
    private String OriginalPrice;
    private String quantity;
    private String timeStamp;



    public String getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(String itemNumber) {
        this.itemNumber = itemNumber;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getIteration() {
        return iteration == null ? "-1" : iteration;
    }

    public void setIteration(String iteration) {
        this.iteration = iteration;
    }

    public String getCountryCode() {
        return countryCode == null ? "US" : countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getDepartmentNo() {
        return departmentNo;
    }

    public void setDepartmentNo(String departmentNo) {
        this.departmentNo = departmentNo;
    }

    public String getExpiresDays() {
        return expiresDays;
    }

    public void setExpiresDays(String expiresDays) {
        this.expiresDays = expiresDays;
    }

    public String getOriginalPrice() {
        return OriginalPrice;
    }

    public void setOriginalPrice(String originalPrice) {
        OriginalPrice = originalPrice;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    private String key;
    public String getKey(){
        if(key == null){
            key = "{" +
                    "item-" + itemNumber +
                    "__storeId-" + storeId +
                    "__iteration-" + itemNumber +
                    "}";
        }
        return key;
    }
}
