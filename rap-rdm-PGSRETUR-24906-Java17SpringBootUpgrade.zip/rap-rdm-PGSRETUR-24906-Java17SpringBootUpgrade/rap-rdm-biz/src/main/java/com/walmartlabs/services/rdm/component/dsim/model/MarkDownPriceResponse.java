package com.walmartlabs.services.rdm.component.dsim.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.math.BigDecimal;

/***
 *
 *
 * {
 *     "newPrice": 11.50,
 *     "markdownPercentage": 50,
 *     "reductionType": "STATIC_MARKDOWN"
 * }
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MarkDownPriceResponse {
    private Integer markdownPercentage;
    private BigDecimal newPrice;
    private String reductionType;

    public Integer getMarkdownPercentage() {
        return markdownPercentage;
    }

    public void setMarkdownPercentage(Integer markdownPercentage) {
        this.markdownPercentage = markdownPercentage;
    }

    public BigDecimal getNewPrice() {
        return newPrice;
    }

    public void setNewPrice(BigDecimal newPrice) {
        this.newPrice = newPrice;
    }

    public String getReductionType() {
        return reductionType;
    }

    public void setReductionType(String reductionType) {
        this.reductionType = reductionType;
    }

    @Override
    public String toString() {
        return "MarkDownPriceResponse{" +
                "markdownPercentage=" + markdownPercentage +
                ", newPrice=" + newPrice +
                ", reductionType='" + reductionType + '\'' +
                '}';
    }
}
