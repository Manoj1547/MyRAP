package com.walmartlabs.services.rdm.formula.impl.java;

import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.Formula;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import java.util.Map;

/**
 *
 * Author:v0s00g0
 */
@Service
public class StoreToRCTransportCostResolver implements JavaEngineClass {

    @ManagedConfiguration
    RDMSwitches switches;
    private static final Logger LOG = LoggerFactory.getLogger(StoreToRCTransportCostResolver.class);


    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        Double storeToRcTransportCost = 0.0;

        String storeId = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_STORE_ID);
        double storeItemShipToRCCostFactor = RDMConstants.STORE_ITEM_SHIP_TO_RC_COST_MULTIPLIER_FACTOR;
        double dotcomItemShipToRCCostFactor = RDMConstants.DOTCOM_ITEM_SHIP_TO_RC_COST_MULTIPLIER_FACTOR;
        if(switches.getReturnToRCExceptionStores().contains(storeId)){
            //If storeID belongs to exception stores then over ride the transportation cost multiplier factor
            storeItemShipToRCCostFactor = Double.parseDouble(switches.getStoreItemReturntoRcExceptionCostFactor());
            dotcomItemShipToRCCostFactor = Double.parseDouble(switches.getDotcomItemReturntoRcExceptionCostFactor());
        }

        boolean isDotcomItem = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.VARIABLE_DOTCOM_ITEM);
        if(isDotcomItem){
            //cost = multiplierFactor * quantity
            Integer quantity = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.VARIABLE_QUANTITY);
            storeToRcTransportCost = dotcomItemShipToRCCostFactor * quantity;
        } else{
            //cost = multiplierFactor * volume * quantity
            Double volumeInQubicInches = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.VARIABLE_VOLUME);
            if(switches.getItemVolumeValidationEnabled()) {
                if (volumeInQubicInches <= 0) {
                    //If productDimensions are not available in IQS response, volume will be computed as 0
                    String errorMsg = "INVALID IQS RESPONSE:ProductPackageDimensions are invalid";
                    LOG.error(errorMsg);
                    throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                            ErrorCodeMapping.IQS_DATA_VALIDATION_FAILED, errorMsg);
                }
            }
            Double volumeInQubicFoot = volumeInQubicInches/1728;
            Integer quantity = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.VARIABLE_QUANTITY);
            storeToRcTransportCost = storeItemShipToRCCostFactor * volumeInQubicFoot * quantity;
        }

        return storeToRcTransportCost;
    }

}
