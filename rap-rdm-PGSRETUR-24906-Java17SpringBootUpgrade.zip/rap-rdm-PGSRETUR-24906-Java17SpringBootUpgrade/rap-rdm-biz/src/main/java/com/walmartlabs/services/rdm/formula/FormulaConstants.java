package com.walmartlabs.services.rdm.formula;

import java.util.regex.Pattern;

/**
 * 
 * @author Tim Jin
 *
 */
public interface FormulaConstants {

    public String  VARIABLE_WEIGHT_LB                  = "weight";

    public String  VARIABLE_QUANTITY                  = "quantity";

    public String  VARIABLE_R2D2                       = "r2d2";
    public String  VARIABLE_OFFERTYPE                  = "offerType";
    public String  VARIABLE_STORE_ITEM                 = "store";
    public String  VARIABLE_DOTCOM_ITEM                = "dotcom";
    public String  VARIABLE_IS_DOTCOM                  = "is_dotcom";
    public String  VARIABLE_VENDOR_NMUBER              = "vendor_no";
    public String  VARIABLE_DEPARTMENT_NUMBER          = "department_no";
    public String  VARIABLE_CONTRACT_NUMBER            = "contract_no";
    public String  VARIABLE_PRISTINE                   = "pristine";
    public String  VARIABLE_VOLUME                     = "volume";
    public String  VARIABLE_SELLER_ID                   = "sellerId";


    public String  INTERNAL_DATA_NAME_PREFIX           = "@";
    public String  INTERMEDIATE_DATA_NAME_PREFIX       = "_";

    public String  INTERNAL_DATA_NAME_REQUEST_ITEM     = INTERNAL_DATA_NAME_PREFIX + "REQUEST";
    public String  INTERNAL_DATA_NAME_REQUEST_ITEMS    = INTERNAL_DATA_NAME_PREFIX + "REQUEST_ITEMS";
    public String  INTERNAL_DATA_NAME_PRECALL          = INTERNAL_DATA_NAME_PREFIX + "PRECALL";
    public String  INTERNAL_DATA_NAME_POOL             = INTERNAL_DATA_NAME_PREFIX + "POOL";              //thread safe

    public String INTERNAL_DATA_NAME_IQSRDM            = INTERMEDIATE_DATA_NAME_PREFIX + "IQSRDMCALL";
    public String  INTERNAL_DATA_NAME_IQSOFFER         = INTERMEDIATE_DATA_NAME_PREFIX + "IQSOFFER";
    public String  INTERNAL_DATA_NAME_IQSSI            = INTERMEDIATE_DATA_NAME_PREFIX + "IQSSI";
    public String  INTERNAL_DATA_NAME_IQSINDIGO        = INTERMEDIATE_DATA_NAME_PREFIX + "IQSINDIGO";
    public String  INTERNAL_DATA_NAME_IQS_OFFER        = INTERMEDIATE_DATA_NAME_PREFIX + "IQS_OFFER";
    public String  INTERNAL_DATA_NAME_IQS_SI           = INTERMEDIATE_DATA_NAME_PREFIX + "IQS_SI";
    public String  INTERNAL_DATA_NAME_SIRO             = INTERMEDIATE_DATA_NAME_PREFIX + "SIRO";
    public String  INTERNAL_DATA_NAME_SIRO_PR             = INTERMEDIATE_DATA_NAME_PREFIX + "SIRO_PR";
    public String  INTERNAL_DATA_NAME_SIRO_STORE_ITEM  = INTERMEDIATE_DATA_NAME_PREFIX + "SIRO_STORE_ITEM";
    public String  INTERNAL_DATA_NAME_RCP              = INTERMEDIATE_DATA_NAME_PREFIX + "RCP";
    public String  INTERNAL_DATA_NAME_OVT              = INTERMEDIATE_DATA_NAME_PREFIX + "OVT";

    public String  INTERNAL_DATA_NAME_DSIM_MARKDOWN            = INTERMEDIATE_DATA_NAME_PREFIX + "DSIM_MARKDOWN";
    public String  INTERNAL_DATA_NAME_DSIM_MARKDOWN_PRICE_PERCENT            = INTERMEDIATE_DATA_NAME_PREFIX + "DSIM_MARKDOWN_PRICE_PERCENT";
    public String INTERNAL_DATA_NAME_RESTOCK_ELIGIBILITY = INTERMEDIATE_DATA_NAME_PREFIX + "RESTOCK_ELIGIBILITY";


    public String  INTERNAL_DATA_NAME_STORE_ID         = INTERMEDIATE_DATA_NAME_PREFIX + "storeId";
    public String  INTERNAL_DATA_NAME_PRIMARY_ITEM_NBR = INTERMEDIATE_DATA_NAME_PREFIX + "primaryItemNbr";
    public String  INTERNAL_DATA_NAME_ITEM_ID          = INTERMEDIATE_DATA_NAME_PREFIX + "itemId";
    public String  INTERNAL_DATA_NAME_ITEM_NUMBER         = INTERMEDIATE_DATA_NAME_PREFIX + "item_number";

    public String  INTERNAL_DATA_NAME_LENGTH           = INTERMEDIATE_DATA_NAME_PREFIX + "length";
    public String  INTERNAL_DATA_NAME_WIDTH            = INTERMEDIATE_DATA_NAME_PREFIX + "width";
    public String  INTERNAL_DATA_NAME_HEIGHT           = INTERMEDIATE_DATA_NAME_PREFIX + "height";

    public String  INTERNAL_DATA_NAME_IQS_PRICE        = INTERMEDIATE_DATA_NAME_PREFIX + "iqs_price";
    public String  INTERNAL_DATA_NAME_DOTCOM_RETAIL    = INTERMEDIATE_DATA_NAME_PREFIX + "dotcom_retail";

    public String INTERNAL_DATA_NAME_DISPOSITION       = INTERMEDIATE_DATA_NAME_PREFIX + "DISPOSITION";

    public Object  INVALID_VALUE                       = Double.NaN;                                      //null is valid

    public Pattern FORMULA_DISPLAY_NAME_PATTERN        = Pattern.compile("([^@]+)__(.+)");
    public Pattern JSONP_FORMULA_PATTERN               = Pattern.compile("([^:]+):(.+)");

    public String INTERMEDIATE_DATA_NAME_EXTERNAL_API_EXCEPTIONS = INTERMEDIATE_DATA_NAME_PREFIX + "EXTERNAL_API_EXCEPTIONS";
    public String  INTERMEDIATE_DATA_NAME_EXCEPTION              = INTERMEDIATE_DATA_NAME_PREFIX + "EXCEPTION";

    String USE_RAP_RULE = "use_rap_rule";
    String INTERNAL_DATA_NAME_IQSRDM_FUTURE = "iqs_rdm_future";
    String INTERNAL_DATA_NAME_SIRO_FUTURE = "siro_rdm_future";
    String INTERNAL_DATA_NAME_POS_ITEM_DATA_FUTURE = "pos_item_data_future";
    String INTERNAL_DATA_NAME_POS_DEPT_DATA_FUTURE = "pos_dept_data_future";
    String INTERNAL_DATA_NAME_GSF_FUTURE = "gsf_future";
    String INTERNAL_DATA_NAME_RCP_FUTURE = "rcp_future";
    String INTERNAL_DATA_NAME_IQS_FUTURE = "iqs_future";
    String INTERNAL_DATA_NAME_DISPOSITION_FUTURE = "disposition_future";
    String INTERNAL_DATA_NAME_LS_FUTURE = "ls_future";
    String INTERNAL_DATA_NAME_LS_NEW_API_FUTURE = "ls_new_api_future";
    String INTERNAL_DATA_NAME_OVT_OMNI_FUTURE = "ovt_future";

    String FORMULA_NAME_DISPOSITION = "_DISPOSITION";

    String FORMULA_NAME_POS_ITEM    = "_POS_ITEM";
    String FORMULA_NAME_POS_ITEM_PREDICTION    = "_pos_item";
    String FORMULA_NAME_POS_DEPT_PREDICTION    = "_pos_dept";

    String FORMULA_NAME_DONATE_IN_STORE    = "_donate_in_store";

    String FORMULA_NAME_DISPOSE_IN_STORE    = "_dispose_in_store";

    String FORMULA_NAME_IQSRDMCALL = "_IQSRDMCALL";
    String FORMULA_NAME_LS    = "_LS";
    String FORMULA_NAME_GSF = "_GSF";
    String FORMULA_NAME_SIRO = "_SIRO";
    String FORMULA_NAME_OVT = "_OVT";

    String INTERNAL_DATA_NAME_OVT_FILTERED_STORE = "ovt_filtered_store";

    String PRE_CALL = "_PRE_CALL";
    String EXCLUDED_DEPT_LIST = "excluded_dept_list";

    String LMD = "LMD";
    String CURBSIDE = "CURB_SIDE";
    String STORE = "STORE";
    String CARRIER_PICKUP = "CARRIER_PICKUP";


    //null is a valid value while NaN means something wrong or a mandatory value is missing
    public static boolean isInvalidValue(Object value) {
        if(value != null && value instanceof Double){ return Double.isNaN((Double) value); }
        return false;
    }

}
