package com.walmartlabs.services.rdm.component.common;

import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import com.walmartlabs.services.rdm.config.ConfigConstants;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import com.walmartlabs.services.rdm.util.TransactionUtil;
import com.walmartlabs.services.rdm.util.cache.CacheManager;

import io.strati.StratiServiceProvider;
import io.strati.configuration.ConfigurationService;
import io.strati.txnmarking.Transaction;
import io.strati.txnmarking.TransactionMarkingService;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public abstract class CommonCCMHttpClient {

    private static final Logger  LOG                  = LoggerFactory.getLogger(CacheManager.class);

    private static final String  DEFAULT_CONTENT_TYPE = "application/json";
    private static final String  DEFAULT_CHAR_SET     = "UTF-8";
    private static final Integer DEFAULT_TIMEOUT_MS   = 1000;

    protected abstract String getServiceName();

    protected abstract String getCCMName();

    @Resource
    private ConfigurationService      configService;

    private TransactionMarkingService TMS;

    private Properties allCCMProperties;

    @PostConstruct
    protected void init() {
        try{
            TMS = StratiServiceProvider.getInstance().getTransactionMarkingService().get();
            LOG.info("Success");
        }catch (Exception e){
            //if cache not initialized don't block the app to start
            LOG.error("CommonCCMHttpClient failed to load. {}", e.getMessage());
        }
    }

    public String call(String request) {
        String name = getServiceName();
        String ccm = getCCMName();

        allCCMProperties = configService.getConfiguration(ccm).getPropertiesSnapshot();
        Transaction t = TransactionUtil.getTransaction(TMS, "CommonHttpClient-" + name);
        t.start();
        try{
            LOG.info("POS Service Call, ServiceName {}, CCM {}", name, ccm);
            String response = post(getEndpoint(name), collectQueryParams(name), collectHeaders(name), getTimeout(name), request);
            t.end();
            LOG.info("POS Service Response, ServiceName {}, Request {}, Response {}", name, request, response);
            return response;
        }catch (Exception e){
            t.endWithFailure(e.getMessage());
            LOG.error("POS Httpclient failed, ServiceName {} ,Request {}, error {}", name, request, e.getMessage(),e);
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.COMMON_HTTP_CLIENT, e.getMessage(), e);
        }

    }

    public Integer getTimeout(String name) {
        String timeout = allCCMProperties.getProperty(name + ".timeout");
        return timeout == null ? DEFAULT_TIMEOUT_MS : Integer.valueOf(timeout);
    }

    protected String getEndpoint(String name) {
        String endpoint = StringUtils.trimToNull(allCCMProperties.getProperty(name + ".endpoint"));
        if(endpoint == null) {
            String errorMsg = MessageFormat.format("POS Service Endpoint is invalid. serviceName{}", name);
            LOG.error(errorMsg);
            throw new IllegalArgumentException(errorMsg);
        }
        return endpoint;
    }

    protected Map<String, List<String>> collectQueryParams(String name) {
        return collectMap(allCCMProperties, name + ".query.");
    }

    protected Map<String, List<String>> collectHeaders(String name) {
        return collectMap(allCCMProperties, name + ".header.");
    }

    protected Map<String, List<String>> collectMap(Properties properties, String name) {
        Map<String, List<String>> map = new HashMap<>();
        if(properties != null) for(String property : properties.stringPropertyNames()){
            String key = StringUtils.removeStart(property, name);
            if(key != property){
                map.putIfAbsent(key, new ArrayList<>());
                map.get(key).add(properties.getProperty(property));
            }
        }
        return map;
    }

    private String post(String endpoint, Map<String, List<String>> params, Map<String, List<String>> headers, Integer timeout, String payload) throws ServiceException {
        try{
            URIBuilder builder = new URIBuilder(endpoint);
            if(params != null) for(Map.Entry<String, List<String>> entry : params.entrySet()){
                for(String value : entry.getValue()){
                    builder.addParameter(entry.getKey(), value);
                }
            }

            HttpPost request = new HttpPost(builder.build());
            if(headers != null) for(Map.Entry<String, List<String>> entry : headers.entrySet()){
                for(String value : entry.getValue()){
                    request.addHeader(entry.getKey(), value);
                }
            }

            RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(timeout).setConnectionRequestTimeout(timeout).setSocketTimeout(timeout).build();
            request.setConfig(requestConfig);

            StringEntity body = new StringEntity(payload, DEFAULT_CHAR_SET);
            body.setContentType(DEFAULT_CONTENT_TYPE);
            request.setEntity(body);

            return execute(request);
        }catch (URISyntaxException e){
            String errorMsg = MessageFormat.format("Invalid URI from query params [{0}]. Error message: {1}", params.toString(), e.getMessage());
            LOG.error(errorMsg);
            throw new IllegalArgumentException(errorMsg, e);
        }

    }

    private String execute(HttpRequestBase request) throws ServiceException {
        try (CloseableHttpClient httpClient = HttpClientBuilder.create().build()){
            LOG.info("Executing {} for endpoint {}", request.getMethod(), request.getURI());
            HttpResponse response = httpClient.execute(request);

            int responseCode = response.getStatusLine().getStatusCode();
            if(responseCode != 200){
                String errorMsg = MessageFormat.format("Executing {0} failed with response code:{1}", request, responseCode);
                LOG.error(errorMsg);

                String errorPayload;
                try (InputStream inputStream = response.getEntity().getContent()){
                    errorPayload = IOUtils.toString(inputStream, "UTF-8");
                }
                LOG.error(errorPayload);

                throw new ServiceException(errorPayload);
            }

            String responseString = EntityUtils.toString(response.getEntity());
            LOG.info("Response {}", responseString);
            return responseString;
        }catch (IOException e){
            String errorMsg = MessageFormat.format("IOException when executing [{0}]: {1}", request, e.getMessage());
            LOG.error(errorMsg);
            throw new ServiceException(e.getMessage());
        }

    }
}
