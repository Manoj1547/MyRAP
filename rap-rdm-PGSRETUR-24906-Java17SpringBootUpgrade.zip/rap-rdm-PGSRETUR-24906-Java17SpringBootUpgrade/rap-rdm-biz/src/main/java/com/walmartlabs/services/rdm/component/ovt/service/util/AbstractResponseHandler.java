package com.walmartlabs.services.rdm.component.ovt.service.util;

import com.walmartlabs.services.rdm.component.ovt.model.response.*;
import org.apache.commons.collections4.CollectionUtils;

import static com.walmartlabs.services.rdm.component.ovt.constants.OVTOmniConstant.*;


import java.util.List;
import java.util.Set;

public abstract class AbstractResponseHandler {

    abstract OVTOmniItemPolicyDetails handleResponse(ItemPolicyDetailsResponse itemPolicyDetailsResponse, String vendorNo, Set<String> items);

    protected void updateRequiredAttributesFromRecallAgreement(OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails, ReturnTerm returnTerm) {
        List<ReturnTermPolicy> returnTermPolicies = returnTerm.getReturnTermPolicies();
        if (CollectionUtils.isEmpty(returnTermPolicies)) {
            return;
        }
        for (ReturnTermPolicy returnTermPolicy : returnTermPolicies) {
            if (RC_BASE_AGREEMENT_POLICY.equals(returnTermPolicy.getPolicyType())) {
                updateRequiredAttributesFromBaseAgreementPolicy(ovtOmniItemPolicyDetails, returnTermPolicy);
                return;
            }
        }
    }

    protected void updateRequiredAttributesFromBaseAgreementPolicy(OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails, ReturnTermPolicy returnTermPolicy) {
        List<Policy> policies = returnTermPolicy.getPolicies();
        if (CollectionUtils.isEmpty(policies)) {
            return;
        }
        for (Policy policy : policies) {
            if (POLICY_KEY_ALL.equals(policy.getPolicyKey())) {
                List<Attribute> attributeList = policy.getAttributeList();
                if (CollectionUtils.isEmpty(attributeList)) {
                    return;
                }
                for (Attribute attribute : attributeList) {
                    if (REASON_FOR_REMOVAL.equals(attribute.getName()) && attribute.getValue() != null
                            && (RECALL.equals(attribute.getValue()) || UNDEFINED.equals(attribute.getValue()))) {
                        ovtOmniItemPolicyDetails.setRecall(true);
                        return;

                    }
                }
            }
        }
    }

    protected void updateRequiredAttributesFromClaimPolicy(OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails, ReturnTermPolicy returnTermPolicy) {
        List<Policy> policies = returnTermPolicy.getPolicies();
        if (CollectionUtils.isEmpty(policies)) {
            return;
        }
        for (Policy policy : policies) {
            if (POLICY_KEY_ALL.equals(policy.getPolicyKey())) {
               updateClaimPolicyAttributesFromAttributeList(ovtOmniItemPolicyDetails,policy.getAttributeList());
                return;
            }
        }
    }

    abstract void validateResponse(OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails, Set<String> items, String vendorNo);

    protected void updateClaimPolicyAttributesFromAttributeList(OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails, List<Attribute> attributeList) {
        if (CollectionUtils.isEmpty(attributeList)) {
            return;
        }
        for (Attribute attribute : attributeList) {
            switch (attribute.getName()) {
                case HANDLING_FEE:
                    if (attribute.getValue() != null) {
                        ovtOmniItemPolicyDetails.setHandlingFeeAmount(Double.valueOf(attribute.getValue()));
                    }
                    break;
                case CREDIT_PERCENT:
                    if (attribute.getValue() != null) {
                        ovtOmniItemPolicyDetails.setClaimPercent(Double.valueOf(attribute.getValue()));
                    }
                    break;
                case WALMART_DISCRETION:
                    ovtOmniItemPolicyDetails.setWalmartDiscretion(Boolean.valueOf(attribute.getValue()));
                    break;
                case DISPOSITION_DISCRETION:
                    ovtOmniItemPolicyDetails.setDispositionDiscretion(Boolean.valueOf(attribute.getValue()));
                    break;
                case CLAIMABLE:
                    ovtOmniItemPolicyDetails.setClaimable(Boolean.valueOf(attribute.getValue()));
                    break;
                default: // Do Nothing
            }
        }
    }

    protected void updateDispositionPolicyAttributesFromAttributeList(OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails, List<Attribute> attributeList) {
        if (CollectionUtils.isEmpty(attributeList)) {
            return;
        }

        for (Attribute attribute : attributeList) {
            switch (attribute.getName()) {
                case CLAIM_METHOD:
                    ovtOmniItemPolicyDetails.setClaimFiledBy(attribute.getValue());
                    break;
                case RETURN_CENTRE_DISPOSITION:
                    ovtOmniItemPolicyDetails.setReturnCentreDisposition(attribute.getValue());
                    break;
                case CVP_ELIGIBLE_AT_STORE:
                    ovtOmniItemPolicyDetails.setCvpEligibleAtStore(Boolean.valueOf(attribute.getValue()));
                    break;
                case STORE_DISPOSITION:
                    ovtOmniItemPolicyDetails.setStoreDisposition(attribute.getValue());
                    break;
                default: // Do Nothing
            }
        }
    }

    protected void updateRequiredAttributesFromDispositionPolicy(OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails, ReturnTermPolicy returnTermPolicy){
        List<Policy> policies = returnTermPolicy.getPolicies();
        if (CollectionUtils.isEmpty(policies)) {
            return;
        }
        for (Policy policy : policies) {
            if (POLICY_KEY_ALL.equals(policy.getPolicyKey())) {
                updateDispositionPolicyAttributesFromAttributeList(ovtOmniItemPolicyDetails,policy.getAttributeList());
            }
        }
    }

    protected String getPolicyKeyNames(String policyKey) {
        String policyKeyName = null;
        String[] policyKeyNames = policyKey.split("/");
        if(policyKeyNames.length>2){
            policyKeyName = policyKeyNames[2];
        }
        return policyKeyName;
    }
}
