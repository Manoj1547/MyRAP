package com.walmartlabs.services.rdm.formula.impl.java.iqs.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmartlabs.services.rdm.component.iqs.model.request.ItemRDMRequest;
import com.walmartlabs.services.rdm.component.iqs.model.response.GetItemDetailsResponse;
import com.walmartlabs.services.rdm.component.iqs.model.response.iqs.*;
import com.walmartlabs.services.rdm.component.iqs.model.response.iqs.mapper.RDMiqsGetItemMapper;
import com.walmartlabs.services.rdm.component.iqs.service.utl.RDMIQSHttpClient;
import com.walmartlabs.services.rdm.config.client.IQSServiceConfig;
import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import com.walmartlabs.services.rdm.model.SellerType;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import com.walmartlabs.services.rdm.util.cache.CacheManager;
import com.walmartlabs.services.rdm.util.cache.CacheRole;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * Author:v0s00g0
 */

@Component
public class IQSRDMService {

    private static final Logger LOG = LoggerFactory.getLogger(IQSRDMService.class);

    public static final String GTIN = "GTIN";

    private ObjectMapper objectMapper;

    @ManagedConfiguration
    private RDMSwitches switches;

    @Resource
    @ManagedConfiguration
    private IQSServiceConfig iqsServiceConfig;

    @Autowired
    private RDMIQSHttpClient rdmiqsHttpClient;

    @Autowired
    private RDMiqsGetItemMapper rdmIQSItemMapper;

    @Resource
    private CacheManager cacheManager;

    private boolean throwEx = false;

    @PostConstruct
    protected void init() {
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    public GetItemDetailsResponse getIQSRdmItemDetails(BaseItem item) {

        LOG.info("Entering IQSRDMService.getIQSRdmItemDetails");
        ItemRDMRequest request = prepareRequest(item);

        IQSRDMResponse iqsRdmResponse = null;
        if (iqsServiceConfig.getIqsServiceCachingEnabled()) {
            iqsRdmResponse = getIQSRdmItemDetailsWithCache(request);
        } else {
            iqsRdmResponse = getIQSRdmItemDetailsWithOutCache(request);
        }

        GetItemDetailsResponse getItemDetailsResponse = rdmIQSItemMapper.map(iqsRdmResponse);
        LOG.info("Exiting IQSRDMService.getIQSRdmItemDetails");
        return getItemDetailsResponse;

    }

    private IQSRDMResponse getIQSRdmItemDetailsWithOutCache(ItemRDMRequest request) {
        IQSRDMResponse iqsRdmResponse = callIQSService(request);
        return iqsRdmResponse;
    }

    private IQSRDMResponse getIQSRdmItemDetailsWithCache(ItemRDMRequest request) {
        String key = request.getKey();
        IQSRDMResponse iqsRdmCachedResponse = getIQSDataFromCache(key);

        if (iqsRdmCachedResponse == null) {
            iqsRdmCachedResponse = callIQSService(request);
            putIQSDataInCache(key, iqsRdmCachedResponse);
        }
        return iqsRdmCachedResponse;
    }

    private void putIQSDataInCache(String key, IQSRDMResponse iqsRdmResponse) {

        String cacheData;
        try {
            cacheData = objectMapper.writeValueAsString(iqsRdmResponse);
        } catch (JsonProcessingException e) {
            LOG.error("JsonProcessingException while putting data in IQS cache for key, " + key, e);
            return;
        }
        cacheManager.put(key, cacheData, CacheRole.IQS);
    }


    private IQSRDMResponse getIQSDataFromCache(String key) {
        String iqsCachedData = cacheManager.get(key, CacheRole.IQS);
        IQSRDMResponse iqsRdmCachedResponse = null;
        if(iqsCachedData != null) {
            try {
                iqsRdmCachedResponse = objectMapper.readValue(iqsCachedData, IQSRDMResponse.class);
            } catch (JsonProcessingException e) {
                LOG.error("JsonProcessingException while converting iqs cached data in response format for key, " + key, e);
            }
        }
        return iqsRdmCachedResponse;
    }

    private IQSRDMResponse callIQSService(ItemRDMRequest request) {
        IQSRDMResponse iqsRdmResponse = rdmiqsHttpClient.getRDMItemDetails(request);

        if (switches.getValidateIQSResponse()) {
            validateIQSResponse(iqsRdmResponse, request);
        }
        return iqsRdmResponse;
    }


    private void validateIQSResponse(IQSRDMResponse iqsRdmResponse, ItemRDMRequest request) {

        if (iqsRdmResponse == null || iqsRdmResponse.getIqsResponseData() == null || iqsRdmResponse.getIqsResponseData().getCatalogItemData() == null
                || iqsRdmResponse.getIqsResponseData().getCatalogItemData().isEmpty()) {
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, "INVALID IQS RESPONSE :catalog item data not found " + request);
        }
        CatalogItemData catalogItemData = iqsRdmResponse.getIqsResponseData().getCatalogItemData().get(0);

        List<SupplyItem> supplyItems = catalogItemData.getSupplyItemsList();
        if (CollectionUtils.isEmpty(supplyItems)) {
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, "INVALID IQS RESPONSE :catalog item supplyitem details not found " + request);
        }
        List<com.walmartlabs.services.rdm.component.iqs.model.response.iqs.OfferInfo> offerInfoList = catalogItemData.getOfferInfoList();
        if (CollectionUtils.isEmpty(offerInfoList)) {
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, "INVALID IQS RESPONSE :catalog item offerInfo details not found " + request);
        }
        if (catalogItemData.getIdentifiers() == null) {
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, "INVALID IQS RESPONSE :catalog item idetifier not  found " + request);
        }
        if (catalogItemData.getIdentifiers().getItemId() == null) {
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, "INVALID IQS RESPONSE :catalog item idetifier  itemId not  found " + request);
        }

        if (catalogItemData.getProduct() == null || catalogItemData.getProduct().getReD2Info() == null || catalogItemData.getProduct().getReD2Info().getPath() == null) {
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, "INVALID IQS RESPONSE :catalog item product details   are not valid " + request);
        }
        for (com.walmartlabs.services.rdm.component.iqs.model.response.iqs.OfferInfo offerInfo : offerInfoList) {

            validateOfferInfo(offerInfo, request);
        }


    }

    private void validateOfferInfo(com.walmartlabs.services.rdm.component.iqs.model.response.iqs.OfferInfo offerInfo, ItemRDMRequest request) {
        if (offerInfo == null) {
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, "INVALID IQS RESPONSE :OfferInfo details   are not valid " + request);
        }


        if (offerInfo.getCurrentPriceCurrencyAmount() == null) {
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, "INVALID IQS RESPONSE :OfferInfo price is missing " + request);
        }
        if (switches.getValidateIQSResponsePackageDimension()) {
            validatePackageDimension(offerInfo, request);
        }

    }

    private void validatePackageDimension(OfferInfo offerInfo, ItemRDMRequest request) {
        if (offerInfo.getProductPackageDimensions() == null || offerInfo.getProductPackageDimensions().isEmpty()) {
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, "INVALID IQS RESPONSE :OfferInfo ProductPackageDimensions  is missing " + request);
        }

        ProductPackageDimension productPackageDimension = offerInfo.getProductPackageDimensions().get(0);
        if (productPackageDimension.getUnitHeight() == null || productPackageDimension.getUnitLength() == null || productPackageDimension.getUnitWidth() == null
                || productPackageDimension.getUnitWeight() == null) {
                throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                        ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, "INVALID IQS RESPONSE :OfferInfo ProductPackageDimensions attributes  are missing " + request);
        }
    }

    private ItemRDMRequest prepareRequest(BaseItem item) {
        ItemRDMRequest rdmRequest = new ItemRDMRequest();
        List<String> gtins = new ArrayList<>();
        gtins.add(item.getGtin());
        rdmRequest.setType(GTIN);
        if(null == item.getSellerType() || SellerType.WM.equals(item.getSellerType())){
            rdmRequest.setSellerId(switches.getOnePSellerID());
        }else{
            rdmRequest.setSellerId(item.getSellerId());
        }
        rdmRequest.setIds(gtins);
        return rdmRequest;
    }

}
