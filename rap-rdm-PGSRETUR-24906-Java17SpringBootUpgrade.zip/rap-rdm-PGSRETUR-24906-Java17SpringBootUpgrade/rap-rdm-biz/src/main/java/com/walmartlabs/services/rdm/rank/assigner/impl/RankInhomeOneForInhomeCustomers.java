package com.walmartlabs.services.rdm.rank.assigner.impl;

import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import com.walmartlabs.services.rdm.rank.assigner.RankAssigner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

import static com.walmartlabs.services.rdm.RDMConstants.INHOME_PICKUP;

/**
 * If Inhome is eligible return mode/ disposition path in response then prioritize it i.e rank it as one whatever maybe
 * the recovery value
 * @author v0h01q5
 */
@Component("rankInhomeOneForInhomeCustomers")
public class RankInhomeOneForInhomeCustomers extends RankAssigner {
    private static final Logger LOG                      = LoggerFactory.getLogger(RankInhomeOneForInhomeCustomers.class);

    @Override
    public void assignRanks(List<DispositionInfo> allItemsDispositionInfoList) {

        for (DispositionInfo dispositionInfo : allItemsDispositionInfoList) {
            if (!dispositionInfo.getIsDefault() && null != dispositionInfo.getDispositionPaths()) {
                Optional<DispositionPath> optionalDispositionInfo = dispositionInfo.getDispositionPaths().stream().filter(e ->  INHOME_PICKUP.equalsIgnoreCase(e.getPath())).findFirst();
                if (optionalDispositionInfo.isPresent()) {
                    DispositionPath inhomeDispositionPath = optionalDispositionInfo.get();
                    for(DispositionPath dispositionPath:dispositionInfo.getDispositionPaths()){
                        int currDispositionPathRank = dispositionPath.getRank();
                        if(currDispositionPathRank < inhomeDispositionPath.getRank()){
                            dispositionPath.setRank(currDispositionPathRank+1);
                        }
                    }
                    inhomeDispositionPath.setRank(1);
                    LOG.info("RankAssigner ranked Inhome 1 for orderNo:{}, itemId:{}, channel:{}", dispositionInfo.getItem().getOrderNo(),
                            dispositionInfo.getItem().getItemId(), dispositionInfo.getItem().getChannelName());
                }
            }
        }
    }
}
