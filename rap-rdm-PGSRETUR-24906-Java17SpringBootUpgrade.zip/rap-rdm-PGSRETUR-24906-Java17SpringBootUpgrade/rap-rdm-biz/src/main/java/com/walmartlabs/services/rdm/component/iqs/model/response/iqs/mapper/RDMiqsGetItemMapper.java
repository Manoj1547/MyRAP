package com.walmartlabs.services.rdm.component.iqs.model.response.iqs.mapper;

import com.walmart.services.common.model.money.CurrencyUnitEnum;
import com.walmart.services.common.model.money.MoneyType;
import com.walmartlabs.services.rdm.component.iqs.model.response.*;
import com.walmartlabs.services.rdm.component.iqs.model.response.iqs.CatalogItemData;
import com.walmartlabs.services.rdm.component.iqs.model.response.iqs.IQSRDMResponse;
import com.walmartlabs.services.rdm.component.iqs.model.response.iqs.SupplyItem;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class RDMiqsGetItemMapper {

    public void mapProduct(IQSRDMResponse iqsrdmResponse, GetItemDetailsResponse itemDetailsResponse){

        // for IQS Product
        // JSONP
        //"_IQSPRODUCT:product.derived_attributes.r2d2.values[0].path"
        Product product = new Product();
        CatalogItemData itemData = iqsrdmResponse.getIqsResponseData().getCatalogItemData().get(0);
        itemDetailsResponse.setItemId(itemData.getIdentifiers().getItemId());
        product.setProductId(itemData.getProductId());
        DerivedAttributes derivedAttributes  = new DerivedAttributes();
        product.setDerivedAttributes( derivedAttributes);
        R2D2Hierarchy r2D2Hierarchy = new R2D2Hierarchy();
        List<Value> valueList = new ArrayList<>();
        Value value= new Value();

        value.setPath(itemData.getProduct().getReD2Info().getPath());
        valueList.add(value);
        r2D2Hierarchy.setValues(valueList);
        derivedAttributes.setR2D2Hierarchy( r2D2Hierarchy);
        itemDetailsResponse.setProduct(product);


    }

    private void mapSupplyItems(IQSRDMResponse iqsrdmResponse,GetItemDetailsResponse itemDetailsResponse) {
        /*
         * _IQS_SI
         * "formula": "_IQS_SI:payloadJson.attributes.baseRetailAmt",
         * "_IQS_SI:payloadJson.attributes.supplierSeqNbr",
         * IQS_SI:payloadJson.attributes.deptNbr",
         *  "formula": "_IQS_SI:payloadJson.attributes.unitCostAmt",
         *  IQS_SI:payloadJson.attributes.supplierNbr",
         * _IQS_SI
         */
        // Missing parameters
        // getPartnershipTypeCode
        // getItemNbr
        // getIsPrimaryVendor


        List<SupplyTradeItem> supplyTradeItemList = new ArrayList<>();
        itemDetailsResponse.setSupplyTradeItems(supplyTradeItemList);
        List<SupplyItem> supplyItems = iqsrdmResponse.getIqsResponseData().getCatalogItemData().get(0).getSupplyItemsList();
        for(SupplyItem supplyItem : supplyItems){
            SupplyTradeItem supplyTradeItem = new SupplyTradeItem();
            PayloadJson json = new PayloadJson();
            Attributes attributes = new Attributes();
            attributes.setBaseRetailAmt(supplyItem.getBaseRetailAmt());
            attributes.setSupplierSeqNbr(supplyItem.getSupplierSequenceNumber().intValue());
            attributes.setDeptNbr(supplyItem.getDepartmentNumber().intValue());
            attributes.setUnitCostAmt(supplyItem.getUnitCostAmt());
            attributes.setSupplierNbr(supplyItem.getSupplierNumber().intValue());
            attributes.setIsPrimaryVendor(supplyItem.isPrimaryVendor());
            attributes.setItemNbr(supplyItem.getItemNumber().intValue());
            supplyItem.setPartnershipTypeCode(supplyItem.getPartnershipTypeCode());
            json.setAttributes(attributes);
            supplyTradeItem.setPayloadJson(json);
            supplyTradeItemList.add(supplyTradeItem);
        }


    }

    private void mapOffer(IQSRDMResponse iqsrdmResponse,GetItemDetailsResponse itemDetailsResponse) {
        List<OfferInfo> offerInfoList = new ArrayList<>();
        itemDetailsResponse.setOffers(offerInfoList);
        for(com.walmartlabs.services.rdm.component.iqs.model.response.iqs.OfferInfo offerInfo : iqsrdmResponse.getIqsResponseData().getCatalogItemData().get(0).getOfferInfoList()){
            OfferInfo offerInfo1 = new OfferInfo();
            Limo limo = new Limo();
            LogisticsOffer logisticsOffer = new LogisticsOffer();
            FlagAttributes flagAttributes = new FlagAttributes();
            logisticsOffer.setFlagAttributes(flagAttributes);
            flagAttributes.setHazmat(offerInfo.getIsHazmat());
            Offer offer = new Offer();
            offer.setOfferId(offerInfo.getOfferId());
            offer.setOfferType(offerInfo.getOfferType());
            offer.setSellerId(offerInfo.getSellerId());
            offerInfo1.setOffer(offer);
            List<Pricing> pricings = new ArrayList<>();
            offerInfo1.setPricing(pricings);
            Pricing pricing = new Pricing();
            StorefrontPricing storefrontPricing = new StorefrontPricing();
            CurrentPrice currentPrice = new CurrentPrice();
            storefrontPricing.setCurrentPrice(currentPrice);
            MoneyType moneyType = new MoneyType(offerInfo.getCurrentPriceCurrencyAmount(), CurrencyUnitEnum.USD);
            currentPrice.setCurrentValue(moneyType);
            List<StorefrontPricing> storefrontPricings = new ArrayList<>();
            storefrontPricings.add(storefrontPricing);
            pricing.setStorefrontPricingList(storefrontPricings);
            pricings.add(pricing);
            limo.setLogisticsOffer(logisticsOffer);
            offerInfo1.setLimo(limo);
            OfferShipmentSpecification shipmentSpecification = new OfferShipmentSpecification();
            shipmentSpecification.setShipSizeCode(offerInfo.getShipSizeCode());
            List<ProductPackageDimension> productPackageDimensions = new ArrayList<>();
            for(com.walmartlabs.services.rdm.component.iqs.model.response.iqs.ProductPackageDimension productPackageDimensionSource : offerInfo.getProductPackageDimensions()) {
                ProductPackageDimension productPackageDimension = new ProductPackageDimension();
                productPackageDimension.setUnitHeight(productPackageDimensionSource.getUnitHeight());
                productPackageDimension.setUnitLength(productPackageDimensionSource.getUnitLength());
                productPackageDimension.setUnitWeight(productPackageDimensionSource.getUnitWeight());
                productPackageDimension.setUnitWidth(productPackageDimensionSource.getUnitWidth());
                productPackageDimensions.add(productPackageDimension);

            }
            limo.getLogisticsOffer().setProductPackageDimensions(productPackageDimensions);
            limo.getLogisticsOffer().setOfferShipmentSpecification(shipmentSpecification);
            offerInfoList.add(offerInfo1);
        }


    }


     public GetItemDetailsResponse map(IQSRDMResponse iqsrdmResponse){
         GetItemDetailsResponse itemDetailsResponse = new GetItemDetailsResponse();

         mapProduct(iqsrdmResponse,itemDetailsResponse);
         mapSupplyItems(iqsrdmResponse,itemDetailsResponse);;
         mapOffer(iqsrdmResponse,itemDetailsResponse);;
         return itemDetailsResponse;
     }




}
