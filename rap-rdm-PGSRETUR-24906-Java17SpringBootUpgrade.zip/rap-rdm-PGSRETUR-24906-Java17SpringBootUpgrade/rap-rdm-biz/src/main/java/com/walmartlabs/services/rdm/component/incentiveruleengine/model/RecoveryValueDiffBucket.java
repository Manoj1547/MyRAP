package com.walmartlabs.services.rdm.component.incentiveruleengine.model;

public class RecoveryValueDiffBucket {

    private Double toRange;
    private Double fromRange;
    private Double incentiveAmount;


    public Double getToRange() {
        return toRange;
    }

    public void setToRange(Double toRange) {
        this.toRange = toRange;
    }

    public Double getFromRange() {
        return fromRange;
    }

    public void setFromRange(Double fromRange) {
        this.fromRange = fromRange;
    }

    public Double getIncentiveAmount() {
        return incentiveAmount;
    }

    public void setIncentiveAmount(Double incentiveAmount) {
        this.incentiveAmount = incentiveAmount;
    }


}
