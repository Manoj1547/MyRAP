package com.walmartlabs.services.rdm.component.rap.service.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmart.platform.txnmarking.impl.NullTransactionImpl;
import com.walmart.platform.txnmarking.impl.TransactionImpl;
import com.walmartlabs.services.rdm.component.rap.model.request.GetReturnEligibilityRequest;
import com.walmartlabs.services.rdm.component.rap.model.response.GetReturnEligibilityResponse;
import com.walmartlabs.services.rdm.config.client.ReturnEligibilityServiceConfig;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import com.walmartlabs.services.rdm.util.BaseHTTPClient;
import com.walmartlabs.services.rdm.util.HeaderElements;
import io.strati.StratiServiceProvider;
import io.strati.configuration.annotation.ManagedConfiguration;
import io.strati.txnmarking.TransactionMarkingService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

@Component
public class ReturnEligibilityServiceHttpClient extends BaseHTTPClient {

    private static final Logger LOG = LoggerFactory.getLogger(ReturnEligibilityServiceHttpClient.class);

    private TransactionMarkingService TMS;

    @Resource
    @ManagedConfiguration
    ReturnEligibilityServiceConfig returnEligibilityServiceConfig;

    private ReturnEligibilityServiceHttpClient() {
        TMS = StratiServiceProvider.getInstance().getTransactionMarkingService().get();
    }

    public GetReturnEligibilityResponse getReturnEligibility(GetReturnEligibilityRequest request) {

        TransactionImpl top;
        if(TMS.currentTransaction() instanceof NullTransactionImpl) {
            top = (TransactionImpl) TMS.topTransaction("ReturnEligibility", "ReturnEligibility");
        }else {
            top = (TransactionImpl) TMS.transaction("ReturnEligibility", "ReturnEligibility");
        }
        top.start();

        String baseUrl = returnEligibilityServiceConfig.getServiceBaseHostUrl();
        String pathUrl = returnEligibilityServiceConfig.getServiceEndpoint();
        pathUrl = pathUrl.replaceAll("\\{orderId\\}", request.getOrderId());
        int apiTimeout = returnEligibilityServiceConfig.getApiTimeOut();
        Map<String, String> headerParams = getHeaderParams(returnEligibilityServiceConfig);

        GetReturnEligibilityResponse response = null;
        String responseString = null;
        try {
            LOG.info(MessageFormat.format("Invoking return eligibility service. URL:{0}{1}", baseUrl, pathUrl));
            responseString = get(baseUrl, pathUrl, headerParams, apiTimeout, String.class);
            LOG.info(MessageFormat.format("Return eligibility response: {0}", responseString));

            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

            response = objectMapper.readValue(responseString, GetReturnEligibilityResponse.class);
            top.end();
        } catch (JsonProcessingException e) {
            String errorMsg = MessageFormat.format("Failed to read value : {0}", responseString);
            LOG.error(errorMsg);
            top.logException(e);
            top.endWithFailure(e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.RAP_ELIGIBILITY_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        } catch (Exception e) {
            String errorMsg = MessageFormat.format("Unexpected exception for order {0}: {1}", request.getOrderId(),
                    e.getMessage());
            LOG.error(errorMsg);
            top.logException(e);
            top.endWithFailure(e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.RAP_ELIGIBILITY_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        }

        return response;
    }

    private Map<String, String> getHeaderParams(ReturnEligibilityServiceConfig config) {
        HashMap<String, String> headers = new HashMap<>();

        addHeaderParam(headers, HeaderElements.SERVICE_VERSION, config.getServiceVersion());
        addHeaderParam(headers, HeaderElements.SERVICE_ENV, config.getServiceEnv());
        addHeaderParam(headers, HeaderElements.SERVICE_NAME, config.getServiceName());
        addHeaderParam(headers, HeaderElements.CONSUMER_ID, config.getServiceConsumerId());
        addHeaderParam(headers, HeaderElements.CORRELATION_ID, config.getCorrelationId());
        addHeaderParam(headers, HeaderElements.USER_ID, config.getUserId());
        addHeaderParam(headers, HeaderElements.CONTENT_TYPE, config.getContentType());
        addHeaderParam(headers, HeaderElements.BU_ID, config.getBuId());
        addHeaderParam(headers, HeaderElements.MART_ID, config.getMartId());

        return headers;
    }

    private void addHeaderParam(HashMap<String, String> headers, String name, String value) {
        if (StringUtils.isNotBlank(value))
            headers.put(name, value);
    }
    
}
