package com.walmartlabs.services.rdm.formula.impl.java;

import com.walmartlabs.services.rdm.component.ovt.model.request.ItemPolicyDetailsRequest;
import com.walmartlabs.services.rdm.component.ovt.model.request.Payload;
import com.walmartlabs.services.rdm.component.ovt.model.request.ReturnTermFilter;
import com.walmartlabs.services.rdm.component.ovt.model.response.*;
import com.walmartlabs.services.rdm.component.ovt.service.util.OVTOmniServiceHelper;
import com.walmartlabs.services.rdm.config.client.OVTServiceConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.formula.Formula;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.concurrent.CompletableFuture;

import static com.walmartlabs.services.rdm.RDMConstants.*;
import static com.walmartlabs.services.rdm.component.ovt.constants.OVTOmniConstant.*;

/**
 * @author Vrushali
 * It will call OVT Omni API and get filtered data from response
 */
@Service
public class OVTOmniDataResolver implements JavaEngineClass {

    @Autowired
    OVTOmniServiceHelper ovtOmniServiceHelper;

    @Resource
    @ManagedConfiguration
    OVTServiceConfig ovtServiceConfig;


    public void setOvtOmniServiceHelper(OVTOmniServiceHelper ovtOmniServiceHelper) {
        this.ovtOmniServiceHelper = ovtOmniServiceHelper;
    }

    public void setOvtServiceConfig(OVTServiceConfig ovtServiceConfig) {
        this.ovtServiceConfig = ovtServiceConfig;
    }


    @Override
    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {

        if (!inputData.containsKey(FormulaConstants.INTERNAL_DATA_NAME_OVT_OMNI_FUTURE)) {
            ItemPolicyDetailsRequest itemPolicyDetailsRequest = prepareRequest(formula, inputData);
            inputData.put(FormulaConstants.INTERNAL_DATA_NAME_OVT_OMNI_FUTURE,
                    ovtOmniServiceHelper.triggerOVTOmniApiCall(itemPolicyDetailsRequest));
        }

        CompletableFuture<OVTOmniItemPolicyDetails> itemPolicyDetailsResponseCompletableFuture =
                (CompletableFuture<OVTOmniItemPolicyDetails>) inputData.get(FormulaConstants.INTERNAL_DATA_NAME_OVT_OMNI_FUTURE);

        return ovtOmniServiceHelper.getItemPolicyDetailsFromFutureObject(itemPolicyDetailsResponseCompletableFuture);
    }


    private ItemPolicyDetailsRequest prepareRequest(Formula formula, Map<String, Object> inputData) throws VariableMissingException {

        Integer vendorNo = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.VARIABLE_VENDOR_NMUBER);
        String storeId = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_STORE_ID);
        Integer departmentNo = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.VARIABLE_DEPARTMENT_NUMBER);
        Integer contractNo = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.VARIABLE_CONTRACT_NUMBER);
        boolean dotcom = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.VARIABLE_IS_DOTCOM);
        String itemId = null;

        if(ovtServiceConfig.getEnableItemNumberLogicForStoreRequest() && !dotcom){
            itemId = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_ITEM_NUMBER);
        }else{
            itemId = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_ITEM_ID);
        }


        ItemPolicyDetailsRequest itemPolicyDetailsRequest = new ItemPolicyDetailsRequest();
        ReturnTermFilter returnTermFilter = new ReturnTermFilter();

        returnTermFilter.setContractNo(String.valueOf(contractNo));
        returnTermFilter.setVendorNo(String.valueOf(vendorNo));
        returnTermFilter.setDepartmentNo(String.valueOf(departmentNo));
        returnTermFilter.setRegion(ovtServiceConfig.getDefaultRegion());
        returnTermFilter.setReturnTermTypes(ovtServiceConfig.getReturnTermTypes());

        Set<String> tenantIds = new HashSet<>(2);
        tenantIds.add(TENANTID_OMNI);
        tenantIds.add(dotcom ? TENANTID_DOTCOM : TENANTID_STORE);
        returnTermFilter.setTenantIds(tenantIds);

        Set<String> itemIds = new HashSet<>(1);
        itemIds.add(itemId);
        returnTermFilter.setItems(itemIds);

        if(ovtServiceConfig.getEnableConfigTypesForOVTRequest()) {
               returnTermFilter.setConfigTypes(dotcom?ovtServiceConfig.getConfigTypesForDotcomRequest():
                       ovtServiceConfig.getConfigTypesForStoreRequest());
        }


        Set<String> storeIds = new HashSet<>(1);
        storeIds.add(storeId);
        returnTermFilter.setStoreIds(storeIds);

        List<ReturnTermFilter> returnTermFilters = new ArrayList<>();
        returnTermFilters.add(returnTermFilter);

        Payload payload = new Payload();
        payload.setReturnTermFilters(returnTermFilters);
        itemPolicyDetailsRequest.setPayload(payload);

        return itemPolicyDetailsRequest;
    }
}
