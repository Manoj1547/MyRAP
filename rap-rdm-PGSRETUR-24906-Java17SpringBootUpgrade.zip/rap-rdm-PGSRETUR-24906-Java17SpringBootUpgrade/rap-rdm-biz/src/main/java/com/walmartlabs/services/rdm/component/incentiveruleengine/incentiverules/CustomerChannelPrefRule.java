package com.walmartlabs.services.rdm.component.incentiveruleengine.incentiverules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.incentiveruleengine.model.ReturnIncentiveEngineContext;
import com.walmartlabs.services.rdm.component.incentiveruleengine.util.AbstractReturnIncentiveRule;
import org.springframework.stereotype.Component;

@Component("customerChannelPrefRule")
public class CustomerChannelPrefRule extends AbstractReturnIncentiveRule {

    @Override
    public boolean runReturnIncentiveRule(ReturnIncentiveEngineContext returnIncentiveEngineContext) {
        return true;
    }

    @Override
    public String getRuleName() {
        return RDMConstants.RULE_NAME_CUSTOMER_CHANNEL_PREF;
    }
}
