package com.walmartlabs.services.rdm.component.apollorestock.restockrules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibilityContext;
import com.walmartlabs.services.rdm.component.siro.model.response.GetStoreItem;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

@Component("modLocationRule")
public class ModLocationRule extends AbstractRestockRule {

    @Override
    public String getRuleName() {
        String ruleName = RDMConstants.RULE_MOD_LOCATION;
        return ruleName;
    }

    @Override
    public boolean runRule(RestockEligibilityContext restockEligibilityContext) {
        GetStoreItem storeItemResponse = restockEligibilityContext.getStoreItemResponse();
        boolean isModLocationAvailable = false;
        if(storeItemResponse.getLocations() != null && CollectionUtils.isNotEmpty(storeItemResponse.getLocations().getSalesfloor()) &&
           storeItemResponse.getLocations().getSalesfloor().get(0).getModular() != null){
            isModLocationAvailable = true;
        }
        return isModLocationAvailable;
    }


}
