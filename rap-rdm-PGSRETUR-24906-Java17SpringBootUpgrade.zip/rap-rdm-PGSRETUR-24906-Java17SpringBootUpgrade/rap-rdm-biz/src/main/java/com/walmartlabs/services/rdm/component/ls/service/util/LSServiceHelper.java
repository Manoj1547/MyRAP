package com.walmartlabs.services.rdm.component.ls.service.util;

import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmartlabs.services.rdm.component.ls.model.GetPrefStoreRequest;
import com.walmartlabs.services.rdm.component.ls.model.GetPrefStoreResponse;
import com.walmartlabs.services.rdm.component.ls.model.newls.PrefStoreResponse;
import com.walmartlabs.services.rdm.config.client.LocationServiceConfig;
import com.walmartlabs.services.rdm.executors.RdmExecutorService;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.text.MessageFormat;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Component
public class LSServiceHelper {
    private static final Logger LOG = LoggerFactory.getLogger(LSServiceHelper.class);

    @Resource
    LocationServiceHttpClient   lsClient;

    @Resource
    @ManagedConfiguration
    LocationServiceConfig locationServiceConfig;

    public CompletableFuture<GetPrefStoreResponse> triggerLSServiceCall(GetPrefStoreRequest getPrefStoreRequest) {
        CompletableFuture<GetPrefStoreResponse> prefStoreResponseFuture =
                CompletableFuture.supplyAsync(() -> lsClient.getPrefStore(getPrefStoreRequest), RdmExecutorService.getExecutor());

        return prefStoreResponseFuture;
    }

    public GetPrefStoreResponse getLSResponseFromFuture(CompletableFuture<GetPrefStoreResponse> storeItemFinderResponseFuture, BaseItem item) {
        GetPrefStoreResponse prefStoreResponse = null;

        try {
            prefStoreResponse = storeItemFinderResponseFuture.get(locationServiceConfig.getApiTimeout(), TimeUnit.MILLISECONDS);;
        } catch (InterruptedException | TimeoutException | ExecutionException e) {
            String errorMsg =  MessageFormat.format("LS response fetch failed, gtin {0} , offerId {1}, error {2}",
                    item.getGtin(), item.getOfferId(), e.getMessage());
            LOG.error(errorMsg, e);

            if(e.getCause() instanceof RDMException){
                throw (RDMException) e.getCause();
            } else{
                throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.LS_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
            }
        }
        return prefStoreResponse;
    }

    public CompletableFuture<PrefStoreResponse> triggerNewLSServiceCall(GetPrefStoreRequest getPrefStoreRequest) {
        CompletableFuture<PrefStoreResponse> prefStoreResponseFuture =
                CompletableFuture.supplyAsync(() -> lsClient.getPrefStoreWithNewLS(getPrefStoreRequest), RdmExecutorService.getExecutor());
        return prefStoreResponseFuture;
    }

    public PrefStoreResponse getNewLSResponseFromFuture(CompletableFuture<PrefStoreResponse> storeItemFinderResponseFuture, BaseItem item) {
        PrefStoreResponse prefStoreResponse = null;

        try {
            prefStoreResponse = storeItemFinderResponseFuture.get(locationServiceConfig.getApiTimeout(), TimeUnit.MILLISECONDS);;
        } catch (InterruptedException | TimeoutException | ExecutionException e) {
            String errorMsg =  MessageFormat.format("LS response fetch failed, gtin {0} , offerId {1}, error {2}",
                    item.getGtin(), item.getOfferId(), e.getMessage());
            LOG.error(errorMsg, e);

            if(e.getCause() instanceof RDMException){
                throw (RDMException) e.getCause();
            } else{
                throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.LS_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
            }
        }
        return prefStoreResponse;
    }

}
