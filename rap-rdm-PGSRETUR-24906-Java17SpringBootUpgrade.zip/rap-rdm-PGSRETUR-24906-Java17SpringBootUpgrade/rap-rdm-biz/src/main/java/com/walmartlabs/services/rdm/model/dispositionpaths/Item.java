package com.walmartlabs.services.rdm.model.dispositionpaths;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;

/**
 * 
 * @author Tim Jin
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Item extends BaseItem {

    public Item() {

    }
}