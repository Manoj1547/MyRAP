package com.walmartlabs.services.rdm.formula.impl.java.r2d2;

import java.text.MessageFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.R2d2Data.R2d2DataType;
import com.walmartlabs.services.rdm.model.formula.Formula;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public class LiquidationRecoveryResolver extends R2D2DataResolver {

    private static final Logger LOG   = LoggerFactory.getLogger(LiquidationRecoveryResolver.class);

    final List<R2d2DataType>    types = Arrays.asList(R2d2DataType.RECOVERY_LIQUIDATION);

    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        String id = getL1(formula, inputData);
        Double v = getData(id);
        LOG.info(MessageFormat.format("liq_rcvry({0})={1}", id, v));
        return v;
    }

    @Override
    List<R2d2DataType> getTypes() {
        return types;
    }

}
