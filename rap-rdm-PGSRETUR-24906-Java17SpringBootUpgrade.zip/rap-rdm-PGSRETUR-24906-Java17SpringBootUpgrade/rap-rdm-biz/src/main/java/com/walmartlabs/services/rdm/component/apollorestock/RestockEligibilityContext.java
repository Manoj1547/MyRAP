package com.walmartlabs.services.rdm.component.apollorestock;

import com.walmartlabs.services.rdm.component.dsim.model.MarkDownPriceResponse;
import com.walmartlabs.services.rdm.component.dsim.model.config.summary.response.MarkDownConfigResponse;
import com.walmartlabs.services.rdm.component.rcp.model.response.GetItemDispositionDetailsResponse;
import com.walmartlabs.services.rdm.component.siro.model.response.GetStoreItem;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

public class RestockEligibilityContext {


    private Map<String, Object> inputData;

    private CompletableFuture<MarkDownConfigResponse> markDownConfigResponseFuture;

    private CompletableFuture<MarkDownPriceResponse> markDownPriceResponseFuture;

    private GetStoreItem storeItemResponse;

    private GetItemDispositionDetailsResponse itemDispositionDetailsResponse;

    private RestockEligibiltyResponse restockEligibiltyResponse = new RestockEligibiltyResponse();

    private Map<String, Boolean> restockRulesExecutionResult = new HashMap<>();

    private Map<String, Boolean> conjuctionConditionsEvaluationResults = new HashMap<>();

    public Map<String, Object> getInputData() {
        return inputData;
    }

    public void setInputData(Map<String, Object> inputData) {
        this.inputData = inputData;
    }

    public Map<String, Boolean> getConjuctionConditionsEvaluationResults() {
        return conjuctionConditionsEvaluationResults;
    }

    public void setConjuctionConditionsEvaluationResults(Map<String, Boolean> conjuctionConditionsEvaluationResults) {
        this.conjuctionConditionsEvaluationResults = conjuctionConditionsEvaluationResults;
    }

    public Map<String, Boolean> getRestockRulesExecutionResult() {
        return restockRulesExecutionResult;
    }

    public void setRestockRulesExecutionResult(Map<String, Boolean> restockRulesExecutionResult) {
        this.restockRulesExecutionResult = restockRulesExecutionResult;
    }

    public RestockEligibiltyResponse getRestockEligibiltyResponse() {
        return restockEligibiltyResponse;
    }

    public void setRestockEligibiltyResponse(RestockEligibiltyResponse restockEligibiltyResponse) {
        this.restockEligibiltyResponse = restockEligibiltyResponse;
    }

    public CompletableFuture<MarkDownPriceResponse> getMarkDownPriceResponseFuture() {
        return markDownPriceResponseFuture;
    }

    public void setMarkDownPriceResponseFuture(CompletableFuture<MarkDownPriceResponse> markDownPriceResponseFuture) {
        this.markDownPriceResponseFuture = markDownPriceResponseFuture;
    }

    public GetStoreItem getStoreItemResponse() {
        return storeItemResponse;
    }

    public void setStoreItemResponse(GetStoreItem storeItemResponse) {
        this.storeItemResponse = storeItemResponse;
    }

    public GetItemDispositionDetailsResponse getItemDispositionDetailsResponse() {
        return itemDispositionDetailsResponse;
    }

    public void setItemDispositionDetailsResponse(GetItemDispositionDetailsResponse itemDispositionDetailsResponse) {
        this.itemDispositionDetailsResponse = itemDispositionDetailsResponse;
    }

    public CompletableFuture<MarkDownConfigResponse> getMarkDownConfigResponseFuture() {
        return markDownConfigResponseFuture;
    }

    public void setMarkDownConfigResponseFuture(CompletableFuture<MarkDownConfigResponse> markDownConfigResponseFuture) {
        this.markDownConfigResponseFuture = markDownConfigResponseFuture;
    }

}
