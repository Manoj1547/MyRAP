package com.walmartlabs.services.rdm.listener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import com.walmartlabs.services.rdm.domain.model.FinalDispositionDO;
import com.walmartlabs.services.rdm.domain.persistence.FinalDispositionPersistenceManager;
import com.walmartlabs.services.rdm.model.finaldisposition.FinalDisposition;
import com.walmartlabs.services.rdm.model.roevent.ROEvent;
import com.walmartlabs.services.rdm.model.roevent.ReturnOrder;
import com.walmartlabs.services.rdm.model.roevent.ReturnOrderLine;

import io.strati.configuration.annotation.ManagedConfiguration;
import org.apache.commons.lang.BooleanUtils;

@Component("ROEventListener")
public class ROEventListener {

    private static final Logger        LOG = LoggerFactory.getLogger(ROEventListener.class);

    private ObjectReader               reader;

    @Resource
    FinalDispositionPersistenceManager persistenceManager;

    @ManagedConfiguration
    RDMSwitches                        switches;

    @PostConstruct
    public void init() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.setSerializationInclusion(Include.NON_NULL);

        this.reader = mapper.readerFor(ROEvent.class);
    }

    /**
     * Listens to the RAP RETURNORDER topic and filters out the RETURN_CREATED events. If the event has the final disposition info, then save it in the DB.
     *
     * @param message
     *            RO event
     */
    public void process(String message) {
        if(BooleanUtils.isTrue(switches.getKafkaConsumerRoLogEntry())) LOG.info("RO event: {}", message);
        
        try{
            processMsg(message);
        }catch (JsonProcessingException e){
            LOG.error("Failed to read value : {}", message);
            LOG.error("{}", e.getMessage(), e);
        }catch (Exception e){
            LOG.error("Unexpected error when processing the RO event: {}", e.getMessage());
        }
    }

    public List<FinalDispositionDO> processMsg(String message) throws IOException {
        ROEvent roEvent = reader.readValue(message, ROEvent.class);
        Objects.requireNonNull(roEvent.getHeader(), "RO event: header is null.");

        String eventName = roEvent.getHeader().getEventName();
        if(!CollectionUtils.isEmpty(switches.getRapEventEligibleForFinalDisposition()) && !switches.getRapEventEligibleForFinalDisposition().contains(eventName)){
            LOG.debug("Skipping RO event: {}", message);
            return null;
        }

        List<FinalDispositionDO> finals = new ArrayList<>();
        // persist at item level
        ReturnOrder returnOrder = roEvent.getPayload();
        for(ReturnOrderLine returnOrderLine : returnOrder.getOrderLines()){
            /*
             * Assuming either all the return lines will the final disposition or none of them will have the info. So break the loop if the first line didn't
             * have the final disposition.
             *
             * Also the disposition path could be empty in the case CCA agent overrides the IEB from yes to no. And we will have the ReturnExpectedOverride flag
             * passed in the create return request.
             */
            if(returnOrderLine.getFinalDisposition() == null || StringUtils.isEmpty(returnOrderLine.getFinalDisposition().getPath()) || StringUtils.isEmpty(returnOrderLine.getFinalDisposition().getReturnExpectedOverride())) break;

            FinalDispositionDO finalDispositionDO = new FinalDispositionDO();

            FinalDisposition finalDisposition = returnOrderLine.getFinalDisposition();
            finalDispositionDO.setFinalDispositionPath(finalDisposition.getPath());
            finalDispositionDO.setOverrideReason(finalDisposition.getOverrideReason());
            finalDispositionDO.setReturnExpectedOverride(finalDisposition.getReturnExpectedOverride());

            finalDispositionDO.setSalesOrderNo(returnOrder.getSalesOrderNo());
            finalDispositionDO.setReturnOrderNo(returnOrder.getReturnOrderNo());
            finalDispositionDO.setReturnRefNo(returnOrder.getReturnRefNumber());
            finalDispositionDO.setStoreId(returnOrder.getStoreId());
            finalDispositionDO.setChannelName(returnOrder.getChannelInfo().getChannelName());
            finalDispositionDO.setReturnOrderLineNo(returnOrderLine.getLineNo());
            finalDispositionDO.setSalesOrderLineNo(returnOrderLine.getSalesOrderLineNo());
            finalDispositionDO.setIsKeepIt(returnOrderLine.getIsKeepIt());

            persistenceManager.save(finalDispositionDO);
            LOG.info("Final Disposition saved in DB: {}", finalDispositionDO);
            finals.add(finalDispositionDO);
        }
        return finals;

    }
}
