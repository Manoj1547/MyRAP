package com.walmartlabs.services.rdm.component.incentiveruleengine.incentiverules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.incentiveruleengine.model.ReturnIncentiveEngineContext;
import com.walmartlabs.services.rdm.component.incentiveruleengine.util.AbstractReturnIncentiveRule;
import org.springframework.stereotype.Component;

@Component("wmPlusMemberCustomerRule")
public class WmPlusMemberCustomerRule extends AbstractReturnIncentiveRule {

    @Override
    public boolean runReturnIncentiveRule(ReturnIncentiveEngineContext returnIncentiveEngineContext) {
        return returnIncentiveEngineContext.getItem().isWalmartPlusCustomer();
    }

    @Override
    public String getRuleName() {
        return RDMConstants.RULE_NAME_WM_PLUS_MEMBER_CUSTOMER;
    }
}
