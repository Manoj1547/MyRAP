package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitrules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.common.IRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * @author v0s00g0
 */
@Component("visionRxItemRule")
public class VisionRxItemRule extends AbstractRDMKeepItRule{

    private static final Logger LOG = LoggerFactory.getLogger(VisionRxItemRule.class);

    @Override
    public void applyRuleDecision(IRuleEngineContext ruleEngineContext) {
        KeepItRuleEngineContext keepItRuleEngineContext = (KeepItRuleEngineContext) ruleEngineContext;
        BaseItem item = keepItRuleEngineContext.getItem();
        DispositionInfo dispositionInfo = keepItRuleEngineContext.getDispositionInfo();
        //For visionRx set KeepIt=False for every path
        for(DispositionPath dispositionPath : CollectionUtils.emptyIfNull(dispositionInfo.getDispositionPaths())){
            dispositionPath.setKeepIt(false);
        }

        LOG.info(String.format("%s.applyRuleDecision() is executed for itemId %s and salesOrderNo %s", this.getRuleName(), item.getItemId(), item.getOrderNo()));
    }

    @Override
    public String getRuleName() {
        return RDMConstants.RULE_NAME_VISION_RX_ITEM;
    }
}
