package com.walmartlabs.services.rdm.component.pos;

import org.springframework.stereotype.Service;

import com.walmartlabs.services.rdm.component.pos.model.Request;
import com.walmartlabs.services.rdm.config.ConfigConstants;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public class POSDeptHttpClient extends POSHttpClient {

    @Override
    protected String getServiceName() {
        return "pos.dept";
    }

    @Override
    protected String getCCMName() {
        return ConfigConstants.CONFIG_NAME_POS_SERVICE;
    }

    public String getDeptPos(String r2d2L1, String storeId, boolean shared) {
        Request r = new Request();
        r.setL1(r2d2L1);
        r.setStoreId(fromString(storeId));
        r.setShared(shared ? 1 : 0L);
        return call(getPayload(r));
    }
}
