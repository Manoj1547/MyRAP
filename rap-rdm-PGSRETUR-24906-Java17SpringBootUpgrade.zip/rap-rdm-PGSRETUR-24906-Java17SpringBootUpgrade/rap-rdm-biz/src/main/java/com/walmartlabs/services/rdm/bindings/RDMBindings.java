package com.walmartlabs.services.rdm.bindings;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmartlabs.services.rdm.component.dsim.util.DSIMClient;

import io.strati.StratiServiceProvider;
import io.strati.txnmarking.TransactionMarkingService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RDMBindings {

    @Bean
    public DSIMClient dsimClient(){
        return  new DSIMClient();
    }

    @Bean
    public ObjectMapper objectMapper(){
        ObjectMapper objectMapper =  new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return objectMapper;
    }

    @Bean
    public TransactionMarkingService transactionMarkingService(){
        TransactionMarkingService TMS = StratiServiceProvider.getInstance().getTransactionMarkingService().get();
        return TMS;
    }
}
