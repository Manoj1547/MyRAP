package com.walmartlabs.services.rdm.component.apollorestock.restockrules;

import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibilityContext;
import com.walmartlabs.services.rdm.component.apollorestock.jsonmodel.ConjuctionRuleCondition;
import com.walmartlabs.services.rdm.component.apollorestock.jsonmodel.LowlevelCondition;
import com.walmartlabs.services.rdm.component.apollorestock.jsonmodel.Rule;
import com.walmartlabs.services.rdm.component.apollorestock.util.IOperatorBasedConditionEvaluator;
import com.walmartlabs.services.rdm.component.apollorestock.util.RestockRulesFactory;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


import java.util.List;




@Component
public class RestockRuleEngine {

    private static final Logger LOG  = LoggerFactory.getLogger(RestockRuleEngine.class);






    /**
     *
     * ExecutionFlow:
     * For Every Conjuction Rule:
     *      1. Trigger runConjuctionRule method
     *      2. Get All the conjuctionRuleConditions and corresponding conditionEvaluator
     *      3. conditionEvalautor will evaluate the conjuctionRuleConditions
     *          For everyConjuctionRuleCondtion
     *          3.1. If condition is evaluated previously then get the result from context
     *          3.2 If condition is not evaluated then evaluate the conditions and store result in context
     *
     *
     *          Evaluationg a Conjuctionrule Condition:
     *           Get all the low level conditions under conjuctionRuleCondition
     *           For every low level condition:
     *              1.Get the conditionEvaluator
     *              2.Check all the restock rules status under lowlevelconditions
     *                2.1 If a restock rule is already executed then get the result from context
     *                2.2 If a restock rule is not executed then execute the rule and store result in context
     *
     *
     *
     *
     * Run All Conjuction Rules,
     * Stop execution when any conjuction rule returns true
     * Inside apply ruleDecision, update the restockEligibilityResponse object with resul
     *
     * @param restockEligibilityContext
     */
    public void runConjuctionRules(RestockEligibilityContext restockEligibilityContext){
        BaseItem item = (BaseItem) restockEligibilityContext.getInputData().get(FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);
        LOG.info("RestockRuleEngine.runConjucitonRules started for gtin," + item.getGtin());

        List<Rule> allConjuctionRules = RestockRulesFactory.getAllConjuctionRules();

        for(Rule conjuctionRule : allConjuctionRules){
            AbstractRestockRule conjuctionRuleBean = RestockRulesFactory.getConjuctionRule(conjuctionRule.getRuleName());
            boolean ruleResult = conjuctionRuleBean.runConjuctionRule(conjuctionRule, restockEligibilityContext);
            if(ruleResult == true){
                conjuctionRuleBean.applyConjuctionRuleDecision(restockEligibilityContext);
                break;
            }
        }

        LOG.info("RestockRuleEngine.runConjucitonRules exited for gtin," + item.getGtin());
    }



    public Boolean executeRestockRule(String ruleName, RestockEligibilityContext restockEligibilityContext) {
        BaseItem item = (BaseItem) restockEligibilityContext.getInputData().get(FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);
        LOG.info("Restock rule excution started, ruleName, "+ ruleName + " for gtin,"+ item.getGtin() );

        AbstractRestockRule restockRule = RestockRulesFactory.getRestockRule(ruleName);

        boolean ruleExecutionResult = restockRule.runRule(restockEligibilityContext);

        restockEligibilityContext.getRestockRulesExecutionResult().put(ruleName, ruleExecutionResult);
        LOG.info("Restock rule excution ended, ruleName, "+ ruleName + " for gtin,"+ item.getGtin() );
        return ruleExecutionResult;
    }


    /**
     * A conjuctionRuleCondition evaluates to true only Iff ,
     * All the lowlevelConditions under it evaluates to true.
     */
    public Boolean evaluateConjuctionRuleCondition(String conditionName, RestockEligibilityContext restockEligibilityContext) {

        ConjuctionRuleCondition conjuctionRuleCondition = RestockRulesFactory.getConjuctionRuleCondition(conditionName);
        List<LowlevelCondition> lowLevelConditions = conjuctionRuleCondition.getLowlevelConditions();

        boolean conditionEvaluationResult = true;
        for(LowlevelCondition lowlevelCondition : lowLevelConditions){
            IOperatorBasedConditionEvaluator conditionEvaluator = RestockRulesFactory.getConditionEvaluator(lowlevelCondition.getOperator());
            conditionEvaluationResult = conditionEvaluator.evaluateLowLevelCondition(lowlevelCondition, restockEligibilityContext);
            if(conditionEvaluationResult == false){
                break;
            }
        }

        restockEligibilityContext.getConjuctionConditionsEvaluationResults().put(conditionName, conditionEvaluationResult);
        return conditionEvaluationResult;
    }

}
