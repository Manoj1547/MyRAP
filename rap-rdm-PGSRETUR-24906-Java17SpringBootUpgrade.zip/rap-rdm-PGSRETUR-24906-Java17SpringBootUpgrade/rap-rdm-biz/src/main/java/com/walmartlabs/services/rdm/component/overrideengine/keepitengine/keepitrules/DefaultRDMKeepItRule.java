package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitrules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.common.IRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component("defaultRDMKeepItRule")
public class DefaultRDMKeepItRule extends AbstractRDMKeepItRule {

    private static final Logger LOG = LoggerFactory.getLogger(DefaultRDMKeepItRule.class);

    @Autowired
    RDMKeepItUtil rdmKeepItUtil;

    @Override
    public void applyRuleDecision(IRuleEngineContext ruleEngineContext) {
        KeepItRuleEngineContext keepItRuleEngineContext = (KeepItRuleEngineContext) ruleEngineContext;
        String offerId = keepItRuleEngineContext.getItem().getOfferId();
        LOG.info(this.getRuleName() + ".applyRuleDecision() started for offerId," + offerId);

        DispositionInfo dispositionInfo = keepItRuleEngineContext.getDispositionInfo();
        boolean isTrustCustomerToKeepIt = dispositionInfo.getKeepItInfo().getTrustCustomerToKeepIt();
        boolean isItemKeepIt = (rdmKeepItUtil.itemGtinCountCheck(keepItRuleEngineContext) &&
                                rdmKeepItUtil.itemPriceCheck(keepItRuleEngineContext)) ;

        if(isTrustCustomerToKeepIt && isItemKeepIt){
            rdmKeepItUtil.updateKeepItByComparingRecoveryValue(keepItRuleEngineContext);
        } else{
            rdmKeepItUtil.updateKeepItForAllPaths(keepItRuleEngineContext, false);
        }

        LOG.info(this.getRuleName() + ".applyRuleDecision() exited for offerId, " + offerId);

    }





    @Override
    public String getRuleName() {
        String ruleName = RDMConstants.RULE_NAME_DEFAULT_RDM_KEEP_IT;
        return ruleName;
    }

}