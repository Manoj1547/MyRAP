package com.walmartlabs.services.rdm.component.siro.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class Locations{

    @JsonProperty("salesfloor")
    public List<Salesfloor> salesfloor;

    public List<Salesfloor> getSalesfloor() {
        return salesfloor;
    }

    public void setSalesfloor(List<Salesfloor> salesfloor) {
        this.salesfloor = salesfloor;
    }
}