package com.walmartlabs.services.rdm.component.apollorestock.restockrules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibilityContext;
import com.walmartlabs.services.rdm.component.dsim.model.MarkDownPriceResponse;
import com.walmartlabs.services.rdm.component.dsim.model.config.summary.response.MarkDownConfigResponse;
import com.walmartlabs.services.rdm.component.dsim.util.DSIMServiceHelper;
import com.walmartlabs.services.rdm.component.rcp.model.response.GetItemDispositionDetailsResponse;
import com.walmartlabs.services.rdm.config.client.RestockEligibilityConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component("itemCVPEligibleRule")
public class ItemCVPEligibleRule extends AbstractRestockRule {

    @Resource
    @ManagedConfiguration
    private RestockEligibilityConfig restockEligibilityConfig;
    @Autowired
    DSIMServiceHelper dsimServiceHelper;

    @Override
    public String getRuleName() {
        String ruleName = RDMConstants.RULE_ITEM_CVP_ELIGIBLE_RULE;
        return ruleName;
    }

    /** Item is not cvp eligible if
     * 1. vendor does not allows CVP
     * OR
     * 2. Item belongs to CVP InEligilble departments
     * OR
     * 3. markdownallowed is false
     * OR
     * 4. markdownPercent is 0 or 100
     *
     */
    @Override
    public boolean runRule(RestockEligibilityContext restockEligibilityContext) {
        GetItemDispositionDetailsResponse itemDispositionDetailsResponse = restockEligibilityContext.getItemDispositionDetailsResponse();
        boolean isVendorAllowsCVP = itemDispositionDetailsResponse.getCvpEligibleAtStore();
        if(isVendorAllowsCVP == false){
            return false;
        }


        int departmentNo = (int)restockEligibilityContext.getInputData().get(FormulaConstants.VARIABLE_DEPARTMENT_NUMBER);
        if(restockEligibilityConfig.getCvpIneligibleDeptList().contains(String.valueOf(departmentNo))){
            return false;
        }

        String itemId = (String) restockEligibilityContext.getInputData().get(FormulaConstants.INTERNAL_DATA_NAME_ITEM_ID);
        MarkDownConfigResponse markDownConfigResponse = dsimServiceHelper.getDsimMarkDownConfigResponse(restockEligibilityContext.getMarkDownConfigResponseFuture(), itemId);
        if(markDownConfigResponse.getMarkdownAllowed() == false){
            return false;
        }



        MarkDownPriceResponse markDownPriceResponse = dsimServiceHelper.getDsimPricePercentResponse(restockEligibilityContext.getMarkDownPriceResponseFuture(), itemId);
        if(markDownPriceResponse.getMarkdownPercentage() == 0 || markDownPriceResponse.getMarkdownPercentage() == 100){
            return false;
        }
        
        return true;
    }

}
