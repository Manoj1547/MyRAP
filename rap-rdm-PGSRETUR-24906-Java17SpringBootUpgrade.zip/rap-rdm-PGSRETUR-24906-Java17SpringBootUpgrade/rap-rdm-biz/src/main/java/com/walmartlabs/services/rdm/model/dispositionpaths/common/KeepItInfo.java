package com.walmartlabs.services.rdm.model.dispositionpaths.common;

import com.walmartlabs.services.rdm.model.Base;

/**
 * 
 * @author Tim Jin
 *
 */
public class KeepItInfo extends Base {

    private Boolean trustCustomerToKeepIt;
    private Boolean itemKeepItEligibility;

    public Boolean getTrustCustomerToKeepIt() {
        return trustCustomerToKeepIt;
    }

    public void setTrustCustomerToKeepIt(Boolean trustCustomerToKeepIt) {
        this.trustCustomerToKeepIt = trustCustomerToKeepIt;
    }

    public Boolean getItemKeepItEligibility() {
        return itemKeepItEligibility;
    }

    public void setItemKeepItEligibility(Boolean itemKeepItEligibility) {
        this.itemKeepItEligibility = itemKeepItEligibility;
    }

    public KeepItInfo() {
    }
}