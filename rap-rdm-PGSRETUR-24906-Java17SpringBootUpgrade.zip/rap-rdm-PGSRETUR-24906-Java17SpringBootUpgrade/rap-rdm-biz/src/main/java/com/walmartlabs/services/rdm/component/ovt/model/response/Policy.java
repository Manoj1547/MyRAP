package com.walmartlabs.services.rdm.component.ovt.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class Policy {

    @JsonProperty("policyKey")
    private String policyKey;

    @JsonProperty("attributeList")
    private List<Attribute> attributeList;


    public String getPolicyKey() {
        return policyKey;
    }

    public void setPolicyKey(String policyKey) {
        this.policyKey = policyKey;
    }

    public List<Attribute> getAttributeList() {
        return attributeList;
    }

    public void setAttributeList(List<Attribute> attributeList) {
        this.attributeList = attributeList;
    }

}
