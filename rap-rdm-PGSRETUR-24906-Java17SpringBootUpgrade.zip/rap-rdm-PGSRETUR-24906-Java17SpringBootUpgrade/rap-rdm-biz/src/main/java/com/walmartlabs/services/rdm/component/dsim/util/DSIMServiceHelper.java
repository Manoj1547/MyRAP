package com.walmartlabs.services.rdm.component.dsim.util;

import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibilityContext;
import com.walmartlabs.services.rdm.component.dsim.model.MarkDownPriceResponse;
import com.walmartlabs.services.rdm.component.dsim.model.config.summary.response.MarkDownConfigResponse;
import com.walmartlabs.services.rdm.config.client.DSIMConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Component
public class DSIMServiceHelper {

    @Resource
    @ManagedConfiguration
    private DSIMConfig dsimConfig;

    private static final Logger LOG = LoggerFactory.getLogger(DSIMServiceHelper.class);

    public MarkDownConfigResponse getDsimMarkDownConfigResponse(CompletableFuture<MarkDownConfigResponse> markdownConfigResponseFuture, String itemId){


        MarkDownConfigResponse markDownConfigResponse = null;
        try {
            markDownConfigResponse = markdownConfigResponseFuture.get(dsimConfig.getDsimMarkDownConfigServiceApiTimeout(), TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            String errorMsg = "DSIM Markdown Config Service failed for Itemid " + itemId;
            String errorMsgLog = errorMsg + " exceptionMsg:" +e.getMessage();
            LOG.error(errorMsgLog, e);
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.DSIM_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        }
        return markDownConfigResponse;
    }

    public MarkDownPriceResponse getDsimPricePercentResponse(CompletableFuture<MarkDownPriceResponse> markDownPriceResponseFuture, String itemId){
        MarkDownPriceResponse markDownPriceResponse = null;

        try {
            markDownPriceResponse = markDownPriceResponseFuture.get(dsimConfig.getDsimMarkDownpriceServiceApiTimeout(), TimeUnit.MILLISECONDS);;
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            String errorMsg = "DSIM Markdown Price Service failed for Itemid " + itemId;
            String errorMsgLog = errorMsg + " exceptionMsg:" +e.getMessage();
            LOG.error(errorMsgLog, e);
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.DSIM_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        }
        return markDownPriceResponse;
    }

}
