package com.walmartlabs.services.rdm.model;

/**
 * 
 * @author Tim Jin
 *
 */
public abstract class Base {

}
