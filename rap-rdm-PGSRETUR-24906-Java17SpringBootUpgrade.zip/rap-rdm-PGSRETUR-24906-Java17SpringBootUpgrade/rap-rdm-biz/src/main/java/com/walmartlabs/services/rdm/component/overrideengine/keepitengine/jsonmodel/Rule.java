package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.jsonmodel;

import java.util.List;

public class Rule implements Comparable<Rule>{
    public String ruleName;
    public String ruleBean;
    public int priority;
    public List<RuleCheck> ruleChecks;
    public String desc;
    public boolean isActive;

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public String getRuleName() {
        return ruleName;
    }

    public void setRuleName(String ruleName) {
        this.ruleName = ruleName;
    }

    public String getRuleBean() {
        return ruleBean;
    }

    public void setRuleBean(String ruleBean) {
        this.ruleBean = ruleBean;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public List<RuleCheck> getRuleChecks() {
        return ruleChecks;
    }

    public void setRuleChecks(List<RuleCheck> ruleChecks) {
        this.ruleChecks = ruleChecks;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    @Override
    public int compareTo(Rule thatObj){
        if(this.getPriority() > thatObj.getPriority()){
            return 1;
        } else if(this.getPriority() < thatObj.getPriority()){
            return -1;
        } else{
            return 0;
        }
    }
}
