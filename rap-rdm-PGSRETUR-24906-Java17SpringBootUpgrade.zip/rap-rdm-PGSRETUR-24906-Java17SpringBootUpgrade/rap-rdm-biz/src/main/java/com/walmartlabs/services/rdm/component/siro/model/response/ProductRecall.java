package com.walmartlabs.services.rdm.component.siro.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductRecall {
    @JsonProperty("itemNumber")
    private Integer itemNumber;

    @JsonProperty("defectiveAgreement")
    private DefectiveAgreement defectiveAgreement;

    @JsonProperty("recallOverstock")
    private RecallOverstock[] recallOverstock;

    public Integer getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(Integer itemNumber) {
        this.itemNumber = itemNumber;
    }

    public RecallOverstock[] getRecallOverstock() {
        return recallOverstock;
    }

    public void setRecallOverstock(RecallOverstock[] recallOverstock) {
        this.recallOverstock = recallOverstock;
    }

    public DefectiveAgreement getDefectiveAgreement() {
        return defectiveAgreement;
    }

    public void setDefectiveAgreement(DefectiveAgreement defectiveAgreement) {
        this.defectiveAgreement = defectiveAgreement;
    }
}
