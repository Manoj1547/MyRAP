package com.walmartlabs.services.rdm.component.dsim.model.config.summary.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/***
 *
 * "baseDivNbr": 1,
 *  *         "businessUnitNbr": 100,
 *  *         "countryCode": "US",
 *  *         "itemNbr": 9401350,
 *  *         "marketNbr": 323,
 *  *         "regionNbr": 42,
 *  *         "subdivNbr": "B"
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ConfigSelection {
    @JsonProperty("baseDivNbr")
    private Integer baseDivNbr;
    @JsonProperty("businessUnitNbr")
    private Long storeId;
    private String  countryCode;
    @JsonProperty("itemNbr")
    private Long itemNbr;

    public Integer getBaseDivNbr() {
        return baseDivNbr;
    }

    public void setBaseDivNbr(Integer baseDivNbr) {
        this.baseDivNbr = baseDivNbr;
    }

    public Long getStoreId() {
        return storeId;
    }

    public void setStoreId(Long storeId) {
        this.storeId = storeId;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public Long getItemNbr() {
        return itemNbr;
    }

    public void setItemNbr(Long itemNbr) {
        this.itemNbr = itemNbr;
    }

    @Override
    public String toString() {
        return "ConfigSelection{" +
                "baseDivNbr=" + baseDivNbr +
                ", storeId=" + storeId +
                ", countryCode='" + countryCode + '\'' +
                ", itemNbr=" + itemNbr +
                '}';
    }
}
