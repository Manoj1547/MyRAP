package com.walmartlabs.services.rdm.component.ovt.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Set;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReturnTermFilter {
    @JsonProperty("vendorNo")
    private String vendorNo;

    @JsonProperty("departmentNo")
    private String departmentNo;

    @JsonProperty("contractNo")
    private String contractNo;

    @JsonProperty("tenantIds")
    private Set<String> tenantIds;

    @JsonProperty("region")
    private String region;

    @JsonProperty("items")
    private Set<String> items;

    @JsonProperty("returnTermTypes")
    private Set<String> returnTermTypes;

    @JsonProperty("upcs")
    private Set<String> upcs;

    @JsonProperty("storeIds")
    private Set<String> storeIds;

    @JsonProperty("configTypes")
    private Set<String> configTypes;


    public String getVendorNo() {
        return vendorNo;
    }

    public void setVendorNo(String vendorNo) {
        this.vendorNo = vendorNo;
    }

    public String getDepartmentNo() {
        return departmentNo;
    }

    public void setDepartmentNo(String departmentNo) {
        this.departmentNo = departmentNo;
    }

    public String getContractNo() {
        return contractNo;
    }

    public void setContractNo(String contractNo) {
        this.contractNo = contractNo;
    }

    public Set<String> getTenantIds() {
        return tenantIds;
    }

    public void setTenantIds(Set<String> tenantIds) {
        this.tenantIds = tenantIds;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public Set<String> getItems() {
        return items;
    }

    public void setItems(Set<String> items) {
        this.items = items;
    }

    public Set<String> getReturnTermTypes() {
        return returnTermTypes;
    }

    public void setReturnTermTypes(Set<String> returnTermTypes) {
        this.returnTermTypes = returnTermTypes;
    }

    public Set<String> getUpcs() {
        return upcs;
    }

    public void setUpcs(Set<String> upcs) {
        this.upcs = upcs;
    }

    public Set<String> getStoreIds() {
        return storeIds;
    }

    public void setStoreIds(Set<String> storeIds) {
        this.storeIds = storeIds;
    }

    public Set<String> getConfigTypes() {
        return configTypes;
    }

    public void setConfigTypes(Set<String> configTypes) {
        this.configTypes = configTypes;
    }
}
