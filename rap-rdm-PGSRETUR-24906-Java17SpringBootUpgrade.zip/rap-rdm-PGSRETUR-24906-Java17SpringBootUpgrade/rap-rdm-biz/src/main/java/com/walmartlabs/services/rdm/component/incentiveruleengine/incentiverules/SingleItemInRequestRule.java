package com.walmartlabs.services.rdm.component.incentiveruleengine.incentiverules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.incentiveruleengine.model.ReturnIncentiveEngineContext;
import com.walmartlabs.services.rdm.component.incentiveruleengine.util.AbstractReturnIncentiveRule;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.model.dispositionpaths.Item;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("singleItemInRequestRule")
public class SingleItemInRequestRule extends AbstractReturnIncentiveRule {

    @Override
    public boolean runReturnIncentiveRule(ReturnIncentiveEngineContext returnIncentiveEngineContext) {
        List<Item> items = (List<Item>) returnIncentiveEngineContext.getSession().getInputData().get(FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEMS);

        return (items.size()==1);
    }

    @Override
    public String getRuleName() {
        return RDMConstants.RULE_NAME_SINGLE_ITEM_IN_REQUEST;
    }
}
