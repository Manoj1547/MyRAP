
package com.walmartlabs.services.rdm.model.finaldisposition;

import com.walmartlabs.services.rdm.model.Audit;
import com.walmartlabs.services.rdm.model.Base;
import com.walmartlabs.services.rdm.model.dispositionpaths.Item;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.ChannelInfo;

/**
 * 
 * @author Tim Jin
 *
 */
public class FinalDispositionRequest extends Base {

    private Item         itemInfo;

    private ChannelInfo      channelInfo;

    private FinalDisposition finalDisposition;

    private Audit audit;

    public Item getItemInfo() {
        return itemInfo;
    }

    public void setItemInfo(Item itemInfo) {
        this.itemInfo = itemInfo;
    }

    public ChannelInfo getChannelInfo() {
        return channelInfo;
    }

    public void setChannelInfo(ChannelInfo channelInfo) {
        this.channelInfo = channelInfo;
    }

    public FinalDisposition getFinalDisposition() {
        return finalDisposition;
    }

    public void setFinalDisposition(FinalDisposition finalDisposition) {
        this.finalDisposition = finalDisposition;
    }

    public Audit getAudit() {
        return audit;
    }

    public void setAudit(Audit audit) {
        this.audit = audit;
    }

}
