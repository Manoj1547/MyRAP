package com.walmartlabs.services.rdm.formula;

import java.util.Set;

/**
 * 
 * @author Tim Jin
 *
 */
public class Context {

    private Set<String> inputVariables;

    private Set<String> outputVariables;

    public Set<String> getInputVariables() {
        return inputVariables;
    }

    public void setInputVariables(Set<String> inputVariables) {
        this.inputVariables = inputVariables;
    }

    public Set<String> getOutputVariables() {
        return outputVariables;
    }

    public void setOutputVariables(Set<String> outputVariables) {
        this.outputVariables = outputVariables;
    }

}