package com.walmartlabs.services.rdm.component.ovt.service.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.txnmarking.impl.NullTransactionImpl;
import com.walmart.platform.txnmarking.impl.TransactionImpl;
import com.walmartlabs.services.rdm.component.ovt.model.request.ItemPolicyDetailsRequest;
import com.walmartlabs.services.rdm.component.ovt.model.request.ReturnTermFilter;
import com.walmartlabs.services.rdm.component.ovt.model.response.*;
import com.walmartlabs.services.rdm.config.client.OVTServiceConfig;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import com.walmartlabs.services.rdm.util.BaseHTTPClient;
import com.walmartlabs.services.rdm.util.BeanHelper;
import com.walmartlabs.services.rdm.util.HeaderElements;
import com.walmartlabs.services.rdm.util.cache.CacheManager;
import com.walmartlabs.services.rdm.util.cache.CacheRole;
import io.strati.StratiServiceProvider;
import io.strati.configuration.annotation.ManagedConfiguration;
import io.strati.txnmarking.TransactionMarkingService;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.text.MessageFormat;
import java.util.*;

import static com.walmartlabs.services.rdm.RDMConstants.TENANTID_DOTCOM;


@Component
public class OVTOmniHttpClient extends BaseHTTPClient {

    private static final Logger LOG = LoggerFactory.getLogger(OVTOmniHttpClient.class);

    private TransactionMarkingService TMS;

    @Resource
    @ManagedConfiguration
    private OVTServiceConfig ovtServiceConfig;

    public void setOvtServiceConfig(OVTServiceConfig ovtServiceConfig) {
        this.ovtServiceConfig = ovtServiceConfig;
    }

    @Resource
    private CacheManager cacheManager;

    public void setCacheManager(CacheManager cacheManager) {
        this.cacheManager = cacheManager;
    }

    private static ObjectMapper objectMapper;

    private static final String OVT_OMNI_ITEM_POLICY_DETAILS = "OVTOmniItemPolicyDetails";

    @PostConstruct
    void init() {
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        TMS = StratiServiceProvider.getInstance().getTransactionMarkingService().get();
    }

    public OVTOmniItemPolicyDetails getOVTOmniItemPolicyDetails(ItemPolicyDetailsRequest request) {

        String responseString = null;
        String key = null;
        try {
            OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails = new OVTOmniItemPolicyDetails();

            if (ovtServiceConfig.getMockResponseEnable()) {
                ServiceResponse<OVTOmniItemPolicyDetails> serviceResponse = objectMapper.readValue(ovtServiceConfig.getMockResponseForOVT(),
                        new TypeReference<ServiceResponse<OVTOmniItemPolicyDetails>>() {
                        });
                return serviceResponse.getPayload();
            }

            key = objectMapper.writeValueAsString(request);
            if (ovtServiceConfig.getOvtServiceCachingEnabled()) {
                responseString = cacheManager.get(DigestUtils.sha256Hex(key), CacheRole.OVT);
            }

            if (responseString == null) {
                ReturnTermFilter returnTermFilter = request.getPayload().getReturnTermFilters().get(0);
                ServiceResponse<ItemPolicyDetailsResponse> serviceResponse = objectMapper.readValue(callOvtOmniService(key, returnTermFilter),
                        new TypeReference<ServiceResponse<ItemPolicyDetailsResponse>>() {
                        });
                validateResponse(serviceResponse.getPayload(), returnTermFilter.getVendorNo(), returnTermFilter.getItems());
                ovtOmniItemPolicyDetails = filterOVTOmniResponse(serviceResponse.getPayload(), returnTermFilter.getTenantIds() , returnTermFilter.getVendorNo(), returnTermFilter.getItems());
                LOG.info("Ovt Omni service response: {}", ovtOmniItemPolicyDetails);
                if (ovtServiceConfig.getOvtServiceCachingEnabled()) {
                    responseString = objectMapper.writeValueAsString(ovtOmniItemPolicyDetails);
                    cacheManager.put(DigestUtils.sha256Hex(key), responseString, CacheRole.OVT);
                }
            }
            else{
                ovtOmniItemPolicyDetails = objectMapper.readValue(responseString,OVTOmniItemPolicyDetails.class);
            }
            return ovtOmniItemPolicyDetails;

        } catch (JsonProcessingException e) {
            String errorMsg = MessageFormat.format("Ovt Omni service JsonProcessing exception, for request: {0}", key);
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.OVT_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        } catch (Exception e) {
            String errorMsg = MessageFormat.format("Ovt Omni service Unexpected exception for request: {0}", key);
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.OVT_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        }

    }

    private OVTOmniItemPolicyDetails filterOVTOmniResponse(ItemPolicyDetailsResponse itemPolicyDetailsResponse, Set<String> tenantIds, String vendorNo, Set<String> itemIds) {
        AbstractResponseHandler responseHandler = (AbstractResponseHandler) BeanHelper.getBean(isDotcomOrder(tenantIds) ? "dotcomResponseHandler" : "storeResponseHandler");
        return responseHandler.handleResponse(itemPolicyDetailsResponse, vendorNo, itemIds);
    }


    private boolean isDotcomOrder(Set<String> tenantIds) {
        return tenantIds.contains(TENANTID_DOTCOM);
    }

    private void validateResponse(ItemPolicyDetailsResponse response, String vendorNo, Set<String> itemIds) {

        if (response == null || CollectionUtils.isEmpty(response.getReturnTerms())) {
            String errorMsg = MessageFormat.format("OVT-HTTP response validation failed as response is null for vendorNo :{0} and itemId :{1}"
                    , vendorNo, itemIds.toString());
            LOG.error(errorMsg);
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.OVT_HTTP_CLIENT_EXECUTION_FAILED, errorMsg);
        }
    }

    private String callOvtOmniService(String requestPayload, ReturnTermFilter request) {
        TransactionImpl top;
        if (TMS.currentTransaction() instanceof NullTransactionImpl) {
            top = (TransactionImpl) TMS.topTransaction(OVT_OMNI_ITEM_POLICY_DETAILS, OVT_OMNI_ITEM_POLICY_DETAILS);
        } else {
            top = (TransactionImpl) TMS.transaction(OVT_OMNI_ITEM_POLICY_DETAILS, OVT_OMNI_ITEM_POLICY_DETAILS);
        }

        String baseUrl = ovtServiceConfig.getServiceBaseHostUrl();
        String pathUrl = ovtServiceConfig.getServiceEndpoint();
        int apiTimeOut = ovtServiceConfig.getTimeOut();
        Map<String, String> headerParams = getHeaderParams(ovtServiceConfig);

        try {
            top.start();
            LOG.info("Invoking Ovt service for request having itemId: {}, vendorNo: {}, departmentNo: {}, contractNo: {}, tenantId: {} ", request.getItems(),
                    request.getVendorNo(), request.getDepartmentNo(), request.getContractNo(), request.getTenantIds());
            String ovtOmniResponse = post(baseUrl, pathUrl, requestPayload, headerParams, apiTimeOut, String.class);
            if (ovtServiceConfig.getRequestResponseLoggingEnabled()) {
                LOG.info("Invoking Ovt service for request: {} and response: {}", requestPayload, ovtOmniResponse);
            }
            top.end();
            return ovtOmniResponse;
        }catch (ServiceException e) {
            String errorMsg = MessageFormat.format("OvtHttpClient failed with ServiceException for request: {0}", requestPayload);
            LOG.error(errorMsg, e);
            top.logException(e);
            top.endWithFailure(e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.OVT_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        } catch (Exception e) {
            String errorMsg = MessageFormat.format("OvtHttpClient failed with Unexpected exception for request: {0}", requestPayload);
            LOG.error(errorMsg, e);
            top.logException(e);
            top.endWithFailure(e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.OVT_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        }
    }

    private Map<String, String> getHeaderParams(OVTServiceConfig config) {
        HashMap<String, String> headers = new HashMap<>();

        addHeaderParam(headers, HeaderElements.SERVICE_VERSION, config.getServiceVersion());
        addHeaderParam(headers, HeaderElements.SERVICE_ENV, config.getServiceEnv());
        addHeaderParam(headers, HeaderElements.SERVICE_NAME, config.getServiceName());
        addHeaderParam(headers, HeaderElements.CONSUMER_ID, config.getServiceConsumerId());
        addHeaderParam(headers, HeaderElements.CONTENT_TYPE, config.getContentType());
        addHeaderParam(headers, HeaderElements.ACCEPT, config.getAccept());
        addHeaderParam(headers, HeaderElements.WM_REQUEST_SOURCE, config.getRequestSource());

        return headers;
    }

    private void addHeaderParam(HashMap<String, String> headers, String name, String value) {
        if (StringUtils.isNotBlank(value)) {
            headers.put(name, value);
        }
    }
}
