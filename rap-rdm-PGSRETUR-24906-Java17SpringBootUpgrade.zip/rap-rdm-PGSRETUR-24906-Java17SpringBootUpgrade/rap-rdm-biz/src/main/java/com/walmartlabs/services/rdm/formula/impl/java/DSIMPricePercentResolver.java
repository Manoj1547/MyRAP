package com.walmartlabs.services.rdm.formula.impl.java;

import com.walmartlabs.services.rdm.component.dsim.util.DSIMClient;
import com.walmartlabs.services.rdm.component.dsim.model.config.summary.request.MarkDownRequestContext;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.formula.Formula;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@Service
public class DSIMPricePercentResolver implements JavaEngineClass {

    private static final Logger LOG = LoggerFactory.getLogger(DSIMPricePercentResolver.class);


    @Autowired
    private DSIMClient dsimClient;
    @Override
    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        BaseItem item = FormulaEngine.getInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);
        String itemId = FormulaEngine.getInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_ITEM_ID);
        String storeId = FormulaEngine.getInput(formula,inputData,FormulaConstants.INTERNAL_DATA_NAME_STORE_ID);
        String departmentNumber = FormulaEngine.getInput(formula,inputData,FormulaConstants.VARIABLE_DEPARTMENT_NUMBER).toString();

        Double price = FormulaEngine.getInput(formula,inputData,FormulaConstants.INTERNAL_DATA_NAME_DOTCOM_RETAIL);

        Integer quantity = FormulaEngine.getInput(formula,inputData,FormulaConstants.VARIABLE_QUANTITY);

        MarkDownRequestContext markDownRequestContext = prepareRequest(itemId,storeId,departmentNumber,price,quantity);
        return CompletableFuture.supplyAsync(() -> dsimClient.getMarkDownPrice(markDownRequestContext));

    }

    private MarkDownRequestContext prepareRequest(String itemId, String storeId, String departmentNumber, Double price, Integer quantity) {
        MarkDownRequestContext requestContext = new MarkDownRequestContext();
        requestContext.setDepartmentNo(departmentNumber);
        requestContext.setOriginalPrice(String.valueOf(price));
        requestContext.setQuantity(String.valueOf(quantity));
        requestContext.setExpiresDays("1");
        requestContext.setStoreId(storeId);
        requestContext.setIteration("1");
        requestContext.setTimeStamp(OffsetDateTime.now().truncatedTo(ChronoUnit.SECONDS).toString());
        requestContext.setItemNumber(itemId);
        return requestContext;
    }
}
