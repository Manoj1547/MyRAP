package com.walmartlabs.services.rdm.rank.assigner.impl;

import com.walmartlabs.services.rdm.model.SellerType;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import com.walmartlabs.services.rdm.rank.assigner.RankAssigner;
import org.apache.cxf.common.util.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
public class RankOnCommonAggregatedValue extends RankAssigner {

    /**
     * Aggregates dispositions based on common dispositions, available dispositions, seller type and defaults.
     *
     * @param allItemsDispositionInfoList list of dispositions
     */
    @Override
    protected void assignRanks(List<DispositionInfo> allItemsDispositionInfoList) {

        Map<SellerType, Set<String>> sellerTypeBasedCommonDispositionPaths = new HashMap<>();

        findCommonPaths(sellerTypeBasedCommonDispositionPaths, allItemsDispositionInfoList);

        recomputeAllRanks(sellerTypeBasedCommonDispositionPaths, allItemsDispositionInfoList);
    }

    private void recomputeAllRanks(Map<SellerType, Set<String>> sellerTypeBasedCommonDispositionPaths, List<DispositionInfo> allItemsDispositionInfoList) {
        for (Map.Entry<SellerType, Set<String>> entry : sellerTypeBasedCommonDispositionPaths.entrySet()) {

            if (entry.getValue().isEmpty()) {
                continue;
            }

            sortDispositionPathsOnRank(allItemsDispositionInfoList);

            recomputeRanksForAllNonDefaultItems(allItemsDispositionInfoList, entry.getValue(), entry.getKey());
        }
    }

    private void findCommonPaths(Map<SellerType, Set<String>> sellerTypeBasedCommonDispositionPaths,
                                 List<DispositionInfo> allItemsDispositionInfoList) {

        /* 1. Loop all items DispositionInfoList.
           2. Add Non-Default first item's disposition path to commonDispositionPaths list
           3. Check if those commonDispositionPaths are present in other Non-Default item's dispositionPath or not
         */
        for (DispositionInfo dispositionInfo : allItemsDispositionInfoList) {
            if(null == dispositionInfo || null == dispositionInfo.getItem() ||
                    null == dispositionInfo.getItem().getSellerType()) {
                continue;
            }

            SellerType sellerType = dispositionInfo.getItem().getSellerType();

            if (!dispositionInfo.getIsDefault() && (SellerType.WFS.equals(sellerType)
                    || SellerType.WM.equals(sellerType))) {

                Set<String> commonDispositionPaths = sellerTypeBasedCommonDispositionPaths
                        .get(sellerType);
                if(CollectionUtils.isEmpty(commonDispositionPaths)) {
                    commonDispositionPaths = dispositionInfo.getDispositionPaths().stream()
                            .map(DispositionPath::getPath).collect(Collectors.toSet());
                } else {
                    Set<String> finalCommonDispositionPaths = commonDispositionPaths;
                    commonDispositionPaths = dispositionInfo.getDispositionPaths().stream()
                            .map(DispositionPath::getPath)
                            .filter(finalCommonDispositionPaths::contains).collect(Collectors.toSet());
                }
                sellerTypeBasedCommonDispositionPaths.put(sellerType, commonDispositionPaths);
            }
        }
    }

    private void sortDispositionPathsOnRank(List<DispositionInfo> infoList) {
        /* Sort dispositionPaths for all items based on Rank */
        infoList.forEach(dispositionInfo -> dispositionInfo.getDispositionPaths()
                .sort(Comparator.comparing(DispositionPath::getRank)));
    }


    /**
     * recomputes ranks for all Non-Default Items based on commonDispositionPaths and their cumulative sum of values
     *
     * @param infoList original list of dispositionPaths
     * @param commonDispositionPaths unique common paths among different items
     */
    private void recomputeRanksForAllNonDefaultItems(List<DispositionInfo> infoList, Set<String> commonDispositionPaths, SellerType sellerType) {

        /* Get Cumulative dispositionPaths sum for all commonDispositionPaths*/
        Map<String, Double> dispositionPathCumulativeSumMap =
                computeCumulativeSumForCommonDispositionPaths(infoList, commonDispositionPaths, sellerType);

        /* Sort the dispositionPathCumulativeSumMap in ascending order for assigning new ranks*/
        List<Map.Entry<String, Double>> sortedCommonDispositionPaths =
                new LinkedList<>(dispositionPathCumulativeSumMap.entrySet());

        if (commonDispositionPaths.size() > 1) {
            sortedCommonDispositionPaths.sort((value1, value2) -> (value2.getValue()).compareTo(value1.getValue()));
        }

        /* Update Ranks of dispositionPaths for Non-Default items */
        updatingRanksForAllDispositionPaths(sortedCommonDispositionPaths, infoList, commonDispositionPaths, sellerType);

    }

    /**
     * Compute and Update ranks for all dispositionPaths based on sortedCommonDispositionPaths for Non-Default Items
     *
     * @param sortedCommonDispositionPaths common dispositionPaths sorted on rank
     * @param infoList original list of dispositionPaths
     * @param commonDispositionPaths unique common paths among different items
     */
    private void updatingRanksForAllDispositionPaths(List<Map.Entry<String, Double>> sortedCommonDispositionPaths,
                                                     List<DispositionInfo> infoList,
                                                     Set<String> commonDispositionPaths, SellerType sellerType) {

        int newRank = 0;
        /*
          Updating Rank based on cumulative score for CommonDispositionPaths for Non-Default Items
        */
        for (Map.Entry<String, Double> sortedDisposition : sortedCommonDispositionPaths) {
            newRank++;
            for (DispositionInfo dispositionInfo : infoList) {
                if (!dispositionInfo.getIsDefault() && sellerType.equals(dispositionInfo.getItem().getSellerType())) {
                    List<DispositionPath> dispositionPaths = dispositionInfo.getDispositionPaths();

                    for (DispositionPath dispositionPath : dispositionPaths) {
                        if (sortedDisposition.getKey().equals(dispositionPath.getPath())) {
                            dispositionPath.setRank(newRank);
                        }
                    }
                }
            }
        }
        /*
          Updating Rank Non-CommonDispositionPaths for Non-Default Items
        */
        for (DispositionInfo dispositionInfo : infoList) {
            if (!dispositionInfo.getIsDefault() && sellerType.equals(dispositionInfo.getItem().getSellerType())) {
                List<DispositionPath> dispositionPaths = dispositionInfo.getDispositionPaths();
                int newReassignedRank = newRank;
                for (DispositionPath dispositionPath : dispositionPaths) {
                    if (!commonDispositionPaths.contains(dispositionPath.getPath())) {
                        newReassignedRank++;
                        dispositionPath.setRank(newReassignedRank);
                    }
                }
            }
        }
    }

    /**
     * Calculate cumulative sum for all commonDispositionPaths for Non-Default Items
     *
     * @param infoList original list of dispositionPaths
     * @param commonDispositions unique common paths among different items
     */
    private Map<String, Double> computeCumulativeSumForCommonDispositionPaths(
            List<DispositionInfo> infoList, Set<String> commonDispositions, SellerType sellerType) {

        Map<String, Double> dispositionPathCumulativeSumMap = new HashMap<>();
        for (DispositionInfo dispositionInfo : infoList) {
            List<DispositionPath> dispositionPaths = dispositionInfo.getDispositionPaths();
            /* Default dispositions will not participate in rank calculation */
            if (!dispositionInfo.getIsDefault() && sellerType.equals(dispositionInfo.getItem().getSellerType())) {
                for (DispositionPath dispositionPath : dispositionPaths) {
                    if (commonDispositions.contains(dispositionPath.getPath())) {
                        dispositionPathCumulativeSumMap.merge(dispositionPath.getPath(), dispositionPath.getValue(), Double::sum);
                    }
                }
            }
        }
        return dispositionPathCumulativeSumMap;
    }
}
