package com.walmartlabs.services.rdm.component.incentiveruleengine.util;

import com.walmartlabs.services.rdm.component.incentiveruleengine.model.RecoveryValueDiffBucket;
import com.walmartlabs.services.rdm.component.incentiveruleengine.model.ReturnIncentiveEngineContext;
import com.walmartlabs.services.rdm.config.client.ReturnIncentiveConfig;
import com.walmartlabs.services.rdm.formula.Session;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.*;

/**
 * @author: v0h01q5
 */
@Component
public class RdmIncentiveUtil {

    @Autowired
    ReturnIncentiveEngine returnIncentiveEngine;

    @Resource
    @ManagedConfiguration
    ReturnIncentiveConfig returnIncentiveConfig;

    List<RecoveryValueDiffBucket> recoveryValueDiffBuckets = new ArrayList<>();


    /**
     * For each item trigger the Return Incentive Rule Engine
     * @param dispositionInfo
     * @param session
     * @param item
     */
    public void calculateReturnIncentiveOfItem(DispositionInfo dispositionInfo, Session session, BaseItem item) {
        ReturnIncentiveEngineContext returnIncentiveEngineContext = prepareEngineContext(dispositionInfo,session, item);
        returnIncentiveEngine.runReturnIncentiveRuleEngine(returnIncentiveEngineContext);
    }

    private static ReturnIncentiveEngineContext prepareEngineContext(DispositionInfo dispositionInfo, Session session, BaseItem item) {
        ReturnIncentiveEngineContext returnIncentiveEngineContext = new ReturnIncentiveEngineContext();
        returnIncentiveEngineContext.setDispositionInfo(dispositionInfo);
        returnIncentiveEngineContext.setSession(session);
        returnIncentiveEngineContext.setItem(item);
        return returnIncentiveEngineContext;
    }

    public void loadRecoveryValueDiffBucketsFromCCM()
    {
        String allRecoveryValueDiffBuckets = returnIncentiveConfig.getRecoveryValueDiffBuckets();

        if(StringUtils.isNotEmpty(allRecoveryValueDiffBuckets)) {
            StringTokenizer recoveryValueRangeBucketTokenizer = new StringTokenizer(allRecoveryValueDiffBuckets, ";");
            while (recoveryValueRangeBucketTokenizer.hasMoreTokens()) {
                RecoveryValueDiffBucket recoveryValueDiffBucket = new RecoveryValueDiffBucket();
                String recoveryValueBucketWithIncentiveAmount = recoveryValueRangeBucketTokenizer.nextToken();

                StringTokenizer recoveryValueBucketWithIncentiveAmountTokenizer = new StringTokenizer(recoveryValueBucketWithIncentiveAmount, "=");
                while (recoveryValueBucketWithIncentiveAmountTokenizer.hasMoreTokens()) {
                    String recoveryValueRange = recoveryValueBucketWithIncentiveAmountTokenizer.nextToken();
                    String incentiveAmountString = recoveryValueBucketWithIncentiveAmountTokenizer.nextToken();
                    StringTokenizer recoveryValueRangeTokenizer = new StringTokenizer(recoveryValueRange, "-");
                    while (recoveryValueRangeTokenizer.hasMoreTokens()) {
                        String rangeLimitString = recoveryValueRangeTokenizer.nextToken();
                        Double rangeLimit = Double.parseDouble(rangeLimitString);
                        if(recoveryValueDiffBucket.getFromRange() != null)
                        {
                            recoveryValueDiffBucket.setToRange(rangeLimit);
                        }
                        else
                        {
                            recoveryValueDiffBucket.setFromRange(rangeLimit);
                        }
                    }
                    Double incentiveAmount=Double.parseDouble(incentiveAmountString);
                    recoveryValueDiffBucket.setIncentiveAmount(incentiveAmount);
                }
                recoveryValueDiffBuckets.add(recoveryValueDiffBucket);
            }
        }
    }
    /**
     * Convert string
     * @return
     */
    public List<RecoveryValueDiffBucket> prepareRecoveryValueDiffBuckets()
    {
        if(returnIncentiveConfig.getConfigUpdated())
        {
            loadRecoveryValueDiffBucketsFromCCM();
            returnIncentiveConfig.setConfigUpdated(false);
        }
        return recoveryValueDiffBuckets;
    }
}
