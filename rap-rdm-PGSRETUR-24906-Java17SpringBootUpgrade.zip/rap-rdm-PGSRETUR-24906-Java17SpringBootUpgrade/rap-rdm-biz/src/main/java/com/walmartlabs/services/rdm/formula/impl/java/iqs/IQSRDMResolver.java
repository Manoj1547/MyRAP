package com.walmartlabs.services.rdm.formula.impl.java.iqs;

import com.walmartlabs.services.rdm.component.iqs.model.response.GetItemDetailsResponse;

import com.walmartlabs.services.rdm.component.iqs.service.utl.IQSServiceHelper;
import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import com.walmartlabs.services.rdm.formula.*;
import com.walmartlabs.services.rdm.formula.impl.java.iqs.service.IQSRDMService;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.formula.Formula;
import com.walmartlabs.services.rdm.util.RDMCommonUtils;
import io.strati.configuration.annotation.ManagedConfiguration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



import java.util.Map;
import java.util.concurrent.*;


@Component
public class IQSRDMResolver implements JavaEngineClass {

    @ManagedConfiguration
    private RDMSwitches switches;

    @Autowired
    private IQSRDMService iqsRdmService;


    @Autowired
    private IQSServiceHelper iqsServiceHelper;



    private static final Logger LOG = LoggerFactory.getLogger(IQSRDMResolver.class);

    @Override
    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        BaseItem item = FormulaEngine.getInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);
        CompletableFuture<GetItemDetailsResponse> itemDetailsResponseFuture = null;

        if(!inputData.containsKey(FormulaConstants.INTERNAL_DATA_NAME_IQSRDM_FUTURE)) {
            itemDetailsResponseFuture = iqsServiceHelper.triggerRdmIqsServiceCall(item);
            inputData.put(FormulaConstants.INTERNAL_DATA_NAME_IQSRDM_FUTURE,itemDetailsResponseFuture);
        }

        /**
         If service is called as part of preCall then,
         No need to wait for response at this point, return from here
         */
        if(RDMCommonUtils.isExternalServicePreCall(formula, inputData)){
            return null;
        }

        itemDetailsResponseFuture = (CompletableFuture<GetItemDetailsResponse>) inputData.get(FormulaConstants.INTERNAL_DATA_NAME_IQSRDM_FUTURE);
        GetItemDetailsResponse iqsResponse = iqsServiceHelper.getIqsRdmResponseFromFuture(itemDetailsResponseFuture, item);


        return iqsResponse;


       /* //TODO 1. Cleannnnn this Code
        //Handle multicall scenarios in cleaner way
        if(switches.getStopExternalServiceMulticall()){
            FormulaServiceUtil.CheckForException(formula, inputData);
            try {
                response = iqsRdmService.getIQSRdmItemDetails(item);
            } catch (RDMException e) {
                FormulaServiceUtil.addExceptionInInputData(formula, inputData, e);
                throw e;
            }
        } else {
            if (switches.getExternalServiceExceptionHandlingEnabled()) {
                if (switches.getExternalApiVarialblesForExceptionHandling().contains(FormulaConstants.INTERNAL_DATA_NAME_IQSRDM)) {
                    *//**
                     * Below is a temporary Hack to stop multiCalls for external service in case of failure
                     * TODO: Design a cleaner way to do the same
                     *//*
                    try {
                        response = iqsRdmService.getIQSRdmItemDetails(item);
                    } catch (RDMException e) {
                        *//**
                         * Store the exception data in session, so that it can be used evaluate the value next time,
                         * and we don't call service multiple times
                         *//*
                        Map<String, Exception> externalApiExceptions = (Map<String, Exception>) inputData.get(FormulaConstants.INTERMEDIATE_DATA_NAME_EXTERNAL_API_EXCEPTIONS);
                        externalApiExceptions.put(FormulaConstants.INTERNAL_DATA_NAME_IQSRDM, e);
                        throw e;
                    }
                }

            } else {
                response = iqsRdmService.getIQSRdmItemDetails(item);
            }
        }

        return response;*/

    }

}
