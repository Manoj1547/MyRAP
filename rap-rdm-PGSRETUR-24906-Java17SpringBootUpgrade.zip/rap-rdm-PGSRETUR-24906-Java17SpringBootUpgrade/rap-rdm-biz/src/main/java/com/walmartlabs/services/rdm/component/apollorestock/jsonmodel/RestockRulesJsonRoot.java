package com.walmartlabs.services.rdm.component.apollorestock.jsonmodel;

import java.util.List;

public class RestockRulesJsonRoot{
    public RestockRules restockRules;
    public ConjuctionRules conjuctionRules;
    public List<ConjuctionRuleCondition> conjuctionRuleConditions;

    public List<ConjuctionRuleCondition> getConjuctionRuleConditions() {
        return conjuctionRuleConditions;
    }

    public void setConjuctionRuleConditions(List<ConjuctionRuleCondition> conjuctionRuleConditions) {
        this.conjuctionRuleConditions = conjuctionRuleConditions;
    }

    public RestockRules getRestockRules() {
        return restockRules;
    }

    public void setRestockRules(RestockRules restockRules) {
        this.restockRules = restockRules;
    }

    public ConjuctionRules getConjuctionRules() {
        return conjuctionRules;
    }

    public void setConjuctionRules(ConjuctionRules conjuctionRules) {
        this.conjuctionRules = conjuctionRules;
    }
}