package com.walmartlabs.services.rdm.util;

import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.impl.java.iqs.service.IQSRDMService;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.formula.Formula;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

import static com.walmartlabs.services.rdm.formula.FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM;

public class FormulaServiceUtil {

    private static final Logger LOG = LoggerFactory.getLogger(FormulaServiceUtil.class);
    /**
     * If there  already an exception present against this variable then throw the exception
     * @param formula
     * @param inputData
     */
    public static void CheckForException(Formula formula, Map<String, Object> inputData) {
       String formulaName = formula.getName();
       if(StringUtils.isNotEmpty(formulaName)){
           String exceptionVariableForFormula = formulaName + FormulaConstants.INTERMEDIATE_DATA_NAME_EXCEPTION;
           if(inputData.get(exceptionVariableForFormula) != null){
               BaseItem item = (BaseItem) inputData.get(INTERNAL_DATA_NAME_REQUEST_ITEM);
               LOG.info("External service exception already exist for, service " + formulaName + " gtin " + item.getGtin());
               throw (RDMException)inputData.get(exceptionVariableForFormula);
           }
       }
    }

    public static void addExceptionInInputData(Formula formula, Map<String, Object> inputData, RDMException exception) {
        String formulaName = formula.getName();
        if(StringUtils.isNotEmpty(formulaName)){
            String exceptionVariableForFormula = formulaName + FormulaConstants.INTERMEDIATE_DATA_NAME_EXCEPTION;
            inputData.put(exceptionVariableForFormula, exception);
        }
    }
}
