package com.walmartlabs.services.rdm.rank.assigner.impl;

import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.Comparator;

/**
 * It assigns ranks to every disposition path in continuity
 * @author v0h01q5
 */
@Component
public class AssignContinuousRank implements IAssignFinalRanksForNonDefaultCase{

    @Override
    public void assignFinalRanks(DispositionInfo dispositionInfo) {
        if(null != dispositionInfo && CollectionUtils.isNotEmpty(dispositionInfo.getDispositionPaths())) {
            Collections.sort(dispositionInfo.getDispositionPaths(), Comparator.comparingInt(d -> d.getRank()));
            int rank = 1;
            for (DispositionPath dispositionPath : dispositionInfo.getDispositionPaths()) {
                dispositionPath.setRank(rank);
                rank++;
            }
        }
    }
}
