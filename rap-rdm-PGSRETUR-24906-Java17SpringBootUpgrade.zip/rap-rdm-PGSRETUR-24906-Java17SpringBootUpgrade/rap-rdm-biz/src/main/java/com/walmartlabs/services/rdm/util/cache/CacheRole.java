package com.walmartlabs.services.rdm.util.cache;

/**
 * 
 * @author Tim Jin
 *
 */
public enum CacheRole {
    DEFAULT, RCP, SIRO, IQS, OVT,DSIM

}
