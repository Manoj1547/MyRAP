package com.walmartlabs.services.rdm.model.fedexratecard;

/**
 * 
 * @author Tim Jin
 *
 */
public class FedexRateCard {

    private Double  lower;

    private Double  higher;

    private Double  value;

    private Boolean lowerInclusive;

    private Boolean higherInclusive;

    public Double getLower() {
        return lower;
    }

    public void setLower(Double lower) {
        this.lower = lower;
    }

    public Double getHigher() {
        return higher;
    }

    public void setHigher(Double higher) {
        this.higher = higher;
    }

    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    public Boolean getLowerInclusive() {
        return lowerInclusive;
    }

    public void setLowerInclusive(Boolean lowerInclusive) {
        this.lowerInclusive = lowerInclusive;
    }

    public Boolean getHigherInclusive() {
        return higherInclusive;
    }

    public void setHigherInclusive(Boolean higherInclusive) {
        this.higherInclusive = higherInclusive;
    }

}