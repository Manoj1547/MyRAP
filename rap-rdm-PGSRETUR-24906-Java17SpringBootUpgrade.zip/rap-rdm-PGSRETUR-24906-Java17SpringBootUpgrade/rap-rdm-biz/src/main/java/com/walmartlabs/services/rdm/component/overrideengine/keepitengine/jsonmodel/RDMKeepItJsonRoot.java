package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.jsonmodel;

import java.util.List;

public class RDMKeepItJsonRoot {
    public List<KeepItRules> keepItRules;

    public List<KeepItRules> getKeepItRules() {
        return keepItRules;
    }

    public void setKeepItRules(List<KeepItRules> keepItRules) {
        this.keepItRules = keepItRules;
    }
}

