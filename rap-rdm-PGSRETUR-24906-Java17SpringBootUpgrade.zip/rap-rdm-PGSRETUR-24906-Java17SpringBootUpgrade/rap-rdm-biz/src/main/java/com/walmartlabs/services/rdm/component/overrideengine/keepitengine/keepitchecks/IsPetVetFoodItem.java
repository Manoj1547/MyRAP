package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.stereotype.Component;

import java.util.Map;

import static com.walmartlabs.services.rdm.RDMConstants.PET_VET_FOOD_ITEM;
import static com.walmartlabs.services.rdm.RDMConstants.YES;

@Component("isPetVetFoodItem")
public class IsPetVetFoodItem implements IRDMKeepItRuleCheck{
    @ManagedConfiguration
    private RDMKeepItConfig rdmKeepItConfig;

    public void setRdmKeepItConfig(RDMKeepItConfig rdmKeepItConfig) {
        this.rdmKeepItConfig = rdmKeepItConfig;
    }

    @Override
    public String getKeepItCheckName() {
        return RDMConstants.RULE_CHECK_NAME_IS_PET_VET_FOOD_ITEM;
    }

    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {
        Map<String,String> itemCustomAttributes = keepItRuleEngineContext.getItem().getItemCustomAttributes();
        return (rdmKeepItConfig.getRuleForPetVetFoodEnabled() && null != itemCustomAttributes &&
                itemCustomAttributes.containsKey(PET_VET_FOOD_ITEM)
                && (Boolean.parseBoolean(itemCustomAttributes.get(PET_VET_FOOD_ITEM))
        || YES.equals(itemCustomAttributes.get(PET_VET_FOOD_ITEM))));
    }
}
