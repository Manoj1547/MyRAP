package com.walmartlabs.services.rdm.component.rcp.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.walmart.platform.kernel.exception.error.Error;


@JsonIgnoreProperties(ignoreUnknown = true)
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class RDMError extends Error {

    private static final long serialVersionUID = 1L;

    @JsonProperty("errorSource")
    private String errorSource;

    @JsonProperty("instructions")
    private String instructions;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getErrorSource() {
        return errorSource;
    }

    public void setErrorSource(String errorSource) {
        this.errorSource = errorSource;
    }

    public String getInstructions() {
        return instructions;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }
}