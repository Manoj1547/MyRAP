package com.walmartlabs.services.rdm.api.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.dto.dispositionpaths.common.DispositionPath;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.platform.kernel.exception.error.Error;
import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.service.wrappers.Status;
import com.walmart.platform.txnmarking.impl.NullTransactionImpl;
import com.walmart.platform.txnmarking.impl.TransactionImpl;
import com.walmartlabs.services.rdm.RDMUtils;
import com.walmartlabs.services.rdm.api.KafkaPublisher;
import com.walmartlabs.services.rdm.api.RDMManager;
import com.walmartlabs.services.rdm.api.RDMServices;
import com.walmartlabs.services.rdm.dto.dispositionpaths.common.Item;
import com.walmartlabs.services.rdm.dto.dispositionpaths.kafka.DispositionEventPayload;
import com.walmartlabs.services.rdm.dto.dispositionpaths.request.DispositionPathsRequestDTO;
import com.walmartlabs.services.rdm.dto.dispositionpaths.response.DispositionPathsResponseDTO;
import com.walmartlabs.services.rdm.dto.dispositionpaths.simulation.request.DispositionPathsSimulationRequestDTO;
import com.walmartlabs.services.rdm.dto.dispositionpaths.simulation.response.DispositionPathsSimulationResponseDTO;
import com.walmartlabs.services.rdm.dto.dispositionpaths.simulation.response.Info;
import com.walmartlabs.services.rdm.dto.dispositionpaths.simulation.response.VariableInfo;
import com.walmartlabs.services.rdm.mapper.ModelMapper;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPathResult;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.KeepItDispositionInfo;
import com.walmartlabs.services.rdm.server.common.exception.InvalidRequestException;

import io.strati.StratiServiceProvider;
import org.apache.commons.lang.BooleanUtils;
import io.strati.txnmarking.TransactionMarkingService;

/**
 * @author Tim Jin
 */
public class RDMServicesImpl implements RDMServices {

    private static final Logger       LOG = LoggerFactory.getLogger(RDMManager.class);

    private TransactionMarkingService TMS;

    @Resource
    RDMManager                        rdmManager;

    @Resource
    ModelMapper                       mapper;

    @Resource
    KafkaPublisher                    publisher;

    @Resource
    RDMUtils                          util;

    @PostConstruct
    private void init() {}

    private RDMServicesImpl() {
        TMS = StratiServiceProvider.getInstance().getTransactionMarkingService().get();
    }

    @Override
    public ServiceResponse<DispositionPathsResponseDTO> dispositionPaths(ServiceRequest<DispositionPathsRequestDTO> request, Boolean test) throws ServiceException {

        TransactionImpl top;
        if(TMS.currentTransaction() instanceof NullTransactionImpl){
            top = (TransactionImpl) TMS.topTransaction("DispositionPaths", "DispositionPaths");
        }else{
            top = (TransactionImpl) TMS.transaction("DispositionPaths", "DispositionPaths");
        }
        top.start();

        ServiceResponse<DispositionPathsResponseDTO> sr = new ServiceResponse<>();

        DispositionPathsResponseDTO response = mapper.clone(request.getPayload());
        DispositionEventPayload kafka = mapper.map(response);

        List<Item> items = response.getItems();
        List<Error> errors = new ArrayList<>();

        try{
            if(items != null){
                DispositionPathResult rst = rdmManager.getPaths(mapper.map(request.getPayload()), test);
                List<DispositionInfo> infoList = rst.getDispositionInfos();
                List<com.walmartlabs.services.rdm.model.dispositionpaths.Item> responseItemList = rst.getItems();
                for(int i = 0; i < items.size(); i++){
                    Item item = items.get(i);
                    DispositionInfo info = infoList.get(i);
                    KeepItDispositionInfo keepItDispositionInfo = info.getKeepItInfo();
                    com.walmartlabs.services.rdm.model.dispositionpaths.Item responseItem = responseItemList.get(i);

                    if(info.getError() != null) errors.add(info.getError());

                    item.setDispositionInfo(mapper.map(info));
                    item.setKeepItInfo(mapper.map(keepItDispositionInfo));
                    item.setVariableOverrides(null);
                    item.setCvpEligible(responseItem.getCvpEligible());
                    item.setPartialKeepIt(responseItem.getPartialKeepIt());

                    //set curbside store ids in disposition path level if curbside return mode found
                    addSelfServeDispositionDetails(item);

                    kafka.getItems().get(i).setDispositionInfo(mapper.mapKafka(info));
                    kafka.getItems().get(i).setVariableOverrides(null);
                    kafka.getItems().get(i).setKeepItInfo(mapper.map(keepItDispositionInfo));
                    kafka.getItems().get(i).setPartialKeepIt(mapper.map(responseItem.getPartialKeepIt()));
                }
                if(BooleanUtils.isNotTrue(test)) publisher.publish(kafka, errors.size() != 0, rst.getDate());
            }
            sr.setPayload(response);

            if(errors.size() == 0){
                sr.setStatus(Status.OK);
            }else{
                if(items != null && errors.size() == items.size()) sr.setStatus(Status.FAIL);
                else sr.setStatus(Status.PARTIAL);
                sr.setErrors(errors);
            }
            LOG.info("Test:{}, RDM-Request:{}, RDM-Response:{} ", test, util.getJsonString(request), util.getJsonString(sr));
            top.end();
            return sr;
        }catch (InvalidRequestException e){
            LOG.info("Test:{}, RDM-Request:{}, RDM-Error:{}", test, util.getJsonString(request), util.getJsonString(e));
            top.endWithFailure(e.getMessage());
            throw e;
        }
    }

    private void addSelfServeDispositionDetails(Item item) {
        populateCurbSideStoreDetails(item);
    }

    private void populateCurbSideStoreDetails(Item item) {
        item.getDispositionInfo().getDispositionPaths().forEach(dispositionPath -> {
            if(RDMConstants.RETURN_MODE_CURBSIDE.equalsIgnoreCase(dispositionPath.getPath())){
                dispositionPath.setStoreIds(item.getCurbSideStoreIds());
            }
        });
    }

    @Override
    public ServiceResponse<DispositionPathsSimulationResponseDTO> dispositionPathsSimulation(ServiceRequest<DispositionPathsSimulationRequestDTO> request, Boolean debug) throws ServiceException {

        ServiceResponse<DispositionPathsSimulationResponseDTO> sr = new ServiceResponse<>();

        if(request != null && request.getPayload() != null){
            DispositionPathsSimulationResponseDTO response = new DispositionPathsSimulationResponseDTO();

            List<Error> errors = new ArrayList<>();
            List<com.walmartlabs.services.rdm.dto.dispositionpaths.simulation.request.Item> dtoItems = request.getPayload().getItems();

            if(dtoItems != null){

                List<com.walmartlabs.services.rdm.model.dispositionpaths.simulation.Item> items = mapper.mapSimulationItemList(dtoItems);
                items.forEach(item -> {
                    item.setWalmartPlusCustomer(request.getPayload().isWalmartPlusCustomer());
                    item.setCustomerId(request.getPayload().getCustomerId());
                    item.setOrderNo(request.getPayload().getOrderNo());

                    if(request.getPayload().getChannelInfo() != null && request.getPayload().getChannelInfo().getChannelName() != null)
                    {
                        item.setChannelName(request.getPayload().getChannelInfo().getChannelName());
                    }
                });

                List<DispositionInfo> infoList = rdmManager.getSimulation(items, debug);
                infoList.forEach(info -> {
                    com.walmartlabs.services.rdm.model.dispositionpaths.simulation.Item i = (com.walmartlabs.services.rdm.model.dispositionpaths.simulation.Item) info.getItem();
                    info.setSeqNo(i.getSeqNo());

                    com.walmartlabs.services.rdm.dto.Node nodeDTO = mapper.map(info.getNode());
                    List<VariableInfo> variablesDTO = mapper.mapList(info.getVariableInfos());
                    if(i.getChannelName() != null){
                        if(response.getInfo() == null) response.setInfo(new HashMap<>());
                        response.getInfo().putIfAbsent(i.getChannelName(), new Info());
                        response.getInfo().get(i.getChannelName()).setNode(nodeDTO);
                        response.getInfo().get(i.getChannelName()).setVariables(variablesDTO);
                    }
                    com.walmartlabs.services.rdm.dto.dispositionpaths.simulation.response.DispositionInfo dispositionInfoDTO = mapper.mapSimulation(info);
                    if(dispositionInfoDTO != null){
                        if(response.getDispositionInfo() == null) response.setDispositionInfo(new ArrayList<>());
                        response.getDispositionInfo().add(dispositionInfoDTO);
                        if(dispositionInfoDTO.getError() != null) errors.add(dispositionInfoDTO.getError());
                    }
                });
            }

            sr.setPayload(response);

            if(errors.size() == 0) sr.setStatus(Status.OK);
            else{
                if(dtoItems != null && errors.size() == dtoItems.size()) sr.setStatus(Status.FAIL);
                else sr.setStatus(Status.PARTIAL);
                sr.setErrors(errors);
            }

        }else{
            sr.setStatus(Status.FAIL);
        }
        return sr;
    }

}
