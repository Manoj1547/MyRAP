package com.walmartlabs.services.rdm.component.iqs.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.walmart.services.common.model.measurement.Measurement;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductPackageDimension {
    @JsonProperty("unitWeight")
    private Measurement unitWeight;

    @JsonProperty("unitHeight")
    private Measurement unitHeight;

    @JsonProperty("unitWidth")
    private Measurement unitWidth;

    @JsonProperty("unitLength")
    private Measurement unitLength;

    public Measurement getUnitWeight() {
        return unitWeight;
    }

    public void setUnitWeight(Measurement unitWeight) {
        this.unitWeight = unitWeight;
    }

    public Measurement getUnitHeight() {
        return unitHeight;
    }

    public void setUnitHeight(Measurement unitHeight) {
        this.unitHeight = unitHeight;
    }

    public Measurement getUnitWidth() {
        return unitWidth;
    }

    public void setUnitWidth(Measurement unitWidth) {
        this.unitWidth = unitWidth;
    }

    public Measurement getUnitLength() {
        return unitLength;
    }

    public void setUnitLength(Measurement unitLength) {
        this.unitLength = unitLength;
    }
}
