package com.walmartlabs.services.rdm.component.restock.service.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmart.platform.txnmarking.impl.NullTransactionImpl;
import com.walmart.platform.txnmarking.impl.TransactionImpl;
import com.walmartlabs.services.rdm.component.restock.model.request.GetRestockItemDetailsRequest;
import com.walmartlabs.services.rdm.component.restock.model.response.GetRestockItemDetailsResponse;
import com.walmartlabs.services.rdm.config.client.RestockServiceConfig;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import com.walmartlabs.services.rdm.util.BaseHTTPClient;
import io.strati.StratiServiceProvider;
import com.walmartlabs.services.rdm.util.HeaderElements;
import io.strati.configuration.annotation.ManagedConfiguration;
import io.strati.txnmarking.TransactionMarkingService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ws.rs.core.MediaType;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

@Component
public class RestockHttpClient extends BaseHTTPClient {

    private static final Logger LOG = LoggerFactory.getLogger(RestockHttpClient.class);
    private static final String QUERY_PARAM_Q = "pristineCondition";

    private TransactionMarkingService TMS;

    private ObjectMapper mapper;

    @Resource
    @ManagedConfiguration
    RestockServiceConfig restockServiceConfig;

    @PostConstruct
    private void init() {
        mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    private RestockHttpClient(){
        TMS = StratiServiceProvider.getInstance().getTransactionMarkingService().get();
    }

    public GetRestockItemDetailsResponse getRestockItemDetails(GetRestockItemDetailsRequest request) {

        if(restockServiceConfig.isMockedDispositionServiceResponseEnabled()){
            LOG.info("Mock enabled for Restock API Service");
            GetRestockItemDetailsResponse mockedRestockItemDetailsResponse = null;
            String mockedResponseString = restockServiceConfig.getMockedDispositionServiceResponse();
            try {
                mockedRestockItemDetailsResponse = mapper.readValue(mockedResponseString, GetRestockItemDetailsResponse.class);
            } catch (JsonProcessingException e) {
                String errorMsg = "Response mapping failed for Restock mock service";
                LOG.error(errorMsg, e);
                throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.RESTOCK_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
            }

            return mockedRestockItemDetailsResponse;
        }

        TransactionImpl top;
        if(TMS.currentTransaction() instanceof NullTransactionImpl) {
            top = (TransactionImpl) TMS.topTransaction("RestockItemDetails", "RestockItemDetails");
        }else {
            top = (TransactionImpl) TMS.transaction("RestockItemDetails", "RestockItemDetails");
        }
        top.start();

        String baseUrl = restockServiceConfig.getServiceBaseHostUrl();
        String pathUrl = restockServiceConfig.getServiceEndpoint();
        pathUrl = pathUrl.replaceAll("\\{storeId\\}", request.getStoreId());
        pathUrl = pathUrl.replaceAll("\\{orderNo\\}", request.getOrderNo());
        pathUrl = pathUrl.replaceAll("\\{upc\\}", request.getUpc());
        int apiTimeout = restockServiceConfig.getApiTimeOut();
        Map<String, String> headerParams = getHeaderParams(restockServiceConfig);
        Map<String, String> queryParams = getQueryParams(request);

        GetRestockItemDetailsResponse response;
        String responseString = null;
        try {
            LOG.info("Invoking Restock api. URL:{}{}", baseUrl, pathUrl);
            responseString = get(baseUrl, pathUrl, queryParams, headerParams ,apiTimeout, String.class);
            LOG.info("Restock api, Request:{}, Response: {}", request,responseString);
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            response = objectMapper.readValue(responseString, GetRestockItemDetailsResponse.class);

            validateResponse(response);
            top.end();

        } catch (JsonProcessingException e) {
            String errorMsg = MessageFormat.format("Response mapping failed for Restock api service, Request: {0}, Response: {1}", request,responseString);
            LOG.error(errorMsg);
            top.logException(e);
            top.endWithFailure(e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.RESTOCK_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        } catch (Exception e) {
            String errorMsg = MessageFormat.format("Unexpected exception for UPC: {0}, Request: {1}", request.getUpc(),request,
                    e.getMessage());
            LOG.error(errorMsg);
            top.logException(e);
            top.endWithFailure(e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.RESTOCK_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        }

        return response;
    }

    private Map<String, String> getHeaderParams(RestockServiceConfig restockServiceConfig) {
        HashMap<String, String> headers = new HashMap<>();

        addHeaderParam(headers, HeaderElements.ACCEPT, MediaType.APPLICATION_JSON);
        addHeaderParam(headers, HeaderElements.CLAIMS_APP_VERSION, restockServiceConfig.getServiceVersion());
        addHeaderParam(headers, HeaderElements.CLAIMS_USER_ID, restockServiceConfig.getUserId());
        addHeaderParam(headers, HeaderElements.CLAIMS_SOURCE_ID, restockServiceConfig.getSourceId());

        return headers;
    }

    private void addHeaderParam(HashMap<String, String> headers, String name, String value) {
        if (StringUtils.isNotBlank(value))
            headers.put(name, value);
    }

    private void validateResponse(GetRestockItemDetailsResponse response) {

        if(response == null || response.getDisposition() == null || response.getItemInfo() == null){
            String errorMsg = "Restock-HTTP failed - Null/Empty Value";
            LOG.error(errorMsg);
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.RESTOCK_HTTP_CLIENT_EXECUTION_FAILED, errorMsg);
        }
    }

    private Map<String, String> getQueryParams(GetRestockItemDetailsRequest request) {
        Map<String, String> queryParams = new HashMap<>();
            queryParams.put(QUERY_PARAM_Q, String.valueOf(request.getPristineCondition()));
        return queryParams;
    }

}
