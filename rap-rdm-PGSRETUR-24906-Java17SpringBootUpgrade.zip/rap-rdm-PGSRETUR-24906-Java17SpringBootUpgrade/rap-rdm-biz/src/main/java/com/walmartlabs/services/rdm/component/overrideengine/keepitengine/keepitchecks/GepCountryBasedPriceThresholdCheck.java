package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;
import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Component("gepCountryBasedPriceThresholdCheck")
public class GepCountryBasedPriceThresholdCheck implements IRDMKeepItRuleCheck{
    @Autowired
    private RDMKeepItUtil rdmKeepItUtil;
    @ManagedConfiguration
    private RDMKeepItConfig rdmKeepItConfig;

    public void setRdmKeepItUtil(RDMKeepItUtil rdmKeepItUtil) {
        this.rdmKeepItUtil = rdmKeepItUtil;
    }

    public void setRdmKeepItConfig(RDMKeepItConfig rdmKeepItConfig) {
        this.rdmKeepItConfig = rdmKeepItConfig;
    }

    @Override
    public String getKeepItCheckName() {
        return RDMConstants.RULE_CHECK_NAME_GEP_ITEM_PRICE;
    }

    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {
        BigDecimal itemRetailPrice;
        // fetch the itemPrice and compare it with threshold value of that GEP country
        if(rdmKeepItUtil.checkGepOrder(keepItRuleEngineContext)) {
            if(rdmKeepItConfig.getKeepItItemDetailsFromRequestEnabled()) {
                itemRetailPrice = rdmKeepItUtil.getItemPriceFromRequest(keepItRuleEngineContext);
            }else{
                itemRetailPrice = rdmKeepItUtil.getItemPrice(keepItRuleEngineContext);
            }
            return itemRetailPrice.compareTo(new BigDecimal (rdmKeepItUtil.getdefaultKeepItThresholdValueForGepCountry(keepItRuleEngineContext.getItem().getCountryCode()))) <= 0 ;
        }
        return false;
    }
}
