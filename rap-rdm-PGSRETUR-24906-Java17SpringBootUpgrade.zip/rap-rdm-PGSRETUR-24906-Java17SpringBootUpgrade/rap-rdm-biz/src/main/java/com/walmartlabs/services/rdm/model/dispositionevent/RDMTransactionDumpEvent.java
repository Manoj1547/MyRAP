package com.walmartlabs.services.rdm.model.dispositionevent;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.walmartlabs.services.rdm.model.dispositionpaths.DispositionPathsRequest;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RDMTransactionDumpEvent {

    @JsonProperty("request")
    DispositionPathsRequest request;
    @JsonProperty("response")
    List<DispositionInfo> response;
    @JsonProperty("test")
    boolean test;
    @JsonProperty("isReprocess")
    boolean isReprocess;

    public RDMTransactionDumpEvent(DispositionPathsRequest request, List<DispositionInfo> response, boolean test, boolean isReprocess) {
        this.request = request;
        this.response = response;
        this.test = test;
        this.isReprocess = isReprocess;
    }

    public RDMTransactionDumpEvent() {
    }

    public boolean isTest() {
        return test;
    }

    public void setTest(boolean test) {
        this.test = test;
    }

    public DispositionPathsRequest getRequest() {
        return request;
    }

    public void setRequest(DispositionPathsRequest request) {
        this.request = request;
    }

    public List<DispositionInfo> getResponse() {
        return response;
    }

    public void setResponse(List<DispositionInfo> response) {
        this.response = response;
    }

    public boolean isReprocess() {
        return isReprocess;
    }

    public void setReprocess(boolean reprocess) {
        isReprocess = reprocess;
    }
}
