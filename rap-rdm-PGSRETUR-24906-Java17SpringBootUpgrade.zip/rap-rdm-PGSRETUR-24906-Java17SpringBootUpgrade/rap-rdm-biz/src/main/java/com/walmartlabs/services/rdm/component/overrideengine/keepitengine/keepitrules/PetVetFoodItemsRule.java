package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitrules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.common.IRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component("petVetFoodItemsRule")
public class PetVetFoodItemsRule extends AbstractRDMKeepItRule{

    private static final Logger LOG = LoggerFactory.getLogger(PetVetFoodItemsRule.class);

    @Override
    public void applyRuleDecision(IRuleEngineContext ruleEngineContext) {
        KeepItRuleEngineContext keepItRuleEngineContext = (KeepItRuleEngineContext) ruleEngineContext;
        BaseItem item = keepItRuleEngineContext.getItem();
        DispositionInfo dispositionInfo = keepItRuleEngineContext.getDispositionInfo();
        for(DispositionPath dispositionPath : CollectionUtils.emptyIfNull(dispositionInfo.getDispositionPaths())){
                dispositionPath.setKeepIt(item.getKeepItInfo().getTrustCustomerToKeepIt());
        }


        LOG.info(String.format("%s.applyRuleDecision() is executed for itemId %s and salesOrderNo %s", this.getRuleName(), item.getItemId(), item.getOrderNo()));
    }

    @Override
    public String getRuleName() {
        return RDMConstants.RULE_NAME_PET_VET_FOOD_ITEM;
    }
}
