package com.walmartlabs.services.rdm.formula.impl.java;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import com.walmartlabs.services.rdm.component.iqs.model.response.GetItemDetailsResponse;
import com.walmartlabs.services.rdm.component.iqs.service.utl.IQSServiceHelper;
import com.walmartlabs.services.rdm.component.rcp.model.request.ItemDispositionRequestPayload;
import com.walmartlabs.services.rdm.component.rcp.service.util.RCPServiceHelper;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.walmartlabs.services.rdm.component.rcp.model.request.GetItemDispositionDetailsRequest;
import com.walmartlabs.services.rdm.component.rcp.model.request.ItemPrice;
import com.walmartlabs.services.rdm.component.rcp.model.response.GetItemDispositionDetailsResponse;
import com.walmartlabs.services.rdm.component.rcp.service.util.RCPHttpClient;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.FormulaException;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.Formula;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public class RCPDataResolver implements JavaEngineClass {

    @Resource
    RCPHttpClient rcpClient;

    ObjectReader  reader;

    @Autowired
    RCPServiceHelper rcpServiceHelper;

    private static final Logger LOG = LoggerFactory.getLogger(RCPDataResolver.class);


    @PostConstruct
    private void init() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        reader = mapper.reader();
    }

    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        Integer vendorNo = FormulaEngine.getNotNullInput(formula,inputData, FormulaConstants.VARIABLE_VENDOR_NMUBER);
        Integer departmentNo = FormulaEngine.getNotNullInput(formula,inputData, FormulaConstants.VARIABLE_DEPARTMENT_NUMBER);
        Integer contractNo = FormulaEngine.getNotNullInput(formula,inputData, FormulaConstants.VARIABLE_CONTRACT_NUMBER);
        String price = FormulaEngine.getNotNullInput(formula,inputData, FormulaConstants.INTERNAL_DATA_NAME_IQS_PRICE);
        String itemId = FormulaEngine.getNotNullInput(formula,inputData, FormulaConstants.INTERNAL_DATA_NAME_ITEM_ID);

        GetItemDispositionDetailsRequest request = new GetItemDispositionDetailsRequest();
        ItemDispositionRequestPayload requestPayload = request.getPayload();
        requestPayload.setVendorNo(vendorNo);
        requestPayload.setDepartmentNo(departmentNo);
        requestPayload.setContractNo(contractNo);
        requestPayload.setItemId(itemId);

        try{
            requestPayload.setItemPrice(reader.readValue(price, ItemPrice.class));
        }catch (IOException e){
            LOG.error("Error while preparing rcp request, iqs price is not valid, dept {} vendorNo {} itemid {} iqsprice {} ",
                    departmentNo, vendorNo, itemId, price);
            throw new FormulaException(MessageFormat.format("iqs price is not valid {0}", price), e);
        }

        if(!inputData.containsKey(FormulaConstants.INTERNAL_DATA_NAME_RCP_FUTURE)) {
            inputData.put(FormulaConstants.INTERNAL_DATA_NAME_RCP_FUTURE, rcpServiceHelper.triggerRcpServiceCall(request));
        }

        CompletableFuture<GetItemDispositionDetailsResponse> itemDispositionDetailsResponseCompletableFuture =
                (CompletableFuture<GetItemDispositionDetailsResponse>) inputData.get(FormulaConstants.INTERNAL_DATA_NAME_RCP_FUTURE);
        GetItemDispositionDetailsResponse itemDispositionDetailsResponse =
                rcpServiceHelper.getRcpResponseFromFuture(itemDispositionDetailsResponseCompletableFuture, itemId);


        return itemDispositionDetailsResponse;
    }

}
