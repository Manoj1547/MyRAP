package com.walmartlabs.services.rdm.rank.assigner.impl;

import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.rank.assigner.RankAssigner;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.walmartlabs.services.rdm.util.PartialKeepItUtil.removePartialKeepItFromDispositionPath;

@Component("eliminatePartialKeepItFromPaths")
public class EliminatePartialKeepItFromPaths extends RankAssigner {

    /**
     * remove partial keepIt from disposition paths response
     * @param allItemsDispositionInfoList
     */
    @Override
    protected void assignRanks(List<DispositionInfo> allItemsDispositionInfoList) {
        for (DispositionInfo dispositionInfo : allItemsDispositionInfoList) {
            removePartialKeepItFromDispositionPath(dispositionInfo);
        }
    }
}
