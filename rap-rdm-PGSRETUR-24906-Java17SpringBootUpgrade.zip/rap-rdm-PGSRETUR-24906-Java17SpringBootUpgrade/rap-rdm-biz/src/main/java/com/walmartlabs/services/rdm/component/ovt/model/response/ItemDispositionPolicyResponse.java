package com.walmartlabs.services.rdm.component.ovt.model.response;

public class ItemDispositionPolicyResponse {


    private boolean RESTOCKABLE_AT_STORE;
    private boolean CVP_ELIGIBLE_AT_STORE;
    private boolean IS_CLAIMABLE;
    private boolean IS_RECALL;
    private boolean STORE_KEEP_IT;
    private double CLAIM_PERCENTAGE;
    private boolean DMB_ELIGIBLE;
    private double SUPPLIER_HANDLING_FEE;
    private String RPT_DESC;
    private boolean WALMART_DISCRETION_ALLOWED;

    public boolean isRESTOCKABLE_AT_STORE() {
        return RESTOCKABLE_AT_STORE;
    }

    public void setRESTOCKABLE_AT_STORE(boolean RESTOCKABLE_AT_STORE) {
        this.RESTOCKABLE_AT_STORE = RESTOCKABLE_AT_STORE;
    }

    public boolean isCVP_ELIGIBLE_AT_STORE() {
        return CVP_ELIGIBLE_AT_STORE;
    }

    public void setCVP_ELIGIBLE_AT_STORE(boolean CVP_ELIGIBLE_AT_STORE) {
        this.CVP_ELIGIBLE_AT_STORE = CVP_ELIGIBLE_AT_STORE;
    }

    public boolean isIS_CLAIMABLE() {
        return IS_CLAIMABLE;
    }

    public void setIS_CLAIMABLE(boolean IS_CLAIMABLE) {
        this.IS_CLAIMABLE = IS_CLAIMABLE;
    }

    public boolean isIS_RECALL() {
        return IS_RECALL;
    }

    public void setIS_RECALL(boolean IS_RECALL) {
        this.IS_RECALL = IS_RECALL;
    }

    public boolean isSTORE_KEEP_IT() {
        return STORE_KEEP_IT;
    }

    public void setSTORE_KEEP_IT(boolean STORE_KEEP_IT) {
        this.STORE_KEEP_IT = STORE_KEEP_IT;
    }

    public double getCLAIM_PERCENTAGE() {
        return CLAIM_PERCENTAGE;
    }

    public void setCLAIM_PERCENTAGE(double CLAIM_PERCENTAGE) {
        this.CLAIM_PERCENTAGE = CLAIM_PERCENTAGE;
    }

    public boolean isDMB_ELIGIBLE() {
        return DMB_ELIGIBLE;
    }

    public void setDMB_ELIGIBLE(boolean DMB_ELIGIBLE) {
        this.DMB_ELIGIBLE = DMB_ELIGIBLE;
    }

    public double getSUPPLIER_HANDLING_FEE() {
        return SUPPLIER_HANDLING_FEE;
    }

    public void setSUPPLIER_HANDLING_FEE(double SUPPLIER_HANDLING_FEE) {
        this.SUPPLIER_HANDLING_FEE = SUPPLIER_HANDLING_FEE;
    }

    public String getRPT_DESC() {
        return RPT_DESC;
    }

    public void setRPT_DESC(String RPT_DESC) {
        this.RPT_DESC = RPT_DESC;
    }

    public boolean isWALMART_DISCRETION_ALLOWED() {
        return WALMART_DISCRETION_ALLOWED;
    }

    public void setWALMART_DISCRETION_ALLOWED(boolean WALMART_DISCRETION_ALLOWED) {
        this.WALMART_DISCRETION_ALLOWED = WALMART_DISCRETION_ALLOWED;
    }
}
