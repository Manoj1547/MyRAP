package com.walmartlabs.services.rdm.component.iqs.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Product {
    @JsonProperty("product_id")
    private String productId;

    @JsonProperty("tenant_id")
    private String tenantId;

    @JsonProperty("derived_attributes")
    private DerivedAttributes derivedAttributes;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public DerivedAttributes getDerivedAttributes() {
        return derivedAttributes;
    }

    public void setDerivedAttributes(DerivedAttributes derivedAttributes) {
        this.derivedAttributes = derivedAttributes;
    }
}
