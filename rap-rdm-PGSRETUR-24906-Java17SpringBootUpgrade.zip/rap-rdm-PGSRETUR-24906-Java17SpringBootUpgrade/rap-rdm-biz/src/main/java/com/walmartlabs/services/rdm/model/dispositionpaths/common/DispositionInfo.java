package com.walmartlabs.services.rdm.model.dispositionpaths.common;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.walmart.platform.kernel.exception.error.Error;
import com.walmartlabs.services.rdm.model.Base;
import com.walmartlabs.services.rdm.model.Node;

/**
 * 
 * @author Tim Jin
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DispositionInfo extends Base {

    private BaseItem              item;
    private long                  start                 = System.currentTimeMillis();
    private long                  end;

    private KeepItDispositionInfo keepItInfo;

    @JsonIgnore
    private Node                  node;

    @JsonIgnore
    private List<VariableInfo>    variableInfos         = new ArrayList<>();

    private Integer               seqNo;

    private Error                 error;

    private Boolean               isDefault             = false;

    private List<DispositionPath> dispositionPaths      = new ArrayList<>();

    private Map<String, Object>   businessRuleVariables = new LinkedHashMap<>();

    @JsonIgnore
    private Map<String, Timing>   timing                = new ConcurrentHashMap<>();

    private String                defaultReason;

    public Boolean getDefault() {
        return isDefault;
    }

    public void setDefault(Boolean aDefault) {
        isDefault = aDefault;
    }

    public String getDefaultReason() {
        return defaultReason;
    }

    public void setDefaultReason(String defaultReason) {
        this.defaultReason = defaultReason;
    }


    public BaseItem getItem() {
        return item;
    }

    public void setItem(BaseItem item) {
        this.item = item;
    }

    public long getStart() {
        return start;
    }

    public KeepItDispositionInfo getKeepItInfo() {
        return keepItInfo;
    }

    public void setKeepItInfo(KeepItDispositionInfo keepItInfo) {
        this.keepItInfo = keepItInfo;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    public Boolean getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(Boolean isDefault) {
        this.isDefault = isDefault;
    }

    public Node getNode() {
        return node;
    }

    public void setNode(Node node) {
        this.node = node;
    }

    public Integer getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(Integer seqNo) {
        this.seqNo = seqNo;
    }

    public List<DispositionPath> getDispositionPaths() {
        return dispositionPaths;
    }

    public void setDispositionPaths(List<DispositionPath> dispositionPaths) {
        this.dispositionPaths = dispositionPaths;
    }

    public List<VariableInfo> getVariableInfos() {
        return variableInfos;
    }

    public void setVariableInfos(List<VariableInfo> variableInfos) {
        this.variableInfos = variableInfos;
    }

    public Map<String, Object> getBusinessRuleVariables() {
        return businessRuleVariables;
    }

    public void setBusinessRuleVariables(Map<String, Object> businessRuleVariables) {
        this.businessRuleVariables = businessRuleVariables;
    }

    public Map<String, Timing> getTiming() {
        return timing;
    }

    public void setTiming(Map<String, Timing> timing) {
        this.timing = timing;
    }

    public long getEnd() {
        return end;
    }

    public void setEnd(long end) {
        this.end = end;
    }

    public void setStart(long start) {
        this.start = start;
    }


    public DispositionInfo() {
    }

}
