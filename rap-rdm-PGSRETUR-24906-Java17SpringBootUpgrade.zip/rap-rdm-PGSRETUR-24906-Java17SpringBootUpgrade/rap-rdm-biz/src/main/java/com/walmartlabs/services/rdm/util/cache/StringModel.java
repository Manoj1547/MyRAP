package com.walmartlabs.services.rdm.util.cache;

import java.io.Serializable;

import io.strati.persistence.Model;

/**
 * 
 * @author Tim Jin
 *
 */
public class StringModel implements Model<String>, Serializable {

    private static final long serialVersionUID = 6688002502731041986L;

    private String            id;                                     //Primary Key

    private String            data;

    private Long              version;

    private String            lock;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public String getLock() {
        return lock;
    }

    public void setLock(String lock) {
        this.lock = lock;
    }

}