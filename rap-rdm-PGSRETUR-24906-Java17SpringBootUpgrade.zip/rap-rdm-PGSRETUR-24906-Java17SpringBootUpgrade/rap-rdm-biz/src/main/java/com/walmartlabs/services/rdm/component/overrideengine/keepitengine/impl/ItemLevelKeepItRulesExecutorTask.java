package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.impl;

import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.exception.KeepItRuleEngineException;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.executor.RdmKeepItRuleExcutorService;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitrules.AbstractRDMKeepItRule;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitrules.KeepItRulesFactory;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.config.client.ConfigManager;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.Timing;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.util.BeanHelper;
import com.walmartlabs.services.rdm.util.RDMCommonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;
import java.util.function.Function;

public class ItemLevelKeepItRulesExecutorTask {

    private static final Logger LOG = LoggerFactory.getLogger(ItemLevelKeepItRulesExecutorTask.class);

    KeepItRuleEngineContext keepItRuleEngineContext;

    public ItemLevelKeepItRulesExecutorTask(KeepItRuleEngineContext keepItRuleEngineContext){
        this.keepItRuleEngineContext = keepItRuleEngineContext;
    }

    public void excuteTask(){

        List<AbstractRDMKeepItRule> allKeepItRules = KeepItRulesFactory.getAllKeepItRules(keepItRuleEngineContext);

        runRulesParallel(allKeepItRules);

    }

    private void runRulesParallel(List<AbstractRDMKeepItRule> allKeepItRules) {

        RdmKeepItRuleExcutorService rdmKeepItRuleExcutorService = BeanHelper.getBean(RdmKeepItRuleExcutorService.class);
        ExecutorService executor = rdmKeepItRuleExcutorService.getExecutor();

        Map<AbstractRDMKeepItRule, Future<Boolean>> rulesResponseFutureList = new HashMap<>();
        Function<AbstractRDMKeepItRule, Boolean> keepItRuleRunnerFunction = rdmKeepItRule -> rdmKeepItRule.runRule(keepItRuleEngineContext);

        for (AbstractRDMKeepItRule keepItRule : allKeepItRules) {
            Future<Boolean> ruleResponseFuture = executor.submit(() -> keepItRuleRunnerFunction.apply(keepItRule));
            rulesResponseFutureList.put(keepItRule, ruleResponseFuture);
        }

        RDMCommonUtils rdmCommonUtils = BeanHelper.getBean(RDMCommonUtils.class);
        RDMKeepItConfig rdmKeepItConfig = ConfigManager.getRdmKeepItConfig();

        for (AbstractRDMKeepItRule keepItRule : allKeepItRules) {
            Future<Boolean> ruleResponseFuture = rulesResponseFutureList.get(keepItRule);
            try {
                Boolean ruleOutput = ruleResponseFuture.get(rdmKeepItConfig.getKeepItRuleExecutionMaxWaitTime(), TimeUnit.MILLISECONDS);
                if (ruleOutput == true) {
                    long startTime = System.currentTimeMillis();

                    keepItRule.applyRuleDecision(keepItRuleEngineContext);

                    rdmCommonUtils.timingProxy(RDMConstants.KEEP_IT_RULE_APPLY_DECISION + keepItRule.getRuleName(),
                            keepItRuleEngineContext.getDispositionInfo().getTiming(), Timing.Type.KEEPIT_RULE, startTime);
                    break;
                }
            } catch (TimeoutException e) {
                String errorMsg = "Timeout exception in keepIt rule engine execution, ";
                LOG.error(errorMsg, e);
                throw new KeepItRuleEngineException(ApplicationLayer.BUSINESS_LAYER,
                        ErrorCodeMapping.KEEP_IT_RULE_ENGINE_EXECUTION_FAILED, errorMsg, e);
            } catch (InterruptedException e) {
                String errorMsg = "Interrupted exception in keepIt rule engine execution, ";
                LOG.error(errorMsg + e.getMessage(), e);
                throw new KeepItRuleEngineException(ApplicationLayer.BUSINESS_LAYER,
                        ErrorCodeMapping.KEEP_IT_RULE_ENGINE_EXECUTION_FAILED, errorMsg, e);
            } catch (ExecutionException e) {
                String errorMsg = "Execution exception in keepIt rule engine execution, ";
                LOG.error(errorMsg + e.getMessage(), e);
                throw new KeepItRuleEngineException(ApplicationLayer.BUSINESS_LAYER,
                        ErrorCodeMapping.KEEP_IT_RULE_ENGINE_EXECUTION_FAILED, errorMsg, e);
            }
        }


    }

}
