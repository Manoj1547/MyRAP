package com.walmartlabs.services.rdm.component.rcp.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetItemDispositionDetailsResponse {
    @JsonProperty("RESTOCKABLE_AT_STORE")
    private Boolean        restockableAtStore;

    @JsonProperty("CVP_ELIGIBLE_AT_STORE")
    private Boolean        cvpEligibleAtStore;

    @JsonProperty("IS_CLAIMABLE")
    private Boolean        isClaimable;

    @JsonProperty("IS_RECALL")
    private Boolean        isRecall;

    @JsonProperty("STORE_KEEP_IT")
    private Boolean        storeKeepIt;

    @JsonProperty("CLAIM_PERCENTAGE")
    private Float          claimPercentage     = 0f;

    @JsonProperty("DMB_ELIGIBLE")
    private Boolean        dmbEligible         = false;

    @JsonProperty("SUPPLIER_HANDLING_FEE")
    private Float          supplierHandlingFee = 0f;
    
    @JsonProperty("RPT_DESC")
    private String          rptDesc;
    
    @JsonProperty("entityErrors")
    private List<RDMError> entityErrorList;

    @JsonProperty("DISPOSITION_DISCRETION_ALLOWED")
    private Boolean dispositionDiscretionAllowed;

    public Boolean getDispositionDiscretionAllowed() {
        return dispositionDiscretionAllowed;
    }

    public void setDispositionDiscretionAllowed(Boolean dispositionDiscretionAllowed) {
        this.dispositionDiscretionAllowed = dispositionDiscretionAllowed;
    }

    public Boolean getRestockableAtStore() {
        return restockableAtStore;
    }

    public void setRestockableAtStore(Boolean restockableAtStore) {
        this.restockableAtStore = restockableAtStore;
    }

    public Boolean getCvpEligibleAtStore() {
        return cvpEligibleAtStore;
    }

    public void setCvpEligibleAtStore(Boolean cvpEligibleAtStore) {
        this.cvpEligibleAtStore = cvpEligibleAtStore;
    }

    public Boolean getIsClaimable() {
        return isClaimable;
    }

    public void setIsClaimable(Boolean claimable) {
        isClaimable = claimable;
    }

    public Boolean getIsRecall() {
        return isRecall;
    }

    public void setIsRecall(Boolean recall) {
        isRecall = recall;
    }

    public Boolean getStoreKeepIt() {
        return storeKeepIt;
    }

    public void setStoreKeepIt(Boolean storeKeepIt) {
        this.storeKeepIt = storeKeepIt;
    }

    public Float getClaimPercentage() {
        return claimPercentage;
    }

    public void setClaimPercentage(Float claimPercentage) {
        this.claimPercentage = claimPercentage;
    }

    public Boolean getDmbEligible() {
        return dmbEligible;
    }

    public void setDmbEligible(Boolean dmbEligible) {
        this.dmbEligible = dmbEligible;
    }

    public Float getSupplierHandlingFee() {
        return supplierHandlingFee;
    }

    public void setSupplierHandlingFee(int supplierHandlingFee) {
        this.supplierHandlingFee = supplierHandlingFee / 100f;
    }

    public String getRptDesc() {
        return rptDesc;
    }

    public void setRptDesc(String rptDesc) {
        this.rptDesc = rptDesc;
    }

    public void setSupplierHandlingFee(Float supplierHandlingFee) {
        this.supplierHandlingFee = supplierHandlingFee;
    }

    public List<RDMError> getEntityErrorList() {
        return entityErrorList;
    }

    public void setEntityErrorList(List<RDMError> entityErrorList) {
        this.entityErrorList = entityErrorList;
    }
}
