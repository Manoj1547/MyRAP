package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.model.DamagedItemKeepItRuleCategoryThreshold;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

import static com.walmartlabs.services.rdm.RDMConstants.NAME;
import static com.walmartlabs.services.rdm.RDMConstants.RULE_CHECK_NAME_DAMAGED_ITEM_QUANTITY;

@Component("damagedItemQtyCheck")
public class DamagedItemQtyCheck implements IRDMKeepItRuleCheck{

    private static final Logger LOG = LoggerFactory.getLogger(DamagedItemQtyCheck.class);

    @Autowired
    RDMKeepItUtil rdmKeepItUtil;

    public void setRdmKeepItUtil(RDMKeepItUtil rdmKeepItUtil) {
        this.rdmKeepItUtil = rdmKeepItUtil;
    }

    @Override
    public String getKeepItCheckName() {
        return RULE_CHECK_NAME_DAMAGED_ITEM_QUANTITY;
    }

    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {

        Map<String, Map<String, DamagedItemKeepItRuleCategoryThreshold>> divisionCategoryThresholdMap = rdmKeepItUtil.getDamagedItemDivisionCategoryThresholdMap();
        Map<String, Map<String, String>> pathMap = rdmKeepItUtil.getDerivedAttributePathMap(keepItRuleEngineContext);

        for (Map.Entry<String, Map<String, DamagedItemKeepItRuleCategoryThreshold>> divisionEntry : divisionCategoryThresholdMap.entrySet()) {
            String divisionName = divisionEntry.getKey();
            Map<String, DamagedItemKeepItRuleCategoryThreshold> categoryThresholdMap = divisionEntry.getValue();

            Map<String, String> categoryMap = pathMap.get(divisionName);

            if (categoryMap != null && categoryThresholdMap.containsKey(categoryMap.get(NAME))) {
                LOG.info("DamagedItemQtyCheck :: quantity threshold is {}, for category {}", categoryThresholdMap.get(categoryMap.get(NAME)).getQuantity(), categoryMap.get(NAME));
                return rdmKeepItUtil.isItemCountEligibleForKeepIt(categoryThresholdMap.get(categoryMap.get(NAME)).getQuantity(),
                        Integer.valueOf(keepItRuleEngineContext.getItem().getQuantity().getMeasurementValue()));
            }
        }
        LOG.info("DamagedItemQtyCheck :: quantity threshold not found or not enabled");
        return false;

    }
}
