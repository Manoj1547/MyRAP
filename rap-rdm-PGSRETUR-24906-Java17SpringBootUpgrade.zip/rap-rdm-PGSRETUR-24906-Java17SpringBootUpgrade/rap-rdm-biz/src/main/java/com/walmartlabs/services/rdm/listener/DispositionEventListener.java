package com.walmartlabs.services.rdm.listener;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import com.walmartlabs.services.rdm.domain.model.FinalDispositionDO;
import com.walmartlabs.services.rdm.domain.persistence.DataPersistenceManager;
import com.walmartlabs.services.rdm.domain.persistence.FinalDispositionPersistenceManager;
import com.walmartlabs.services.rdm.model.dispositionevent.DispositionEvent;

import io.strati.configuration.annotation.ManagedConfiguration;
import org.apache.commons.lang.BooleanUtils;

/**
 * 
 * @author Tim Jin
 *
 */
@Component("DispositionEventListener")
public class DispositionEventListener {

    private static final Logger        LOG = LoggerFactory.getLogger(DispositionEventListener.class);

    private ObjectReader               reader;

    @Resource
    FinalDispositionPersistenceManager persistenceManager;

    @Resource
    DataPersistenceManager             dataPersistenceManager;

    @ManagedConfiguration
    RDMSwitches                        switches;

    @PostConstruct
    public void init() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.setSerializationInclusion(Include.NON_NULL);

        this.reader = mapper.readerFor(DispositionEvent.class);
    }

    public void process(String message) {
        try{
            if(BooleanUtils.isTrue(switches.getKafkaConsumerRoLogEntry())) LOG.info("Disposition event: {}", message);
            DispositionEvent event = reader.readValue(message, DispositionEvent.class);
            Objects.requireNonNull(event, "Disposition event is null.");

            if(isRDMApplicable(event)){
                LOG.info("Final Disposition event applicable");
                FinalDispositionDO finalDispositionDO = new FinalDispositionDO();

                finalDispositionDO.setFinalDispositionPath(mapFinalDisposition(event.getFinalDisposition().getCode()));
                finalDispositionDO.setSmartLabelId(event.getSmartLabelId());
                finalDispositionDO.setStoreId(event.getStoreId());
                finalDispositionDO.setChannelName("CLAIMS");

                persistenceManager.save(finalDispositionDO);
                LOG.info("Final Disposition saved in DB: {}", finalDispositionDO);
            }
        }catch (Exception e){
            LOG.error("Failed to process:{}, Msg:{}", e.getMessage(), message, e);
        }
    }

    private String mapFinalDisposition(String code) {
        Map<String, String> mapping = new HashMap<>();
        String[] mappings = StringUtils.split(switches.getKafkaConsumerDispositionCodeMapping(), ",");
        if(mappings != null) for(String map : mappings){
            String[] pair = StringUtils.split(map, ":");
            if(pair != null && pair.length == 2){
                mapping.put(pair[0], pair[1]);
            }
        }

        return mapping.getOrDefault(code, code);
    }

    private boolean isRDMApplicable(DispositionEvent event) {
        if(event.getFinalDisposition() == null || StringUtils.isBlank(event.getFinalDisposition().getCode())) return false;

        if(BooleanUtils.isNotTrue(event.getRdmFinancialFlowEnabled())) return false;

        double value = 0;
        if(event.getRdmDisposeNoHazValue() != null) value += event.getRdmDisposeNoHazValue();
        if(event.getRdmDonateValue() != null) value += event.getRdmDonateValue();
        if(event.getRdmLiquidateBlendValue() != null) value += event.getRdmLiquidateBlendValue();
        if(event.getRdmSellInStoreValue() != null) value += event.getRdmSellInStoreValue();

        if(value == 0) return false;

        if(BooleanUtils.isTrue(switches.getKafkaConsumerDispositionMatchSmartLabelId())){
            long count = dataPersistenceManager.searchTransactionBySmartLabelId(event.getSmartLabelId());
            if(count == 0) return false;
        }
        return true;
    }

}
