package com.walmartlabs.services.rdm.component.apollorestock.restockrules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibilityContext;
import com.walmartlabs.services.rdm.config.client.ConfigManager;
import com.walmartlabs.services.rdm.config.client.RestockEligibilityConfig;

import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import static com.walmartlabs.services.rdm.formula.FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM;

@Component("itemConditionPristinRule")
public class ItemConditionPristinRule extends AbstractRestockRule {

    @Override
    public String getRuleName() {
        String ruleName = RDMConstants.RULE_ITEM_CONDITION_PRISTINE;
        return ruleName;
    }

    @Override
    public boolean runRule(RestockEligibilityContext restockEligibilityContext) {

        BaseItem item = (BaseItem) restockEligibilityContext.getInputData().get(INTERNAL_DATA_NAME_REQUEST_ITEM);
        String itemCondition = item.getItemCondition();
        RestockEligibilityConfig restockEligibilityConfig = ConfigManager.getRestockEligibilityConfig();


        boolean isItemConditionPristine = false;
        if(!StringUtils.isEmpty(itemCondition) && restockEligibilityConfig.getItemConditionsPristine().contains(itemCondition)){
            isItemConditionPristine = true;
        }
        return isItemConditionPristine;
    }

}
