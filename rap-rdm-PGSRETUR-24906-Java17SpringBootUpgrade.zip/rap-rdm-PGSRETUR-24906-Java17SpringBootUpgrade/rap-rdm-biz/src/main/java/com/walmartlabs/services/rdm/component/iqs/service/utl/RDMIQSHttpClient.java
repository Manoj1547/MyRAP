package com.walmartlabs.services.rdm.component.iqs.service.utl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.txnmarking.impl.NullTransactionImpl;
import com.walmart.platform.txnmarking.impl.TransactionImpl;
import com.walmartlabs.services.rdm.component.iqs.model.request.ItemRDMRequest;
import com.walmartlabs.services.rdm.component.iqs.model.response.iqs.IQSRDMResponse;
import com.walmartlabs.services.rdm.config.client.IQSServiceConfig;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import com.walmartlabs.services.rdm.util.BaseHTTPClient;
import com.walmartlabs.services.rdm.util.HeaderElements;
import io.strati.StratiServiceProvider;
import io.strati.configuration.annotation.ManagedConfiguration;
import io.strati.txnmarking.TransactionMarkingService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.ws.rs.core.MediaType;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;


@Component
public class RDMIQSHttpClient extends BaseHTTPClient {

    private static final Logger LOG = LoggerFactory.getLogger(RDMIQSHttpClient.class);

    public static final String APP_NAME = "apqName";
    public static final String APP_NAME_VALUE = "RDM_SIOfferProduct";
    public final String METHOD_NAME_GET_RDM_ITEM_DETAILS = "getRDMItemDetails";

    private TransactionMarkingService TMS;
    private ObjectMapper objectMapper;

    @Resource
    @ManagedConfiguration
    private IQSServiceConfig iqsServiceConfig;

    private RDMIQSHttpClient() {
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        TMS = StratiServiceProvider.getInstance().getTransactionMarkingService().get();
    }


    public IQSRDMResponse getRDMItemDetails(ItemRDMRequest request) {
        if(iqsServiceConfig.getMockRdmIqsServiceEnabled()){
            LOG.info("Mock enabled for RDM IQS Service");
            IQSRDMResponse iqsrdmResponse = null;
            String mockedResponseString = iqsServiceConfig.getMockedRdmIqsServiceResponse();
            try {
                iqsrdmResponse = objectMapper.readValue(mockedResponseString, IQSRDMResponse.class);
            } catch (JsonProcessingException e) {
                LOG.error("RDM IQS mock service response mapping failed" , e);
                throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, "RDM IQS Service Failed", e);
            }

            return iqsrdmResponse;
        }

        TransactionImpl top;
        if (TMS.currentTransaction() instanceof NullTransactionImpl) {
            top = (TransactionImpl) TMS.topTransaction(METHOD_NAME_GET_RDM_ITEM_DETAILS, METHOD_NAME_GET_RDM_ITEM_DETAILS);
        } else {
            top = (TransactionImpl) TMS.transaction(METHOD_NAME_GET_RDM_ITEM_DETAILS, METHOD_NAME_GET_RDM_ITEM_DETAILS);
        }
        String baseUrl = iqsServiceConfig.getIqsGraphqlServiceBaseUrl();
        String serviceUrl = iqsServiceConfig.getRdmIQSServiceUrl();
        int apiTimeout = iqsServiceConfig.getRdmIQSApiTimeout();
        Map<String, String> queryParams = prepareQueryParams();
        Map<String,String> headers = prepareHeaders();
        IQSRDMResponse response = null;
        top.start();
        try {
            LOG.info("Invoking IQS service URL:{}{}, query params: {} for request:{}", baseUrl, serviceUrl, queryParams, request.getKey());
            String requestPayload = objectMapper.writeValueAsString(request);
            response = this.post(baseUrl, serviceUrl, requestPayload, headers, apiTimeout, queryParams, IQSRDMResponse.class);
            LOG.info("Response from IQS Service: {}", response);
            top.end();
        } catch (JsonProcessingException | ServiceException e) {
            String errorMsg = MessageFormat.format("IQS service exception for request : {0} ", request.getKey());
            LOG.error(errorMsg, e);
            top.logException(e);
            top.endWithFailure(e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        }
        return response;

    }


    private Map<String, String> prepareHeaders() {
        HashMap<String, String> headers = new HashMap<>();
        addHeaderParam(headers, HeaderElements.SERVICE_VERSION, iqsServiceConfig.getServiceVersion());
        addHeaderParam(headers, HeaderElements.SERVICE_ENV, iqsServiceConfig.getServiceEnv());
        addHeaderParam(headers, HeaderElements.SERVICE_NAME, iqsServiceConfig.getServiceName());
        addHeaderParam(headers, HeaderElements.CONSUMER_ID, iqsServiceConfig.getRdmIQSConsumerId());
        addHeaderParam(headers, HeaderElements.CORRELATION_ID, iqsServiceConfig.getRdmIQSCorrelationId());
        addHeaderParam(headers, HeaderElements.CONSUMER_TENANT_ID, iqsServiceConfig.getTenantId());
        addHeaderParam(headers, HeaderElements.CONTENT_TYPE, iqsServiceConfig.getContentType());
        addHeaderParam(headers, HeaderElements.ACCEPT, MediaType.APPLICATION_JSON);
        return headers;
    }

    private Map<String , String> prepareQueryParams() {
        HashMap<String, String> params = new HashMap<>();
        params.put(APP_NAME, APP_NAME_VALUE);
        return  params ;
    }


    private void addHeaderParam(HashMap<String, String> headers, String name, String value) {
        if (StringUtils.isNotBlank(value))
            headers.put(name, value);
    }

}
