package com.walmartlabs.services.rdm.formula.impl.java;

import java.text.MessageFormat;
import java.util.Map;
import java.util.concurrent.CompletableFuture;


import com.walmartlabs.services.rdm.component.pos.POSServiceHelper;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.util.RDMCommonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.FormulaException;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.Formula;

import org.apache.commons.lang.StringUtils;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public class POSDeptDataResolver implements JavaEngineClass {

    private static final Logger LOG = LoggerFactory.getLogger(POSDeptDataResolver.class);

    private ObjectReader        reader;

    @Autowired
    POSServiceHelper posServiceHelper;

    POSDeptDataResolver() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        reader = mapper.reader();
    }

    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        BaseItem item = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);
        String r2d2 = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.VARIABLE_R2D2);
        String storeId = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_STORE_ID);
        String offerType = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.VARIABLE_OFFERTYPE);

        String l1Id = getL1IdFromR2D2(r2d2, item);



        if(!inputData.containsKey(FormulaConstants.INTERNAL_DATA_NAME_POS_DEPT_DATA_FUTURE)) {
            inputData.put(FormulaConstants.INTERNAL_DATA_NAME_POS_DEPT_DATA_FUTURE,
                    posServiceHelper.triggerPosDeptDataServiceCall(l1Id, storeId, StringUtils.contains(offerType, "SHARED")));
        }

        /**
         If service is called as part of preCall then,
         No need to wait for response at this point, return from here
         */
        if(RDMCommonUtils.isExternalServicePreCall(formula, inputData)){
            return null;
        }

        CompletableFuture<String> posDeptResponseFuture = (CompletableFuture<String>) inputData.get(FormulaConstants.INTERNAL_DATA_NAME_POS_DEPT_DATA_FUTURE);
        String posDeptServiceResponse = posServiceHelper.getPosItemDataResponseFromFuture(posDeptResponseFuture, item);

        return  posDeptServiceResponse;

    }

    private String getL1IdFromR2D2(String r2d2, BaseItem item) {
        String l1Id = null;
        try{
            JsonNode tree = reader.readTree(r2d2);
            if(tree != null && tree.has("L1")){
                JsonNode l1 = tree.get("L1");
                if(l1 != null && l1.has("name")){
                    l1Id = l1.get("id").asText();
                }
            }
        }catch (JsonProcessingException e){
            LOG.error("POSDeptDataResolver JsonParsingException for r2d2, gtin {}, offerId {}, r2d2 {}",
                    item.getGtin(),item.getOfferId(), r2d2,e);
        }
        if(l1Id == null) {
            String errorMsg = MessageFormat.format("POSDeptData fetch failed, " +
                    "{0}(={1}) is invalid for offerId {2}.", FormulaConstants.VARIABLE_R2D2, r2d2, item.getOfferId());
            throw new FormulaException(errorMsg);
        }
        return l1Id;
    }

}
