package com.walmartlabs.services.rdm.api;

import java.util.List;

import com.walmartlabs.services.rdm.model.dispositionpaths.DispositionPathsRequest;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPathResult;
import com.walmartlabs.services.rdm.model.dispositionpaths.simulation.Item;

/**
 * 
 * @author Tim Jin
 *
 */
public interface RDMManager {

    public DispositionPathResult getPaths(DispositionPathsRequest dispositionPathsRequest, Boolean test);

    public List<DispositionInfo> getSimulation(List<Item> items, Boolean debug);

}
