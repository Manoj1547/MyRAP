package com.walmartlabs.services.rdm.component.ovt.model.request;

import java.math.BigDecimal;

public class ItemPrice{
    public BigDecimal currencyAmount;
    public String currencyUnit;

    public BigDecimal getCurrencyAmount() {
        return currencyAmount;
    }

    public void setCurrencyAmount(BigDecimal currencyAmount) {
        this.currencyAmount = currencyAmount;
    }

    public String getCurrencyUnit() {
        return currencyUnit;
    }

    public void setCurrencyUnit(String currencyUnit) {
        this.currencyUnit = currencyUnit;
    }
}
