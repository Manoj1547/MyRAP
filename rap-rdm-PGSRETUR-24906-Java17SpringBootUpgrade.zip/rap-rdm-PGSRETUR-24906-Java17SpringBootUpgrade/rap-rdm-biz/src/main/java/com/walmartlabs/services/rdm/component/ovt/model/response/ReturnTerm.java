package com.walmartlabs.services.rdm.component.ovt.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class ReturnTerm {

    @JsonProperty("vendorNo")
    private String vendorNo;

    @JsonProperty("departmentNo")
    private String departmentNo;

    @JsonProperty("contractNo")
    private String contractNo;

    @JsonProperty("tenantId")
    private String tenantId;

    @JsonProperty("region")
    private String region;

    @JsonProperty("returnTermType")
    private String returnTermType;

    @JsonProperty("agreementStatus")
    private String agreementStatus;

    @JsonProperty("returnTermPolicies")
    private List<ReturnTermPolicy> returnTermPolicies;


    public String getVendorNo() {
        return vendorNo;
    }

    public void setVendorNo(String vendorNo) {
        this.vendorNo = vendorNo;
    }

    public String getDepartmentNo() {
        return departmentNo;
    }

    public void setDepartmentNo(String departmentNo) {
        this.departmentNo = departmentNo;
    }

    public String getContractNo() {
        return contractNo;
    }

    public void setContractNo(String contractNo) {
        this.contractNo = contractNo;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getReturnTermType() {
        return returnTermType;
    }

    public void setReturnTermType(String returnTermType) {
        this.returnTermType = returnTermType;
    }

    public String getAgreementStatus() {
        return agreementStatus;
    }

    public void setAgreementStatus(String agreementStatus) {
        this.agreementStatus = agreementStatus;
    }

    public List<ReturnTermPolicy> getReturnTermPolicies() {
        return returnTermPolicies;
    }

    public void setReturnTermPolicies(List<ReturnTermPolicy> returnTermPolicies) {
        this.returnTermPolicies = returnTermPolicies;
    }


}
