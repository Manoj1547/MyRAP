package com.walmartlabs.services.rdm.component.iqs.service.utl;

import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmartlabs.services.rdm.component.iqs.model.request.GetItemDetailsRequest;
import com.walmartlabs.services.rdm.component.iqs.model.response.GetItemDetailsResponse;
import com.walmartlabs.services.rdm.config.client.IQSServiceConfig;
import com.walmartlabs.services.rdm.formula.impl.java.iqs.service.IQSRDMService;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.text.MessageFormat;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import static com.walmartlabs.services.rdm.executors.RdmExecutorService.getExecutor;

@Component
public class IQSServiceHelper {
    private static final Logger LOG = LoggerFactory.getLogger(IQSServiceHelper.class);

    @Resource
    @ManagedConfiguration
    private IQSServiceConfig iqsServiceConfig;

    @Autowired
    private IQSRDMService iqsRdmService;

    @Resource
    IQSHttpClient iqsClient;


    public GetItemDetailsResponse getIqsRdmResponseFromFuture(CompletableFuture<GetItemDetailsResponse> getItemDetailsResponseCompletableFuture, BaseItem item){
        GetItemDetailsResponse getItemDetailsResponse = null;

        try {
            getItemDetailsResponse = getItemDetailsResponseCompletableFuture.get(iqsServiceConfig.getIqsRdmServiceApiTimeout(), TimeUnit.MILLISECONDS);;
        } catch (InterruptedException | TimeoutException | ExecutionException e) {
            String errorMsg =  MessageFormat.format("IQS rdm response fetch failed, gtin {0} , offerId {1}, error {2}",
                               item.getGtin(), item.getOfferId(), e.getMessage());
            LOG.error(errorMsg, e);

            //In Case of RDM exception throw same exception otherwise wrap the exception in rdm exception
            if(e.getCause() instanceof RDMException){
                throw (RDMException) e.getCause();
            } else{
                throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
            }
        }
        return getItemDetailsResponse;
    }


    public CompletableFuture<GetItemDetailsResponse> triggerRdmIqsServiceCall(BaseItem item) {
        //get itemDetailsResponseFuture from inputData
        CompletableFuture<GetItemDetailsResponse> itemDetailsResponseFuture = CompletableFuture.supplyAsync(() -> iqsRdmService.getIQSRdmItemDetails(item), getExecutor());
        return itemDetailsResponseFuture;
    }

    public CompletableFuture<GetItemDetailsResponse> triggerIqsServiceCall(BaseItem item) {
        GetItemDetailsRequest iqsr = new GetItemDetailsRequest();
        iqsr.setId(item.getGtin());
        CompletableFuture<GetItemDetailsResponse> itemDetailsResponseFuture = CompletableFuture.supplyAsync(() -> iqsClient.getItemDetails(iqsr),getExecutor());
        return itemDetailsResponseFuture;
    }

    public GetItemDetailsResponse getIqsResponseFromFuture(CompletableFuture<GetItemDetailsResponse> itemDetailsResponseFuture, BaseItem item) {
        GetItemDetailsResponse getItemDetailsResponse = null;

        try {
            getItemDetailsResponse = itemDetailsResponseFuture.get(iqsServiceConfig.getIqsRdmServiceApiTimeout(), TimeUnit.MILLISECONDS);;
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            String errorMsg =  MessageFormat.format("IQS response fetch failed, gtin {0} , offerId {1}, error {2}",
                    item.getGtin(), item.getOfferId(), e.getMessage());
            LOG.error(errorMsg, e);

            //In Case of RDM exception throw same exception otherwise wrap the exception in rdm exception
            if(e.getCause() instanceof RDMException){
                throw (RDMException) e.getCause();
            } else{
                throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
            }
        }

        return getItemDetailsResponse;
    }
}
