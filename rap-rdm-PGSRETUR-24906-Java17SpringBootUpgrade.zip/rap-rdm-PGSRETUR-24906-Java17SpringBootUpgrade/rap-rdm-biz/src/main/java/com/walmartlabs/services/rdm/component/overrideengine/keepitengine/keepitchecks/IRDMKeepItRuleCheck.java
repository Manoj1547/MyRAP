package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;

public interface IRDMKeepItRuleCheck {

     String getKeepItCheckName();

     boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext);
}
