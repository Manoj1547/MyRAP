package com.walmartlabs.services.rdm.component.dsim.model.config.summary.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/***
 *
 * {
 *   "markdownAllowed": false,
 *   "priceOverride": false,
 *   "markDownAllowedAtThisTime": true
 * }
 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MarkDownConfigResponse {
    @JsonProperty("markdownAllowed")
    private Boolean markdownAllowed;
    @JsonProperty("priceOverride")
    private Boolean priceOverride;
    @JsonProperty("markDownAllowedAtThisTime")
    private Boolean markDownAllowedAtThisTime;

    public Boolean getMarkdownAllowed() {
        return markdownAllowed;
    }

    public void setMarkdownAllowed(Boolean markdownAllowed) {
        this.markdownAllowed = markdownAllowed;
    }

    public Boolean getPriceOverride() {
        return priceOverride;
    }

    public void setPriceOverride(Boolean priceOverride) {
        this.priceOverride = priceOverride;
    }

    public Boolean getMarkDownAllowedAtThisTime() {
        return markDownAllowedAtThisTime;
    }

    public void setMarkDownAllowedAtThisTime(Boolean markDownAllowedAtThisTime) {
        this.markDownAllowedAtThisTime = markDownAllowedAtThisTime;
    }

    @Override
    public String toString() {
        return "MarkDownConfigResponse{" +
                "markdownAllowed=" + markdownAllowed +
                ", priceOverride=" + priceOverride +
                ", markDownAllowedAtThisTime=" + markDownAllowedAtThisTime +
                '}';
    }
}
