package com.walmartlabs.services.rdm.util;

import com.walmart.platform.txnmarking.impl.NullTransactionImpl;
import com.walmart.platform.txnmarking.impl.TransactionImpl;
import io.strati.txnmarking.Transaction;
import io.strati.txnmarking.TransactionMarkingService;
import org.springframework.stereotype.Component;

/**
 * 
 * @author Tim Jin
 *
 */

@Component
public class TransactionUtil {

    public static Transaction getTransaction(TransactionMarkingService TMS, String name) {
        if(TMS.currentTransaction() instanceof NullTransactionImpl){
            return TMS.topTransaction(name, name);
        }else{
            return (TransactionImpl) TMS.transaction(name, name);
        }
    }
}
