package com.walmartlabs.services.rdm.api.impl;

import com.walmart.platform.kernel.exception.error.Error;
import com.walmartlabs.services.rdm.RDMUtils;
import com.walmartlabs.services.rdm.api.KafkaPublisher;
import com.walmartlabs.services.rdm.api.RDMManager;
import com.walmartlabs.services.rdm.component.incentiveruleengine.util.RdmIncentiveUtil;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.impl.RDMKeepitRuleEngine;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.config.client.ConfigManager;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import com.walmartlabs.services.rdm.config.client.ReturnIncentiveConfig;
import com.walmartlabs.services.rdm.domain.model.TransactionDO;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaService;
import com.walmartlabs.services.rdm.formula.Session;
import com.walmartlabs.services.rdm.mapper.ModelMapper;
import com.walmartlabs.services.rdm.model.SellerType;
import com.walmartlabs.services.rdm.model.dispositionevent.RDMTransactionDumpEvent;
import com.walmartlabs.services.rdm.model.dispositionpaths.DispositionPathsRequest;
import com.walmartlabs.services.rdm.model.dispositionpaths.Item;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPathResult;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.KeepItDispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.KeepItInfo;
import com.walmartlabs.services.rdm.rank.assigner.RankAssignerChain;
import com.walmartlabs.services.rdm.util.RDMCommonUtils;
import com.walmartlabs.services.rdm.util.RDMManagerUtil;
import com.walmartlabs.services.rdm.util.RdmUtils;
import io.strati.StratiServiceProvider;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.apache.commons.lang.BooleanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.annotation.Resource;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import static com.walmartlabs.services.rdm.util.PartialKeepItUtil.populatePartialKeepItEligibility;

/**
 * @author Tim Jin
 */
@Service
public class RDMManagerImpl implements RDMManager {

    private static final Logger LOG = LoggerFactory.getLogger(RDMManager.class);

    @Resource
    FormulaService formulaService;

    @Resource
    ModelMapper mapper;

    @ManagedConfiguration
    RDMSwitches rdmSwitches;

    @ManagedConfiguration
    ReturnIncentiveConfig returnIncentiveConfig;

    @Resource
    RDMUtils util;

    @Resource
    RDMManagerUtil rdmManagerUtil;

    @Autowired
    RDMCommonUtils rdmCommonUtils;

    @Autowired
    RDMKeepItUtil rdmKeepItUtil;

    @Autowired
    RDMKeepitRuleEngine rdmKeepitRuleEngine;

    @Autowired
    RdmIncentiveUtil rdmIncentiveUtil;

    @Override
    public DispositionPathResult getPaths(DispositionPathsRequest request, Boolean test) {
        List<Item> items = request.getItems();
        String channel = request.getChannelInfo().getChannelName();
        RDMKeepItConfig rdmKeepItConfig = ConfigManager.getRdmKeepItConfig();
        String storeId = request.getChannelInfo() != null ? request.getChannelInfo().getStoreId() : null;
        items.forEach(item -> {
            item.setChannelName(channel);
            item.setStoreId(storeId);
            item.setOrderNo(request.getOrderNo());
            item.setCustomerId(request.getCustomerId());
            item.setWalmartPlusCustomer(request.isWalmartPlusCustomer());
            item.setTrustCustomerToIncentive(request.isTrustCustomerToIncentive());
            item.setRdmApiCallerName(request.getRdmCallerApiName());
            // setting GEP flag and country code at item level to check the ruleEngine
            if (rdmKeepItConfig.getGepPilotEnabled() && request.isGep() && request.getCountryCode() != null){
                item.setGep(request.isGep());
                item.setCountryCode(request.getCountryCode());
            }
        });


        List<DispositionInfo> infoList = calculatePaths(items, keepIt -> mapper.clone(keepIt, false), false);
        Date time = new Date();
        if (!rdmSwitches.getCallDBAsync()) {
            /*
              Insert into  DB
             */
            TransactionDO transactionDO = rdmManagerUtil.convertToTransactionDO(request);
            rdmManagerUtil.populateResponseInTransactionDOO(transactionDO, infoList);
            boolean hasError = infoList.stream().anyMatch(info -> info.getError() != null);
            time = rdmManagerUtil.saveTransaction(request, test, transactionDO, hasError);
        } else if (rdmSwitches.getEnablePublishTransactionDump()) {
            /*
              Insert In Kafka
             */
//            RDMTransactionDumpEvent rdmTransactionDumpEvent = new RDMTransactionDumpEvent(request, infoList, Boolean.TRUE.equals(test), false);
//            publisher.publishToRDMTxnDump(rdmTransactionDumpEvent, null);
        }
        DispositionPathResult result = new DispositionPathResult();
        result.setDate(time);
        result.setDispositionInfos(infoList);
        result.setItems(items);
        return result;
    }

    @Override
    public List<DispositionInfo> getSimulation(List<com.walmartlabs.services.rdm.model.dispositionpaths.simulation.Item> item, Boolean debug) {
        return calculatePaths(item, keepIt -> mapper.clone(keepIt, true), debug);
    }

    private List<DispositionInfo> calculatePaths(List<? extends BaseItem> items, Function<KeepItInfo, KeepItDispositionInfo> getKeepItInfo, Boolean debug) {
        DispositionInfo[] infoArray = new DispositionInfo[items.size()];

        items.forEach(item -> {
            if (!util.getUomEachAllPossibilites().contains(item.getQuantity().getUnitOfMeasure())) {
                /*
                  If UnitOfMeasure is not 'EA','ea','EACH','each' then consider Qty as 1 and
                  compute rdm recovery values.
                  For more info, refer product spreadsheet

                  In the end, set originalQty in response.
                 */
                String originalQty = item.getQuantity().getMeasurementValue();
                item.getQuantity().setMeasurementValue("1");
                item.getQuantity().setMeasurementValueOriginal(originalQty);
            }
        });

        ConcurrentHashMap<String, Object> shared = new ConcurrentHashMap<>();

        Map<String, Map<String, Object>> itemIdVsOutputSessionDataMap = new HashMap<>();

        //TODO Create a common pool of threads
        ExecutorService ex = Executors.newFixedThreadPool(Math.min(items.size(), rdmSwitches.getMultiitemsMaxThreads()));
        try {
            for (int i = 0; i < items.size(); i++) {
                BaseItem item = items.get(i);
                final int idx = i;
                ex.submit(() -> {
                    KeepItDispositionInfo keepItInfo = getKeepItInfo.apply(item.getKeepItInfo());

                    mapper.copy(keepItInfo, item.getKeepItInfo());//will be used by formulas

                    item.setItemSize(items.size());

                    Session session = new Session();
                    session.getInputData().put(FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM, item);
                    session.getInputData().put(FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEMS, items);
                    session.getInputData().put(FormulaConstants.INTERNAL_DATA_NAME_POOL, shared);

                    if (rdmSwitches.getExternalServiceExceptionHandlingEnabled()) {
                        session.getInputData().put(FormulaConstants.INTERMEDIATE_DATA_NAME_EXTERNAL_API_EXCEPTIONS, new HashMap<String, Exception>());
                    }

                    DispositionInfo info = calculatePaths(session, item, debug);

                    itemIdVsOutputSessionDataMap.put(item.getItemId(), session.getOutputData());

                    Error error = info.getError();
                    if (error != null) {
                        error.setField(item.getOfferId());

                        keepItInfo.setIsDefault(true);
                    }

                    infoArray[idx] = info;
                    info.setKeepItInfo(keepItInfo);

                    RDMKeepItConfig rdmKeepItConfig = ConfigManager.getRdmKeepItConfig();
                    if (rdmKeepItConfig.getEligibleChannelsForKeepItExecution().contains(item.getChannelName())) {
                        executeKeepItLogic(info, item, session);
                    }

                    populatePartialKeepItEligibility(info, item);

                });
            }
        } finally {
            ex.shutdown();
        }
        try {
            //formula service should not throw an exception and handle the timeout scenario 
            //external service call should set timeout value smaller then this
            if (!ex.awaitTermination(rdmSwitches.getMultiitemsTimeout(), TimeUnit.MILLISECONDS)) {
                LOG.error("MultiItem timeout");
                ex.shutdownNow();
            }
        } catch (InterruptedException e) {
            LOG.error("MultiItem error {}", e.getMessage());
            ex.shutdownNow();
            Thread.currentThread().interrupt();
        }
        List<DispositionInfo> infoList = Arrays.asList(infoArray);


        infoList.forEach(dispositionInfo -> {
            BaseItem item = dispositionInfo.getItem();
            if (!util.getUomEachAllPossibilites().contains(item.getQuantity().getUnitOfMeasure())) {
                /*
                  If UnitOfMeasure is not 'EA','ea','EACH','each' then
                  Set OriginalQty in response
                 */
                item.getQuantity().setMeasurementValue(item.getQuantity().getMeasurementValueOriginal());
                item.getQuantity().setMeasurementValueOriginal(null);
            }
        });



        /*
        rankAssignerChain to execute business rule and custom preference ranking
         */
        RankAssignerChain.executeRankAssigner(infoList);


        /*
           Calculate Return Incentive Amount for all Items
         */
        List<String> incentiveComputationEligibleRdmCallerApiNames = returnIncentiveConfig.getIncentiveComputationEligibleRdmCallerContext();
        if (returnIncentiveConfig.isEnableReturnIncentiveFeature() && checkIfMultiItemEnabledForReturnIncentive(items, returnIncentiveConfig)
                && !items.isEmpty() && incentiveComputationEligibleRdmCallerApiNames.contains(items.get(0).getRdmApiCallerName())) {
            calculateReturnIncentiveForAllItems(infoList, items, itemIdVsOutputSessionDataMap);
        }

        return infoList;
    }



    private boolean checkIfMultiItemEnabledForReturnIncentive(List<? extends BaseItem> items, ReturnIncentiveConfig returnIncentiveConfig) {
        boolean isMultiItemRequestEligibleForIncentiveRuleEngine = returnIncentiveConfig.getEnableReturnIncentiveFeatureForMultiItems();
        if (!isMultiItemRequestEligibleForIncentiveRuleEngine) {
            return items.size() == 1;
        } else {
            return true;
        }
    }

    public void calculateReturnIncentiveForAllItems(List<DispositionInfo> infoList, List<? extends BaseItem> items, Map<String, Map<String, Object>> itemIdVsOutputSessionDataMap) {

        for (int i = 0; i < items.size(); i++) {
            BaseItem item = items.get(i);
            DispositionInfo dispositionInfo = infoList.get(i);

            Session session = new Session();
            session.getInputData().put(FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEMS, items);
            session.setOutputData(itemIdVsOutputSessionDataMap.get(item.getItemId()));

            try {
                rdmIncentiveUtil.calculateReturnIncentiveOfItem(dispositionInfo, session, item);
            } catch (Exception e) {
                LOG.error("Calculation of Return Incentive failed for gtin: {}  and orderId: {}", item.getGtin(), item.getOrderNo(), e);
            }
        }
    }


    private void executeKeepItLogic(DispositionInfo dispositionInfo, BaseItem item, Session session) {

        Object isUseRapRule = session.getOutputData().get(FormulaConstants.USE_RAP_RULE);

        /*
          1. if isUseRapRule == null, means some exception occurred during computation, set Default keepIt as False
          2. If isUseRapRule == true, means use defaultRaprules
          3. if isUseRapRule == false, means use rdm KeepIt rules
         */
        if (isUseRapRule == null) {
            rdmKeepItUtil.updateDefaultKeepItFalseForAllPaths(dispositionInfo);
        } else if ((Boolean) isUseRapRule) {
            rdmKeepItUtil.updateKeepItForRapRules(dispositionInfo);
        } else {
            triggerRDMKeepItRules(dispositionInfo, item, session);
        }


        //As keepIt is a disposition Path, remove it from response
        rdmKeepItUtil.removeKeepItPathFromResponse(dispositionInfo);
    }

    private void triggerRDMKeepItRules(DispositionInfo dispositionInfo, BaseItem item, Session session) {
        boolean trustCustomer = dispositionInfo.getKeepItInfo().getTrustCustomerToKeepIt();
        /*

          When trustCustomerToKeepIt=true then run RDM KeepIT rule engine otherwise
          update KeepIT false for all the disposition paths.
         */
        if (trustCustomer) {
            KeepItRuleEngineContext keepItRuleEngineContext = rdmKeepItUtil.prepareRequest(dispositionInfo, item, session);
            rdmKeepitRuleEngine.start(keepItRuleEngineContext);
        } else {
            rdmKeepItUtil.updateKeepItFalseForNonTrustedCustomer(dispositionInfo);
        }
    }


    private DispositionInfo calculatePaths(Session session, BaseItem item, Boolean debug) {
        String channel = item.getChannelName();
        SellerType sellerType = RdmUtils.getSellerTypeFromRequest(item);

        //overrides
        Map<String, Object> overrides = item.getVariableOverrides();
        if (overrides != null) {
            Iterator<Entry<String, Object>> i = overrides.entrySet().iterator();
            Entry<String, Object> override;
            while (i.hasNext()) {
                override = i.next();
                session.getInputData().put(override.getKey(), override.getValue());
                LOG.info(MessageFormat.format("Overrides {0} to {1}", override.getKey(), override.getValue()));
            }
        }

        //for debugging
        session.setOutputData(new HashMap<>(session.getInputData()));

        //there should be no exception throw out
        DispositionInfo info = formulaService.calculatePaths(channel, sellerType, session, BooleanUtils.isTrue(debug));

        info.setItem(item);

        rdmCommonUtils.printTimings(info);

        return info;
    }

}
