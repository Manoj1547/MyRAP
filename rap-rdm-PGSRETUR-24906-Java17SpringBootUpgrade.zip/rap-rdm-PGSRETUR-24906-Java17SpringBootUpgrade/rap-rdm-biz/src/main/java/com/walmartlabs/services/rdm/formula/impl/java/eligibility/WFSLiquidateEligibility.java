package com.walmartlabs.services.rdm.formula.impl.java.eligibility;

import com.walmartlabs.services.rdm.config.client.RestockEligibilityConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.formula.Formula;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * It will return true if Item is eligible for liquidate i.e if it does not belongs to restricted product type category
 */
@Component
public class WFSLiquidateEligibility implements JavaEngineClass {

    @ManagedConfiguration
    RestockEligibilityConfig restockEligibilityConfig;

    public void setRestockEligibilityConfig(RestockEligibilityConfig restockEligibilityConfig) {
        this.restockEligibilityConfig = restockEligibilityConfig;
    }

    @Override
    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        BaseItem item = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);
        return null != item.getProductType() &&
                !restockEligibilityConfig.getRestrictedProductTypes().contains(item.getProductType());
    }
}
