package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Rule Check added as a part of PGSRETUR-20059.
 * Checks whether the order is a photo order and customer is trusted for keep it
 */
@Component("photoItemCheck")
public class PhotoItemCheck implements IRDMKeepItRuleCheck{

    @Autowired
    RDMKeepItUtil rdmKeepItUtil;

    @ManagedConfiguration
    private RDMKeepItConfig rdmKeepItConfig;

    @Autowired
    public void setRdmKeepItUtil(RDMKeepItUtil rdmKeepItUtil) {
        this.rdmKeepItUtil = rdmKeepItUtil;
    }

    public void setRdmKeepItConfig(RDMKeepItConfig rdmKeepItConfig) {
        this.rdmKeepItConfig = rdmKeepItConfig;
    }

    @Override
    public String getKeepItCheckName() {
        return RDMConstants.RULE_CHECK_NAME_PHOTO_ITEM;
    }

    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {
        BaseItem item = keepItRuleEngineContext.getItem();
        return rdmKeepItConfig.getPhotoItemRuleEnabled() && rdmKeepItUtil.isCustomerTrustedForKeepIt(item) && rdmKeepItUtil.isPhotoOrderLine(item);
    }
}
