package com.walmartlabs.services.rdm.component.rcp.service.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.txnmarking.impl.NullTransactionImpl;
import com.walmart.platform.txnmarking.impl.TransactionImpl;
import com.walmartlabs.services.rdm.component.rcp.model.request.GetItemDispositionDetailsRequest;
import com.walmartlabs.services.rdm.component.rcp.model.response.GetItemDispositionDetailsResponse;
import com.walmartlabs.services.rdm.config.client.RCPServiceConfig;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import com.walmartlabs.services.rdm.util.BaseHTTPClient;
import com.walmartlabs.services.rdm.util.HeaderElements;
import com.walmartlabs.services.rdm.util.cache.CacheManager;
import com.walmartlabs.services.rdm.util.cache.CacheRole;

import io.strati.StratiServiceProvider;
import io.strati.configuration.annotation.ManagedConfiguration;
import io.strati.txnmarking.TransactionMarkingService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.text.MessageFormat;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

@Component
public class RCPHttpClient extends BaseHTTPClient {

    private static final Logger LOG = LoggerFactory.getLogger(RCPHttpClient.class);

    private TransactionMarkingService TMS;

    @Resource
    @ManagedConfiguration RCPServiceConfig rcpServiceConfig;

    @Resource
    private CacheManager              cacheManager;

    private ObjectMapper objectMapper;

    @PostConstruct
    protected void init() {
        objectMapper = new ObjectMapper();
    }
    
    private RCPHttpClient() {
        TMS = StratiServiceProvider.getInstance().getTransactionMarkingService().get();
    }
    
    public GetItemDispositionDetailsResponse getRcpItemDispositionPolicyDetails(GetItemDispositionDetailsRequest request) {

        TransactionImpl top;
        if(TMS.currentTransaction() instanceof NullTransactionImpl) {
            top = (TransactionImpl) TMS.topTransaction("RCPItemDispositionPolicyDetails", "RCPItemDispositionPolicyDetails");
        }else {
            top = (TransactionImpl) TMS.transaction("RCPItemDispositionPolicyDetails", "RCPItemDispositionPolicyDetails");
        }
        top.start();

        String payload = getJsonString(request);

        GetItemDispositionDetailsResponse response ;
        String responseString = null;
        try {
            String key = payload;//not sure if key has length limitation
            String data = null;
            if(rcpServiceConfig.getRcpServiceCachingEnabled()){
                data = cacheManager.get(key, CacheRole.RCP);
                if(data == null){
                    responseString = callRcpService(payload);
                    cacheManager.put(key, responseString, CacheRole.RCP);
                } else{
                    responseString = data;
                }
            } else{
                responseString = callRcpService(payload);
            }


            ServiceResponse<GetItemDispositionDetailsResponse> serviceResponse = objectMapper.readValue(responseString,
                    new TypeReference<ServiceResponse<GetItemDispositionDetailsResponse>>() {
                    });
            response = serviceResponse.getPayload();

            validateResponse(response, request.getPayload().getItemId());
            top.end();
        } catch (ServiceException e) {
            String errorMsg = MessageFormat.format("RCP-HTTP failed for request {0}: {1}", payload);
            LOG.error(errorMsg, e);
            top.logException(e);
            top.endWithFailure(e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.RCP_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        } catch (JsonProcessingException e) {
            String errorMsg = MessageFormat.format("RCP service JsonProcessing excpetion, for response", responseString);
            LOG.error(errorMsg, e);
            top.logException(e);
            top.endWithFailure(e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.RCP_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        }catch (Exception e) {
            String errorMsg = MessageFormat.format("RCP service Unexpected exception for request {0}", payload);
            LOG.error(errorMsg, e);
            top.logException(e);
            top.endWithFailure(e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.RCP_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        }

        return response;
    }

    private String callRcpService(String requestPayload) throws ServiceException {
        if(rcpServiceConfig.getMockRcpServiceEnabled()){
            LOG.info("Mock enabled for RCP service");
            return rcpServiceConfig.getMockedRcpServiceResponse();
        }
        String baseUrl = rcpServiceConfig.getServiceBaseHostUrl();
        String pathUrl = rcpServiceConfig.getServiceEndpoint();
        int apiTimeOut = rcpServiceConfig.getTimeOut();
        Map<String, String> headerParams = getHeaderParams(rcpServiceConfig);
        LOG.info("Invoking RCP service for request,"+ requestPayload);
        String rcpResponse =  post(baseUrl, pathUrl, requestPayload, headerParams, apiTimeOut, String.class);
        LOG.info("RCP service response for request, "+ requestPayload + " response, " + rcpResponse);

        return rcpResponse;
    }

    private void validateResponse(GetItemDispositionDetailsResponse response, String itemId) {
        if(response == null || response.toString().isEmpty()){
            String errorMsg = MessageFormat.format("RCP-HTTP failed for itemId : {0}", itemId);
            LOG.error(errorMsg);
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.RCP_HTTP_CLIENT_EXECUTION_FAILED, errorMsg);
        }
        if(response.getEntityErrorList() != null && response.getEntityErrorList().size() > 0){
            String errorMsg = MessageFormat.format("RCP-HTTP failed due to : {0} ", response.getEntityErrorList().get(0).getDescription());
            LOG.error(errorMsg);
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.RCP_HTTP_CLIENT_EXECUTION_FAILED, errorMsg);
        }
    }

    private Map<String, String> getHeaderParams(RCPServiceConfig config) {
        HashMap<String, String> headers = new HashMap<>();

        addHeaderParam(headers, HeaderElements.SERVICE_VERSION, config.getServiceVersion());
        addHeaderParam(headers, HeaderElements.SERVICE_ENV, config.getServiceEnv());
        addHeaderParam(headers, HeaderElements.SERVICE_NAME, config.getServiceName());
        addHeaderParam(headers, HeaderElements.CONSUMER_ID, config.getServiceConsumerId());
        addHeaderParam(headers, HeaderElements.CONSUMER_TENANT_ID, config.getTenantId());
        addHeaderParam(headers, HeaderElements.CONTENT_TYPE, config.getContentType());
        addHeaderParam(headers, HeaderElements.ACCEPT, config.getAccept());
        addHeaderParam(headers, HeaderElements.BU_ID, config.getBuId());
        addHeaderParam(headers, HeaderElements.MART_ID, config.getMartId());
        addHeaderParam(headers, HeaderElements.TENAT_ID, config.getTenantId());
        addHeaderParam(headers, HeaderElements.RESPONSE_GROUP, config.getResponseGroup());

        return headers;
    }

    private void addHeaderParam(HashMap<String, String> headers, String name, String value) {
        if (StringUtils.isNotBlank(value))
            headers.put(name, value);
    }

    private String getJsonString(Object o) {
        try{
            return new ObjectMapper().writeValueAsString(o);
        }catch (JsonProcessingException e){
            LOG.error(e.getMessage());
            return null;
        }
    }
}
