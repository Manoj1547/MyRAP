package com.walmartlabs.services.rdm.util;

import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import org.apache.commons.collections4.CollectionUtils;

import java.util.Iterator;
import java.util.List;

public class PartialKeepItUtil {

    public static final String PARTIAL_KEEP_IT_DISPOSITION_PATH = "partialKeepIt";

    /**
     * Populates the partial keep it eligibility of the given item based on the disposition info.
     *
     * @param dispositionInfo The disposition info for the item.
     * @param item            The item to populate the partial keep it eligibility for.
     */
    public static void populatePartialKeepItEligibility(DispositionInfo dispositionInfo, BaseItem item) {
        if (!isPartialKeepItEligibleItem(dispositionInfo)) {
            item.getPartialKeepIt().setItemPartialKeepItEligibility(false);
        }
    }

    /**
     * Checks if the given disposition info represents a partial keep it eligible item.
     * Partial KeepIt is eligible if:
     * 1. Default is false
     * 2. There are at least 2 paths
     * 3. The partial keep it path is ranked as the first path
     * 4. All paths are non keep it
     * @param dispositionInfo The disposition info to check.
     * @return True if the item is partial keep it eligible, false otherwise.
     */

    private static boolean isPartialKeepItEligibleItem(DispositionInfo dispositionInfo) {
        return null != dispositionInfo && Boolean.FALSE.equals(dispositionInfo.getDefault())
                && CollectionUtils.isNotEmpty(dispositionInfo.getDispositionPaths())
                && dispositionInfo.getDispositionPaths().size() >=2
                && partialKeepItIsRankOne(dispositionInfo)
                && allPathsAreNonKeepIt(dispositionInfo);
    }

    /**
     * Checks if all paths in the disposition info are non keep it, except for the partial keep it path.
     *
     * @param dispositionInfo The disposition info to check.
     * @return True if all paths are non keep it, false otherwise.
     */

    private static boolean allPathsAreNonKeepIt(DispositionInfo dispositionInfo) {
        for(DispositionPath path : dispositionInfo.getDispositionPaths()){
            if(Boolean.TRUE.equals(path.getKeepIt()) && !PARTIAL_KEEP_IT_DISPOSITION_PATH.equals(path.getPath())){
                return false;
            }
        }
        return true;
    }


    /**
     * Checks if the partial keep it path is ranked as the first path in the disposition info.
     *
     * @param dispositionInfo The disposition info to check.
     * @return True if the partial keep it path is ranked first, false otherwise.
     */
    private static boolean partialKeepItIsRankOne(DispositionInfo dispositionInfo) {
        for(DispositionPath path : dispositionInfo.getDispositionPaths()){
            if(PARTIAL_KEEP_IT_DISPOSITION_PATH.equals(path.getPath())){
                return path.getRank() == 1;
            }
        }
        return false;
    }

    /**
     * Removes the partial keep it path from the disposition info.
     *
     * @param dispositionInfo The disposition info to remove the partial keep it path from.
     */
    public static void removePartialKeepItFromDispositionPath(DispositionInfo dispositionInfo) {
        List<DispositionPath> paths = dispositionInfo.getDispositionPaths();
        Iterator<DispositionPath> i = paths.iterator();
        while(i.hasNext()){
            DispositionPath path = i.next();
            if(PARTIAL_KEEP_IT_DISPOSITION_PATH.equals(path.getPath())){
                i.remove();
                return;
            }
        }
    }
}
