package com.walmartlabs.services.rdm.component.incentiveruleengine.incentiverules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.incentiveruleengine.model.ReturnIncentiveEngineContext;
import com.walmartlabs.services.rdm.component.incentiveruleengine.util.AbstractReturnIncentiveRule;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import org.springframework.stereotype.Component;

@Component("rdmDefaultItemRule")
public class RdmDefaultItemRule extends AbstractReturnIncentiveRule {
    @Override
    public boolean runReturnIncentiveRule(ReturnIncentiveEngineContext returnIncentiveEngineContext) {
        return !(returnIncentiveEngineContext.getDispositionInfo().getIsDefault());
    }

    @Override
    public String getRuleName() {
        return RDMConstants.RULE_NAME_DEFAULT_ITEM;
    }
}
