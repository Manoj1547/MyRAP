package com.walmartlabs.services.rdm.component.apollorestock.jsonmodel;

import java.util.List;

public class RuleCondition{
    public String operator;
    public List<String> conjuctionConditionNames;

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public List<String> getConjuctionConditionNames() {
        return conjuctionConditionNames;
    }

    public void setConjuctionConditionNames(List<String> conjuctionConditionNames) {
        this.conjuctionConditionNames = conjuctionConditionNames;
    }
}
