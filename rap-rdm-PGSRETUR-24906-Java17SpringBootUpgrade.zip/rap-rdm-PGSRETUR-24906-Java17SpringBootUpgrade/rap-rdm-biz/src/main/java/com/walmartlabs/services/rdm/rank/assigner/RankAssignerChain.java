package com.walmartlabs.services.rdm.rank.assigner;

import com.walmartlabs.services.rdm.config.client.ConfigManager;
import com.walmartlabs.services.rdm.config.client.RankAssignerChainConfig;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.util.BeanHelper;
import java.util.List;


public class RankAssignerChain{

    private static RankAssigner rankAssigner;


    private static void buildChain() {

        List<String> rankAssignerRules = ConfigManager.getRankAssignerChainConfig().getRankAssignerChainInSequence();

        rankAssigner = (RankAssigner) BeanHelper.getBean(rankAssignerRules.get(0));
        RankAssigner prevRankAssigner = rankAssigner;
        for(int i=1;i<rankAssignerRules.size();i++){
            RankAssigner currRankAssigner = (RankAssigner) BeanHelper.getBean(rankAssignerRules.get(i));
            prevRankAssigner.setNextRankAssigner(currRankAssigner);
            prevRankAssigner = currRankAssigner;
        }
    }

    public static void executeRankAssigner(List<DispositionInfo> dispositionInfoList) {
        if(null == rankAssigner) {
             buildChain();
        }
        rankAssigner.executeRankAssigner(dispositionInfoList);
    }


}
