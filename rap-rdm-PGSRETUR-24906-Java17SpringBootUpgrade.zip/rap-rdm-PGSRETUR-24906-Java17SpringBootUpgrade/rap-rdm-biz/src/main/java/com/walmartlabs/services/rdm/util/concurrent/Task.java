package com.walmartlabs.services.rdm.util.concurrent;



import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

public class Task {
    public static enum DependantType {
        ANY, ALL
    }

    private String        name;
    private List<Task>    dependents    = new ArrayList<>();
    private DependantType dependantType = DependantType.ALL;
    private Runnable      runnable;
    private Callable<Object> callable;

    public Task(Runnable runnable) {
        this(runnable, null);
    }

    public Task(Runnable runnable, String name) {
        this.runnable = runnable;
        this.name = name;
    }

    public Task(Callable<Object> callable, String name) {
        this.callable = callable;
        this.name = name;
    }

    public List<Task> getDependents() {
        return dependents;
    }

    public void setDependents(List<Task> dependents) {
        this.dependents = dependents;
    }

    public DependantType getDependantType() {
        return dependantType;
    }

    public void setDependantType(DependantType dependantType) {
        this.dependantType = dependantType;
    }

    public Runnable getRunnable() {
        return runnable;
    }

    public void setRunnable(Runnable runnable) {
        this.runnable = runnable;
    }

    public Callable<Object> getCallable() {
        return callable;
    }

    public void setCallable(Callable<Object> callable) {
        this.callable = callable;
    }

}
