package com.walmartlabs.services.rdm.component.iqs.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LogisticsOffer {
    @JsonProperty("flagAttributes")
    private FlagAttributes flagAttributes;

    @JsonProperty("offerShipmentSpecification")
    private OfferShipmentSpecification offerShipmentSpecification;

    @JsonProperty("productPackageDimensions")
    private List<ProductPackageDimension> productPackageDimensions;

    public FlagAttributes getFlagAttributes() {
        return flagAttributes;
    }

    public void setFlagAttributes(FlagAttributes flagAttributes) {
        this.flagAttributes = flagAttributes;
    }

    public OfferShipmentSpecification getOfferShipmentSpecification() {
        return offerShipmentSpecification;
    }

    public void setOfferShipmentSpecification(OfferShipmentSpecification offerShipmentSpecification) {
        this.offerShipmentSpecification = offerShipmentSpecification;
    }

    public List<ProductPackageDimension> getProductPackageDimensions() {
        return productPackageDimensions;
    }

    public void setProductPackageDimensions(List<ProductPackageDimension> productPackageDimensions) {
        this.productPackageDimensions = productPackageDimensions;
    }
}
