
package com.walmartlabs.services.rdm.model.finaldisposition;

import com.walmartlabs.services.rdm.model.Base;

/**
 * 
 * @author Tim Jin
 *
 */
public class FinalDisposition extends Base {

    private String path;

    private String overrideReason;

    private Boolean returnExpectedOverride;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getOverrideReason() {
        return overrideReason;
    }

    public void setOverrideReason(String overrideReason) {
        this.overrideReason = overrideReason;
    }

    public Boolean getReturnExpectedOverride() { return returnExpectedOverride; }

    public void setReturnExpectedOverride(Boolean returnExpectedOverride) {
        this.returnExpectedOverride = returnExpectedOverride;
    }

    @Override
    public String toString() {
        return "FinalDisposition [path=" + path + ", overrideReason=" + overrideReason + ", returnExpectedOverride="
                       + returnExpectedOverride + "]";
    }
}
