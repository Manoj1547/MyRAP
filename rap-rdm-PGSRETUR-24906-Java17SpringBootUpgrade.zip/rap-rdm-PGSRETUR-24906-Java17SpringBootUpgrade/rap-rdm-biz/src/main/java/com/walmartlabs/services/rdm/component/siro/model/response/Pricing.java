package com.walmartlabs.services.rdm.component.siro.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Pricing {
    @JsonProperty("retailPrice")
    private BigDecimal retailPrice;

    @JsonProperty("sellPrice")
    private BigDecimal sellPrice;

    @JsonProperty("storeCost")
    private int storeCost;

    public BigDecimal getRetailPrice() {
        return retailPrice;
    }

    public void setRetailPrice(BigDecimal retailPrice) {
        this.retailPrice = retailPrice;
    }

    public BigDecimal getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(BigDecimal sellPrice) {
        this.sellPrice = sellPrice;
    }

    public int getStoreCost() {
        return storeCost;
    }

    public void setStoreCost(int storeCost) {
        this.storeCost = storeCost;
    }
}
