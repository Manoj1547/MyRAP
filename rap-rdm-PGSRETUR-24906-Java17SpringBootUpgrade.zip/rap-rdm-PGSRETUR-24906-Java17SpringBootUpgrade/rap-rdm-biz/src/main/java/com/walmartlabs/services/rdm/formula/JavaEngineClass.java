package com.walmartlabs.services.rdm.formula;

import java.util.Map;

import com.walmartlabs.services.rdm.model.formula.Formula;

public interface JavaEngineClass {

    Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException;

}
