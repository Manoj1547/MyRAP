package com.walmartlabs.services.rdm.rank.assigner.impl;

import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.rank.assigner.RankAssigner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * It arranges the final response of RDM after executing every business rule in the rank assigner chain.
 * This rule should be executed at the end of Rank Assigner always
 * If the response is default it executes DefaultCase behaviour or if its non-default case it executes Non-DefaultCase
 * behaviour
 * @author v0h01q5
 */
@Component
public class FinalizeRanksAndReturnMethods extends RankAssigner {

    @Autowired
    IAssignReturnMethodsForDefaultCase assignReturnMethodsForDefaultCase;

    @Autowired
    IAssignFinalRanksForNonDefaultCase assignFinalRanksForNonDefaultCase;


    public void setAssignReturnMethodsForDefaultCase(AssignReturnModesFromReturnEligibility assignReturnMethodsForDefaultCase) {
        this.assignReturnMethodsForDefaultCase = assignReturnMethodsForDefaultCase;
    }

    public void setAssignFinalRanksForNonDefaultCase(AssignContinuousRank assignFinalRanksForNonDefaultCase) {
        this.assignFinalRanksForNonDefaultCase = assignFinalRanksForNonDefaultCase;
    }

    @Override
    protected void assignRanks(List<DispositionInfo> allItemsDispositionInfoList) {
        for (DispositionInfo dispositionInfo : allItemsDispositionInfoList) {
            if(!dispositionInfo.getDefault()){
               assignFinalRanksForNonDefaultCase.assignFinalRanks(dispositionInfo);
            }else{
                assignReturnMethodsForDefaultCase.assignFinalReturnModes(dispositionInfo);
            }

        }
    }
}
