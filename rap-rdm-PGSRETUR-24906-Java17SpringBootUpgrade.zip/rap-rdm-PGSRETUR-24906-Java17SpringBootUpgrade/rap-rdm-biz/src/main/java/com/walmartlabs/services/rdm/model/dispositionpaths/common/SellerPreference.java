package com.walmartlabs.services.rdm.model.dispositionpaths.common;


public class SellerPreference {


    String sellableItemDisposition;


    String unsellableItemDisposition;

    public String getSellableItemDisposition() {
        return sellableItemDisposition;
    }

    public void setSellableItemDisposition(String sellableItemDisposition) {
        this.sellableItemDisposition = sellableItemDisposition;
    }

    public String getUnsellableItemDisposition() {
        return unsellableItemDisposition;
    }

    public void setUnsellableItemDisposition(String unsellableItemDisposition) {
        this.unsellableItemDisposition = unsellableItemDisposition;
    }

}
