package com.walmartlabs.services.rdm.model.dispositionpaths.common;

import com.walmartlabs.services.rdm.model.Base;

/**
 * 
 * @author Tim Jin
 *
 */
public class Timing extends Base {
    public static enum Type {
        EXTERNAL, CODE_FLOW, FORMULA, KEEPIT_RULE
    }

    private long   time = System.currentTimeMillis();
    private long   span;
    private Type   type;
    private Object other;

    public Timing(long span, Object other, Type type) {
        this.span = span;
        this.other = other;
        this.type = type;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public long getSpan() {
        return span;
    }

    public void setSpan(long span) {
        this.span = span;
    }

    public Object getOther() {
        return other;
    }

    public void setOther(Object other) {
        this.other = other;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

}