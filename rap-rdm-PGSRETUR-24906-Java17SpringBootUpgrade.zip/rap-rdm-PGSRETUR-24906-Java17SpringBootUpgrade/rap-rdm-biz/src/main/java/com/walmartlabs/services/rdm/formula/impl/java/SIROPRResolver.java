package com.walmartlabs.services.rdm.formula.impl.java;

import java.util.Map;

import com.walmartlabs.services.rdm.component.siro.service.util.SIROHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.stereotype.Service;
import org.apache.commons.lang.BooleanUtils;

import com.walmartlabs.services.rdm.component.siro.model.response.GetStoreItem;
import com.walmartlabs.services.rdm.component.siro.model.response.GetStoreItemResponse;
import com.walmartlabs.services.rdm.component.siro.model.response.ProductRecall;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.FormulaException;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.Formula;
import org.springframework.util.ObjectUtils;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public class SIROPRResolver implements JavaEngineClass {

    private static final Logger LOG = LoggerFactory.getLogger(SIROPRResolver.class);

    @ManagedConfiguration
    RDMSwitches switches;

    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        LOG.info("SIROPRResolver started");
        GetStoreItemResponse response = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_SIRO);

        if(response == null || response.getPayload() == null || response.getPayload().length == 0 || response.getPayload()[0].getData() == null
                || response.getPayload()[0].getData().getGetStoreItem() == null || response.getPayload()[0].getData().getGetStoreItem() == null){
            throw new FormulaException("SIRO response is invalid!");
        }

        GetStoreItem storeItem = response.getPayload()[0].getData().getGetStoreItem();
        ProductRecall[] prs = storeItem.getProductRecall();

        if(storeItem.getActiveItem() != null){
            LOG.info("SIROPRResolver new flow");
            return storeItem.getActiveItem().getProductRecall();
        }else {
            LOG.info("SIROPRResolver old flow");
            if (prs != null) {
                for (ProductRecall item : prs) {
                    try {
                        if (BooleanUtils.isTrue(switches.getExternalServiceResponseValidationEnabled())) {
                            validateRequiredFields(item);
                        }
                        if (item.getItemNumber().equals(storeItem.getBasicInfo().getItemNumber())) return item;
                    } catch (Exception e) {
                        return prs[0];
                    }
                }
            }
        }
        return FormulaConstants.INVALID_VALUE;
    }

    public void validateRequiredFields(ProductRecall productRecall) {
        if(ObjectUtils.isEmpty(productRecall) || ObjectUtils.isEmpty(productRecall.getDefectiveAgreement())
            || ObjectUtils.isEmpty(productRecall.getDefectiveAgreement().getItemExcpDefectAgmt())
            || ObjectUtils.isEmpty(productRecall.getDefectiveAgreement().getSupDeptDefectAgmt())) {
            throw new FormulaException("Defective Agreement not available in SIRO response.");
        }
    }

}
