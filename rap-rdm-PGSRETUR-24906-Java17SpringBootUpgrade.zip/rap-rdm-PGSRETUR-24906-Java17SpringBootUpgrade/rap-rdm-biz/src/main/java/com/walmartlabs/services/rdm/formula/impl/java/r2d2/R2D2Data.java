package com.walmartlabs.services.rdm.formula.impl.java.r2d2;

import java.text.MessageFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectReader;
import com.walmartlabs.services.rdm.domain.persistence.DataPersistenceManager;
import com.walmartlabs.services.rdm.formula.FormulaException;
import com.walmartlabs.services.rdm.mapper.ModelMapper;
import com.walmartlabs.services.rdm.model.R2d2Data;
import com.walmartlabs.services.rdm.model.R2d2Data.R2d2DataType;
import com.walmartlabs.services.rdm.util.DataContainer;
import com.walmartlabs.services.rdm.util.Reloadable;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public abstract class R2D2Data implements Reloadable {

    static class CacheModel {
        Date                time      = new Date();
        Map<String, Double> idMap     = new HashMap<>();
        Map<String, Double> nameMap   = new HashMap<>();
        Map<String, Double> idNameMap = new HashMap<>();
    }

    static final Pattern        L1_PATTERN = Pattern.compile("^((\\d+)\\s+)?(.+)$");

    private static final Logger LOG        = LoggerFactory.getLogger(R2D2Data.class);

    @Resource
    DataPersistenceManager      persistenceManager;

    @Resource
    ModelMapper                 mapper;

    abstract List<R2d2DataType> getTypes();

    DataContainer<Map<R2d2DataType, CacheModel>> container = new DataContainer<>();

    @PostConstruct
    private void init() {
        LOG.info("init");
        reload(true);
    }

    ObjectReader reader;

    public void reload(boolean blocking) {
        LOG.info("reload {} {}", blocking, getTypes());
        container.requestSet((old) -> {
            Map<R2d2DataType, CacheModel> cache = new HashMap<>();
            for(R2d2DataType type : getTypes()){
                List<R2d2Data> list = mapper.mapR2d2List(persistenceManager.getR2D2Data(mapper.map(type)));
                //always an empty map
                cache.put(type, new CacheModel());
                if(list != null){
                    for(R2d2Data data : list){
                        cache.get(type).idMap.put(data.getCategoryId(), data.getVaule());
                        cache.get(type).nameMap.put(data.getCategoryName(), data.getVaule());
                        cache.get(type).idNameMap.put(data.getCategoryId() + data.getCategoryName(), data.getVaule());
                    }
                }
            }
            return cache;
        }, blocking);
    }

    Double getData(String l1) {
        Map<R2d2DataType, CacheModel> cache = container.get();
        Double v = null;
        Matcher matcher = L1_PATTERN.matcher(l1);
        if(matcher.find()){
            String departmentNo = StringUtils.trimToNull(matcher.group(1));
            if(departmentNo != null) departmentNo = departmentNo.replaceFirst("^0+(?!$)", "");//negative lookahead ensures that not the entire string will be matched
            String name = StringUtils.trimToNull(matcher.group(3));

            for(R2d2DataType type : getTypes()){
                v = cache.get(type).idNameMap.get(departmentNo + name);
                if(v != null) break;
                v = cache.get(type).idMap.get(departmentNo);
                if(v != null) break;
                v = cache.get(type).nameMap.get(name);
                if(v != null) break;
            }
            return v;
        }else throw new FormulaException(MessageFormat.format("R2D2 L1({0}) is invalid.", l1));
    }

}
