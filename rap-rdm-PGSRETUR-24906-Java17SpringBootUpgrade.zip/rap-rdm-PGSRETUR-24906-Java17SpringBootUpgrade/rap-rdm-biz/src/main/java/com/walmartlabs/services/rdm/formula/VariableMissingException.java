package com.walmartlabs.services.rdm.formula;

public class VariableMissingException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = -7182415805610839173L;
    
    private String variable;

    public VariableMissingException(Exception e, String variable) {
        super(e);
        this.variable = variable;
    }

    public String getVariable() {
        return variable;
    }

    public void setVariable(String variable) {
        this.variable = variable;
    }

}
