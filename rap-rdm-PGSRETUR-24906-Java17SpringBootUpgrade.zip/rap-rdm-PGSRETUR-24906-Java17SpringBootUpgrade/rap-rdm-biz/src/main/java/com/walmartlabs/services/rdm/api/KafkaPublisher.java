package com.walmartlabs.services.rdm.api;

import java.util.Date;
import java.util.UUID;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import com.walmart.platform.txnmarking.impl.NullTransactionImpl;
import com.walmart.platform.txnmarking.impl.TransactionImpl;
import io.strati.StratiServiceProvider;
import io.strati.txnmarking.TransactionMarkingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.walmart.iris.services.producer.KafkaEventProducer;
import com.walmartlabs.services.rdm.config.client.KafkaProducerConfig;
import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import com.walmartlabs.services.rdm.dto.dispositionpaths.kafka.DispositionEventPayload;
import com.walmartlabs.services.rdm.dto.dispositionpaths.kafka.Event;
import com.walmartlabs.services.rdm.dto.dispositionpaths.kafka.EventHeader;

import io.strati.configuration.annotation.ManagedConfiguration;
import org.apache.commons.lang.BooleanUtils;

/**
 * 
 * @author Tim Jin
 *
 */
public class KafkaPublisher {

    private static final Logger LOG                                = LoggerFactory.getLogger(KafkaPublisher.class);

    private static final String EVENT_NAME_RECOMMENDED_DISPOSITION = "RECOMMENDED_DISPOSITION";
    public static final String RDM_TRANSACTION_DUMPS = "RDM_TRANSACTION_DUMPS";

    @ManagedConfiguration
    KafkaProducerConfig         kafkaConfig;

    @ManagedConfiguration
    RDMSwitches                 switches;

    @SuppressWarnings("rawtypes")
    @Resource(name = "KafkaProducer")
    KafkaEventProducer          producer;

    private ObjectWriter        writer;

    private TransactionMarkingService TMS;

    @PostConstruct
    public void init() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.setSerializationInclusion(Include.NON_NULL);

        this.writer = mapper.writerFor(new TypeReference<Event<DispositionEventPayload>>() {});
        TMS =  StratiServiceProvider.getInstance().getTransactionMarkingService().get();
    }

    public void publish(DispositionEventPayload kafka, boolean hasError, Date date) {
        TransactionImpl top = null;
        try{
            if (TMS.currentTransaction() instanceof NullTransactionImpl) {
                top = (TransactionImpl) TMS.topTransaction("publishKafka", "publishKafka");
            } else {
                top = (TransactionImpl) TMS.transaction("publishKafka", "publishKafka");
            }
            top.start();
            Event<DispositionEventPayload> event = new Event<DispositionEventPayload>();
            EventHeader header = new EventHeader();
            header.setEventId(UUID.randomUUID().toString());
            header.setProducerName(kafkaConfig.getProducerName());
            header.setTimestamp(System.currentTimeMillis());
            header.setEventName(EVENT_NAME_RECOMMENDED_DISPOSITION);
            header.setCreatets(date);
            event.setHeader(header);
            event.setPayload(kafka);

            boolean sendMsg = BooleanUtils.isTrue(switches.getKafkaSendDispositions()) &&
                    (!hasError || (hasError && BooleanUtils.isTrue(switches.getKafkaSendDispositionsOnError())));

            LOG.info("hasError:{}, sendMsg:{}, topic:{}", hasError, sendMsg, kafkaConfig.getTopic());
            long b = System.currentTimeMillis();
            if(sendMsg){
                producer.publish(writer.writeValueAsString(event), header.getEventId(), kafkaConfig.getTopic());
                LOG.info("Msg sent");
            }
            LOG.info("Timing-CODE_FLOW Publish-Kafka={} {}", System.currentTimeMillis() - b, System.currentTimeMillis());
            top.end();
        }catch (Exception e){
            if(top != null) top.endWithFailure(e.getMessage());
            LOG.error("publish to kafka failed. {}", e);
        }
    }

}
