package com.walmartlabs.services.rdm.util.concurrent;

import com.walmartlabs.services.rdm.executors.RdmPrecallExcecutorService;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import org.jboss.netty.util.Timeout;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Array;
import java.sql.Time;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

public class TaskRunner {


    private static final Logger LOG = LoggerFactory.getLogger(TaskRunner.class);

    /**
     * 
     * @param timeout
     *            ms
     * @param tasks
     */
    @SuppressWarnings("static-access")
    public static void run(int timeout, Task... tasks) {

        //TODO a Common thread pool
        ExecutorService ex = Executors.newFixedThreadPool(getCount(tasks));

        CompletableFuture<?> cf = CompletableFuture.completedFuture(null);

        cf = cf.allOf(listToArray(Arrays.asList(tasks).stream().map(task -> submitTask(ex, task)).collect(Collectors.toList())));

        cf.thenRun(() -> {
            ex.shutdown();
        });

        try{
            if(!ex.awaitTermination(timeout, TimeUnit.MILLISECONDS)){
                ex.shutdownNow();
            }
        }catch (InterruptedException e){
            ex.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }

    public static void runEnhanced(List<Task> allTasks, int preCallMaxTimeout, BaseItem item) {
        invokeAllTasks(allTasks, preCallMaxTimeout, item);
    }

    private static CompletableFuture<?>[] listToArray(List<CompletableFuture<?>> list) {
        return list.toArray((CompletableFuture<?>[]) Array.newInstance(CompletableFuture.class, 0));
    }

    private static int getCount(Task... tasks) {
        int c = 0;
        for(Task task : tasks){
            if(task.getDependents().size() == 0) c += 1;
            else for(Task dependency : task.getDependents()){
                c += getCount(dependency);
            }
        }
        return c;
    }

    @SuppressWarnings("static-access")
    private static CompletableFuture<?> submitTask(ExecutorService ex, Task task) {
        CompletableFuture<?> cf = CompletableFuture.completedFuture(null);
        if(task.getDependents().size() > 0){
            switch (task.getDependantType()) {
                case ALL:
                    cf = new CompletableFuture<>().allOf(listToArray(task.getDependents().stream().map(dependent -> submitTask(ex, dependent)).collect(Collectors.toList())));
                    break;
                case ANY:
                    cf = new CompletableFuture<>().anyOf(listToArray(task.getDependents().stream().map(dependent -> submitTask(ex, dependent)).collect(Collectors.toList())));
                    break;
            }
        }

        cf = cf.thenCompose(s -> {
            CompletableFuture<?> fcf = new CompletableFuture<>();

            ex.submit(() -> {
                task.getRunnable().run();
                fcf.complete(null);
            });
            return fcf;
        });

        return cf;
    }

    private static Future<?> submitTaskEnhanced(Task task) {

        // As of now not adding any task as dependent that's why commenting below code
        // Need to revisit whole rdm framework before enabling it.


       /* //If Task has dependent task then recursively submit dependent tasks
        if(CollectionUtils.isNotEmpty(task.getDependents())){
            List<Future<?>> dependentTaskResponseFutureList = new ArrayList<>();
                    task.getDependents().stream().forEach(dependentTask -> {
                        Future<?> dependentResponse = submitTaskEnhanced(ex, dependentTask);
                        dependentTaskResponseFutureList.add(dependentResponse);
                    });

                    triggerResultFetchFromTaskFutures(dependentTaskResponseFutureList);
            }
*/

        Future<?> response = RdmPrecallExcecutorService.getExecutor().submit(() -> {
            task.getRunnable().run();
        });

        return response;
    }

    private static void invokeAllTasks(List<Task> allTasks, int preCallMaxTimeout, BaseItem item) {

        // As of now not adding any task as dependent
        // Need to revisit whole rdm framework before enabling it.

        List<Callable<Object>> allCallables = new ArrayList<>();

        allTasks.forEach(task -> {
            allCallables.add(task.getCallable());
        });

        List<Future<Object>> allResultFutures = null;
        try {
            allResultFutures = RdmPrecallExcecutorService.getExecutor().invokeAll(allCallables, preCallMaxTimeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            LOG.error("Interuptted Exception while invoking all tasks for itemId {}, gtin{}, offerId {}",
                    item.getItemId(),item.getGtin(), item.getOfferId(),e);
        }

        //Trigger Result Fetch
        allResultFutures.forEach(resultFuture ->{
            try {
                resultFuture.get(preCallMaxTimeout, TimeUnit.MILLISECONDS);
            } catch (Exception e) {
                LOG.error("Exception occured while fetching result from futures, itemId {}, gtin{}, offerId {}",
                        item.getItemId(),item.getGtin(), item.getOfferId(),e);
            }
        });

    }

    private static void triggerResultFetchFromTaskFutures(List<Future<?>> taskResponseFutureList) {
        for(Future<?> future : taskResponseFutureList){
            try {
                future.get(100, TimeUnit.MILLISECONDS);
            } catch (InterruptedException | TimeoutException | ExecutionException e) {
                LOG.error("Exception occured while fetching result from future, errorMsg {}", e.getMessage(), e);
            }
        }
    }
}
