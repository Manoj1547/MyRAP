package com.walmartlabs.services.rdm.model.roevent;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.walmartlabs.services.rdm.model.Quantity;
import com.walmartlabs.services.rdm.model.finaldisposition.FinalDisposition;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReturnOrderLine {

    @JsonProperty("lineNo")
    private Integer lineNo;

    @JsonProperty("salesOrderLineId")
    private Integer salesOrderLineId;

    @JsonProperty("salesOrderLineNo")
    private Integer salesOrderLineNo;

    @JsonProperty("returnReason")
    private String returnReason;

    @JsonProperty("returnReasonDescription")
    private String returnReasonDescription;

    @JsonProperty("ecommReasonCode")
    private String ecommReasonCode;

    @JsonProperty("orderProduct")
    private OrderProduct orderProduct;

    @JsonProperty("isFastReplacement")
    private Boolean isFastReplacement;

    @JsonProperty("isKeepIt")
    private Boolean isKeepIt;

    @JsonProperty("returnExpectedFlag")
    private Boolean returnExpectedFlag;

    @JsonProperty("quantity")
    private Quantity quantity;

    @JsonProperty("vendorID")
    private String vendorID;

    @JsonProperty("purchaseOrderNo")
    private String purchaseOrderNo;

    @JsonProperty("isDmbEnabled")
    private Boolean isDmbEnabled;

    @JsonProperty("fulfillByWalmart")
    private boolean fulfillByWalmart;

    @JsonProperty("isVariantReplacement")
    private Boolean isVariantReplacement;

    @JsonProperty("finalDisposition")
    private FinalDisposition finalDisposition;

    public Integer getLineNo() {
        return lineNo;
    }

    public void setLineNo(Integer lineNo) {
        this.lineNo = lineNo;
    }

    public Integer getSalesOrderLineId() {
        return salesOrderLineId;
    }

    public void setSalesOrderLineId(Integer salesOrderLineId) {
        this.salesOrderLineId = salesOrderLineId;
    }

    public Integer getSalesOrderLineNo() {
        return salesOrderLineNo;
    }

    public void setSalesOrderLineNo(Integer salesOrderLineNo) {
        this.salesOrderLineNo = salesOrderLineNo;
    }

    public String getReturnReason() {
        return returnReason;
    }

    public void setReturnReason(String returnReason) {
        this.returnReason = returnReason;
    }

    public String getReturnReasonDescription() {
        return returnReasonDescription;
    }

    public void setReturnReasonDescription(String returnReasonDescription) {
        this.returnReasonDescription = returnReasonDescription;
    }

    public String getEcommReasonCode() {
        return ecommReasonCode;
    }

    public void setEcommReasonCode(String ecommReasonCode) {
        this.ecommReasonCode = ecommReasonCode;
    }

    public OrderProduct getOrderProduct() {
        return orderProduct;
    }

    public void setOrderProduct(OrderProduct orderProduct) {
        this.orderProduct = orderProduct;
    }

    public Boolean getIsFastReplacement() {
        return isFastReplacement;
    }

    public void setIsFastReplacement(Boolean isFastReplacement) {
        this.isFastReplacement = isFastReplacement;
    }

    public Boolean getIsKeepIt() {
        return isKeepIt;
    }

    public void setIsKeepIt(Boolean isKeepIt) {
        this.isKeepIt = isKeepIt;
    }

    public Boolean getReturnExpectedFlag() {
        return returnExpectedFlag;
    }

    public void setReturnExpectedFlag(Boolean returnExpectedFlag) {
        this.returnExpectedFlag = returnExpectedFlag;
    }

    public Quantity getQuantity() {
        return quantity;
    }

    public void setQuantity(Quantity quantity) {
        this.quantity = quantity;
    }

    public String getVendorID() {
        return vendorID;
    }

    public void setVendorID(String vendorID) {
        this.vendorID = vendorID;
    }

    public String getPurchaseOrderNo() {
        return purchaseOrderNo;
    }

    public void setPurchaseOrderNo(String purchaseOrderNo) {
        this.purchaseOrderNo = purchaseOrderNo;
    }

    public Boolean getIsDmbEnabled() {
        return isDmbEnabled;
    }

    public void setIsDmbEnabled(Boolean isDmbEnabled) {
        this.isDmbEnabled = isDmbEnabled;
    }

    public boolean getFulfillByWalmart() {
        return fulfillByWalmart;
    }

    public void setFulfillByWalmart(boolean fulfillByWalmart) {
        this.fulfillByWalmart = fulfillByWalmart;
    }

    public Boolean getIsVariantReplacement() {
        return isVariantReplacement;
    }

    public void setIsVariantReplacement(Boolean isVariantReplacement) {
        this.isVariantReplacement = isVariantReplacement;
    }

    public FinalDisposition getFinalDisposition() {
        return finalDisposition;
    }

    public void setFinalDisposition(FinalDisposition finalDisposition) {
        this.finalDisposition = finalDisposition;
    }

    @Override
    public String toString() {
        return "ReturnOrderLine [" +
                       "lineNo=" + lineNo +
                       ", salesOrderLineId=" + salesOrderLineId +
                       ", salesOrderLineNo=" + salesOrderLineNo +
                       ", returnReason='" + returnReason + '\'' +
                       ", returnReasonDescription='" + returnReasonDescription + '\'' +
                       ", ecommReasonCode='" + ecommReasonCode + '\'' +
                       ", orderProduct=" + orderProduct +
                       ", isFastReplacement=" + isFastReplacement +
                       ", isKeepIt=" + isKeepIt +
                       ", returnExpectedFlag=" + returnExpectedFlag +
                       ", quantity=" + quantity +
                       ", vendorID='" + vendorID + '\'' +
                       ", purchaseOrderNo='" + purchaseOrderNo + '\'' +
                       ", isDmbEnabled=" + isDmbEnabled +
                       ", fulfillByWalmart=" + fulfillByWalmart +
                       ", isVariantReplacement=" + isVariantReplacement +
                       ", finalDisposition='" + finalDisposition + '\'' +
                       ']';
    }
}
