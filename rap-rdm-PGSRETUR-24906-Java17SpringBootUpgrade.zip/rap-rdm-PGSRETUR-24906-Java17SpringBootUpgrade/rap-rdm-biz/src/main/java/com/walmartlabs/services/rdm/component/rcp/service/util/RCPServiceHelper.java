package com.walmartlabs.services.rdm.component.rcp.service.util;

import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmartlabs.services.rdm.executors.RdmExecutorService;
import com.walmartlabs.services.rdm.component.iqs.service.utl.IQSServiceHelper;
import com.walmartlabs.services.rdm.component.rcp.model.request.GetItemDispositionDetailsRequest;
import com.walmartlabs.services.rdm.component.rcp.model.response.GetItemDispositionDetailsResponse;
import com.walmartlabs.services.rdm.config.client.RCPServiceConfig;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.text.MessageFormat;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Component
public class RCPServiceHelper {
    private static final Logger LOG = LoggerFactory.getLogger(IQSServiceHelper.class);

    @Resource
    @ManagedConfiguration
    private RCPServiceConfig rcpServiceConfig;

    @Resource
    private RCPHttpClient rcpClient;

    public CompletableFuture<GetItemDispositionDetailsResponse> triggerRcpServiceCall(GetItemDispositionDetailsRequest request) {

        CompletableFuture<GetItemDispositionDetailsResponse> getItemDispositionDetailsResponseFuture = CompletableFuture.supplyAsync(() -> rcpClient.getRcpItemDispositionPolicyDetails(request), RdmExecutorService.getExecutor());
        return getItemDispositionDetailsResponseFuture;
    }

    public GetItemDispositionDetailsResponse getRcpResponseFromFuture(CompletableFuture<GetItemDispositionDetailsResponse> itemDispositionDetailsResponseCompletableFuture, String itemId) {
        GetItemDispositionDetailsResponse getItemDispositionDetailsResponse = null;

        try {
            getItemDispositionDetailsResponse = itemDispositionDetailsResponseCompletableFuture.get(rcpServiceConfig.getRcpServiceApiTimeout(), TimeUnit.MILLISECONDS);;
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            String errorMsg =  MessageFormat.format("Rcp response fetch failed, itemId {0}, error {1}",
                    itemId, e.getMessage());
            LOG.error(errorMsg, e);
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.RCP_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        } catch (RDMException e) {
            // In case of Rdm Exception just log the error and throw same exception to parent level
            String errorMsg = MessageFormat.format("Rcp fetch failed Rdm Exception occurred, itemId {0}, error {1}",
                    itemId , e.getMessage());
            LOG.error(errorMsg, e);
            throw e;
        }
        return getItemDispositionDetailsResponse;
    }
}
