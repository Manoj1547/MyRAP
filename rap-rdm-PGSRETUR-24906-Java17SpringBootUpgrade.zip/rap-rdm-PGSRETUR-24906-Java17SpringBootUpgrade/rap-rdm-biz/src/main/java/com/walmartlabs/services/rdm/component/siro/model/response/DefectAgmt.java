package com.walmartlabs.services.rdm.component.siro.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DefectAgmt {
    @JsonProperty("claimFiledBy")
    private String claimFiledBy;

    @JsonProperty("claimPercent")
    private BigDecimal claimPercent;

    @JsonProperty("vndrShpmtOrigCd")
    private String vndrShpmtOrigCd;

    @JsonProperty("wmDiscretionInd")
    private String wmDiscretionInd;

    @JsonProperty("handlingFeeAmt")
    private BigDecimal handlingFeeAmt;

    public String getClaimFiledBy() {
        return claimFiledBy;
    }

    public void setClaimFiledBy(String claimFiledBy) {
        this.claimFiledBy = claimFiledBy;
    }

    public BigDecimal getClaimPercent() {
        return claimPercent;
    }

    public void setClaimPercent(BigDecimal claimPercent) {
        this.claimPercent = claimPercent;
    }

    public String getVndrShpmtOrigCd() {
        return vndrShpmtOrigCd;
    }

    public void setVndrShpmtOrigCd(String vndrShpmtOrigCd) {
        this.vndrShpmtOrigCd = vndrShpmtOrigCd;
    }

    public String getWmDiscretionInd() {
        return wmDiscretionInd;
    }

    public void setWmDiscretionInd(String wmDiscretionInd) {
        this.wmDiscretionInd = wmDiscretionInd;
    }

    public BigDecimal getHandlingFeeAmt() {
        return handlingFeeAmt;
    }

    public void setHandlingFeeAmt(BigDecimal handlingFeeAmt) {
        this.handlingFeeAmt = handlingFeeAmt;
    }
}
