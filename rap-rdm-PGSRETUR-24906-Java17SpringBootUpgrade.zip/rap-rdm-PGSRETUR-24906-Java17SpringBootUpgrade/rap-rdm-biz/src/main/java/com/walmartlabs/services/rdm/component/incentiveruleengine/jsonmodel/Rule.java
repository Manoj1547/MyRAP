package com.walmartlabs.services.rdm.component.incentiveruleengine.jsonmodel;
import java.util.List;

public class Rule implements Comparable<Rule>{

    public String ruleName;
    public String ruleBean;
    public List<String> eligibleChannels;
    public Integer priority;
    public String desc;
    public boolean isActive;

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }
    public List<String> getEligibleChannels() {
        return eligibleChannels;
    }

    public void setEligibleChannels(List<String> eligibleChannels) {
        this.eligibleChannels = eligibleChannels;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public String getRuleName() {
        return ruleName;
    }

    public void setRuleName(String ruleName) {
        this.ruleName = ruleName;
    }

    public String getRuleBean() {
        return ruleBean;
    }

    public void setRuleBean(String ruleBean) {
        this.ruleBean = ruleBean;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    @Override
    public int compareTo(Rule thatObj) {
        return Integer.compare(this.getPriority(),thatObj.getPriority());
    }
}
