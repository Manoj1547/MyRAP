package com.walmartlabs.services.rdm.model.formula;

import java.util.Map;
import java.util.Set;

import com.walmartlabs.services.rdm.model.ID;

/**
 * 
 * @author Tim Jin
 *
 */
public class Formula extends ID {

    private String              name;

    private String              formula;

    private FormulaType         formulaType;

    private ValueType           valueType;

    private String              description;

    private String              parallelGroup;

    private Set<String>         inputVariables;

    private Set<String>         outputVariables;

    private Map<String, String> properties;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFormula() {
        return formula;
    }

    public void setFormula(String formula) {
        this.formula = formula;
    }

    public FormulaType getFormulaType() {
        return formulaType;
    }

    public void setFormulaType(FormulaType formulaType) {
        this.formulaType = formulaType;
    }

    public ValueType getValueType() {
        return valueType;
    }

    public void setValueType(ValueType valueType) {
        this.valueType = valueType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getParallelGroup() {
        return parallelGroup;
    }

    public void setParallelGroup(String parallelGroup) {
        this.parallelGroup = parallelGroup;
    }

    public Set<String> getInputVariables() {
        return inputVariables;
    }

    public void setInputVariables(Set<String> inputVariables) {
        this.inputVariables = inputVariables;
    }

    public Set<String> getOutputVariables() {
        return outputVariables;
    }

    public void setOutputVariables(Set<String> outputVariables) {
        this.outputVariables = outputVariables;
    }

    public Map<String, String> getProperties() {
        return properties;
    }

    public void setProperties(Map<String, String> properties) {
        this.properties = properties;
    }

    public Formula() {
    }
}
