package com.walmartlabs.services.rdm.component.siro.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DefectiveAgreement {
    @JsonProperty("supDeptDefectAgmt")
    private DefectAgmt[] supDeptDefectAgmt;

    @JsonProperty("itemExcpDefectAgmt")
    private DefectAgmt[] itemExcpDefectAgmt;

    public DefectAgmt[] getSupDeptDefectAgmt() {
        return supDeptDefectAgmt;
    }

    public void setSupDeptDefectAgmt(DefectAgmt[] supDeptDefectAgmt) {
        this.supDeptDefectAgmt = supDeptDefectAgmt;
    }

    public DefectAgmt[] getItemExcpDefectAgmt() {
        return itemExcpDefectAgmt;
    }

    public void setItemExcpDefectAgmt(DefectAgmt[] itemExcpDefectAgmt) {
        this.itemExcpDefectAgmt = itemExcpDefectAgmt;
    }
}
