package com.walmartlabs.services.rdm.component.iqs.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OfferInfo {
    @JsonProperty("offer")
    private Offer offer;

    @JsonProperty("pricing")
    private List<Pricing> pricing;

    @JsonProperty("limo")
    private Limo limo;

    public Offer getOffer() {
        return offer;
    }

    public void setOffer(Offer offer) {
        this.offer = offer;
    }

    public List<Pricing> getPricing() {
        return this.pricing;
    }

    public void setPricing(List<Pricing> pricing) {
        this.pricing = pricing;
    }

    public Limo getLimo() {
        return limo;
    }

    public void setLimo(Limo limo) {
        this.limo = limo;
    }
}
