package com.walmartlabs.services.rdm.formula.impl.java.iqs.sub;

import java.text.MessageFormat;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.walmartlabs.services.rdm.component.iqs.model.response.*;
import com.walmartlabs.services.rdm.component.iqs.service.utl.IQSHttpClient;
import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import com.walmartlabs.services.rdm.formula.*;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.formula.Formula;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.apache.commons.lang.BooleanUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

/**
 * 
 * @author Tim Jin
 *
 */

public abstract class IQSSubDataResolver implements JavaEngineClass {

    abstract String[] getRT();

    @Resource
    IQSHttpClient iqsClient;



    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {

        BaseItem item = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);
        RDMSwitches switches = this.getRDMSwitches();
           if(switches.getNewIQSResponse()){

               return item;
        }


        GetItemDetailsResponse iqsResponse = iqsClient.getItemDetails(item.getGtin(), getRT());

        /*Validate IQS response for mandatory fields*/
        if(BooleanUtils.isTrue(switches.getExternalServiceResponseValidationEnabled())) {
            validateRequiredFields(iqsResponse, item);
        }
        return iqsResponse;
    }

    /**
     * Validates the availability of fields that are used in formulas later.
     */
    public void validateRequiredFields(GetItemDetailsResponse iqsResponse, BaseItem item) {
        List<OfferInfo> offers = iqsResponse.getOffers();

        if(StringUtils.isEmpty(iqsResponse.getItemId())) {
            throw new FormulaException(MessageFormat.format("Item ID not available in IQS Response for item(OFFERID={0})", item.getOfferId()));
        }

        if(CollectionUtils.isEmpty(offers)) {
            throw new FormulaException(MessageFormat.format("No Offers available in IQS Response for item(OFFERID={0})", item.getOfferId()));
        } else {
            for(OfferInfo offerInfo : offers) {
                if(ObjectUtils.isEmpty(offerInfo) || ObjectUtils.isEmpty(offerInfo.getOffer())) {
                    throw new FormulaException(MessageFormat.format("OfferInfo not available in IQS Response for item(OFFERID={0})", item.getOfferId()));
                } else {
                    Limo limo = offerInfo.getLimo();
                    List<Pricing> pricing = offerInfo.getPricing();
                    if(ObjectUtils.isEmpty(limo) || ObjectUtils.isEmpty(limo.getLogisticsOffer())) {
                        throw new FormulaException(MessageFormat.format("Limo details not available in IQS Response for item(OFFERID={0})", item.getOfferId()));
                    }
                    if(ObjectUtils.isEmpty(limo.getLogisticsOffer().getProductPackageDimensions())
                            || ObjectUtils.isEmpty(limo.getLogisticsOffer().getProductPackageDimensions().get(0))
                            || ObjectUtils.isEmpty(limo.getLogisticsOffer().getProductPackageDimensions().get(0).getUnitHeight())
                            || ObjectUtils.isEmpty(limo.getLogisticsOffer().getProductPackageDimensions().get(0).getUnitLength())
                            || ObjectUtils.isEmpty(limo.getLogisticsOffer().getProductPackageDimensions().get(0).getUnitWidth())
                            || ObjectUtils.isEmpty(limo.getLogisticsOffer().getProductPackageDimensions().get(0).getUnitWeight())) {
                        throw new FormulaException(MessageFormat.format("Product Dimensions not available in IQS Response for item(OFFERID={0})", item.getOfferId()));
                    }

                    if(ObjectUtils.isEmpty(limo.getLogisticsOffer().getFlagAttributes())
                            || ObjectUtils.isEmpty(limo.getLogisticsOffer().getFlagAttributes().getHazmat())) {
                        throw new FormulaException(MessageFormat.format("Hazmat information not available in IQS Response for item(OFFERID={0})", item.getOfferId()));
                    }

                    if(StringUtils.isEmpty(offerInfo.getOffer().getSellerId())) {
                        throw new FormulaException(MessageFormat.format("Seller ID not available in IQS Response for item(OFFERID={0})", item.getOfferId()));
                    }

                    if(StringUtils.isEmpty(offerInfo.getOffer().getOfferType())) {
                        throw new FormulaException(MessageFormat.format("Offer Type not available in IQS Response for item(OFFERID={0})", item.getOfferId()));
                    }

                    if(ObjectUtils.isEmpty(pricing) || ObjectUtils.isEmpty(pricing.get(0))) {
                        throw new FormulaException(MessageFormat.format("Pricing Information not available in IQS Response for item(OFFERID={0})", item.getOfferId()));
                    }
                    if(ObjectUtils.isEmpty(pricing.get(0).getStorefrontPricingList())
                            || ObjectUtils.isEmpty(pricing.get(0).getStorefrontPricingList().get(0).getCurrentPrice())
                            || ObjectUtils.isEmpty(pricing.get(0).getStorefrontPricingList().get(0).getCurrentPrice().getCurrentValue())) {
                        throw new FormulaException(MessageFormat.format("Pricing Information not available in IQS Response for item(OFFERID={0})", item.getOfferId()));
                    }

                }
            }
        }

        /*R2D2*/
        if(ObjectUtils.isEmpty(iqsResponse.getProduct())
                || ObjectUtils.isEmpty(iqsResponse.getProduct().getDerivedAttributes())
                || ObjectUtils.isEmpty(iqsResponse.getProduct().getDerivedAttributes().getR2D2Hierarchy())
                || ObjectUtils.isEmpty(iqsResponse.getProduct().getDerivedAttributes().getR2D2Hierarchy().getValues())
                || ObjectUtils.isEmpty(iqsResponse.getProduct().getDerivedAttributes().getR2D2Hierarchy().getValues().get(0).getPath())) {

            throw new FormulaException(MessageFormat.format("R2D2 hierarchy not available in IQS Response for item(OFFERID={0})", item.getOfferId()));
        }

    }

    public  abstract RDMSwitches getRDMSwitches();


}
