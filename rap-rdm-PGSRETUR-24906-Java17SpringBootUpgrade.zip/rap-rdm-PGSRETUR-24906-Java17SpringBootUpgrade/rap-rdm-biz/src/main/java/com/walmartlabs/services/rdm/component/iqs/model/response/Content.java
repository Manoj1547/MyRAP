package com.walmartlabs.services.rdm.component.iqs.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Content {
    @JsonProperty("attributes")
    private StoreAttribute attributes;

    @JsonProperty("siAttributes")
    private List<SiAttribute> siAttributes;

    public StoreAttribute getAttributes() { return attributes; }

    public void setAttributes(StoreAttribute attributes) { this.attributes = attributes; }

    public List<SiAttribute> getSiAttributes() { return siAttributes; }

    public void setSiAttributes(List<SiAttribute> siAttributes) { this.siAttributes = siAttributes; }

}
