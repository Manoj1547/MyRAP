package com.walmartlabs.services.rdm.component.apollorestock.jsonmodel;

public class Rule implements Comparable<Rule>{
    public String ruleName;
    public String ruleBean;
    public String desc;
    public boolean isActive;
    public int priority;
    public RuleCondition ruleCondition;

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public String getRuleName() {
        return ruleName;
    }

    public void setRuleName(String ruleName) {
        this.ruleName = ruleName;
    }

    public String getRuleBean() {
        return ruleBean;
    }

    public void setRuleBean(String ruleBean) {
        this.ruleBean = ruleBean;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public RuleCondition getRuleCondition() {
        return ruleCondition;
    }

    public void setRuleCondition(RuleCondition ruleCondition) {
        this.ruleCondition = ruleCondition;
    }

    @Override
    public int compareTo(Rule thatObj){
        if(this.getPriority() > thatObj.getPriority()){
            return 1;
        } else if(this.getPriority() < thatObj.getPriority()){
            return -1;
        } else{
            return 0;
        }
    }
}
