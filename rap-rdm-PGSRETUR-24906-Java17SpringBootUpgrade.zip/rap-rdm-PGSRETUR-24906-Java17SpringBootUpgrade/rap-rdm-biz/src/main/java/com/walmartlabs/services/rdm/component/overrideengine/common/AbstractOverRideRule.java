package com.walmartlabs.services.rdm.component.overrideengine.common;


public abstract class AbstractOverRideRule {

    public abstract boolean runRule(IRuleEngineContext ruleEngineContext);

    public abstract void applyRuleDecision(IRuleEngineContext ruleEngineContext);

    public abstract String getRuleName();




}
