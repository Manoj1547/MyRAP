package com.walmartlabs.services.rdm.model;

public class DamagedItemKeepItRuleCategory {

    private String categoryName;
    private boolean enabled;
    private DamagedItemKeepItRuleCategoryThreshold threshold;

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public DamagedItemKeepItRuleCategoryThreshold getThreshold() {
        return threshold;
    }

    public void setThreshold(DamagedItemKeepItRuleCategoryThreshold threshold) {
        this.threshold = threshold;
    }

    @Override
    public String toString() {
        return "DamagedItemRuleCategory{" +
                "categoryName='" + categoryName + '\'' +
                ", enabled=" + enabled +
                ", threshold=" + threshold +
                '}';
    }
}
