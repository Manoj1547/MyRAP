package com.walmartlabs.services.rdm.model.formula;

/**
 * 
 * @author Tim Jin
 *
 */
public enum ValueType {
    BOOLEAN, DOUBLE, INTEGER, STRING, OBJECT
}
