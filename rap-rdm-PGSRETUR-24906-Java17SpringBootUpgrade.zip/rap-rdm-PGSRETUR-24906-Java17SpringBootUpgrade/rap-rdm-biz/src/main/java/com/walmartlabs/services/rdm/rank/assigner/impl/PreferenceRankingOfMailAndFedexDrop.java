package com.walmartlabs.services.rdm.rank.assigner.impl;


import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import com.walmartlabs.services.rdm.rank.assigner.RankAssigner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;


@Component
public class PreferenceRankingOfMailAndFedexDrop extends RankAssigner {

    private static final Logger LOG = LoggerFactory.getLogger(PreferenceRankingOfMailAndFedexDrop.class);

    @Override
    protected void assignRanks(List<DispositionInfo> allItemsDispositionInfoList) {
        /*
         resAssignRanks to dispositionPaths which has same formulas and values but different priorities.
         */
        for (DispositionInfo dispositionInfo : allItemsDispositionInfoList) {
            if (null != dispositionInfo.getDispositionPaths() && !dispositionInfo.getDefault()) {
                int count = 0;
                DispositionPath fedexDropDispositionPath = null;
                DispositionPath mailDispositionPath = null;
                for (DispositionPath dispositionPath : dispositionInfo.getDispositionPaths()) {

                    if(RDMConstants.DISPOSITION_PATH_FEDEX_DROP.equals(dispositionPath.getPath())) {
                        fedexDropDispositionPath = dispositionPath;
                        count++;
                    } else if(RDMConstants.DISPOSITION_PATH_MAIL.equals(dispositionPath.getPath())) {
                        mailDispositionPath = dispositionPath;
                        count++;
                    }
                    /*
                     * If Mail has greater rank then Fedex_Drop and recovery value is same
                     * then their ranks will be swapped.
                     */
                    if (count == 2 && null != fedexDropDispositionPath && null != mailDispositionPath &&
                            fedexDropDispositionPath.getRank() > mailDispositionPath.getRank() &&
                            null != fedexDropDispositionPath.getValue() &&
                            fedexDropDispositionPath.getValue().equals(mailDispositionPath.getValue())) {

                        int tempRank = fedexDropDispositionPath.getRank();
                        fedexDropDispositionPath.setRank(mailDispositionPath.getRank());
                        mailDispositionPath.setRank(tempRank);
                        LOG.info("RankAssigner Swapped Fedex_Drop and Mail Ranks for orderNo:{}, itemId:{}, channel:{}",
                                dispositionInfo.getItem().getOrderNo(), dispositionInfo.getItem().getItemId(),
                                dispositionInfo.getItem().getChannelName());
                        break;
                    }

                }
            }
        }
    }
}
