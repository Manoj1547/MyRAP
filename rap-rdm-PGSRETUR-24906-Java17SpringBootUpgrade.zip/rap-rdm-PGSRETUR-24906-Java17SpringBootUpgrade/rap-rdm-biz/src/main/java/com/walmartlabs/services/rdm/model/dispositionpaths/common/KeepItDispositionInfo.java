package com.walmartlabs.services.rdm.model.dispositionpaths.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author g0b02hs
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class KeepItDispositionInfo extends KeepItInfo {

    private Double  recoveryValue;

    private Boolean isDefault;

    private boolean isTrustCustomerDefault;

    private boolean isItemKeepItDefault;

    public Double getRecoveryValue() {
        return recoveryValue;
    }

    public void setRecoveryValue(Double recoveryValue) {
        this.recoveryValue = recoveryValue;
    }

    public Boolean getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(Boolean aDefault) {
        this.isDefault = aDefault;
    }

    public boolean getIsTrustCustomerDefault() {
        return isTrustCustomerDefault;
    }

    public void setIsTrustCustomerDefault(boolean isTrustCustomerDefault) {
        this.isTrustCustomerDefault = isTrustCustomerDefault;
    }

    public boolean getIsItemKeepItDefault() {
        return isItemKeepItDefault;
    }

    public void setIsItemKeepItDefault(boolean isItemKeepItDefault) {
        this.isItemKeepItDefault = isItemKeepItDefault;
    }

    public KeepItDispositionInfo() {
    }
}
