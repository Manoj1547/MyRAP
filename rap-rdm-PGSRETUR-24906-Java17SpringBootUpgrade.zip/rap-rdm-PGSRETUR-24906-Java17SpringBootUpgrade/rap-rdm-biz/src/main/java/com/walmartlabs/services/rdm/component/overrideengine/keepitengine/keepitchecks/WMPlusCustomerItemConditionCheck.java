package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component("wmPlusCustomerItemConditionCheck")
public class WMPlusCustomerItemConditionCheck implements IRDMKeepItRuleCheck {

    private static final Logger LOG = LoggerFactory.getLogger(WMPlusCustomerItemConditionCheck.class);


    @Override
    public String getKeepItCheckName() {
        String keepItRuleCheckName = RDMConstants.RULE_CHECK_NAME_WMPLUS_CUST_ITEM_CONDITION_CHECK;
        return keepItRuleCheckName;
    }

    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {
        LOG.debug("WMPlusCustomerItemConditionCheck.runCheck() started");

        BaseItem item = keepItRuleEngineContext.getItem();

        boolean isItemKeepItBasedOnCondition = RDMConstants.ITEM_CONDITION_DAMAGED.equals(item.getItemCondition());

        LOG.debug("WMPlusCustomerItemConditionCheck.runCheck() exited");
        return isItemKeepItBasedOnCondition;
    }
}
