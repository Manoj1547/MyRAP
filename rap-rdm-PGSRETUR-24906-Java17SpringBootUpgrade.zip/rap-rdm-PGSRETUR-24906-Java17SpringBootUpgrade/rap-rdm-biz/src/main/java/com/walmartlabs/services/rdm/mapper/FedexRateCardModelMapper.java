package com.walmartlabs.services.rdm.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.walmartlabs.services.rdm.domain.model.FedexRateCardDO;
import com.walmartlabs.services.rdm.model.fedexratecard.FedexRateCard;

/**
 * 
 * @author Tim Jin
 *
 */
@Mapper(componentModel = "spring")
public interface FedexRateCardModelMapper {

    FedexRateCardModelMapper INSTANCE = Mappers.getMapper(FedexRateCardModelMapper.class);

    public FedexRateCard map(FedexRateCardDO model);

    public List<FedexRateCard> map(List<FedexRateCardDO> modelList);

}
