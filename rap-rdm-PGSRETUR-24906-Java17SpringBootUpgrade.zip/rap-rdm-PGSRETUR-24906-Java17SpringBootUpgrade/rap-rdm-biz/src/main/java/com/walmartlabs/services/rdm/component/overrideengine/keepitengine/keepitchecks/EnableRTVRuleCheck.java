package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.model.SellerType;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.stereotype.Component;


@Component("enableRTVRuleCheck")
public class EnableRTVRuleCheck implements IRDMKeepItRuleCheck{

    @ManagedConfiguration
    private RDMKeepItConfig rdmKeepItConfig;
    @Override
    public String getKeepItCheckName() {
        return RDMConstants.ENABLE_RTV_RULE_CHECK;
    }

    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {
        return rdmKeepItConfig.getEnableRTVCheck() && SellerType.WM.equals(keepItRuleEngineContext.getItem().getSellerType());
    }
}
