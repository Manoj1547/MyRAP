package com.walmartlabs.services.rdm.component.incentiveruleengine.incentiverules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.incentiveruleengine.model.ReturnIncentiveEngineContext;
import com.walmartlabs.services.rdm.component.incentiveruleengine.util.AbstractReturnIncentiveRule;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.walmartlabs.services.rdm.RDMConstants.CCA_RETURN_TO_STORE_PATH;
import static com.walmartlabs.services.rdm.RDMConstants.MYACCOUNT_STORE_PATH;

@Component("itemNonKeepItRule")
public class ItemNonKeepItRule extends AbstractReturnIncentiveRule{

    @Override
    public boolean runReturnIncentiveRule(ReturnIncentiveEngineContext returnIncentiveEngineContext) {
        DispositionInfo dispositionInfo = returnIncentiveEngineContext.getDispositionInfo();
        List<DispositionPath> dispositionPaths = dispositionInfo.getDispositionPaths();

        for(DispositionPath dispositionPath: dispositionPaths)
        {
            if(CCA_RETURN_TO_STORE_PATH.equals(dispositionPath.getPath()) || MYACCOUNT_STORE_PATH.equals(dispositionPath.getPath()))
            {
                if(dispositionPath.getKeepIt() != null && dispositionPath.getKeepIt())
                {
                    return !Boolean.TRUE.equals(dispositionPath.getKeepIt());
                }
            }
        }

        return true;
    }

    @Override
    public String getRuleName() {
        return RDMConstants.RULE_NAME_ITEM_NON_KEEP_IT;
    }
}
