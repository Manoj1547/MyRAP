package com.walmartlabs.services.rdm.formula.impl.java.eligibility.util;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.ReturnMode;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.ReturnModesInfo;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * Author: v0s00g0
 */
public class ReturnModeCheckerUtil {

    public static boolean checkReturnModeEligibility(BaseItem item, String returnModeNameToCheck, String returnRequestType) {
        boolean isReturnAllowedForMode = false;
        boolean isReplacementAllowedForMode = false;
        ReturnModesInfo returnModeInfo = item.getReturnModesInfo();
        if(returnModeInfo != null && CollectionUtils.isNotEmpty(returnModeInfo.getReturnModes())){
            for(ReturnMode returnMode : returnModeInfo.getReturnModes()){
                if(returnModeNameToCheck.equals(returnMode.getName())){
                    isReturnAllowedForMode = returnMode.isReturnAllowed();
                    isReplacementAllowedForMode = returnMode.isReplacementAllowed();
                    break;
                }
            }
        }

        //If return request type is empty check eligibility for refund or replacement any
        if(StringUtils.isEmpty(returnRequestType)){
            returnRequestType = RDMConstants.RETURN_REQUEST_TYPE_REFUND_OR_REPLACEMENT;
        }
        switch (returnRequestType) {
            case RDMConstants.RETURN_REQUEST_TYPE_REFUND:
                return isReturnAllowedForMode;
            case RDMConstants.RETURN_REQUEST_TYPE_REPLACEMENT:
                return isReplacementAllowedForMode;
            case RDMConstants.RETURN_REQUEST_TYPE_REFUND_OR_REPLACEMENT:
                return (isReturnAllowedForMode || isReplacementAllowedForMode);
            case RDMConstants.RETURN_REQUEST_TYPE_REFUND_AND_REPLACEMENT:
                return (isReturnAllowedForMode && isReplacementAllowedForMode);
            default:
                return false;
        }
    }
}
