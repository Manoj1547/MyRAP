package com.walmartlabs.services.rdm.model.dispositionpaths.common;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.walmart.services.common.model.money.MoneyType;
import com.walmartlabs.services.rdm.dto.Quantity;
import com.walmartlabs.services.rdm.dto.dispositionpaths.common.DispositionPath;
import com.walmartlabs.services.rdm.dto.dispositionpaths.common.PartialKeepIt;
import com.walmartlabs.services.rdm.model.Base;
import com.walmartlabs.services.rdm.model.SellerType;

/**
 * 
 * @author Tim Jin
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BaseItem extends Base {

    private String              storeId;

    private String              channelName;

    private String              gtin;

    private String              upc;

    private String              offerId;

    private String              itemCondition;

    private String              orderNo;

    private Quantity            quantity;

    private Boolean             storeReturnEligibility;

    private boolean             simulation;

    @JsonIgnore
    private Map<String, Object> variableOverrides;

    private int                 itemSize;

    private KeepItInfo          keepItInfo;

    /**
     * Adding all Item fields to this
     */
    private String                itemId;

    private String                orderLineNo;

    private String                returnReason;

    private String                zipCode;

    private String                customerId;

    private String                smartLabelId;

    private List<DispositionPath> dispositionPaths;

    private boolean isWalmartPlusCustomer;

    private String fulfillmentType;

    @JsonProperty("sellerType")
    private SellerType sellerType;

    @JsonProperty("returnModesInfo")
    private ReturnModesInfo returnModesInfo;

    @JsonProperty("returnRequestType")
    private String returnRequestType;

    @JsonProperty("trustCustomerToIncentive")
    private boolean trustCustomerToIncentive;

    @JsonProperty("lineRefundAmount")
    private Double                           lineRefundAmount;

    @JsonProperty("unitPrice")
    private MoneyType unitPrice;

    @JsonProperty("departmentNo")
    private String departmentNo;

    @JsonProperty("itemCustomAttributes")
    private Map<String,String> itemCustomAttributes;

    @JsonProperty("faultCategory")
    private String faultCategory;

    @JsonProperty("productType")
    private String productType;

    @JsonProperty("sellerPreference")
    private SellerPreference sellerPreference;

    @JsonProperty("sellerId")
    private String sellerId;

    @JsonProperty("partialKeepIt")
    private PartialKeepIt partialKeepIt;

    @JsonProperty("refNumber")
    private String refNumber;
    @JsonProperty("isGep")
    private boolean isGep;

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    @JsonProperty("countryCode")
    private String countryCode;

    public boolean isGep() {
        return isGep;
    }

    public void setGep(boolean gep) {
        this.isGep = gep;
    }



    public PartialKeepIt getPartialKeepIt() {
        return partialKeepIt;
    }

    public void setPartialKeepIt(PartialKeepIt partialKeepIt) {
        this.partialKeepIt = partialKeepIt;
    }

    public String getSellerId() {
        return sellerId;
    }

    public void setSellerId(String sellerId) {
        this.sellerId = sellerId;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getFaultCategory() {
        return faultCategory;
    }

    public void setFaultCategory(String faultCategory) {
        this.faultCategory = faultCategory;
    }

    public SellerType getSellerType() {
        return sellerType;
    }

    public void setSellerType(SellerType sellerType) {
        this.sellerType = sellerType;
    }

    public SellerPreference getSellerPreference() {
        return sellerPreference;
    }

    public void setSellerPreference(SellerPreference sellerPreference) {
        this.sellerPreference = sellerPreference;
    }


    public Map<String, String> getItemCustomAttributes() {
        return itemCustomAttributes;
    }

    public void setItemCustomAttributes(Map<String, String> itemCustomAttributes) {
        this.itemCustomAttributes = itemCustomAttributes;
    }

    public String getDepartmentNo() {
        return departmentNo;
    }

    public void setDepartmentNo(String departmentNo) {
        this.departmentNo = departmentNo;
    }


    public MoneyType getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(MoneyType unitPrice) {
        this.unitPrice = unitPrice;
    }


    public Double getLineRefundAmount() {
        return lineRefundAmount;
    }

    public void setLineRefundAmount(Double lineRefundAmount) {
        this.lineRefundAmount = lineRefundAmount;
    }

    private String rdmApiCallerName;

    public String getRdmApiCallerName() {
        return rdmApiCallerName;
    }

    public void setRdmApiCallerName(String rdmApiCallerName) {
        this.rdmApiCallerName = rdmApiCallerName;
    }



    public boolean isTrustCustomerToIncentive() {
        return trustCustomerToIncentive;
    }

    public void setTrustCustomerToIncentive(boolean trustCustomerToIncentive) {
        this.trustCustomerToIncentive = trustCustomerToIncentive;
    }


    @JsonProperty("cvpEligible")
    private Boolean cvpEligible;

    public Boolean getCvpEligible() {
        return cvpEligible;
    }

    public void setCvpEligible(Boolean cvpEligible) {
        this.cvpEligible = cvpEligible;
    }

    public String getReturnRequestType() {
        return returnRequestType;
    }

    public void setReturnRequestType(String returnRequestType) {
        this.returnRequestType = returnRequestType;
    }

    public ReturnModesInfo getReturnModesInfo() {
        return returnModesInfo;
    }

    public void setReturnModesInfo(ReturnModesInfo returnModesInfo) {
        this.returnModesInfo = returnModesInfo;
    }

    public String getFulfillmentType() {
        return fulfillmentType;
    }

    public void setFulfillmentType(String fulfillmentType) {
        this.fulfillmentType = fulfillmentType;
    }

    public boolean isWalmartPlusCustomer() {
        return isWalmartPlusCustomer;
    }

    public void setWalmartPlusCustomer(boolean walmartPlusCustomer) {
        isWalmartPlusCustomer = walmartPlusCustomer;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getGtin() {
        return gtin;
    }

    public void setGtin(String gtin) {
        this.gtin = gtin;
    }

    public String getUpc() {
        return upc;
    }

    public void setUpc(String upc) {
        this.upc = upc;
    }

    public String getOfferId() {
        return offerId;
    }

    public void setOfferId(String offerId) {
        this.offerId = offerId;
    }

    public String getItemCondition() {
        return itemCondition;
    }

    public void setItemCondition(String itemCondition) {
        this.itemCondition = itemCondition;
    }

    public Quantity getQuantity() {
        return quantity;
    }

    public void setQuantity(Quantity quantity) {
        this.quantity = quantity;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public Boolean getStoreReturnEligibility() {
        return storeReturnEligibility;
    }

    public void setStoreReturnEligibility(Boolean storeReturnEligibility) {
        this.storeReturnEligibility = storeReturnEligibility;
    }

    public boolean isSimulation() {
        return simulation;
    }

    public void setSimulation(boolean simulation) {
        this.simulation = simulation;
    }

    public Map<String, Object> getVariableOverrides() {
        return variableOverrides;
    }

    public void setVariableOverrides(Map<String, Object> variableOverrides) {
        this.variableOverrides = variableOverrides;
    }

    public int getItemSize() {
        return itemSize;
    }

    public void setItemSize(int itemSize) {
        this.itemSize = itemSize;
    }

    public KeepItInfo getKeepItInfo() {
        return keepItInfo;
    }

    public void setKeepItInfo(KeepItInfo keepItInfo) {
        this.keepItInfo = keepItInfo;
    }


    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getOrderLineNo() {
        return orderLineNo;
    }

    public void setOrderLineNo(String orderLineNo) {
        this.orderLineNo = orderLineNo;
    }

    public String getReturnReason() {
        return returnReason;
    }

    public void setReturnReason(String returnReason) {
        this.returnReason = returnReason;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getSmartLabelId() {
        return smartLabelId;
    }

    public void setSmartLabelId(String smartLabelId) {
        this.smartLabelId = smartLabelId;
    }

    public List<DispositionPath> getDispositionPaths() {
        return dispositionPaths;
    }

    public void setDispositionPaths(List<DispositionPath> dispositionPaths) {
        this.dispositionPaths = dispositionPaths;
    }


    public BaseItem() {
    }

    public String getRefNumber() {
        return refNumber;
    }

    public void setRefNumber(String refNumber) {
        this.refNumber = refNumber;
    }
}