package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.exception;

import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;


public class KeepItRuleEngineException extends RDMException {

    public KeepItRuleEngineException(ApplicationLayer applicationLayer, ErrorCodeMapping errorCode, String message, Throwable cause) {
        super(applicationLayer, errorCode, message, cause);
    }

    public KeepItRuleEngineException(ApplicationLayer applicationLayer, ErrorCodeMapping errorCode, String errorMsg) {
        super(applicationLayer, errorCode, errorMsg);
    }
}
