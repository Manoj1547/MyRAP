package com.walmartlabs.services.rdm.util;

import com.walmartlabs.services.rdm.domain.model.ProductTypeCategoryDO;
import com.walmartlabs.services.rdm.model.CategoryType;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ProductTypeUtil {

    private static HashMap<String, Integer> rowHeaderMap = new HashMap<>();

    private static final String PRODUCT_TYPE = "prod_type_nm";

    private static final String CATEGORY = "Group";

    private static final DataFormatter dataFormatter = new DataFormatter();

    private static final Logger LOG = LoggerFactory.getLogger(ProductTypeUtil.class);


    public static List<ProductTypeCategoryDO> readFile(String filePath) throws FileNotFoundException {
        List<ProductTypeCategoryDO> productTypeCategoryDOList = new ArrayList<>();
        FileInputStream excelFile = new FileInputStream(new File(filePath));
        int counter = 1;

        try (Workbook workbook = WorkbookFactory.create(excelFile)) {
            Sheet excelSheet = workbook.getSheetAt(0);
            populateRowHeaderMap(excelSheet);
            while(productTypeCategoryDOList.size() < excelSheet.getPhysicalNumberOfRows() - 1) {
                Row row = excelSheet.getRow(counter);
                counter++;
                if(null != row) {
                    ProductTypeCategoryDO entity = createRequestObject(row);
                    if (StringUtils.isNotEmpty(entity.getProductType()) && null != entity.getCategory()) {
                        productTypeCategoryDOList.add(entity);
                    }
                }
            }
            return productTypeCategoryDOList;
        } catch (Exception e) {
            LOG.error("Error at row no: {}", counter);
            throw new RuntimeException(e);
        }
    }

    private static void populateRowHeaderMap(Sheet excelSheet) {
        Row rowHeader = excelSheet.getRow(0);

        for(int cellNum=0; cellNum<rowHeader.getPhysicalNumberOfCells(); cellNum++){
            String cellValue = StringUtils.trim(dataFormatter.formatCellValue(rowHeader.getCell(cellNum)));
            rowHeaderMap.put(cellValue,cellNum);
        }
    }

    public static ProductTypeCategoryDO createRequestObject(Row row) {
        ProductTypeCategoryDO entity = new ProductTypeCategoryDO();

        String cellValue = StringUtils.trim(dataFormatter.formatCellValue(row.getCell(rowHeaderMap.get(PRODUCT_TYPE))));
        entity.setProductType(cellValue);

        cellValue = StringUtils.trim(dataFormatter.formatCellValue(row.getCell(rowHeaderMap.get(CATEGORY))));
        if(StringUtils.isNotEmpty(cellValue)) {
            entity.setCategory(CategoryType.valueOf(cellValue));
        }
        return entity;
    }
}
