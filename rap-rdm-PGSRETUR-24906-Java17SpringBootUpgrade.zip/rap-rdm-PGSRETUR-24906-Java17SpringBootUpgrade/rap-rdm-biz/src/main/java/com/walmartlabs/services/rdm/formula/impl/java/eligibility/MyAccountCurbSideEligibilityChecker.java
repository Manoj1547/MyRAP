package com.walmartlabs.services.rdm.formula.impl.java.eligibility;

import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.formula.impl.java.eligibility.util.ReturnModeCheckerUtil;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.formula.Formula;
import org.springframework.stereotype.Service;

import java.util.Map;

import static com.walmartlabs.services.rdm.RDMConstants.RETURN_MODE_CURBSIDE;

@Service
public class MyAccountCurbSideEligibilityChecker implements JavaEngineClass {
    @Override
    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        BaseItem item = FormulaEngine.getNotNullInput(formula, inputData,
                FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);

        //Eligibility Check based on Return Mode
        boolean isReturnModeAllowed = ReturnModeCheckerUtil.checkReturnModeEligibility(
                item, RETURN_MODE_CURBSIDE, item.getReturnRequestType());

        return isReturnModeAllowed;
    }
}
