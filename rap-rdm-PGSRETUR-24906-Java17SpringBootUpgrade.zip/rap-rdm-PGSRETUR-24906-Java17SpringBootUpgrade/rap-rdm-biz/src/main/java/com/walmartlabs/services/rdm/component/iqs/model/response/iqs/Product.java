package com.walmartlabs.services.rdm.component.iqs.model.response.iqs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Product {
    private String productName;
    @JsonProperty(value = "r2d2")
    private R2D2Info reD2Info;

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public R2D2Info getReD2Info() {
        return reD2Info;
    }

    public void setReD2Info(R2D2Info reD2Info) {
        this.reD2Info = reD2Info;
    }
}
