package com.walmartlabs.services.rdm.model;

/**
 * 
 * @author Tim Jin
 *
 */
public enum NodeFormulaType {
    ELIGIBILITY, VALUE
}
