package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import org.springframework.stereotype.Component;

import java.util.Map;

import static com.walmartlabs.services.rdm.RDMConstants.*;

/**
 * @author v0s00g0
 */
@Component("isVisionRxItem")
public class IsVisionRxItem implements IRDMKeepItRuleCheck{


    @Override
    public String getKeepItCheckName() {
        return RDMConstants.RULE_CHECK_NAME_IS_VISION_RX_ITEM;
    }

    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {
        Map<String,String> itemCustomAttributes = keepItRuleEngineContext.getItem().getItemCustomAttributes();
        return (null != itemCustomAttributes && Boolean.parseBoolean(itemCustomAttributes.get(CONFIG_BUNDLE_VISION_RX)));
    }
}
