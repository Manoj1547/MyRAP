package com.walmartlabs.services.rdm.component.ls.model.newls;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PrefStoreResponse {

    @JsonProperty("assortment")
    private Assortment assortment;

    public Assortment getAssortment() {
        return assortment;
    }

    public void setAssortment(Assortment assortment) {
        this.assortment = assortment;
    }

    @Override
    public String toString() {
        return "{" +
                "assortment=" + assortment +
                '}';
    }
}
