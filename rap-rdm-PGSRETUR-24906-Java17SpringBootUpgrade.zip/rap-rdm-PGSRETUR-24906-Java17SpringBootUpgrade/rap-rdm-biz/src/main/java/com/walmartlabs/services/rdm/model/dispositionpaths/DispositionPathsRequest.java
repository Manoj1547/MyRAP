
package com.walmartlabs.services.rdm.model.dispositionpaths;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.walmartlabs.services.rdm.model.Base;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.ChannelInfo;

/**
 * 
 * @author Tim Jin
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DispositionPathsRequest extends Base {

    private String      orderNo;

    private String      returnRefNumber;

    private String      customerId;

    private List<Item>  items;

    private ChannelInfo channelInfo;

    private boolean isWalmartPlusCustomer;

    private boolean trustCustomerToIncentive;

    private String rdmCallerApiName;

    public boolean isGep() {
        return isGep;
    }

    public void setGep(boolean gep) {
        isGep = gep;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    private boolean isGep;

    private String countryCode;

    public String getRdmCallerApiName() {
        return rdmCallerApiName;
    }

    public void setRdmCallerApiName(String rdmCallerApiName) {
        this.rdmCallerApiName = rdmCallerApiName;
    }


    public boolean isTrustCustomerToIncentive() {
        return trustCustomerToIncentive;
    }

    public void setTrustCustomerToIncentive(boolean trustCustomerToIncentive) {
        this.trustCustomerToIncentive = trustCustomerToIncentive;
    }


    public boolean isWalmartPlusCustomer() {
        return isWalmartPlusCustomer;
    }

    public void setWalmartPlusCustomer(boolean walmartPlusCustomer) {
        isWalmartPlusCustomer = walmartPlusCustomer;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getReturnRefNumber() {
        return returnRefNumber;
    }

    public void setReturnRefNumber(String returnRefNumber) {
        this.returnRefNumber = returnRefNumber;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }

    public ChannelInfo getChannelInfo() {
        return channelInfo;
    }

    public void setChannelInfo(ChannelInfo channelInfo) {
        this.channelInfo = channelInfo;
    }

}
