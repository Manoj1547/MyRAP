package com.walmartlabs.services.rdm.formula.impl.java.eligibility;

import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.config.client.RestockEligibilityConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.formula.impl.java.productType.ProductTypeData;
import com.walmartlabs.services.rdm.model.CategoryType;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.formula.Formula;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Map;

/**
 * It will return true if Item is eligible for restock
 */
@Component
public class WFSRestockEligibility implements JavaEngineClass {

    @ManagedConfiguration
    RestockEligibilityConfig restockEligibilityConfig;

    @ManagedConfiguration
    RDMKeepItConfig rdmKeepItConfig;

    ProductTypeData productTypeData;

    private static final String RESTOCK = "RESTOCK";

    private static final Logger LOG  = LoggerFactory.getLogger(WFSRestockEligibility.class);


    public void setRestockEligibilityConfig(RestockEligibilityConfig restockEligibilityConfig) {
        this.restockEligibilityConfig = restockEligibilityConfig;
    }


    public void setRdmKeepItConfig(RDMKeepItConfig rdmKeepItConfig) {
        this.rdmKeepItConfig = rdmKeepItConfig;
    }
    @Autowired
    public void setProductTypeData(ProductTypeData productTypeData) {
        this.productTypeData = productTypeData;
    }

    @Override
    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        BaseItem item = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);
        if(rdmKeepItConfig.getNonResellableDeptList().contains(item.getDepartmentNo())){
            return Boolean.FALSE;
        }

        if(restockEligibilityConfig.getRestrictedProductTypes().contains(item.getProductType()) ||
                !RESTOCK.equalsIgnoreCase(item.getSellerPreference().getSellableItemDisposition())){
            return Boolean.FALSE;
        }

        CategoryType productTypeCategory = productTypeData.getProductTypeCategory(item.getProductType());

        if(null == productTypeCategory){
            LOG.info("ProductCategory is not present for productType : {}, salesOrderNo:{}",item.getProductType(), item.getOrderNo());
            return Boolean.FALSE;
        }
        if(CategoryType.A.equals(productTypeCategory) &&
                BigDecimal.valueOf(restockEligibilityConfig.getRetailThreshold()).compareTo(item.getUnitPrice().getCurrencyAmount()) < 0){
            return Boolean.FALSE;
        }

        if(CategoryType.B.equals(productTypeCategory) &&
                BigDecimal.valueOf(restockEligibilityConfig.getRetailThreshold()).compareTo(item.getUnitPrice().getCurrencyAmount()) < 0
            && restockEligibilityConfig.getRestrictedItemConditions().contains(item.getItemCondition())){
            return Boolean.FALSE;
        }

        return Boolean.TRUE;
    }
}
