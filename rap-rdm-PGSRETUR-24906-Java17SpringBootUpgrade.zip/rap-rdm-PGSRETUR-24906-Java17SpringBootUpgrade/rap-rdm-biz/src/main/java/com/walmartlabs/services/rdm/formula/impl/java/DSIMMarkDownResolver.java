package com.walmartlabs.services.rdm.formula.impl.java;

import com.walmartlabs.services.rdm.component.dsim.util.DSIMClient;
import com.walmartlabs.services.rdm.component.dsim.model.config.summary.request.ConfigSelection;
import com.walmartlabs.services.rdm.component.dsim.model.config.summary.request.MarkDownConfigRequest;
import com.walmartlabs.services.rdm.component.dsim.model.config.summary.response.MarkDownConfigResponse;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.formula.Formula;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * {
 *     "configHierSelection": {
 *         "baseDivNbr": 1,
 *         "businessUnitNbr": 100,
 *         "countryCode": "US",
 *         "itemNbr": 9401350,
 *         "marketNbr": 323,
 *         "regionNbr": 42,
 *         "subdivNbr": "B"
 *     },
 *     "iteration": 1,
 *     "timestamp": "2018-06-15T14:28:55-05:00"
 * }
 */

@Service
public class DSIMMarkDownResolver implements JavaEngineClass {
    private static final Logger LOG = LoggerFactory.getLogger(DSIMMarkDownResolver.class);
    private static final String DEFAULT_COUNTRY_CODE = "US";
    @Autowired
    private DSIMClient dsimClient;
    @Override
    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        BaseItem item = FormulaEngine.getInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);
        String itemId = FormulaEngine.getInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_ITEM_ID);
        String storeId = FormulaEngine.getInput(formula,inputData,FormulaConstants.INTERNAL_DATA_NAME_STORE_ID);
        CompletableFuture<MarkDownConfigResponse> downConfigResponseFuture = CompletableFuture.supplyAsync(() -> {
            MarkDownConfigRequest request = prepareMarkDownConfigRequest(itemId, storeId);
            LOG.info("Preparing dsim markdown config request for itemid - storeId [{}] - [{}]  ", itemId, storeId);
            return dsimClient.getMarkConfigResponse(request);
        });
        return downConfigResponseFuture;
    }

    private MarkDownConfigRequest prepareMarkDownConfigRequest(String itemId, String storeId) {
        MarkDownConfigRequest request = new MarkDownConfigRequest();
        ConfigSelection configSelection = new ConfigSelection();
        request.setConfigHierSelection(configSelection);
        configSelection.setBaseDivNbr(1);
        configSelection.setStoreId(Long.valueOf(storeId));
        configSelection.setItemNbr(Long.valueOf(itemId));
        configSelection.setCountryCode(DEFAULT_COUNTRY_CODE);
        request.setIteration(1);
        request.setTimestamp(OffsetDateTime.now().truncatedTo(ChronoUnit.SECONDS).toString());
        return request;

    }
}
