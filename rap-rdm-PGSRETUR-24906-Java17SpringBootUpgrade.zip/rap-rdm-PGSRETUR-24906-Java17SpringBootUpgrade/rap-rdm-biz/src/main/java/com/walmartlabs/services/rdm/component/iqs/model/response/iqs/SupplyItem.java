package com.walmartlabs.services.rdm.component.iqs.model.response.iqs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SupplyItem {

    /****
     *  "supplyItemNbr": null,
     *                         "unitCostAmt": 12.09,
     *                         "baseRetailAmt": 56,
     *                         "supplierNbr": 721407,
     *                         "deptNbr": 5,
     *                         "supplierSeqNbr": 0
     *
     */

    @JsonProperty(value = "supplyItemNbr")
    private  Long supplyItemNumber;
    private BigDecimal unitCostAmt;
    private BigDecimal baseRetailAmt;
    @JsonProperty(value = "supplierNbr")
    private Long supplierNumber;
    @JsonProperty(value = "deptNbr")
    private Long departmentNumber;
    @JsonProperty(value = "isPrimaryVendorInd")
    private boolean isPrimaryVendor ;
    @JsonProperty(value =  "supplierSeqNbr")
    private Long supplierSequenceNumber;
    private String partnershipTypeCode;
    @JsonProperty(value = "itemNbr")
    private Long itemNumber;

    public Long getSupplyItemNumber() {
        return supplyItemNumber;
    }

    public void setSupplyItemNumber(Long supplyItemNumber) {
        this.supplyItemNumber = supplyItemNumber;
    }

    public BigDecimal getUnitCostAmt() {
        return unitCostAmt;
    }

    public void setUnitCostAmt(BigDecimal unitCostAmt) {
        this.unitCostAmt = unitCostAmt;
    }

    public BigDecimal getBaseRetailAmt() {
        return baseRetailAmt;
    }

    public void setBaseRetailAmt(BigDecimal baseRetailAmt) {
        this.baseRetailAmt = baseRetailAmt;
    }

    public Long getSupplierNumber() {
        return supplierNumber;
    }

    public void setSupplierNumber(Long supplierNumber) {
        this.supplierNumber = supplierNumber;
    }

    public Long getDepartmentNumber() {
        return departmentNumber;
    }

    public void setDepartmentNumber(Long departmentNumber) {
        this.departmentNumber = departmentNumber;
    }

    public Long getSupplierSequenceNumber() {
        return supplierSequenceNumber;
    }

    public void setSupplierSequenceNumber(Long supplierSequenceNumber) {
        this.supplierSequenceNumber = supplierSequenceNumber;
    }

    public boolean isPrimaryVendor() {
        return isPrimaryVendor;
    }

    public void setPrimaryVendor(boolean primaryVendor) {
        isPrimaryVendor = primaryVendor;
    }

    public String getPartnershipTypeCode() {
        return partnershipTypeCode;
    }

    public void setPartnershipTypeCode(String partnershipTypeCode) {
        this.partnershipTypeCode = partnershipTypeCode;
    }

    public Long getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(Long itemNumber) {
        this.itemNumber = itemNumber;
    }
}
