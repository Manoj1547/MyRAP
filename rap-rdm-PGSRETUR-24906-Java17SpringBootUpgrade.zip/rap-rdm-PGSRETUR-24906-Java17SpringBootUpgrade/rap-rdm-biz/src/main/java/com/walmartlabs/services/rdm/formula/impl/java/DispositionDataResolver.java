package com.walmartlabs.services.rdm.formula.impl.java;

import java.util.Map;
import java.util.concurrent.CompletableFuture;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import com.walmartlabs.services.rdm.component.restock.service.util.DispositionDataServiceHelper;
import com.walmartlabs.services.rdm.util.RDMCommonUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmartlabs.services.rdm.component.restock.model.request.GetRestockItemDetailsRequest;
import com.walmartlabs.services.rdm.component.restock.model.response.GetRestockItemDetailsResponse;
import com.walmartlabs.services.rdm.component.restock.service.util.RestockHttpClient;
import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.formula.Formula;

import io.strati.configuration.annotation.ManagedConfiguration;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public class DispositionDataResolver implements JavaEngineClass {

    @Resource
    RestockHttpClient client;

    @ManagedConfiguration
    RDMSwitches       switches;



    @Autowired
    DispositionDataServiceHelper dispositionDataServiceHelper;

    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        BaseItem item = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);
        String storeId = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_STORE_ID);
        Boolean pristine = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.VARIABLE_PRISTINE);
        GetRestockItemDetailsRequest request = prepareDispositionDataRequest(item, storeId, pristine);


        if(!inputData.containsKey(FormulaConstants.INTERNAL_DATA_NAME_DISPOSITION_FUTURE)) {
            inputData.put(FormulaConstants.INTERNAL_DATA_NAME_DISPOSITION_FUTURE,
                    dispositionDataServiceHelper.triggerDispositionDataServiceCall(request));
        }

        /**
         If service is called as part of preCall then,
         No need to wait for response at this point, return from here
         */
        if(RDMCommonUtils.isExternalServicePreCall(formula, inputData)){
            return null;
        }

        CompletableFuture<GetRestockItemDetailsResponse> dispositionDataResponseFuture =
                (CompletableFuture<GetRestockItemDetailsResponse>) inputData.get(FormulaConstants.INTERNAL_DATA_NAME_DISPOSITION_FUTURE);
        GetRestockItemDetailsResponse dispositionDataResponse =
                dispositionDataServiceHelper.getDispositionDataResponseFromFuture(dispositionDataResponseFuture, item);

        return dispositionDataResponse;
    }

    private GetRestockItemDetailsRequest prepareDispositionDataRequest(BaseItem item, String storeId, Boolean pristine) {
        GetRestockItemDetailsRequest request = new GetRestockItemDetailsRequest();
        request.setOrderNo(item.getOrderNo());
        request.setUpc(item.getGtin());
        request.setStoreId(storeId);
        request.setPristineCondition(pristine);
        return request;
    }

}
