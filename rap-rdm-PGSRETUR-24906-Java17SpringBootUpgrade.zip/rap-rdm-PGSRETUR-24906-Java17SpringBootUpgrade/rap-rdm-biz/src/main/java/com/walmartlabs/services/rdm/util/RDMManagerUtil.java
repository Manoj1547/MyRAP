package com.walmartlabs.services.rdm.util;

import com.walmart.platform.kernel.exception.error.Error;
import com.walmart.platform.txnmarking.impl.NullTransactionImpl;
import com.walmart.platform.txnmarking.impl.TransactionImpl;
import com.walmartlabs.services.rdm.RDMUtils;
import com.walmartlabs.services.rdm.api.RDMManager;
import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import com.walmartlabs.services.rdm.domain.model.*;
import com.walmartlabs.services.rdm.domain.persistence.RDMTransactionPersistenceManager;
import com.walmartlabs.services.rdm.mapper.ModelMapper;
import com.walmartlabs.services.rdm.model.dispositionpaths.DispositionPathsRequest;
import com.walmartlabs.services.rdm.model.dispositionpaths.Item;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.FinalDisposition;
import io.strati.StratiServiceProvider;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.apache.commons.lang.BooleanUtils;
import io.strati.txnmarking.Transaction;
import io.strati.txnmarking.TransactionMarkingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.*;

@Service
public class RDMManagerUtil {

    private static final Logger LOG                      = LoggerFactory.getLogger(RDMManager.class);

    private TransactionMarkingService TMS;

    @Resource
    ModelMapper mapper;

    @ManagedConfiguration
    RDMSwitches switches;

    @Resource
    RDMUtils util;

    @Resource
    RDMTransactionPersistenceManager persistanceManager;

    @PostConstruct
    private void init() {
        TMS =  StratiServiceProvider.getInstance().getTransactionMarkingService().get();
    }

    public static Transaction getTransaction(TransactionMarkingService TMS, String name) {
        if(TMS.currentTransaction() instanceof NullTransactionImpl){
            return TMS.topTransaction(name, name);
        }else{
            return (TransactionImpl) TMS.transaction(name, name);
        }
    }

    private void saveTransaction(TransactionDO t) {
        try{
            persistanceManager.save(t);
        }catch (Exception e){
            LOG.error("Save transaction failed. {} {}", e.getMessage(), e);
            if(switches != null && switches.getCallDBAsync()){
                throw e;
            }
        }
    }


    public void populateResponseInTransactionDOO(TransactionDO transactionDO, List<DispositionInfo> infoList) {
        infoList.forEach(info -> {
            createTransactionLines(transactionDO, info.getItem(), info);
        });
    }

    public TransactionDO convertToTransactionDO(DispositionPathsRequest request) {
        String channel = request.getChannelInfo().getChannelName();
        String storeId = request.getChannelInfo() != null ? request.getChannelInfo().getStoreId() : null;

        TransactionDO transactionDO = mapper.map(request);
        transactionDO.setChannelName(channel);
        transactionDO.setStoreId(storeId);

        return transactionDO;
    }

    public Date saveTransaction(DispositionPathsRequest request, Boolean test, TransactionDO t, boolean hasError) {
        TransactionImpl top;
        if (TMS.currentTransaction() instanceof NullTransactionImpl) {
            top = (TransactionImpl) TMS.topTransaction("saveTransaction", "saveTransaction");
        } else {
            top = (TransactionImpl) TMS.transaction("saveTransaction", "saveTransaction");
        }
        top.start();
        try {
            Date time;
            LOG.info("getPaths {} {} {}", request.getReturnRefNumber(), request.getOrderNo(), hasError);
            if (BooleanUtils.isNotTrue(test) && (!hasError || (BooleanUtils.isTrue(switches.getDbSaveOnError() && hasError)))) {
                long b = System.currentTimeMillis();
                saveTransaction(t);
                time = t.getCreateTs();
                LOG.info("Timing-CODE_FLOW SaveTransaction={} {}", System.currentTimeMillis() - b, System.currentTimeMillis());
            } else {
                time = new Date();
                LOG.info("not saving transaction");
            }
            top.end();
            return time;
        } catch (Exception e) {
            top.endWithFailure(e.getMessage());
            throw e;
        }
    }

    private void createTransactionLines(TransactionDO transactionDO, BaseItem item, DispositionInfo info) {
        TransactionItemDO tItem = mapper.map(item);
        tItem.setTransaction(transactionDO);
        transactionDO.getLines().add(tItem);

        List<DispositionPath> paths = info.getDispositionPaths();
        if(paths != null){
            RecommendDispositionDO r = new RecommendDispositionDO();
            // Add Recommended KeepIt Disposition details
            RecommendKeepItDispositionDO recommendKeepItDispositionDO = mapper.clone(info.getKeepItInfo());

            Error error = info.getError();
            r.setIsError(error != null);
            if(r.getIsError()){
                r.setException(util.getJsonString(error));
            }
            r.setIsDefault(info.getIsDefault());

            for(int i = 0; i < paths.size(); i++){
                r.setPathValue(i + 1, paths.get(i).getPath(), paths.get(i).getValue());
                recommendKeepItDispositionDO.setPathKeepIt(i + 1, paths.get(i).getPath(), paths.get(i).getKeepIt());
            }
            r.setTransactionItem(tItem);
            tItem.setRecommendDisposition(r);

            recommendKeepItDispositionDO.setRecommendDisposition(r);
            r.setRecommendKeepItDisposition(recommendKeepItDispositionDO);

            Map<String, Object> businessVariables = info.getBusinessRuleVariables();
            if(BooleanUtils.isTrue(switches.getDbSaveDispositionsVariables()) && businessVariables != null){
                Iterator<Map.Entry<String, Object>> i = businessVariables.entrySet().iterator();
                Map.Entry<String, Object> entry;
                while(i.hasNext()){
                    entry = i.next();
                    RecommendDispositionVariablesDO v = new RecommendDispositionVariablesDO();
                    v.setName(entry.getKey());
                    v.setValue(util.getJsonString(entry.getValue()));
                    r.getVariables().add(v);
                    v.setDisposition(r);
                }
            }

            if(BooleanUtils.isNotTrue(info.getIsDefault()) && BooleanUtils.isTrue(switches.getDbSaveFinalDispositions())){
                for(DispositionPath path : paths){
                    List<FinalDisposition> finalDispositions = path.getFinalDispositions();
                    if(finalDispositions != null) for(FinalDisposition finalDisposition : finalDispositions){
                        RecommendFinalDispositionDO f = createDO(finalDisposition.getId(), r, finalDisposition.getValue());
                        Map<String, Object> finalVariables = finalDisposition.getVariables();
                        if(BooleanUtils.isTrue(switches.getDbSaveFinalDispositionsVariables()) && finalVariables != null){
                            Iterator<Map.Entry<String, Object>> i = finalVariables.entrySet().iterator();
                            Map.Entry<String, Object> entry;
                            while(i.hasNext()){
                                entry = i.next();
                                RecommendFinalDispositionVariablesDO fv = new RecommendFinalDispositionVariablesDO();
                                fv.setName(entry.getKey());
                                fv.setValue(util.getJsonString(entry.getValue()));
                                fv.setFinalDisposition(f);
                                f.getVariables().add(fv);
                            }
                        }
                    }
                }
            }
        }
    }


    private RecommendFinalDispositionDO createDO(String id, RecommendDispositionDO r, Double value) {
        RecommendFinalDispositionDO f = new RecommendFinalDispositionDO();
        NodeDO node = new NodeDO();
        node.setId(UUID.fromString(id));
        f.setNode(node);
        f.setDisposition(r);
        f.setValue(value);
        r.getPaths().add(f);
        return f;
    }


}
