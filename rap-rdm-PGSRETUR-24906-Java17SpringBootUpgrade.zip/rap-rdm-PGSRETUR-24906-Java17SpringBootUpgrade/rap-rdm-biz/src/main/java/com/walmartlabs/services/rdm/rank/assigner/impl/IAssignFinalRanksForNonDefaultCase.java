package com.walmartlabs.services.rdm.rank.assigner.impl;

import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;

/**
 * Assign final ranks in non-default case
 * @author v0h01q5
 */
public interface IAssignFinalRanksForNonDefaultCase {

    void assignFinalRanks(DispositionInfo dispositionInfo);

}
