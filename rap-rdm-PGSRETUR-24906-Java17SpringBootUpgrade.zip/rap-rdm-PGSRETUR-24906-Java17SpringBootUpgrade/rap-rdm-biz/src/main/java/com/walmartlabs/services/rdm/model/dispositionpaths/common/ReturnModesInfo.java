package com.walmartlabs.services.rdm.model.dispositionpaths.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReturnModesInfo{

    @JsonProperty("returnModes")
    public List<ReturnMode> returnModes;

    public List<ReturnMode> getReturnModes() {
        return returnModes;
    }

    public void setReturnModes(List<ReturnMode> returnModes) {
        this.returnModes = returnModes;
    }
}