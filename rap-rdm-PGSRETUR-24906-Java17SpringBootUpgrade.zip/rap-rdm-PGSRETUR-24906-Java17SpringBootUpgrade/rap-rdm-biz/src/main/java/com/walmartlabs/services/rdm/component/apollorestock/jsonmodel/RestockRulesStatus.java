package com.walmartlabs.services.rdm.component.apollorestock.jsonmodel;

public class RestockRulesStatus {

    public String name;
    public String status;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
