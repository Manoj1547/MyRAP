package com.walmartlabs.services.rdm.component.pos;

import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmartlabs.services.rdm.executors.RdmExecutorService;
import com.walmartlabs.services.rdm.config.client.GSFServiceConfig;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.text.MessageFormat;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Component
public class POSServiceHelper {
    private static final Logger LOG = LoggerFactory.getLogger(POSServiceHelper.class);

    @Resource
    private POSItemHttpClient posItemHttpClient;

    @Resource
    private POSDeptHttpClient posDeptHttpClient;

    @Resource
    @ManagedConfiguration
    private GSFServiceConfig gsfServiceConfig;

    public CompletableFuture<String> triggerPosItemDataServiceCall(BaseItem item, String storeId) {
        CompletableFuture<String> posItemResponseFuture = CompletableFuture.supplyAsync(() -> posItemHttpClient.getItemPos(item.getUpc(), item.getGtin(), storeId), RdmExecutorService.getExecutor());
        return posItemResponseFuture;
    }

    public String getPosItemDataResponseFromFuture(CompletableFuture<String> posItemDataResponseFuture, BaseItem item) {
        String posItemServiceResponse = null;

        try {
            posItemServiceResponse = posItemDataResponseFuture.get(posItemHttpClient.getTimeout(posItemHttpClient.getServiceName()), TimeUnit.MILLISECONDS);;
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            String errorMsg =  MessageFormat.format("POS  item response fetch failed, gtin {0} , offerId {1}, error {2}",
                    item.getGtin(), item.getOfferId(), e.getMessage());
            LOG.error(errorMsg, e);

            //In Case of RDM exception throw same exception otherwise wrap the exception in rdm exception
            if(e.getCause() instanceof RDMException){
                throw (RDMException) e.getCause();
            } else{
                throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.POS_ITEM_DATA_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
            }
        }
        return posItemServiceResponse;
    }

    public CompletableFuture<String> triggerPosDeptDataServiceCall(String l1Id, String storeId, boolean isSharedOffer) {
        CompletableFuture<String> posDeptResponseFuture = CompletableFuture.supplyAsync(() ->
                posDeptHttpClient.getDeptPos(l1Id, storeId, isSharedOffer), RdmExecutorService.getExecutor());
        return posDeptResponseFuture;
    }

    public String getPosDeptDataResponseFromFuture(CompletableFuture<String> posDeptDataResponseFuture, BaseItem item) {
        String posDeptServiceResponse = null;

        try {
            posDeptServiceResponse = posDeptDataResponseFuture.get(posDeptHttpClient.getTimeout(posDeptHttpClient.getServiceName()), TimeUnit.MILLISECONDS);;
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            String errorMsg =  MessageFormat.format("POS dept response fetch failed, gtin {0} , offerId {1}, error {2}",
                    item.getGtin(), item.getOfferId(), e.getMessage());
            LOG.error(errorMsg, e);

            //In Case of RDM exception throw same exception otherwise wrap the exception in rdm exception
            if(e.getCause() instanceof RDMException){
                throw (RDMException) e.getCause();
            } else{
                throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.POS_DEPT_DATA_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
            }
        }
        return posDeptServiceResponse;
    }
}
