package com.walmartlabs.services.rdm.util;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.StampedLock;
import java.util.function.Function;

/**
 * A thread safe container which is good for large amount of read and little write operations. It uses a readwrite lock to ensure better multi-threading
 * performance than a simple lock
 * 
 * @author Tim Jin
 */
public class DataContainer<T> {
    private final ReadWriteLock readWriteLock    = new StampedLock().asReadWriteLock();            //new ReentrantReadWriteLock();
    private final Lock          readLock         = readWriteLock.readLock();
    private final Lock          writeLock        = readWriteLock.writeLock();

    private final Lock          writeRequestLock = new StampedLock().asReadWriteLock().writeLock();

    private T                   value;

    /**
     * see {@link #requestSet(Function)} and {@link #requestSetBlocking(Function)}
     * 
     * @param update
     * @param blocking
     */
    public void requestSet(Function<T, T> update, boolean blocking) {
        if(blocking) requestSetBlocking(update);
        else requestSet(update);
    }

    /**
     * only one set request will be accepted(run in a separate thread) and all the others will be skipped(returned). All the call to requestSet will return
     * immediately and an internal thread being created so the caller can continue and proceed with the "old" value, for requestSetBlocking on the other hand
     * will be blocked until new value is set. this is only used when old value is still usable and not causing too much problem an expiring token for example
     * while requestSetBlocking means the old value can't be used anymore such as an expired token.
     * 
     * @param update
     *            the function to be called if request is accepted
     */
    public void requestSet(Function<T, T> update) {
        if(writeRequestLock.tryLock()){
            new Thread(new Runnable() {
                public void run() {
                    try{
                        T newValue = update.apply(value);
                        writeLock.lock();
                        value = newValue;
                    }finally{
                        writeLock.unlock();
                        writeRequestLock.unlock();
                    }
                }
            }, "CacheContainer.requestSetAsync").start();
        }
    }

    /**
     * request a value updateWithStatus which will block all the other read and updateWithStatus operations.
     * 
     * @param update
     *            the function to be called to get the updated value
     */
    public void requestSetBlocking(Function<T, T> update) {
        T old = value;
        writeLock.lock();
        try{
            //skip other pending write operations
            if(old == value){
                /**
                 * @formatter:off
                 * double check if the value is the same before lock is acquired to make sure only one updateWithStatus will be executed.
                 * check the time lines below:
                 * thread1: request updateWithStatus-> blocked       -> old!=value do nothing
                 * thread2: request updateWithStatus-> value updated
                 * thread3: request updateWithStatus-> blocked                                -> old!=value do nothing
                 * @formatter:on
                 */

                value = update.apply(value);
            }
        }finally{
            writeLock.unlock();
        }
    }

    /**
     * set the contained value. will block all the other set and get operations
     */
    public void set(T o) {
        writeLock.lock();
        try{
            value = o;
        }finally{
            writeLock.unlock();
        }
    }

    /**
     * get the contained value. will be blocked if a set operation is in progress
     * 
     * @return the contained value
     */
    public T get() {
        readLock.lock();
        try{
            return value;
        }finally{
            readLock.unlock();
        }
    }
}