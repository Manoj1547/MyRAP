package com.walmartlabs.services.rdm.component.siro.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Supplier {
    @JsonProperty("legacySupplierID")
    private String legacySupplierID;

    @JsonProperty("supplierID")
    private String supplierID;

    public String getLegacySupplierID() {
        return legacySupplierID;
    }

    public void setLegacySupplierID(String legacySupplierID) {
        this.legacySupplierID = legacySupplierID;
    }

    public String getSupplierID() {
        return supplierID;
    }

    public void setSupplierID(String supplierID) {
        this.supplierID = supplierID;
    }
}
