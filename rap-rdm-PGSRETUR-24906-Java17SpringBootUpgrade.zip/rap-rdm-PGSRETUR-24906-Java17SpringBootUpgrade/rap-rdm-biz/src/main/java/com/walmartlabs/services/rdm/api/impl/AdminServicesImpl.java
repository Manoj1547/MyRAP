package com.walmartlabs.services.rdm.api.impl;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.text.MessageFormat;

import java.util.*;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import com.walmart.platform.kernel.exception.error.Error;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.service.wrappers.Status;
import com.walmartlabs.services.rdm.domain.model.*;
import com.walmartlabs.services.rdm.domain.util.ObjectMapperFactory;
import com.walmartlabs.services.rdm.model.SellerType;
import com.walmartlabs.services.rdm.util.ProductTypeUtil;
import com.walmartlabs.services.rdm.util.cache.CacheManager;
import com.walmartlabs.services.rdm.util.cache.CacheRole;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmartlabs.services.rdm.api.AdminService;
import com.walmartlabs.services.rdm.domain.persistence.DataPersistenceManager;
import com.walmartlabs.services.rdm.domain.persistence.NodePersistenceManager;
import com.walmartlabs.services.rdm.listener.ROEventListener;
import com.walmartlabs.services.rdm.util.Reloadable;

/**
 * 
 * @author Tim Jin
 *
 */
public class AdminServicesImpl implements AdminService, ApplicationContextAware {

    private static final Logger     LOG = LoggerFactory.getLogger(AdminServicesImpl.class);

    @Resource
    NodePersistenceManager          nodeManager;

    @Resource
    DataPersistenceManager          dataManager;

    @Resource
    ROEventListener                 roListener;



    @Resource
    CacheManager cacheManager;

    private Map<String, Reloadable> reloadables;

    public void setApplicationContext(ApplicationContext ctx) throws BeansException {
        Map<String, Reloadable> reloadables = ctx.getBeansOfType(Reloadable.class);
        this.reloadables = reloadables.entrySet().stream().collect(Collectors.toMap(entry -> entry.getKey().toUpperCase(), entry -> entry.getValue()));
    }

    public ServiceResponse<List<NodeDO>> getNodes(String sellerType) throws ServiceException {
        ServiceResponse<List<NodeDO>> response = new ServiceResponse<>();
        SellerType sellerTypeEnum = null;
        if(null != sellerType){
            try {
                sellerTypeEnum = SellerType.valueOf(sellerType);
            }catch(Exception e){
                response.setStatus(Status.BAD_REQUEST);
                Error error = new Error();
                error.setDescription("Invalid SellerType");
                response.setErrors(new ArrayList<>());
                response.getErrors().add(error);
                return response;
            }
        }
        List<NodeDO> nodes = nodeManager.searchRoot(sellerTypeEnum);
        if(nodes != null) {
            for (NodeDO node : nodes) {
                sortNodes(node);
            }
        }

        response.setStatus(Status.OK);
        response.setPayload(nodes);
        return response;
    }

    private void sortNodes(NodeDO node) {
        if(node != null){
            //@formatter:off
            Collections.sort(node.getNodeFormulas(), Comparator.<NodeFormulaDO, NodeFormulaType>
                comparing(p -> p.getType())
               .thenComparing(p -> p.getSeq(), Comparator.nullsFirst(Comparator.naturalOrder()))
               .thenComparing(p -> p.getFormula().getName(), Comparator.nullsFirst(Comparator.naturalOrder()))
               .thenComparing(p -> p.getFormula().getFormulaType())
               .thenComparing(p -> p.getFormula().getFormula()));
            //@formatter:on
            Collections.sort(node.getChildren(), Comparator.<NodeDO, String> comparing(p -> p.getName()));

            for(NodeDO child : node.getChildren()){
                sortNodes(child);
            }
        }
    }

    public ServiceResponse<String> updateNodes(String json, String sellerType)
            throws ServiceException, JsonProcessingException {
        ServiceResponse<String> response = new ServiceResponse<>();
        SellerType sellerTypeEnum = null;
        if(null != sellerType){
            try {
                sellerTypeEnum = SellerType.valueOf(sellerType);
            }catch(Exception e){
                response.setStatus(Status.BAD_REQUEST);
                Error error = new Error();
                error.setDescription("Invalid SellerType");
                response.setErrors(new ArrayList<>());
                response.getErrors().add(error);
                return response;
            }
        }

        ObjectMapper mapper = ObjectMapperFactory.getObjectMapper();
        JavaType listType = mapper.getTypeFactory().constructCollectionType(List.class, NodeDO.class);
        nodeManager.updateNodes(mapper.readValue(json, listType), sellerTypeEnum);
        response.setStatus(Status.OK);
        return response;
    }

    public ServiceResponse<List<SimulationVariableDO>> getVariables(String sellerType) throws ServiceException {
        ServiceResponse<List<SimulationVariableDO>> response = new ServiceResponse<>();
        SellerType sellerTypeEnum = null;
        if(null != sellerType){
            try {
                sellerTypeEnum = SellerType.valueOf(sellerType);
            }catch(Exception e){
                response.setStatus(Status.BAD_REQUEST);
                Error error = new Error();
                error.setDescription("Invalid SellerType");
                response.setErrors(new ArrayList<>());
                response.getErrors().add(error);
                return response;
            }
        }
        List<SimulationVariableDO> variables = dataManager.getSimulationVariables(sellerTypeEnum);

        response.setStatus(Status.OK);
        response.setPayload(variables);
        return response;
    }

    public  ServiceResponse<String> updateVariables(String json, String sellerType)
            throws ServiceException, JsonProcessingException {
        ServiceResponse<String> response = new ServiceResponse<>();
        SellerType sellerTypeEnum = null;
        if(null != sellerType){
            try {
                sellerTypeEnum = SellerType.valueOf(sellerType);
            }catch(Exception e){
                response.setStatus(Status.BAD_REQUEST);
                Error error = new Error();
                error.setDescription("Invalid SellerType");
                response.setErrors(new ArrayList<>());
                response.getErrors().add(error);
                return response;
            }
        }

        ObjectMapper mapper = ObjectMapperFactory.getObjectMapper();
        JavaType listType = mapper.getTypeFactory().constructCollectionType(List.class, SimulationVariableDO.class);
        dataManager.updateVariables(mapper.readValue(json, listType), sellerTypeEnum);
        response.setStatus(Status.OK);
        return response;
    }

    public Object refresh(String json) {
        try{
            ObjectMapper mapper = ObjectMapperFactory.getObjectMapper();
            JsonNode request = mapper.readTree(json);
            Iterator<Entry<String, JsonNode>> i = request.fields();
            while(i.hasNext()){
                Entry<String, JsonNode> field = i.next();
                String key = field.getKey().toUpperCase();
                Boolean blocking = field.getValue().asBoolean();
                if(reloadables.containsKey(key)){
                    Reloadable service = reloadables.get(key);
                    LOG.info(MessageFormat.format("Reloading({0}) {1} ...", blocking, key));
                    service.reload(blocking);
                }
            }
            return "{\"status\":\"OK\"}";
        }catch (JsonProcessingException e){
            return e;
        }
    }

    public Object updateR2d2(String file, String category) throws ServiceException {
        try (Reader in = new StringReader(file)){
            R2d2DataType type = R2d2DataType.valueOf(category);
            List<R2d2DataDO> data = new ArrayList<>();

            Iterable<CSVRecord> records = CSVFormat.RFC4180.parse(in);

            for(CSVRecord record : records){
                data.add(r2d2(record.get(0), record.get(1), Double.valueOf(record.get(2)), type));
            }

            if(data.size() > 0) dataManager.updateR2D2(data, type);

            LOG.info(MessageFormat.format("Updated {0} for {1}", data.size(), category));
        }catch (Exception e){
            return e;
        }
        return "{\"status\":\"OK\"}";
    }

    private R2d2DataDO r2d2(String id, String name, Double value, R2d2DataType type) {
        R2d2DataDO v = new R2d2DataDO();
        v.setCategoryId(id);
        v.setCategoryName(name);
        v.setType(type);
        v.setVaule(value);
        return v;
    }

    @Override
    public Object r2d2() throws ServiceException {
        return dataManager.getAll(R2d2DataDO.class);
    }

    @Override
    public Object updateR2d2(String json) throws ServiceException {
        try{
            ObjectMapper mapper = ObjectMapperFactory.getObjectMapper();

            JavaType listType = mapper.getTypeFactory().constructCollectionType(List.class, R2d2DataDO.class);

            List<R2d2DataDO> data = mapper.readValue(json, listType);

            dataManager.updateR2D2(data, null);
            return "{\"status\":\"OK\"}";
        }catch (JsonProcessingException e){
            return e;
        }
    }

    @Override
    public ServiceResponse<String> updateProductType(String filePath) throws FileNotFoundException {
            ServiceResponse<String> response = new ServiceResponse<>();
            List<ProductTypeCategoryDO> entityList = ProductTypeUtil.readFile(filePath);
            dataManager.insertAndUpdateProductTypeData(entityList);
            response.setStatus(Status.OK);
            return  response;
    }

    @Override
    public ServiceResponse<String> createAndUpdateProductTypeJson(String json) throws ServiceException, JsonProcessingException {
        ServiceResponse<String> response = new ServiceResponse<>();
        ObjectMapper mapper = ObjectMapperFactory.getObjectMapper();
        JavaType listType = mapper.getTypeFactory().constructCollectionType(List.class, ProductTypeCategoryDO.class);
        dataManager.updateProductTypeData(mapper.readValue(json, listType));
        response.setStatus(Status.OK);
        return response;
    }

    @Override
    public ServiceResponse<String> deleteProductTypeJson(String json) throws ServiceException, JsonProcessingException{
        ServiceResponse<String> response = new ServiceResponse<>();
        ObjectMapper mapper = ObjectMapperFactory.getObjectMapper();
        JavaType listType = mapper.getTypeFactory().constructCollectionType(List.class, ProductTypeCategoryDO.class);
        dataManager.deleteProductType(mapper.readValue(json, listType));
        response.setStatus(Status.OK);
        return response;
    }

    @Override
    public ServiceResponse<List<ProductTypeCategoryDO>> getProductType()
            throws ServiceException {
        ServiceResponse<List<ProductTypeCategoryDO>> response = new ServiceResponse<>();
        response.setPayload(dataManager.getProductTypeData());
        response.setStatus(Status.OK);
        return  response;
    }

    @Override
    public Object processROMessage(String json) throws ServiceException {
        try{
            return roListener.processMsg(json);
        }catch (IOException e){
            throw new ServiceException(e);
        }
    }

    @Override
    public Object updateIQSCache(String json, String gtin, String sellerId) throws ServiceException{
        String key = "{" +
                "id-" + gtin +
                "__type-" + "GTIN" +
                "__sellerId-" + sellerId +
                "}";

        cacheManager.put(key, json, CacheRole.IQS);
        return "{\"status\":\"OK\"}";
    }



}
