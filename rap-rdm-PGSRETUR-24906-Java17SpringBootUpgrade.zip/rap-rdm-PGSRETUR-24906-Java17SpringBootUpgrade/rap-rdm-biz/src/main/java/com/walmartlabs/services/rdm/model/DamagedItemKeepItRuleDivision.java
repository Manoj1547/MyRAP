package com.walmartlabs.services.rdm.model;

import java.util.List;

public class DamagedItemKeepItRuleDivision {

    private String divisionName;
    private List<DamagedItemKeepItRuleCategory> category;

    public String getDivisionName() {
        return divisionName;
    }

    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName;
    }

    public List<DamagedItemKeepItRuleCategory> getCategory() {
        return category;
    }

    public void setCategory(List<DamagedItemKeepItRuleCategory> category) {
        this.category = category;
    }

    @Override
    public String toString() {
        return "DamagedItemKeepItRuleDivision{" +
                "divisionName='" + divisionName + '\'' +
                ", category=" + category +
                '}';
    }
}
