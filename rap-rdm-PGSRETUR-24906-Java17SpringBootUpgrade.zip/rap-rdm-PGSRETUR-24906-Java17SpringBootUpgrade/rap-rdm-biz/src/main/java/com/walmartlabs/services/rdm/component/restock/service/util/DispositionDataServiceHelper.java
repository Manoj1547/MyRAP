package com.walmartlabs.services.rdm.component.restock.service.util;

import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmartlabs.services.rdm.component.restock.model.request.GetRestockItemDetailsRequest;
import com.walmartlabs.services.rdm.component.restock.model.response.GetRestockItemDetailsResponse;
import com.walmartlabs.services.rdm.config.client.RestockServiceConfig;
import com.walmartlabs.services.rdm.executors.RdmExecutorService;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.text.MessageFormat;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Component
public class DispositionDataServiceHelper {
    private static final Logger LOG = LoggerFactory.getLogger(DispositionDataServiceHelper.class);

    @Resource
    RestockHttpClient client;

    @Resource
    @ManagedConfiguration
    RestockServiceConfig restockServiceConfig;

    public CompletableFuture<GetRestockItemDetailsResponse> triggerDispositionDataServiceCall(GetRestockItemDetailsRequest request) {
        CompletableFuture<GetRestockItemDetailsResponse> dispositionDataResponseFuture =
                CompletableFuture.supplyAsync(() -> client.getRestockItemDetails(request), RdmExecutorService.getExecutor());
        return dispositionDataResponseFuture;
    }

    public GetRestockItemDetailsResponse getDispositionDataResponseFromFuture
            (CompletableFuture<GetRestockItemDetailsResponse> dispositionDataResponseFuture, BaseItem item) {
        GetRestockItemDetailsResponse dispositionDataResponse = null;

        try {
            dispositionDataResponse = dispositionDataResponseFuture.get(restockServiceConfig.getApiTimeOut(), TimeUnit.MILLISECONDS);;
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            String errorMsg =  MessageFormat.format("Disposition data response fetch failed, gtin {0} , offerId {1}, error {2}",
                    item.getGtin(), item.getOfferId(), e.getMessage());
            LOG.error(errorMsg, e);

            //In Case of RDM exception throw same exception otherwise wrap the exception in rdm exception
            if(e.getCause() instanceof RDMException){
                throw (RDMException) e.getCause();
            } else{
                throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.RESTOCK_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
            }
        }
        return dispositionDataResponse;
    }

}
