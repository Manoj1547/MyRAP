package com.walmartlabs.services.rdm.component.iqs.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SivItems {
    @JsonProperty("div")
    private String div;

    @JsonProperty("gtin")
    private String gtin;

    @JsonProperty("country")
    private String country;

    @JsonProperty("stores")
    private List<String> stores;

    @JsonProperty("content")
    private Map<String, Content> content;

    public String getDiv() { return div; }

    public void setDiv(String div) { this.div = div; }

    public String getGtin() { return gtin; }

    public void setGtin(String gtin) { this.gtin = gtin; }

    public String getCountry() { return country; }

    public void setCountry(String country) { this.country = country; }

    public List<String> getStores() { return stores; }

    public void setStores(List<String> stores) { this.stores = stores; }

    public Map<String, Content> getContent() { return content; }

    public void setContent(Map<String, Content> content) { this.content = content; }
}
