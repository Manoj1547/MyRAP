package com.walmartlabs.services.rdm.component.siro.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Modular{

    @JsonProperty("category")
    public int category;

    @JsonProperty("departmentNumber")
    public int departmentNumber;

    @JsonProperty("discontinueDate")
    public String discontinueDate;

    @JsonProperty("effectiveDate")
    public String effectiveDate;

    public int getCategory() {
        return category;
    }

    public void setCategory(int category) {
        this.category = category;
    }

    public int getDepartmentNumber() {
        return departmentNumber;
    }

    public void setDepartmentNumber(int departmentNumber) {
        this.departmentNumber = departmentNumber;
    }

    public String getDiscontinueDate() {
        return discontinueDate;
    }

    public void setDiscontinueDate(String discontinueDate) {
        this.discontinueDate = discontinueDate;
    }

    public String getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }
}