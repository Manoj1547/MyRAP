package com.walmartlabs.services.rdm.component.apollorestock.util;

import com.walmartlabs.services.rdm.component.apollorestock.restockrules.AbstractRestockRule;
import com.walmartlabs.services.rdm.component.apollorestock.jsonmodel.*;
import io.strati.libs.google.gson.Gson;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

@Service
public class RestockRulesFactory {

    private static final Logger LOGGER = LoggerFactory.getLogger(RestockRulesFactory.class);
    private static final String DEFAULT_JSON_SCHEMA_FILE = "RestockRulesConfig.json";


    @Autowired
    List<IOperatorBasedConditionEvaluator> allOperatorBasedConditionEvaluators;

    @Autowired
    List<AbstractRestockRule> allRestockRuleBeans;

    static Map<String, AbstractRestockRule> restockRulesCache = new HashMap<>();
    static List<Rule> allConjuctionRules = new ArrayList<>();
    static Map<String, AbstractRestockRule> conjuctionRulesCache = new HashMap<>();
    static Map<String, IOperatorBasedConditionEvaluator> operatorBasedConditionEvaluatorCache = new HashMap<>();
    static Map<String, ConjuctionRuleCondition> conjuctionRuleConditionCache = new HashMap<>();

    @PostConstruct
    void initCache() {
        initFromFile();
        initConditionEvaluatorCache();
    }

    private void initFromFile() {
        RestockRulesJsonRoot restockRulesJsonRoot = parseRuleJsonFile();

        RestockRules reStockRules = restockRulesJsonRoot.getRestockRules();
        Set<String> activeRestockRules = new HashSet();
        for(Rule rule : reStockRules.getRules()){
            if(rule.isActive()) {
                activeRestockRules.add(rule.getRuleName());
            }
        }

        ConjuctionRules conjuctionRules = restockRulesJsonRoot.getConjuctionRules();
        Map<String, Rule> activeConjuctionRules = new HashMap<>();
        for(Rule rule : conjuctionRules.getRules()){
            if(rule.isActive()) {
                activeConjuctionRules.put(rule.getRuleName(), rule);
                allConjuctionRules.add(rule);
            }
        }

        for(AbstractRestockRule restockRuleBean : allRestockRuleBeans){
            if(activeRestockRules.contains(restockRuleBean.getRuleName())){
                restockRulesCache.put(restockRuleBean.getRuleName(), restockRuleBean);
            } else if(activeConjuctionRules.containsKey(restockRuleBean.getRuleName())){
                conjuctionRulesCache.put(restockRuleBean.getRuleName(), restockRuleBean);
            }
        }


        //Sort ConjuctionRules based on priority
        Collections.sort(allConjuctionRules);

        //Prepare ConjuctionRuleConditions cache
        for(ConjuctionRuleCondition conjuctionRuleCondition :restockRulesJsonRoot.getConjuctionRuleConditions()){
            conjuctionRuleConditionCache.put(conjuctionRuleCondition.conditionName, conjuctionRuleCondition);
        }

    }


    private void initConditionEvaluatorCache() {

        for(IOperatorBasedConditionEvaluator conditionEvaluator : allOperatorBasedConditionEvaluators){
            operatorBasedConditionEvaluatorCache.put(conditionEvaluator.getConditionalOperatorName(), conditionEvaluator);
        }
    }

    private RestockRulesJsonRoot parseRuleJsonFile() {

        RestockRulesJsonRoot restockRulesJsonRoot = null;
        try {
            ClassLoader classLoader = RestockRulesFactory.class.getClassLoader();
            InputStream inputStream = classLoader.getResourceAsStream(DEFAULT_JSON_SCHEMA_FILE);
            String content = IOUtils.toString(inputStream, System.getProperty("file.encoding"));

            Gson gson = new Gson();
            restockRulesJsonRoot = gson.fromJson(content, RestockRulesJsonRoot.class);
        } catch (IOException e) {
            String errorMsg = "Unable to parse RestockRules config file-" + DEFAULT_JSON_SCHEMA_FILE;
            throw new RuntimeException(errorMsg, e);
        }

        return restockRulesJsonRoot;
    }



    public static List<Rule> getAllConjuctionRules() {
        return allConjuctionRules;
    }

    public static IOperatorBasedConditionEvaluator getConditionEvaluator(String operatorName){
        IOperatorBasedConditionEvaluator conditionEvaluator = operatorBasedConditionEvaluatorCache.get(operatorName);
        return conditionEvaluator;
    }

    public static AbstractRestockRule getRestockRule(String ruleName){
        AbstractRestockRule restockRule = restockRulesCache.get(ruleName);
        return restockRule;
    }

    public static AbstractRestockRule getConjuctionRule(String ruleName){
        AbstractRestockRule conjuctionRule = conjuctionRulesCache.get(ruleName);
        return conjuctionRule;
    }

    public static ConjuctionRuleCondition getConjuctionRuleCondition(String conditionName){
        ConjuctionRuleCondition conjuctionRuleCondition = conjuctionRuleConditionCache.get(conditionName);
        return conjuctionRuleCondition;
    }


}
