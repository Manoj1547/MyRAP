package com.walmartlabs.services.rdm.api.impl;

import javax.annotation.Resource;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmartlabs.services.rdm.dto.healthcheck.HealthCheckResponseDTO;
import com.walmartlabs.services.rdm.formula.FormulaService;

/**
 * 
 * @author Tim Jin
 *
 */
public class HealthCheckServicesImpl extends HealthCheckAsyncServicesImpl {

    @Resource
    FormulaService formulaService;

    public HealthCheckResponseDTO status() throws ServiceException {
        HealthCheckResponseDTO response = super.status();
        response.setModelVersion(formulaService.getModelVersion());
        return response;
    }

}
