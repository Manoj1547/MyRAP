package com.walmartlabs.services.rdm.formula;

import java.text.MessageFormat;
import java.util.Map;

import com.walmartlabs.services.rdm.model.formula.Formula;
import com.walmartlabs.services.rdm.model.formula.FormulaType;

/**
 * 
 * @author Tim Jin
 *
 */
public interface FormulaEngine {

    public FormulaType type();

    public Object eval(Formula f, Map<String, Object> inputData) throws VariableMissingException;

    default public Context getContext(String eval) {
        return new Context();
    }

    static <T> T getInput(Formula formula, Map<String, Object> inputData, String key) throws VariableMissingException {
        if(formula != null && formula.getInputVariables() != null) formula.getInputVariables().add(key);
        if(!inputData.containsKey(key)) throw new VariableMissingException(null, key);

        Object value = inputData.get(key);

        if(FormulaConstants.isInvalidValue(value)) throw new FormulaException(MessageFormat.format("{0} is invalid.", key));
        return (T) value;

    }

    static <T> T getNotNullInput(Formula formula, Map<String, Object> inputData, String key) throws VariableMissingException {
        T value = getInput(formula, inputData, key);
        if(value == null) throw new FormulaException(MessageFormat.format("{0} is null.", key));
        return value;
    }
}
