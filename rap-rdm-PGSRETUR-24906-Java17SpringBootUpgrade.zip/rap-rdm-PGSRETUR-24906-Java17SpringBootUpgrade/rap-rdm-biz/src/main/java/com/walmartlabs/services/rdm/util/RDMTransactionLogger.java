package com.walmartlabs.services.rdm.util;

import com.walmart.platform.txnmarking.impl.NullTransactionImpl;
import com.walmart.platform.txnmarking.impl.TransactionImpl;
import io.strati.StratiServiceProvider;
import io.strati.txnmarking.Transaction;
import io.strati.txnmarking.TransactionMarkingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class RDMTransactionLogger {


    private TransactionMarkingService TMS;

    @PostConstruct
    private void init() {
        TMS =  StratiServiceProvider.getInstance().getTransactionMarkingService().get();
    }

    public  Transaction createTransaction(String categoryName, String groupName){
        Transaction top = null;
        if (TMS.currentTransaction() instanceof NullTransactionImpl) {
            top = TMS.topTransaction(categoryName, groupName);
        } else {
            top = TMS.transaction(categoryName, groupName);
        }
        return top;
    }
    public  Transaction createTransaction(String transactionName){
        Transaction top = null;
        if (TMS.currentTransaction() instanceof NullTransactionImpl) {
            top = TMS.topTransaction(transactionName, transactionName);
        } else {
            top = TMS.transaction(transactionName, transactionName);
        }
        return top;
    }


}
