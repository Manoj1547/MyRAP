package com.walmartlabs.services.rdm.formula.impl.java.iqs;

import java.text.MessageFormat;
import java.util.List;
import java.util.Map;

import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import com.walmartlabs.services.rdm.formula.*;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.walmartlabs.services.rdm.component.iqs.model.response.Attributes;
import com.walmartlabs.services.rdm.component.iqs.model.response.GetItemDetailsResponse;
import com.walmartlabs.services.rdm.component.iqs.model.response.SupplyTradeItem;
import com.walmartlabs.services.rdm.model.formula.Formula;

import org.apache.commons.lang.BooleanUtils;
import org.springframework.util.ObjectUtils;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public class IQSSIResolver implements JavaEngineClass {

    private static final Logger LOG          = LoggerFactory.getLogger(IQSSIResolver.class);
    private static final String LOG_TEMPLATE = "For {0} item, find by {1}. Total: {2}";

    @ManagedConfiguration
    RDMSwitches switches;

    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        GetItemDetailsResponse iqsResponse = null;

        if(!switches.getNewIQSResponse()) {
            iqsResponse = FormulaEngine.getInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_IQSSI);
        }
        else{
            iqsResponse = FormulaEngine.getInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_IQSRDM);
        }
        boolean dotcom = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.VARIABLE_DOTCOM_ITEM);
        boolean store = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.VARIABLE_STORE_ITEM);

        String primaryItemNbr = null;
        if (store) {
            primaryItemNbr = FormulaEngine.getInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_PRIMARY_ITEM_NBR);
        }

        String msg = null;
        List<SupplyTradeItem> items = iqsResponse.getSupplyTradeItems();
        if(items != null && items.size() > 0){
            SupplyTradeItem item = null;
            for(SupplyTradeItem itemInfo : items){
                if(itemInfo.getPayloadJson() != null && itemInfo.getPayloadJson().getAttributes() != null){
                    Attributes attributes = itemInfo.getPayloadJson().getAttributes();
                    if(dotcom){
                        Boolean isPrimary = attributes.getIsPrimaryVendor();
                        if(BooleanUtils.isTrue(isPrimary)){
                            item = itemInfo;
                            msg = MessageFormat.format(LOG_TEMPLATE, store ? "store" : "dotcom", "isPrimaryVendor", items.size());
                            break;
                        }
                    }
                    if(store && primaryItemNbr != null){
                        if(primaryItemNbr.equals(String.valueOf(attributes.getItemNbr()))){
                            item = itemInfo;
                            msg = MessageFormat.format(LOG_TEMPLATE, store ? "store" : "dotcom", "primaryItemNbr(" + primaryItemNbr + ")", items.size());
                            break;
                        }
                    }

                }
            }
            if(item == null) for(SupplyTradeItem itemInfo : items){
                if(itemInfo.getPayloadJson() != null && itemInfo.getPayloadJson().getAttributes() != null){
                    Attributes attributes = itemInfo.getPayloadJson().getAttributes();
                    if("DSV".equals(attributes.getPartnershipTypeCode())){
                        item = itemInfo;
                        msg = MessageFormat.format(LOG_TEMPLATE, store ? "store" : "dotcom", "DSV", items.size());
                        break;

                    }
                }
            }
            if(item == null){
                item = items.get(0);
                msg = MessageFormat.format(LOG_TEMPLATE, store ? "store" : "dotcom", "first", items.size());
            }
            LOG.info(msg);
            /*Validate required fields*/
            if(BooleanUtils.isTrue(switches.getExternalServiceResponseValidationEnabled())) {
                validateRequiredFields(item);
            }
            return item;
        }

        return FormulaConstants.INVALID_VALUE;
    }

    public void validateRequiredFields(SupplyTradeItem item) {
        if(ObjectUtils.isEmpty(item)
                || ObjectUtils.isEmpty(item.getPayloadJson())
                || ObjectUtils.isEmpty(item.getPayloadJson().getAttributes())
                || ObjectUtils.isEmpty(item.getPayloadJson().getAttributes().getBaseRetailAmt())
                || ObjectUtils.isEmpty(item.getPayloadJson().getAttributes().getSupplierSeqNbr())
                || ObjectUtils.isEmpty(item.getPayloadJson().getAttributes().getDeptNbr())
                || ObjectUtils.isEmpty(item.getPayloadJson().getAttributes().getUnitCostAmt())
                || ObjectUtils.isEmpty(item.getPayloadJson().getAttributes().getSupplierNbr())) {
            throw new FormulaException("Supplier attribute not available in IQS SI response.");
        }
    }

}
