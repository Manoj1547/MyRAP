package com.walmartlabs.services.rdm.formula.impl;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.apache.commons.lang3.BooleanUtils;
import org.springframework.stereotype.Service;

import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.FormulaException;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.Formula;
import com.walmartlabs.services.rdm.model.formula.FormulaType;

/**
 *
 * @author Tim Jin
 *
 */
@Service
public class JavaEngine implements FormulaEngine {

    @Resource
    List<JavaEngineClass>        classes;

    Map<String, JavaEngineClass> classMap = new HashMap<>();

    @PostConstruct
    private void init() {
        buildTypeMap();
    }

    private void buildTypeMap() {
        if(classes != null){
            for(JavaEngineClass cls : classes){
                classMap.put(cls.getClass().getName(), cls);
            }
        }
    }

    /**
     * @param formula
     *            not null and type is correct
     * @param inputData
     *            not null
     */
    @Override
    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        JavaEngineClass service = classMap.get(formula.getFormula());
        if(service == null) throw new FormulaException(MessageFormat.format("{0} is not defined!", formula.getFormula()));
        Object v = service.eval(formula, inputData);

        if(v == null) return null;
        switch (formula.getValueType()) {
            case BOOLEAN:
                return BooleanUtils.toBooleanObject(v.toString());
            case DOUBLE:
                return Double.parseDouble(v.toString());
            case INTEGER:
                return (int) Double.parseDouble(v.toString());
            case STRING:
                return v.toString();
            case OBJECT:
            default:
                return v;
        }
    }

    @Override
    public FormulaType type() {
        return FormulaType.JAVA;
    }

}
