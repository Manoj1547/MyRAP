package com.walmartlabs.services.rdm.model.roevent;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrderProduct {

    @JsonProperty("offerId")
    private OfferId offerId;

    public OfferId getOfferId() {
        return offerId;
    }

    public void setOfferId(OfferId offerId) {
        this.offerId = offerId;
    }

    @Override
    public String toString() {
        return "OrderProduct [offerId=" + offerId + "]";
    }
}
