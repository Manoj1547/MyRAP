package com.walmartlabs.services.rdm.component.overrideengine.common;

public abstract class AbstractRuleEngine {

    public abstract void start(IRuleEngineContext ruleEngineContext);
}
