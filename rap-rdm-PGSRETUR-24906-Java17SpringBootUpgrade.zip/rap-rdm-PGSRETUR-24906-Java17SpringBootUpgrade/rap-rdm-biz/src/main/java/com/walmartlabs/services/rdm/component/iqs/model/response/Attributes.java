package com.walmartlabs.services.rdm.component.iqs.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Attributes {
    @JsonProperty("supplierNbr")
    private Integer    supplierNbr;

    @JsonProperty("itemNbr")
    private Integer    itemNbr;

    @JsonProperty("deptNbr")
    private Integer    deptNbr;

    @JsonProperty("supplierSeqNbr")
    private Integer    supplierSeqNbr = 0;

    @JsonProperty("unitCostAmt")
    private BigDecimal unitCostAmt;

    @JsonProperty("isPrimaryVendorInd")
    private Boolean    isPrimaryVendor;

    @JsonProperty("baseRetailAmt")
    private BigDecimal baseRetailAmt;

    @JsonProperty("partnershipTypeCode")
    private String partnershipTypeCode;

    @JsonProperty("orderablePackQty")
    private Integer orderablePackQty;

    @JsonProperty("orderablePackCostAmt")
    private BigDecimal orderablePackCostAmt;

    public Integer getSupplierNbr() {
        return supplierNbr;
    }

    public void setSupplierNbr(Integer supplierNbr) {
        this.supplierNbr = supplierNbr;
    }

    public Integer getItemNbr() {
        return itemNbr;
    }

    public void setItemNbr(Integer itemNbr) {
        this.itemNbr = itemNbr;
    }

    public Integer getDeptNbr() {
        return deptNbr;
    }

    public void setDeptNbr(Integer deptNbr) {
        this.deptNbr = deptNbr;
    }

    public Integer getSupplierSeqNbr() {
        return supplierSeqNbr;
    }

    public void setSupplierSeqNbr(Integer supplierSeqNbr) {
        this.supplierSeqNbr = supplierSeqNbr;
    }

    public Boolean getIsPrimaryVendor() {
        return isPrimaryVendor;
    }

    public void setIsPrimaryVendor(Boolean isPrimaryVendor) {
        this.isPrimaryVendor = isPrimaryVendor;
    }

    public BigDecimal getUnitCostAmt() {
        return unitCostAmt;
    }

    public void setUnitCostAmt(BigDecimal unitCostAmt) {
        this.unitCostAmt = unitCostAmt;
    }

    public String getPartnershipTypeCode() {
        return partnershipTypeCode;
    }

    public void setPartnershipTypeCode(String partnershipTypeCode) {
        this.partnershipTypeCode = partnershipTypeCode;
    }

    public BigDecimal getBaseRetailAmt() { return baseRetailAmt; }

    public void setBaseRetailAmt(BigDecimal baseRetailAmt) { this.baseRetailAmt = baseRetailAmt; }

    public Integer getOrderablePackQty() { return orderablePackQty; }

    public void setOrderablePackQty(Integer orderablePackQty) { this.orderablePackQty = orderablePackQty; }

    public BigDecimal getOrderablePackCostAmt() { return orderablePackCostAmt; }

    public void setOrderablePackCostAmt(BigDecimal orderablePackCostAmt) { this.orderablePackCostAmt = orderablePackCostAmt; }
}
