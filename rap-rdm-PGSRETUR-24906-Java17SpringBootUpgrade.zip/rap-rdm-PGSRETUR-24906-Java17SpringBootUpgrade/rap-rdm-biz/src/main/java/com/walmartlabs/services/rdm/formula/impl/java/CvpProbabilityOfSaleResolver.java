package com.walmartlabs.services.rdm.formula.impl.java;

import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.Formula;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class CvpProbabilityOfSaleResolver implements JavaEngineClass {

    @ManagedConfiguration
    private RDMSwitches switches;

    @Override
    public Double eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        //"formula": "_prob_sale==null?_default_prob_sale:_prob_sale",

        Double probabilityOfSale = Double.parseDouble(switches.getFixedProbabilityOfSale());

        if (switches.getProbabilityOfSaleEnabled()) {
            probabilityOfSale = FormulaEngine
                    .getInput(formula, inputData, FormulaConstants.FORMULA_NAME_POS_ITEM_PREDICTION);
            if (null == probabilityOfSale || -1 == probabilityOfSale) {
                probabilityOfSale = FormulaEngine
                        .getInput(formula, inputData, FormulaConstants.FORMULA_NAME_POS_DEPT_PREDICTION);
            }
            if (null == probabilityOfSale) {
                probabilityOfSale = Double.parseDouble(switches.getDefaultProbabilityOfSale());
            }
        }
        return probabilityOfSale;
    }

    public void setSwitches(RDMSwitches switches) {
        this.switches = switches;
    }
}
