package com.walmartlabs.services.rdm.model.dispositionpaths.simulation;

import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;

/**
 * 
 * @author Tim Jin
 *
 */
public class Item extends BaseItem {

    private Integer seqNo;

    public Integer getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(Integer seqNo) {
        this.seqNo = seqNo;
    }

    public boolean isSimulation() {
        return true;
    }

}
