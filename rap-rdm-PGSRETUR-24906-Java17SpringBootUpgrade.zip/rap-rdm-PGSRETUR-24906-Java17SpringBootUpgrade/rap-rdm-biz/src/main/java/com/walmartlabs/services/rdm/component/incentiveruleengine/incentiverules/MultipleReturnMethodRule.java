package com.walmartlabs.services.rdm.component.incentiveruleengine.incentiverules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.incentiveruleengine.model.ReturnIncentiveEngineContext;
import com.walmartlabs.services.rdm.component.incentiveruleengine.util.AbstractReturnIncentiveRule;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("multipleReturnMethodRule")
public class MultipleReturnMethodRule extends AbstractReturnIncentiveRule {

    @Override
    public boolean runReturnIncentiveRule(ReturnIncentiveEngineContext returnIncentiveEngineContext) {
        DispositionInfo dispositionInfo = returnIncentiveEngineContext.getDispositionInfo();
        List<DispositionPath> dispositionPaths = dispositionInfo.getDispositionPaths();

        return dispositionPaths.size() > 1;
    }

    @Override
    public String getRuleName() {
        return RDMConstants.RULE_NAME_MULTIPLE_RETURN_METHOD;
    }
}
