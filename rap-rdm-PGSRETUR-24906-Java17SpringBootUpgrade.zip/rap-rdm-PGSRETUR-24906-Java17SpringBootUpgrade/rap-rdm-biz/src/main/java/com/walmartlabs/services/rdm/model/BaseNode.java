package com.walmartlabs.services.rdm.model;

import java.util.List;

/**
 * 
 * @author Tim Jin
 *
 */
public class BaseNode<T> extends ID {

    private String  name;

    private List<T> children;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<T> getChildren() {
        return children;
    }

    public void setChildren(List<T> children) {
        this.children = children;
    }

}
