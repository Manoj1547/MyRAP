package com.walmartlabs.services.rdm.component.iqs.model.response.iqs;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CatalogItemData {

    private String productId;
    @JsonProperty(value = "identifiers")
    private Identifiers identifiers;
    @JsonProperty(value = "supplyItems")
    private  List<SupplyItem> supplyItemsList;
    @JsonProperty(value = "offerInfo")
    private List<OfferInfo> offerInfoList;
    private  Product product;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public Identifiers getIdentifiers() {
        return identifiers;
    }

    public void setIdentifiers(Identifiers identifiers) {
        this.identifiers = identifiers;
    }

    public List<SupplyItem> getSupplyItemsList() {
        return supplyItemsList;
    }

    public void setSupplyItemsList(List<SupplyItem> supplyItemsList) {
        this.supplyItemsList = supplyItemsList;
    }

    public List<OfferInfo> getOfferInfoList() {
        return offerInfoList;
    }

    public void setOfferInfoList(List<OfferInfo> offerInfoList) {
        this.offerInfoList = offerInfoList;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
}
