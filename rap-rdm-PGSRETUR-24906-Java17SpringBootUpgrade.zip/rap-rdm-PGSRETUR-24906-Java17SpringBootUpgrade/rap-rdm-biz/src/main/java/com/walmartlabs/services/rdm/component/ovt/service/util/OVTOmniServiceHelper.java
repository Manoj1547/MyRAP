package com.walmartlabs.services.rdm.component.ovt.service.util;

import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmartlabs.services.rdm.component.ovt.model.request.ItemPolicyDetailsRequest;
import com.walmartlabs.services.rdm.component.ovt.model.response.OVTOmniItemPolicyDetails;
import com.walmartlabs.services.rdm.config.client.OVTServiceConfig;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.text.MessageFormat;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import static com.walmartlabs.services.rdm.executors.RdmExecutorService.getExecutor;

@Component
public class OVTOmniServiceHelper {

    private static final Logger LOG = LoggerFactory.getLogger(OVTOmniServiceHelper.class);

    @Resource
    OVTOmniHttpClient ovtOmniHttpClient;

    @Resource
    @ManagedConfiguration
    OVTServiceConfig ovtServiceConfig;

    public void setOvtOmniHttpClient(OVTOmniHttpClient ovtOmniHttpClient) {
        this.ovtOmniHttpClient = ovtOmniHttpClient;
    }

    public void setOvtServiceConfig(OVTServiceConfig ovtServiceConfig) {
        this.ovtServiceConfig = ovtServiceConfig;
    }


    public CompletableFuture<OVTOmniItemPolicyDetails> triggerOVTOmniApiCall(ItemPolicyDetailsRequest itemPolicyDetailsRequest) {
        return CompletableFuture.supplyAsync(() -> ovtOmniHttpClient.getOVTOmniItemPolicyDetails(itemPolicyDetailsRequest), getExecutor());
    }


    public OVTOmniItemPolicyDetails getItemPolicyDetailsFromFutureObject(CompletableFuture<OVTOmniItemPolicyDetails> itemPolicyDetailsResponseCompletableFuture) {
        try {
            return itemPolicyDetailsResponseCompletableFuture.get(Long.valueOf(ovtServiceConfig.getTimeOut()), TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            String errorMsg = MessageFormat.format("OVT response fetch failed, itemId , vendorNo , error {0}", e.getMessage());
            LOG.error(errorMsg, e);
            if (e.getCause() instanceof RDMException) {
                throw (RDMException) e.getCause();
            } else {
                throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.OVT_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
            }
        }

    }
}
