package com.walmartlabs.services.rdm.model.roevent;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ROEvent {
    @JsonProperty("header")
    private ROEventHeader header;

    @JsonProperty("payload")
    private ReturnOrder   payload;

    public ROEventHeader getHeader() {
        return header;
    }

    public void setHeader(ROEventHeader header) {
        this.header = header;
    }

    public ReturnOrder getPayload() {
        return payload;
    }

    public void setPayload(ReturnOrder payload) {
        this.payload = payload;
    }

    @Override
    public String toString() {
        return "ROEvent [header=" + header + ", payload=" + payload + "]";
    }
}
