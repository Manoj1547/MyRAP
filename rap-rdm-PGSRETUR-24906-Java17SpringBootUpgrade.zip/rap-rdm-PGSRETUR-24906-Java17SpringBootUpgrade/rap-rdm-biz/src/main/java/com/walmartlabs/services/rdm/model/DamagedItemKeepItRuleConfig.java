package com.walmartlabs.services.rdm.model;

import java.util.List;

public class DamagedItemKeepItRuleConfig {
    private List<DamagedItemKeepItRuleDivision> division;

    public List<DamagedItemKeepItRuleDivision> getDivision() {
        return division;
    }

    public void setDivision(List<DamagedItemKeepItRuleDivision> division) {
        this.division = division;
    }

    @Override
    public String toString() {
        return "DamagedItemKeepItRuleConfig{" +
                "division=" + division +
                '}';
    }
}
