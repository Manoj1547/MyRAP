package com.walmartlabs.services.rdm.model.formula;

/**
 * 
 * @author Tim Jin
 *
 */
public enum FormulaType {
    JS, JSONP, JAVA
}
