
package com.walmartlabs.services.rdm.model;

/**
 * 
 * @author Tim Jin
 *
 */
public class Quantity extends Base {

    private String unitOfMeasure;

    private String measurementValue;

    public String getUnitOfMeasure() {
        return unitOfMeasure;
    }

    public void setUnitOfMeasure(String unitOfMeasure) {
        this.unitOfMeasure = unitOfMeasure;
    }

    public String getMeasurementValue() {
        return measurementValue;
    }

    public void setMeasurementValue(String measurementValue) {
        this.measurementValue = measurementValue;
    }

}
