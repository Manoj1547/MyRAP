package com.walmartlabs.services.rdm.component.apollorestock.restockrules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibilityContext;
import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibiltyResponse;
import org.springframework.stereotype.Component;

@Component("restockAndCVPEligibleRule")
public class RestockAndCVPEligibleRule extends AbstractRestockRule {

    @Override
    public String getRuleName() {
        String ruleName = RDMConstants.RESTOCK_AND_CVP_ELIGIBLE_RULE;
        return ruleName;
    }

    @Override
    public void applyConjuctionRuleDecision(RestockEligibilityContext restockEligibilityContext) {

        RestockEligibiltyResponse restockEligibiltyResponse = restockEligibilityContext.getRestockEligibiltyResponse();
        restockEligibiltyResponse.setRestockAtStoreEligible(true);
        restockEligibiltyResponse.setCvpAtStoreEligible(true);
    }
}
