package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitrules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.common.IRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Sets keepit as true for all disposition path if WMPlusMemberRule is applicable
 */
@Component("wmPlusMemberRule")
public class WMPlusMemberRule extends AbstractRDMKeepItRule {

    private static final Logger LOG = LoggerFactory.getLogger(WMPlusMemberRule.class);


    @Override
    public void applyRuleDecision(IRuleEngineContext ruleEngineContext) {

        KeepItRuleEngineContext keepItRuleEngineContext = (KeepItRuleEngineContext) ruleEngineContext;
        BaseItem item = keepItRuleEngineContext.getItem();

        //Set KeepIt true for all paths
        DispositionInfo dispositionInfo = keepItRuleEngineContext.getDispositionInfo();
        List<DispositionPath> dispositionPaths = dispositionInfo.getDispositionPaths();

        if(CollectionUtils.isNotEmpty(dispositionPaths)){
            for(DispositionPath dispositionPath : dispositionPaths){
                dispositionPath.setKeepIt(true);
            }
        }

        LOG.info("{}.applyRuleDecision() executed for offerId:{} , salesOrder:{}",this.getRuleName(),
                    item.getOfferId(),item.getOrderNo());
    }

    @Override
    public String getRuleName() {
        return RDMConstants.RULE_NAME_WM_PLUS_MEMBER;
    }

}
