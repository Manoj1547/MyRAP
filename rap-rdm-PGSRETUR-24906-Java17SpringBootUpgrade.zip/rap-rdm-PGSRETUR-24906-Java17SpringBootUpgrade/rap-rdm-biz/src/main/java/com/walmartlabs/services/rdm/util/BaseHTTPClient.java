package com.walmartlabs.services.rdm.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.platform.kernel.exception.error.Error;
import com.walmart.platform.kernel.exception.error.ErrorCategory;
import com.walmart.platform.kernel.exception.error.ErrorSeverity;
import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.text.MessageFormat;
import java.util.List;
import java.util.Map;

import com.walmartlabs.services.rdm.component.iqs.model.response.iqs.IQSRDMResponse;
import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import com.walmartlabs.services.rdm.config.client.ReturnEligibilityServiceConfig;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Resource;

public abstract class BaseHTTPClient {

    private static final Logger LOG = LoggerFactory.getLogger(BaseHTTPClient.class);
    private static final String DEFAULT_CONTENT_TYPE = "application/json";
    private static final String DEFAULT_CHAR_SET = "UTF-8";
    private static final ObjectMapper mapper;

    @ManagedConfiguration
    RDMSwitches rdmSwitches;

    static {
        mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    protected <T> T getWithMultivaluedParams(String baseUrl, String serviceUrl, Map<String, List<String>> params,
                                          Map<String, String> headers, Integer timeout, Class<T> responseClass)
            throws ServiceException {
        T serviceResponse;

        try {
            URIBuilder builder = new URIBuilder(baseUrl + serviceUrl);
            addMultivaluedQueryParams(builder, params);

            HttpGet request = new HttpGet(builder.build());
            timeout = getTimeout(timeout);
            RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(timeout)
                                                  .setConnectionRequestTimeout(timeout)
                                                  .setSocketTimeout(timeout).build();
            request.setConfig(requestConfig);
            addHeader(request, headers);

            serviceResponse = execute(request, responseClass);
        } catch (URISyntaxException e) {
            String errorMsg = MessageFormat.format("Invalid URI from query params [{0}]. Error message: {1}",
                    params.toString(), e.getMessage());
            LOG.error(errorMsg);
            throw new IllegalArgumentException(errorMsg, e);
        } catch (ServiceException e) {
            LOG.error(e.getMessage());
            throw new ServiceException(e);
        }

        return serviceResponse;
    }

    /**
     * Additional check so that timeout never becomes less than global minima.
     * @param timeout
     * @return
     */
    protected Integer getTimeout(Integer timeout){
        if(rdmSwitches != null) {
            Integer minAPITimeout = rdmSwitches.getMinAPITimeout();
            if(rdmSwitches.getMinAPITimeout() != null && timeout != null)
                return Math.max(minAPITimeout,timeout);
        }
        return timeout;
    }

    protected <T> T get(String baseUrl, String serviceUrl, Map<String, String> params, Map<String, String> headers,
                     Integer timeout, Class<T> responseClass)
            throws ServiceException {
        T serviceResponse;

        try {
            URIBuilder builder = new URIBuilder(baseUrl + serviceUrl);
            addQueryParams(builder, params);

            HttpGet request = new HttpGet(builder.build());
            timeout = getTimeout(timeout);
            RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(timeout)
                                                  .setConnectionRequestTimeout(timeout)
                                                  .setSocketTimeout(timeout).build();
            request.setConfig(requestConfig);
            addHeader(request, headers);

            serviceResponse = execute(request, responseClass);
        } catch (URISyntaxException e) {
            String errorMsg = MessageFormat.format("Invalid URI from query params [{0}]. Error message: {1}",
                    params.toString(), e.getMessage());
            LOG.error(errorMsg);
            throw new IllegalArgumentException(errorMsg, e);
        } catch (ServiceException e) {
            LOG.error(e.getMessage());
            throw new ServiceException(e);
        }

        return serviceResponse;
    }

    protected <T> T get(String baseUrl, String serviceUrl, Map<String, String> headers, Integer timeout, Class<T> responseClass)
            throws ServiceException {
        T serviceResponse;

        try {
            HttpGet request = new HttpGet(baseUrl + serviceUrl);
            timeout = getTimeout(timeout);
            RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(timeout)
                                                  .setConnectionRequestTimeout(timeout)
                                                  .setSocketTimeout(timeout).build();
            request.setConfig(requestConfig);
            addHeader(request, headers);

            serviceResponse = execute(request, responseClass);
        } catch (ServiceException e) {
            LOG.error(e.getMessage());
            throw new ServiceException(e);
        }

        return serviceResponse;
    }

    protected <T> T post(String baseUrl, String serviceUrl, String payload, Map<String, String> headers,
                      Integer timeout,Map<String, String> params, Class<T> responseClass) throws ServiceException {
        T serviceResponse;

        try {
            URIBuilder builder = new URIBuilder(baseUrl + serviceUrl);
            addQueryParams(builder, params);
            HttpPost request = new HttpPost(builder.build());
            timeout = getTimeout(timeout);
            RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(timeout)
                                                  .setConnectionRequestTimeout(timeout)
                                                  .setSocketTimeout(timeout).build();
            request.setConfig(requestConfig);

            StringEntity entity = new StringEntity(payload, DEFAULT_CHAR_SET);
            entity.setContentType(DEFAULT_CONTENT_TYPE);
            addHeader(request, headers);
            request.setEntity(entity);
            serviceResponse = executeWithResponseClass(request, responseClass);
        } catch (ServiceException | URISyntaxException e) {
            LOG.error(e.getMessage());
            throw new ServiceException(e);
        }
        return serviceResponse;
    }

    protected <T> T post(String baseUrl, String serviceUrl, String payload, Map<String, String> headers,
                         Integer timeout, Class<T> responseClass) throws ServiceException {
        T serviceResponse;

        try {
            HttpPost request = new HttpPost(baseUrl + serviceUrl);
            timeout = getTimeout(timeout);
            RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(timeout)
                    .setConnectionRequestTimeout(timeout)
                    .setSocketTimeout(timeout).build();
            request.setConfig(requestConfig);

            StringEntity params = new StringEntity(payload, DEFAULT_CHAR_SET);
            params.setContentType(DEFAULT_CONTENT_TYPE);
            addHeader(request, headers);
            request.setEntity(params);

            serviceResponse = execute(request, responseClass);
        } catch (ServiceException e) {
            LOG.error(e.getMessage());
            throw new ServiceException(e);
        }
        return serviceResponse;
    }

    protected <T> T put(String baseUrl, String serviceUrl, String payload, Map<String, String> headers,
                     Class<T> responseClass) throws ServiceException {
        T serviceResponse;

        try {
            HttpPut request = new HttpPut(baseUrl + serviceUrl);
            StringEntity params = new StringEntity(payload, DEFAULT_CHAR_SET);
            params.setContentType(DEFAULT_CONTENT_TYPE);
            addHeader(request, headers);
            request.setEntity(params);

            serviceResponse = execute(request, responseClass);
        } catch (ServiceException e) {
            LOG.error(e.getMessage());
            throw new ServiceException(e);
        }

        return serviceResponse;
    }
    protected <T> T executeWithResponseClass(HttpRequestBase request, Class<T> responseClass) throws ServiceException {
        T serviceResponse;
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();

        try {
            LOG.info("Executing {} for endpoint {}", request.getMethod(), request.getURI());
            HttpResponse response = httpClient.execute(request);

            int responseCode = response.getStatusLine().getStatusCode();
            if (responseCode >= 300) {
                String errorMsg = MessageFormat.format("Executing {0} failed with response code:{1}",
                        request, responseCode);
                LOG.error(errorMsg);

                String errorPayload;
                try (InputStream inputStream = response.getEntity().getContent()) {
                    errorPayload = IOUtils.toString(inputStream, "UTF-8");
                }
                LOG.error(errorPayload);
                ServiceResponse<Object> errorResponse = mapper.readValue(errorPayload,
                        new TypeReference<ServiceResponse<Object>>() {
                        });

                if (errorResponse.getErrors().isEmpty()) {
                    com.walmart.platform.kernel.exception.error.Error error = new Error();
                    error.setCategory(ErrorCategory.APPLICATION);
                    error.setDescription(errorMsg);
                    error.setInfo(errorPayload);
                    error.setSeverity(ErrorSeverity.ERROR);
                    errorResponse.getErrors().add(error);
                }
                throw new ServiceException(errorResponse.getErrors(), responseCode);
            }

            String responseString = EntityUtils.toString(response.getEntity());
            LOG.debug("Response {}", responseString);
            serviceResponse = parseResponse(responseString, responseClass);
        } catch (IOException e) {
            String errorMsg = MessageFormat.format("IOException when executing [{0}]: {1}", request, e.getMessage());
            LOG.error(errorMsg);
            Error error = new Error();
            error.setCategory(ErrorCategory.APPLICATION);
            error.setDescription(errorMsg);
            error.setSeverity(ErrorSeverity.ERROR);
            throw new ServiceException(error);
        } finally {
            try {
                httpClient.close();
                LOG.info("BaseHTTPClient instance closed successfully.");
            } catch (IOException e) {
                LOG.error("IOException when closing the BaseHTTPClient: {}", e.getMessage());
            }
        }
        return serviceResponse;
    }

    protected <T> T execute(HttpRequestBase request, Class<T> responseClass) throws ServiceException {
        T serviceResponse;
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();

        try {
            LOG.info("Executing {} for endpoint {}", request.getMethod(), request.getURI());
            HttpResponse response = httpClient.execute(request);

            int responseCode = response.getStatusLine().getStatusCode();
            if (responseCode >= 300) {
                String errorMsg = MessageFormat.format("Executing {0} failed with response code:{1}",
                        request, responseCode);
                LOG.error(errorMsg);

                String errorPayload;
                try (InputStream inputStream = response.getEntity().getContent()) {
                    errorPayload = IOUtils.toString(inputStream, "UTF-8");
                }
                LOG.error(errorPayload);
                ServiceResponse<Object> errorResponse = mapper.readValue(errorPayload,
                        new TypeReference<ServiceResponse<Object>>() {
                        });

                if (errorResponse.getErrors().isEmpty()) {
                    com.walmart.platform.kernel.exception.error.Error error = new Error();
                    error.setCategory(ErrorCategory.APPLICATION);
                    error.setDescription(errorMsg);
                    error.setInfo(errorPayload);
                    error.setSeverity(ErrorSeverity.ERROR);
                    errorResponse.getErrors().add(error);
                }
                throw new ServiceException(errorResponse.getErrors(), responseCode);
            }

            String responseString = EntityUtils.toString(response.getEntity());
            LOG.debug("Response {}", responseString);
            serviceResponse = castResponse(responseString, responseClass);
        } catch (IOException e) {
            String errorMsg = MessageFormat.format("IOException when executing [{0}]: {1}", request, e.getMessage());
            LOG.error(errorMsg);
            Error error = new Error();
            error.setCategory(ErrorCategory.APPLICATION);
            error.setDescription(errorMsg);
            error.setSeverity(ErrorSeverity.ERROR);
            throw new ServiceException(error);
        } finally {
            try {
                httpClient.close();
                LOG.info("BaseHTTPClient instance closed successfully.");
            } catch (IOException e) {
                LOG.error("IOException when closing the BaseHTTPClient: {}", e.getMessage());
            }
        }
        return serviceResponse;
    }

    private void addMultivaluedQueryParams(URIBuilder builder, Map<String, List<String>> params) {
        for (Map.Entry<String, List<String>> entry : params.entrySet()) {
            for (String value : entry.getValue()) {
                builder.addParameter(entry.getKey(), value);
            }
        }
    }

    private void addQueryParams(URIBuilder builder, Map<String, String> params) {
        if(params == null){
            return;
        }
        for (Map.Entry<String, String> entry : params.entrySet()) {
            builder.addParameter(entry.getKey(), entry.getValue());
        }
    }

    private void addHeader(HttpRequestBase request, Map<String, String> headers) {
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            request.addHeader(entry.getKey(), entry.getValue());
        }
    }

    private <T> T castResponse(String r, Class<T> responseClass) {
        return mapper.convertValue(r, responseClass);
    }

    private <T> T parseResponse(String r, Class<T> responseClass) throws JsonProcessingException {
        return mapper.readValue(r, responseClass);
    }
}
