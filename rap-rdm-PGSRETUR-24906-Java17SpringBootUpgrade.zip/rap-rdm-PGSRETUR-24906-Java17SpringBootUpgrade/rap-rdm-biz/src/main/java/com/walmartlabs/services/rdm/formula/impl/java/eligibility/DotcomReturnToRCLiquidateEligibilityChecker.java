package com.walmartlabs.services.rdm.formula.impl.java.eligibility;

import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibiltyResponse;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.Formula;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class DotcomReturnToRCLiquidateEligibilityChecker implements JavaEngineClass {


    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {

        RestockEligibiltyResponse restockEligibiltyResponse = FormulaEngine.getNotNullInput(formula,inputData, FormulaConstants.INTERNAL_DATA_NAME_RESTOCK_ELIGIBILITY);
        boolean isItemReturnToRCLiquidateEligible = restockEligibiltyResponse.isReturnToRCLiquidateEligible();
        return isItemReturnToRCLiquidateEligible;
    }
}