package com.walmartlabs.services.rdm.component.iqs.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FlagAttributes {
    @JsonProperty("hazmat")
    private Boolean hazmat;

    @JsonProperty("perishable")
    private Boolean perishable;

    @JsonProperty("ORMD")
    private Boolean ormd;

    @JsonProperty("airShippable")
    private Boolean airShippable;

    public Boolean getHazmat() {
        return hazmat;
    }

    public void setHazmat(Boolean hazmat) {
        this.hazmat = hazmat;
    }

    public Boolean getPerishable() { return perishable; }

    public void setPerishable(Boolean perishable) { this.perishable = perishable; }

    public Boolean getOrmd() { return ormd; }

    public void setOrmd(Boolean ormd) { this.ormd = ormd; }

    public Boolean getAirShippable() { return airShippable; }

    public void setAirShippable(Boolean airShippable) { this.airShippable = airShippable; }
}
