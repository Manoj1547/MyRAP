package com.walmartlabs.services.rdm.api;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmartlabs.services.rdm.component.iqs.model.response.GetItemDetailsResponse;
import com.walmartlabs.services.rdm.component.ls.model.GetPrefStoreResponse;
import com.walmartlabs.services.rdm.component.rap.model.response.GetReturnEligibilityResponse;
import com.walmartlabs.services.rdm.component.rcp.model.request.GetItemDispositionDetailsRequest;
import com.walmartlabs.services.rdm.component.rcp.model.response.GetItemDispositionDetailsResponse;
import com.walmartlabs.services.rdm.component.siro.model.response.GetStoreItemResponse;
import com.walmartlabs.services.rdm.component.restock.model.response.GetRestockItemDetailsResponse;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/test")
public interface TestIntegService {

    @GetMapping("/prefstore/{customer_id}")
    GetPrefStoreResponse getPrefStore(@PathVariable("customer_id") final String customerId) throws ServiceException;

    @GetMapping("/iqs")
    GetItemDetailsResponse getItemDetails(@RequestParam("id") final String id) throws ServiceException;

    @PostMapping("/rcpitemdispositionpolicy")
    GetItemDispositionDetailsResponse getRcpItemDispositionPolicyDetails(@RequestBody GetItemDispositionDetailsRequest request) throws ServiceException;

    @GetMapping("/siro")
    GetStoreItemResponse getStoreItemDetails(@RequestParam("g") final String gtin,
                                             @RequestParam("s") final String store,
                                             @RequestParam("c") final String country,
                                             @RequestParam("t") final String gtinType) throws ServiceException;

    @GetMapping("/restock/stores/{store_id}/orders/{order_no}/upc/{upc}")
    GetRestockItemDetailsResponse getRestockItemDetails(@PathVariable("store_id") final String storeId,
                                                        @PathVariable("order_no") final String orderNo,
                                                        @PathVariable("upc") final String upc,
                                                        @RequestParam("pristineCondition") final Boolean pristineCondition) throws ServiceException;

    @GetMapping("/returneligibility/{orderId}")
    GetReturnEligibilityResponse getReturnEligibility(@PathVariable("orderId") final String orderId) throws ServiceException;
}