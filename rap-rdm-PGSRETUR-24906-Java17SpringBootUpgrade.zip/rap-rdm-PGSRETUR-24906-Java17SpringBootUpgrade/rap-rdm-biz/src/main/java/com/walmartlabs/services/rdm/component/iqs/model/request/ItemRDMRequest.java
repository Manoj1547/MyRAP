package com.walmartlabs.services.rdm.component.iqs.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ItemRDMRequest {

    /*******
     *
     *{
     "ids":["05447340300851"],
     "type":"GTIN",
     "supplierNbr":"721407",
     "sellerId":"455A2F43226F41319399794332C71B7F"
     }
     *****/

    private List<String> ids;
    private String type;
    @JsonProperty(value = "supplierNbr")
    private String supplierNumber;
    private String sellerId;

    public List<String> getIds() {
        return ids;
    }

    public void setIds(List<String> ids) {
        this.ids = ids;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSupplierNumber() {
        return supplierNumber;
    }

    public void setSupplierNumber(String supplierNumber) {
        this.supplierNumber = supplierNumber;
    }

    public String getSellerId() {
        return sellerId;
    }

    public void setSellerId(String sellerId) {
        this.sellerId = sellerId;
    }

    @Override
    public String toString() {
        return "ItemRDMRequest{" +
                "ids=" + ids +
                ", type='" + type + '\'' +
                ", supplierNumber='" + supplierNumber + '\'' +
                ", sellerId='" + sellerId + '\'' +
                '}';
    }

    private String key;
    public String getKey(){
        //As of now considering only first id, code is also handling only first id's response
        if(key == null){
            key = "{" +
                    "id-" + this.getIds().get(0) +
                    "__type-" + type +
                    "__sellerId-" + this.getSellerId() +
                    "}";
        }
        return key;

    }
}
