
package com.walmartlabs.services.rdm.model.dispositionpaths.common;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.walmartlabs.services.rdm.model.Base;

/**
 * 
 * @author Tim Jin
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DispositionPath extends Base {

    private String                 path;

    private Double                 value;

    private Integer                rank;

    private String                 id;

    private Boolean                keepIt;

    private Double returnIncentive;

    private String pathValueDerivedFrom;

    @JsonIgnore
    private List<FinalDisposition> finalDispositions;

    public Double getReturnIncentive() {
        return returnIncentive;
    }

    public void setReturnIncentive(Double returnIncentive) {
        this.returnIncentive = returnIncentive;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Boolean getKeepIt() {
        return keepIt;
    }

    public void setKeepIt(Boolean keepIt) {
        this.keepIt = keepIt;
    }

    public List<FinalDisposition> getFinalDispositions() {
        return finalDispositions;
    }

    public void setFinalDispositions(List<FinalDisposition> finalDispositions) {
        this.finalDispositions = finalDispositions;
    }

    public String getPathValueDerivedFrom() {
        return pathValueDerivedFrom;
    }

    public void setPathValueDerivedFrom(String pathValueDerivedFrom) {
        this.pathValueDerivedFrom = pathValueDerivedFrom;
    }

    public DispositionPath() {
    }


}