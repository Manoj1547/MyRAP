package com.walmartlabs.services.rdm.component.apollorestock.restockrules;

import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibilityContext;
import com.walmartlabs.services.rdm.component.apollorestock.jsonmodel.Rule;
import com.walmartlabs.services.rdm.component.apollorestock.jsonmodel.RuleCondition;
import com.walmartlabs.services.rdm.component.apollorestock.util.IOperatorBasedConditionEvaluator;
import com.walmartlabs.services.rdm.component.apollorestock.util.RestockRulesFactory;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractRestockRule {

    private static final Logger LOG = LoggerFactory.getLogger(AbstractRestockRule.class);

    public abstract String getRuleName ();
    public boolean runRule(RestockEligibilityContext restockEligibilityContext){ return false; }



    /**
     * execute a conjuctionRule.
     * Rule execution result depends on evaluation of conjuctionRuleConditions.
     * @param rule
     * @param restockEligibilityContext
     * @return
     */
    public boolean runConjuctionRule(Rule rule, RestockEligibilityContext restockEligibilityContext) {
        BaseItem item = (BaseItem) restockEligibilityContext.getInputData().get(FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);
        LOG.info("ConjuctionRule execution started, RuleName " + rule.getRuleName() + " gtin " +item.getGtin());
        RuleCondition ruleCondition = rule.getRuleCondition();
        String operatorName = ruleCondition.getOperator();

        IOperatorBasedConditionEvaluator conditionEvaluator = RestockRulesFactory.getConditionEvaluator(operatorName);

        boolean ruleExecutionStatus = conditionEvaluator.evaluateConjuctionRuleConditions(ruleCondition, restockEligibilityContext);

        LOG.info("ConjuctionRule execution started, RuleName " + rule.getRuleName() + " gtin " +item.getGtin());
        return ruleExecutionStatus;
    }

    public void applyConjuctionRuleDecision(RestockEligibilityContext restockEligibilityContext){ }
}
