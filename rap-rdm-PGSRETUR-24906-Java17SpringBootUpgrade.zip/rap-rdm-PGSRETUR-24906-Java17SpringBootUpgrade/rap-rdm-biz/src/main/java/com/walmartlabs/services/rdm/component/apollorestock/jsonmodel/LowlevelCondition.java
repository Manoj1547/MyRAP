package com.walmartlabs.services.rdm.component.apollorestock.jsonmodel;

import java.util.List;

public class LowlevelCondition {

    public String operator;
    public List<RestockRulesStatus> restockRulesStatuses;

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public List<RestockRulesStatus> getRestockRulesStatuses() {
        return restockRulesStatuses;
    }

    public void setRestockRulesStatuses(List<RestockRulesStatus> restockRulesStatuses) {
        this.restockRulesStatuses = restockRulesStatuses;
    }
}
