package com.walmartlabs.services.rdm.component.ovt.model.response;


public class OVTOmniItemPolicyDetails {

    private Double handlingFeeAmount;
    private String claimFiledBy;
    private Double claimPercent;
    private String storeDisposition;
    private Boolean walmartDiscretion;

    private Boolean dmbEligible;
    private Boolean recall;
    private Boolean claimable;
    private String returnCentreDisposition;
    private Boolean dispositionDiscretion;

    private Boolean cvpEligibleAtStore;

    public OVTOmniItemPolicyDetails() {
        this.claimPercent = 0d;
        this.handlingFeeAmount = 0d;
        this.recall = false;
    }


    public Boolean getWalmartDiscretion() {
        return walmartDiscretion;
    }

    public void setWalmartDiscretion(Boolean walmartDiscretion) {
        this.walmartDiscretion = walmartDiscretion;
    }

    public Boolean getDmbEligible() {
        return dmbEligible;
    }

    public void setDmbEligible(Boolean dmbEligible) {
        this.dmbEligible = dmbEligible;
    }

    public Boolean getRecall() {
        return recall;
    }

    public void setRecall(Boolean recall) {
        this.recall = recall;
    }

    public Boolean getClaimable() {
        return claimable;
    }

    public void setClaimable(Boolean claimable) {
        this.claimable = claimable;
    }

    public Boolean getDispositionDiscretion() {
        return dispositionDiscretion;
    }

    public void setDispositionDiscretion(Boolean dispositionDiscretion) {
        this.dispositionDiscretion = dispositionDiscretion;
    }

    public Double getHandlingFeeAmount() {
        return handlingFeeAmount;
    }

    public void setHandlingFeeAmount(Double handlingFeeAmount) {
        this.handlingFeeAmount = handlingFeeAmount;
    }

    public String getClaimFiledBy() {
        return claimFiledBy;
    }

    public void setClaimFiledBy(String claimFiledBy) {
        this.claimFiledBy = claimFiledBy;
    }

    public Double getClaimPercent() {
        return claimPercent;
    }

    public void setClaimPercent(Double claimPercent) {
        this.claimPercent = claimPercent;
    }

    public String getStoreDisposition() {
        return storeDisposition;
    }

    public void setStoreDisposition(String storeDisposition) {
        this.storeDisposition = storeDisposition;
    }
    public String getReturnCentreDisposition() {
        return returnCentreDisposition;
    }

    public void setReturnCentreDisposition(String returnCentreDisposition) {
        this.returnCentreDisposition = returnCentreDisposition;
    }
    public Boolean getCvpEligibleAtStore() {
        return cvpEligibleAtStore;
    }

    public void setCvpEligibleAtStore(Boolean cvpEligibleAtStore) {
        this.cvpEligibleAtStore = cvpEligibleAtStore;
    }


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("OVTOmniItemPolicyDetails{");
        sb.append("handlingFeeAmount=").append(handlingFeeAmount);
        sb.append(", claimFiledBy='").append(claimFiledBy).append('\'');
        sb.append(", claimPercent=").append(claimPercent);
        sb.append(", storeDisposition='").append(storeDisposition).append('\'');
        sb.append(", walmartDiscretion=").append(walmartDiscretion);
        sb.append(", dmbEligible=").append(dmbEligible);
        sb.append(", recall=").append(recall);
        sb.append(", claimable=").append(claimable);
        sb.append(", returnCentreDisposition='").append(returnCentreDisposition).append('\'');
        sb.append(", dispositionDiscretion=").append(dispositionDiscretion);
        sb.append(", cvpEligibleAtStore=").append(cvpEligibleAtStore);
        sb.append('}');
        return sb.toString();
    }
}
