package com.walmartlabs.services.rdm.component.apollorestock.restockrules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibilityContext;
import com.walmartlabs.services.rdm.component.rcp.model.response.GetItemDispositionDetailsResponse;
import org.springframework.stereotype.Component;

@Component("walmartDiscretionRule")
public class WalmartDiscretionRule extends AbstractRestockRule {

    @Override
    public String getRuleName() {
        String ruleName = RDMConstants.RULE_WALMART_DISCRETION;
        return ruleName;
    }

    @Override
    public boolean runRule(RestockEligibilityContext restockEligibilityContext) {
        GetItemDispositionDetailsResponse itemDispositionDetailsResponse = restockEligibilityContext.getItemDispositionDetailsResponse();
        boolean isWalmartDiscretionAllowed = itemDispositionDetailsResponse.getDispositionDiscretionAllowed();
        return isWalmartDiscretionAllowed;
    }

}
