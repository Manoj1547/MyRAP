package com.walmartlabs.services.rdm.component.rap.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EligibilityList {

    @JsonProperty("channel")
    private String channel;

    @JsonProperty("stageReturnEligibility")
    private StageReturnEligibility stageReturnEligibility;

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public StageReturnEligibility getStageReturnEligibility() {
        return stageReturnEligibility;
    }

    public void setStageReturnEligibility(StageReturnEligibility stageReturnEligibility) {
        this.stageReturnEligibility = stageReturnEligibility;
    }
}
