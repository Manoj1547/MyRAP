package com.walmartlabs.services.rdm.component.restock.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ItemInfo {

    @JsonProperty("upc")
    private String upc;

    @JsonProperty("department")
    private Integer department;

    @JsonProperty("itemName")
    private String itemName;

    @JsonProperty("dotComItemId")
    private Integer dotComItemId;

    @JsonProperty("orderNumber")
    private String orderNumber;

    @JsonProperty("orderLineNumber")
    private Integer orderLineNumber;

    @JsonProperty("hasModularHome")
    private Boolean hasModularHome;

    @JsonProperty("sharedItem")
    private Boolean sharedItem;

    @JsonProperty("fulfillmentType")
    private String fulfillmentType;

    @JsonProperty("activeItem")
    private Boolean activeItem;

    @JsonProperty("resellable")
    private Boolean resellable;

    @JsonProperty("shipNodeType")
    private String shipNodeType;

    @JsonProperty("gtin")
    private String gtin;

    @JsonProperty("offerType")
    private String offerType;

    @JsonProperty("sellerId")
    private Integer sellerId;

    @JsonProperty("vendorNumber")
    private Integer vendorNumber;

    @JsonProperty("pristineCondition")
    private Boolean pristineCondition;

    @JsonProperty("itemOnRecall")
    private Boolean itemOnRecall;

    @JsonProperty("storeItemId")
    private Integer storeItemId;

    @JsonProperty("storeCostPrice")
    private BigDecimal storeCostPrice;

    @JsonProperty("storeSellPrice")
    private BigDecimal storeSellPrice;

    @JsonProperty("storeRetailPrice")
    private BigDecimal storeRetailPrice;

    public String getUpc() {
        return upc;
    }

    public void setUpc(String upc) {
        this.upc = upc;
    }

    public Integer getDepartment() {
        return department;
    }

    public void setDepartment(Integer department) {
        this.department = department;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Integer getDotComItemId() {
        return dotComItemId;
    }

    public void setDotComItemId(Integer dotComItemId) {
        this.dotComItemId = dotComItemId;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public Integer getOrderLineNumber() {
        return orderLineNumber;
    }

    public void setOrderLineNumber(Integer orderLineNumber) {
        this.orderLineNumber = orderLineNumber;
    }

    public Boolean getHasModularHome() {
        return hasModularHome;
    }

    public void setHasModularHome(Boolean hasModularHome) {
        this.hasModularHome = hasModularHome;
    }

    public Boolean getSharedItem() {
        return sharedItem;
    }

    public void setSharedItem(Boolean sharedItem) {
        this.sharedItem = sharedItem;
    }

    public String getFulfillmentType() {
        return fulfillmentType;
    }

    public void setFulfillmentType(String fulfillmentType) {
        this.fulfillmentType = fulfillmentType;
    }

    public Boolean getActiveItem() {
        return activeItem;
    }

    public void setActiveItem(Boolean activeItem) {
        this.activeItem = activeItem;
    }

    public Boolean getResellable() {
        return resellable;
    }

    public void setResellable(Boolean resellable) {
        this.resellable = resellable;
    }

    public String getShipNodeType() {
        return shipNodeType;
    }

    public void setShipNodeType(String shipNodeType) {
        this.shipNodeType = shipNodeType;
    }

    public String getGtin() {
        return gtin;
    }

    public void setGtin(String gtin) {
        this.gtin = gtin;
    }

    public String getOfferType() {
        return offerType;
    }

    public void setOfferType(String offerType) {
        this.offerType = offerType;
    }

    public Integer getSellerId() {
        return sellerId;
    }

    public void setSellerId(Integer sellerId) {
        this.sellerId = sellerId;
    }

    public Integer getVendorNumber() {
        return vendorNumber;
    }

    public void setVendorNumber(Integer vendorNumber) {
        this.vendorNumber = vendorNumber;
    }

    public Boolean getPristineCondition() {
        return pristineCondition;
    }

    public void setPristineCondition(Boolean pristineCondition) {
        this.pristineCondition = pristineCondition;
    }

    public Boolean getItemOnRecall() {
        return itemOnRecall;
    }

    public void setItemOnRecall(Boolean itemOnRecall) {
        this.itemOnRecall = itemOnRecall;
    }

    public Integer getStoreItemId() {
        return storeItemId;
    }

    public void setStoreItemId(Integer storeItemId) {
        this.storeItemId = storeItemId;
    }

    public BigDecimal getStoreCostPrice() {
        return storeCostPrice;
    }

    public void setStoreCostPrice(BigDecimal storeCostPrice) {
        this.storeCostPrice = storeCostPrice;
    }

    public BigDecimal getStoreSellPrice() {
        return storeSellPrice;
    }

    public void setStoreSellPrice(BigDecimal storeSellPrice) {
        this.storeSellPrice = storeSellPrice;
    }

    public BigDecimal getStoreRetailPrice() {
        return storeRetailPrice;
    }

    public void setStoreRetailPrice(BigDecimal storeRetailPrice) {
        this.storeRetailPrice = storeRetailPrice;
    }
}
