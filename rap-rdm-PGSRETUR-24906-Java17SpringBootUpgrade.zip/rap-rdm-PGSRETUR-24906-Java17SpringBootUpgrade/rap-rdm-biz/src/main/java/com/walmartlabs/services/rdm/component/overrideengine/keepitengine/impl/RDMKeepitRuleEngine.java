package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.impl;

import com.walmartlabs.services.rdm.component.overrideengine.common.AbstractRuleEngine;
import com.walmartlabs.services.rdm.component.overrideengine.common.IRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RDMKeepitRuleEngine extends AbstractRuleEngine {

    private static final Logger LOGGER = LoggerFactory.getLogger(RDMKeepitRuleEngine.class);

    @Autowired
    RDMKeepItUtil rdmKeepItUtil;


    @Override
    public void start(IRuleEngineContext ruleEngineContext){
        execute(ruleEngineContext);

    }

    private void execute(IRuleEngineContext ruleEngineContext){
        KeepItRuleEngineContext keepItRuleEngineContext = (KeepItRuleEngineContext) ruleEngineContext;

        ItemLevelKeepItRulesExecutorTask itemLevelKeepItRulesExecutorTask = new ItemLevelKeepItRulesExecutorTask(keepItRuleEngineContext);
        boolean isExecutionSuccess = false;
        try {
            itemLevelKeepItRulesExecutorTask.excuteTask();
            isExecutionSuccess = true;
        } catch (Exception e) {
            String errorMsg = "Exception during keepIt rule engine execution for offerId, " + keepItRuleEngineContext.getItem().getOfferId();
            LOGGER.error(errorMsg + e.getMessage(), e);

        } finally {
            //when there is any exception in ruleEngine execution then always set default values.
            if(!isExecutionSuccess){
                rdmKeepItUtil.updateDefaultsInResponse(keepItRuleEngineContext);
            }
        }

    }


}
