package com.walmartlabs.services.rdm.mapper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.walmartlabs.services.rdm.domain.model.*;
import com.walmartlabs.services.rdm.dto.dispositionpaths.kafka.PartialKeepIt;
import com.walmartlabs.services.rdm.model.productTypeCategory.ProductTypeCategoryData;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.walmartlabs.services.rdm.dto.dispositionpaths.common.KeepItInfo;
import com.walmartlabs.services.rdm.dto.dispositionpaths.kafka.DispositionEventPayload;
import com.walmartlabs.services.rdm.dto.dispositionpaths.request.DispositionPathsRequestDTO;
import com.walmartlabs.services.rdm.dto.dispositionpaths.response.DispositionPathsResponseDTO;
import com.walmartlabs.services.rdm.dto.dispositionpaths.simulation.request.Item;
import com.walmartlabs.services.rdm.dto.dispositionpaths.simulation.response.VariableInfo;
import com.walmartlabs.services.rdm.model.Node;
import com.walmartlabs.services.rdm.model.R2d2Data;
import com.walmartlabs.services.rdm.model.R2d2Data.R2d2DataType;
import com.walmartlabs.services.rdm.model.dispositionpaths.DispositionPathsRequest;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.KeepItDispositionInfo;
import com.walmartlabs.services.rdm.model.formula.Formula;

/**
 * 
 * @author Tim Jin
 *
 */
@Mapper(componentModel = "spring")
public interface ModelMapper {

    ModelMapper INSTANCE = Mappers.getMapper(ModelMapper.class);

    default public String map(UUID id) {
        return id == null ? null : id.toString();
    }

    public Formula clone(Formula formula);

    public List<Formula> cloneFormulas(List<Formula> formulas);

    public Node clone(Node node);

    public List<Node> cloneNodes(List<Node> nodes);

    public Map<String, Formula> clone(Map<String, Formula> formulas);

    public List<Node> mapNodeList(List<NodeDO> nodes);

    @Mapping(target = "inputVariables", ignore = true)
    @Mapping(target = "outputVariables", ignore = true)
    @Mapping(target = "properties", ignore = true)
    public Formula map(FormulaDO formula);

    @Mapping(target = "valueFormulas", ignore = true)
    @Mapping(target = "valueStopFormulas", ignore = true)
    @Mapping(target = "eligibilityFormulas", ignore = true)
    @Mapping(target = "variableFormulas", ignore = true)
    @Mapping(target = "validationFormulas", ignore = true)
    @Mapping(target = "formulas", ignore = true)
    @Mapping(target = "value", ignore = true)
    public Node map(NodeDO node);

    default Map<String, String> mapNodeFormulaPropertyList(List<NodeFormulaPropertyDO> properties) {
        Map<String, String> map = null;
        if(properties != null && properties.size() > 0){
            map = new HashMap<>();
            for(NodeFormulaPropertyDO pdo : properties){
                map.put(pdo.getName(), pdo.getValue());
            }
        }
        return map;
    }

    @AfterMapping
    default public void postMapNode(NodeDO nodeDo, @MappingTarget Node node) {
        List<NodeFormulaDO> formulas = nodeDo.getNodeFormulas();
        if(formulas != null) for(NodeFormulaDO formulaDo : formulas){
            Formula formula = map(formulaDo.getFormula());
            formula.setProperties(mapNodeFormulaPropertyList(formulaDo.getFormulaPorperties()));
            switch (formulaDo.getType()) {
                case ELIGIBILITY:
                    node.getEligibilityFormulas().add(formula);
                    node.getFormulas().add(formula);
                    break;
                case VALUE:
                    node.getValueFormulas().add(formula);
                    node.getFormulas().add(formula);
                    break;
                case VALUE_STOP:
                    node.getValueStopFormulas().add(formula);
                    node.getFormulas().add(formula);
                    break;
                case VARIABLE:
                    node.getVariableFormulas().add(formula);
                    node.getFormulas().add(formula);
                    break;
                case VALIDATION:
                    node.getValidationFormulas().add(formula);
                    node.getFormulas().add(formula);
                    break;

            }
        }
    }

    public DispositionPathsResponseDTO clone(DispositionPathsRequestDTO request);

    public List<com.walmartlabs.services.rdm.dto.dispositionpaths.common.Item> clone(List<com.walmartlabs.services.rdm.dto.dispositionpaths.common.Item> items);

    @Mapping(target = "lineRefundAmount", ignore = true)
    @Mapping(target = "departmentNo", ignore = true)
    @Mapping(target = "unitPrice", ignore = true)
    @Mapping(target = "itemCustomAttributes", ignore = true)
    public com.walmartlabs.services.rdm.dto.dispositionpaths.common.Item clone(com.walmartlabs.services.rdm.dto.dispositionpaths.common.Item item);

    @AfterMapping
    default public void postItemToItem(com.walmartlabs.services.rdm.dto.dispositionpaths.common.Item i1, @MappingTarget com.walmartlabs.services.rdm.model.dispositionpaths.Item i2) {
        if(i2.getKeepItInfo() == null) i2.setKeepItInfo(new com.walmartlabs.services.rdm.model.dispositionpaths.common.KeepItInfo());
    }

    public com.walmartlabs.services.rdm.dto.dispositionpaths.common.DispositionInfo<com.walmartlabs.services.rdm.dto.dispositionpaths.common.DispositionPath> map(DispositionInfo info);

    public List<com.walmartlabs.services.rdm.dto.dispositionpaths.common.DispositionPath> map(List<DispositionPath> paths);

    public DispositionPathsRequest map(DispositionPathsRequestDTO finalDisposition);

    @AfterMapping
    default public void postMapLine(DispositionPathsRequestDTO requestDTO, @MappingTarget DispositionPathsRequest request) {
        if(request != null){
            List<com.walmartlabs.services.rdm.model.dispositionpaths.Item> items = request.getItems();
            if(items != null) for(com.walmartlabs.services.rdm.model.dispositionpaths.Item item : items){
                item.setSmartLabelId(requestDTO.getSmartLabel());
            }
        }
    }

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "lines", ignore = true)
    @Mapping(target = "createTs", ignore = true)
    @Mapping(target = "createUserId", ignore = true)
    @Mapping(target = "modifyTs", ignore = true)
    @Mapping(target = "modifyuserId", ignore = true)
    @Mapping(target = "channelName", ignore = true)
    @Mapping(target = "storeId", ignore = true)
    public TransactionDO map(DispositionPathsRequest request);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "transaction", ignore = true)
    @Mapping(target = "recommendDisposition", ignore = true)
    @Mapping(target = "quantity", source = "quantity.measurementValue")
    @Mapping(target = "quantityUom", source = "quantity.unitOfMeasure")
    @Mapping(target = "createTs", ignore = true)
    @Mapping(target = "createUserId", ignore = true)
    @Mapping(target = "modifyTs", ignore = true)
    @Mapping(target = "modifyuserId", ignore = true)
    public TransactionItemDO map(com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem item);

    @AfterMapping
    default public void postMapLine(Item item, @MappingTarget TransactionItemDO line) {
        if(item.getQuantity() != null){
            line.setQuantity(item.getQuantity().getMeasurementValue());
            line.setQuantityUom(item.getQuantity().getUnitOfMeasure());
        }
    }

    public List<R2d2Data> mapR2d2List(List<R2d2DataDO> nodes);

    public List<ProductTypeCategoryData> mapProductTypeList(List<ProductTypeCategoryDO> nodes);

    public com.walmartlabs.services.rdm.domain.model.R2d2DataType map(R2d2DataType r2d2DataType);

    public List<com.walmartlabs.services.rdm.model.dispositionpaths.common.VariableInfo> mapVariableList(List<SimulationVariableDO> variableDOs);

    ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    TypeFactory  typeFactory   = OBJECT_MAPPER.getTypeFactory();

    default public Map<String, Object> objToMap(Object o) {
        return OBJECT_MAPPER.convertValue(o, typeFactory.constructMapType(Map.class, String.class, Object.class));
    }

    public com.walmartlabs.services.rdm.dto.Node map(com.walmartlabs.services.rdm.model.Node n);

    public List<VariableInfo> mapList(List<com.walmartlabs.services.rdm.model.dispositionpaths.common.VariableInfo> variables);

    public List<com.walmartlabs.services.rdm.model.dispositionpaths.simulation.Item> mapSimulationItemList(List<com.walmartlabs.services.rdm.dto.dispositionpaths.simulation.request.Item> itemDTOList);

    @Mapping(target = "simulation", expression = "java(true)")
    public com.walmartlabs.services.rdm.model.dispositionpaths.simulation.Item mapItem(com.walmartlabs.services.rdm.dto.dispositionpaths.simulation.request.Item itemDTO);

    public com.walmartlabs.services.rdm.dto.dispositionpaths.simulation.response.DispositionInfo mapSimulation(DispositionInfo info);

    @AfterMapping
    default public void postMapSimulation(com.walmartlabs.services.rdm.dto.dispositionpaths.simulation.request.Item i1, @MappingTarget com.walmartlabs.services.rdm.model.dispositionpaths.simulation.Item i2) {
        if(i2.getKeepItInfo() == null) i2.setKeepItInfo(new com.walmartlabs.services.rdm.model.dispositionpaths.common.KeepItInfo());
    }

    public com.walmartlabs.services.rdm.dto.dispositionpaths.kafka.DispositionInfo mapKafka(DispositionInfo info);

    public DispositionEventPayload map(DispositionPathsResponseDTO info);

    // keepItInfo
    public KeepItDispositionInfo clone(com.walmartlabs.services.rdm.model.dispositionpaths.common.KeepItInfo keepItInfo, boolean simulation);

    public void copy(KeepItDispositionInfo k, @MappingTarget com.walmartlabs.services.rdm.model.dispositionpaths.common.KeepItInfo k2);

    public RecommendKeepItDispositionDO clone(KeepItDispositionInfo keepItInfo);

    @AfterMapping
    default public void postClone(com.walmartlabs.services.rdm.model.dispositionpaths.common.KeepItInfo k1, boolean simulation, @MappingTarget KeepItDispositionInfo k2) {
        if(k2.getTrustCustomerToKeepIt() == null){
            k2.setIsTrustCustomerDefault(true);
            k2.setTrustCustomerToKeepIt(simulation ? true : false);
        }
        if(k2.getItemKeepItEligibility() == null){
            k2.setIsItemKeepItDefault(true);
            k2.setItemKeepItEligibility(simulation ? true : false);
        }
    }

    public KeepItInfo map(KeepItDispositionInfo keepItDispositionInfo);

    public PartialKeepIt map(com.walmartlabs.services.rdm.dto.dispositionpaths.common.PartialKeepIt keepItDispositionInfo);
}
