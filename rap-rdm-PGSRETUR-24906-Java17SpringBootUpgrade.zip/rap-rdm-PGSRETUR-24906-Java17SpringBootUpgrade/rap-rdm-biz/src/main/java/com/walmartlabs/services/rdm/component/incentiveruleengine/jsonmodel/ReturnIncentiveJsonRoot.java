package com.walmartlabs.services.rdm.component.incentiveruleengine.jsonmodel;



import java.util.List;

public class ReturnIncentiveJsonRoot {
    public List<Rule> getReturnIncentiveRules() {
        return returnIncentiveRules;
    }

    public void setReturnIncentiveRules(List<Rule> returnIncentiveRules) {
        this.returnIncentiveRules = returnIncentiveRules;
    }

    public List<Rule> returnIncentiveRules;


}
