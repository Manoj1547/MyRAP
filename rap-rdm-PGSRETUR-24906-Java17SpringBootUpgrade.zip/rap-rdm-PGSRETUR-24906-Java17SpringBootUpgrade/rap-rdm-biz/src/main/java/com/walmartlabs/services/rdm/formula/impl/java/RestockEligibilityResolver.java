package com.walmartlabs.services.rdm.formula.impl.java;

import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibilityContext;
import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibilityEvaluator;
import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibiltyResponse;
import com.walmartlabs.services.rdm.component.apollorestock.restockrules.AbstractRestockRule;
import com.walmartlabs.services.rdm.component.dsim.model.MarkDownPriceResponse;
import com.walmartlabs.services.rdm.component.dsim.model.config.summary.response.MarkDownConfigResponse;
import com.walmartlabs.services.rdm.component.rcp.model.response.GetItemDispositionDetailsResponse;
import com.walmartlabs.services.rdm.component.siro.model.response.GetStoreItem;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.Formula;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import com.walmartlabs.services.rdm.util.FormulaServiceUtil;
import com.walmartlabs.services.rdm.util.RDMTransactionLogger;
import io.strati.txnmarking.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.CompletableFuture;

@Service
public class RestockEligibilityResolver implements JavaEngineClass {

    @Autowired
    private RDMTransactionLogger transactionLogger;
    @Autowired
    RestockEligibilityEvaluator restockEligibilityEvaluator;

    private static final String EVALUATE_RESTOCK_ELIGIBILITY =  "EvaluateRestockEligibility";
    private static final Logger LOG = LoggerFactory.getLogger(RestockEligibilityResolver.class);


    @Override
    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        LOG.info("RestockEligibilityResolver.eval() started");
        FormulaServiceUtil.CheckForException(formula, inputData);
        Transaction transaction = transactionLogger.createTransaction(EVALUATE_RESTOCK_ELIGIBILITY);
        transaction.start();
        RestockEligibiltyResponse restockEligibiltyResponse = null;
        try {
            CompletableFuture<MarkDownConfigResponse> markDownConfigResponseFuture = FormulaEngine.getInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_DSIM_MARKDOWN);

            CompletableFuture<MarkDownPriceResponse> markDownPriceResponseFuture = FormulaEngine.getInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_DSIM_MARKDOWN_PRICE_PERCENT);

            GetStoreItem storeItemResponse = FormulaEngine.getInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_SIRO_STORE_ITEM);

            GetItemDispositionDetailsResponse itemDispositionDetailsResponse = FormulaEngine.getInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_RCP);


            RestockEligibilityContext restockEligibilityContext = new RestockEligibilityContext();
            restockEligibilityContext.setInputData(inputData);
            restockEligibilityContext.setMarkDownConfigResponseFuture(markDownConfigResponseFuture);
            restockEligibilityContext.setMarkDownPriceResponseFuture(markDownPriceResponseFuture);
            restockEligibilityContext.setStoreItemResponse(storeItemResponse);
            restockEligibilityContext.setItemDispositionDetailsResponse(itemDispositionDetailsResponse);


            restockEligibiltyResponse = restockEligibilityEvaluator.evaluateRestockEligibilty(restockEligibilityContext);
            transaction.end();
        } catch(RDMException ex){
            LOG.error("Exception occured in Restock eligibility evaluation," + ex.getMessage(), ex);
            FormulaServiceUtil.addExceptionInInputData(formula, inputData, ex);
            transaction.logException(ex);
            transaction.endWithFailure(ex.getMessage());
            throw ex;
        }
        LOG.info("RestockEligibilityResolver.eval() ended");
        return restockEligibiltyResponse;
    }
}
