package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.config.client.ConfigManager;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;

import io.strati.configuration.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;

@Component("wmPlusCustomerItemPriceCheck")
public class WMPlusCustomerItemPriceCheck implements IRDMKeepItRuleCheck {

    @Autowired
    RDMKeepItUtil rdmKeepItUtil;

    @ManagedConfiguration
    RDMKeepItConfig rdmKeepItConfig;

    private static final Logger LOG = LoggerFactory.getLogger(WMPlusCustomerItemPriceCheck.class);


    @Override
    public String getKeepItCheckName() {
        String keepItRuleCheckName = RDMConstants.RULE_CHECK_NAME_WMPLUS_CUST_ITEM_PRICE_CHECK;
        return keepItRuleCheckName;
    }

    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {
        LOG.debug("WMPlusCustomerItemPriceCheck.runCheck() started");

        BigDecimal itemRetailPrice;
        if(rdmKeepItConfig.getKeepItItemDetailsFromRequestEnabled()) {
            itemRetailPrice = rdmKeepItUtil.getItemPriceFromRequest(keepItRuleEngineContext);
        }else{
            itemRetailPrice = rdmKeepItUtil.getItemPrice(keepItRuleEngineContext);
        }

        boolean isPriceLessThanThreshold = false;

        RDMKeepItConfig rdmKeepItConfig = ConfigManager.getRdmKeepItConfig();
        if(itemRetailPrice.compareTo(new BigDecimal(rdmKeepItConfig.getWmPluskeepItThresholdAmount())) <= 0 ){
            isPriceLessThanThreshold = true;
        }

        LOG.debug("WMPlusCustomerItemPriceCheck.runCheck() exited");
        return isPriceLessThanThreshold;
    }
}
