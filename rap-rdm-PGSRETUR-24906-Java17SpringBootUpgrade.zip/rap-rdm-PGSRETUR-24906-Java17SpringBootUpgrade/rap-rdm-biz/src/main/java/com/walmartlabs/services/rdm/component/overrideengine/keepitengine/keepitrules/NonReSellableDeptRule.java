package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitrules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.common.IRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.config.client.ConfigManager;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.List;


@Component("nonReSellableDeptRule")
public class NonReSellableDeptRule extends AbstractRDMKeepItRule {

    private static final Logger LOG = LoggerFactory.getLogger(NonReSellableDeptRule.class);

    @Autowired
    RDMKeepItUtil rdmKeepItUtil;

    @ManagedConfiguration
    RDMKeepItConfig rdmKeepItConfig;

    @Override
    public void applyRuleDecision(IRuleEngineContext ruleEngineContext) {
        KeepItRuleEngineContext keepItRuleEngineContext = (KeepItRuleEngineContext) ruleEngineContext;
        String offerId = keepItRuleEngineContext.getItem().getOfferId();
        LOG.info(this.getRuleName() + ".applyRuleDecision() started for offerId," + offerId);

        DispositionInfo dispositionInfo = keepItRuleEngineContext.getDispositionInfo();

        BigDecimal itemRetailPrice;
        if(rdmKeepItConfig.getKeepItItemDetailsFromRequestEnabled()) {
            itemRetailPrice = rdmKeepItUtil.getItemPriceFromRequest(keepItRuleEngineContext);
        }else{
            itemRetailPrice = rdmKeepItUtil.getItemPrice(keepItRuleEngineContext);
        }

        boolean isItemKeepIt = false;
        RDMKeepItConfig rdmKeepItConfig = ConfigManager.getRdmKeepItConfig();
        if(itemRetailPrice.compareTo(new BigDecimal(rdmKeepItConfig.getNonResellableDeptkeepItThresholdAmount())) <= 0){
            isItemKeepIt = true;
        }
        List<DispositionPath> dispositionPaths = dispositionInfo.getDispositionPaths();
        boolean trustCustomer = dispositionInfo.getKeepItInfo().getTrustCustomerToKeepIt();
        if(dispositionPaths != null){
            for(DispositionPath dispositionPath : dispositionPaths){
                dispositionPath.setKeepIt(trustCustomer & isItemKeepIt);
            }
        }
        LOG.info(this.getRuleName() + ".applyRuleDecision() exited for offerId," + offerId);

    }

    @Override
    public String getRuleName() {
        String ruleName = RDMConstants.RULE_NAME_NON_RESELLABLE_DEPT;
        return ruleName;
    }


}
