package com.walmartlabs.services.rdm.component.ovt.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class ReturnTermPolicy {

    @JsonProperty("policyType")
    private String policyType;

    @JsonProperty("keyTemplate")
    private String keyTemplate;

    @JsonProperty("policies")
    private List<Policy> policies;


    public String getPolicyType() {
        return policyType;
    }

    public void setPolicyType(String policyType) {
        this.policyType = policyType;
    }

    public String getKeyTemplate() {
        return keyTemplate;
    }

    public void setKeyTemplate(String keyTemplate) {
        this.keyTemplate = keyTemplate;
    }


    public List<Policy> getPolicies() {
        return policies;
    }

    public void setPolicies(List<Policy> policies) {
        this.policies = policies;
    }


}
