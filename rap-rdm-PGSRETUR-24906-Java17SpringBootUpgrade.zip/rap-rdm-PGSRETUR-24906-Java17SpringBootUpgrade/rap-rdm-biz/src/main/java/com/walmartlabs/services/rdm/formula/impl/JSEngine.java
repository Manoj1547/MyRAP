package com.walmartlabs.services.rdm.formula.impl;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.script.Bindings;
import javax.script.Compilable;
import javax.script.CompiledScript;
import javax.script.ScriptContext;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.script.SimpleBindings;
import javax.script.SimpleScriptContext;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.walmartlabs.services.rdm.formula.Context;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.FormulaException;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.Formula;
import com.walmartlabs.services.rdm.model.formula.FormulaType;

/**
 * formula name needs to be unique.
 *
 * @author Tim Jin
 *
 */
@Service
public class JSEngine implements FormulaEngine {


    private static final Pattern NOT_DEFINED = Pattern.compile("ReferenceError: \"([^\"]+)\" is not defined");

    private String getVariable(ScriptException e) {
        String msg = null;
        if(e.getCause() != null) msg = e.getCause().getMessage();
        Matcher matcher = NOT_DEFINED.matcher(msg);
        if(matcher.find()){
            //found a parameter
            return matcher.group(1);
        }
        return null;
    }

    private Map<String, CompiledScript> compiledMap = new ConcurrentHashMap<>();

    private ScriptEngine                eng;

    JSEngine() {
        ScriptEngineManager m = new ScriptEngineManager();
        eng = m.getEngineByName("nashorn");
    }

    public Context getContext(String eval) {
        eval = StringUtils.trimToNull(eval);
        Context ctx = new Context();

        Set<String> input = null;

        if(eval != null){
            ScriptContext sctx = new SimpleScriptContext();
            SimpleBindings b = new SimpleBindings();
            sctx.setBindings(b, ScriptContext.ENGINE_SCOPE);

            boolean failed = true;

            while(failed){
                try{
                    eng.eval(eval, sctx);
                    failed = false;
                }catch (ScriptException e){
                    if(input == null) input = new HashSet<>();

                    String variable = getVariable(e);
                    if(variable != null){
                        b.put(variable, true);
                        input.add(variable);
                    }else{
                        throw new FormulaException(e);
                    }
                }
            }
            Bindings nashorn_global = (Bindings) sctx.getAttribute("nashorn.global");
            ctx.setOutputVariables(nashorn_global.keySet());
        }

        ctx.setInputVariables(input);
        return ctx;
    }

    /**
     * @param formula
     *            not null and type is correct
     * @param inputData
     *            not null
     * @throws VariableMissingException
     */
    @Override
    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        try{
            SimpleBindings b = new SimpleBindings();
            Set<String> inputVariables = formula.getInputVariables();
            if(inputVariables != null){
                for(String input : inputVariables){
                    if(inputData.containsKey(input)) b.put(input, inputData.get(input));
                }
            }

            String eval = formula.getFormula();
            CompiledScript compiled;
            if(compiledMap.containsKey(eval)){
                compiled = compiledMap.get(eval);
            }else{
                compiled = ((Compilable) eng).compile(formula.getFormula());
                compiledMap.put(eval, compiled);
            }

            Object v = compiled.eval(b);

            if(v == null) return null;
            switch (formula.getValueType()) {
                case BOOLEAN:
                    return BooleanUtils.toBooleanObject(v.toString());
                case DOUBLE:
                    return Double.parseDouble(v.toString());
                case INTEGER:
                    return (int) Double.parseDouble(v.toString());
                case STRING:
                    return v.toString();
                case OBJECT:
                default:
                    return convert(v);
            }
        }catch (ScriptException e){
            String variable = getVariable(e);
            if(variable != null){
                throw new VariableMissingException(e, variable);
            }else{
                throw new FormulaException(e);
            }
        }catch (Exception e){
            throw new FormulaException(e);
        }
    }

    private static Object convert(final Object obj) {
        if(obj instanceof Bindings){
            try{
                final Class<?> cls = Class.forName("jdk.nashorn.api.scripting.ScriptObjectMirror");
                if(cls.isAssignableFrom(obj.getClass())){
                    final Method isArray = cls.getMethod("isArray");
                    final Object result = isArray.invoke(obj);
                    if(result != null && result.equals(true)){
                        final Method values = cls.getMethod("values");
                        final Object vals = values.invoke(obj);
                        if(vals instanceof Collection<?>){
                            final Collection<?> coll = (Collection<?>) vals;
                            return coll.toArray(new Object[0]);
                        }
                    }
                }
            }catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e){

            }
        }
        if(obj instanceof List<?>){
            final List<?> list = (List<?>) obj;
            return list.toArray(new Object[0]);
        }
        return obj;
    }

    @Override
    public FormulaType type() {
        return FormulaType.JS;
    }

}
