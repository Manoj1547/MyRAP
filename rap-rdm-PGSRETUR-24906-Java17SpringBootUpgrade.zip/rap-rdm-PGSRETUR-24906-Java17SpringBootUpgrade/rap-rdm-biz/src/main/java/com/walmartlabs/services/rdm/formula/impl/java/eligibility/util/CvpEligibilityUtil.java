package com.walmartlabs.services.rdm.formula.impl.java.eligibility.util;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.executor.RdmKeepItRuleExcutorService;
import com.walmartlabs.services.rdm.component.ovt.model.response.OVTOmniItemPolicyDetails;
import com.walmartlabs.services.rdm.component.ovt.service.util.OVTOmniServiceHelper;
import com.walmartlabs.services.rdm.component.rcp.model.response.GetItemDispositionDetailsResponse;
import com.walmartlabs.services.rdm.component.restock.model.response.Disposition;
import com.walmartlabs.services.rdm.component.restock.model.response.GetRestockItemDetailsResponse;
import com.walmartlabs.services.rdm.config.client.ConfigManager;
import com.walmartlabs.services.rdm.config.client.OVTServiceConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.formula.Formula;
import com.walmartlabs.services.rdm.util.BeanHelper;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;
import java.util.Map;

import static com.walmartlabs.services.rdm.RDMConstants.ITEM_CONDITION_DAMAGED;

public class CvpEligibilityUtil {


    public static boolean isCvpEligible(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        boolean isCvpEligible = false;
        boolean isCvpEligibleForMBS = false;

        BaseItem item = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);

        //Item Condition check
        String itemCondition = item.getItemCondition();
        boolean isCvpEligibleBasedOnItemCondition = !ITEM_CONDITION_DAMAGED.equals(itemCondition);


        boolean isCvpEligibleBasedOnRecalledFromOvt = false;
        boolean isCvpEligibleBasedOnCvpAtStoreFromOvt = false;

       // Apollo phase-3 logic under ccm
        if(ConfigManager.getOvtServiceConfig().getEnableOmniAPILogicForCVPEligible()) {
            OVTOmniServiceHelper ovtOmniServiceHelper = BeanHelper.getBean(OVTOmniServiceHelper.class);

            OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails =
                    ovtOmniServiceHelper.getItemPolicyDetailsFromFutureObject(FormulaEngine.getInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_OVT_OMNI_FUTURE));
            if (ovtOmniItemPolicyDetails != null) {
                isCvpEligibleBasedOnRecalledFromOvt = !ovtOmniItemPolicyDetails.getRecall();
                if (null != ovtOmniItemPolicyDetails.getCvpEligibleAtStore()) {
                    isCvpEligibleBasedOnCvpAtStoreFromOvt = ovtOmniItemPolicyDetails.getCvpEligibleAtStore();
                }
            }
        }else {
            GetItemDispositionDetailsResponse itemDispositionDetailsResponse = FormulaEngine.getInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_RCP);
            if (itemDispositionDetailsResponse != null) {
                isCvpEligibleBasedOnRecalledFromOvt = !itemDispositionDetailsResponse.getIsRecall();
                isCvpEligibleBasedOnCvpAtStoreFromOvt = itemDispositionDetailsResponse.getCvpEligibleAtStore();
            }
        }
        //Item Restock Check
        boolean isCvpEligibleBasedOnRestockFromClaims = false;
        GetRestockItemDetailsResponse restockDataResponse = FormulaEngine.getInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_DISPOSITION);
        if(restockDataResponse != null && restockDataResponse.getDisposition() != null && restockDataResponse.getDisposition().length > 0) {
            Disposition disposition = restockDataResponse.getDisposition()[0];
            isCvpEligibleBasedOnRestockFromClaims = RDMConstants.RESTOCK.equals(disposition.getCode());
        }

        isCvpEligible = isCvpEligibleBasedOnItemCondition & isCvpEligibleBasedOnRecalledFromOvt & isCvpEligibleBasedOnRestockFromClaims;
        isCvpEligibleForMBS = isCvpEligibleBasedOnCvpAtStoreFromOvt | isCvpEligibleBasedOnRestockFromClaims;

        item.setCvpEligible(isCvpEligibleForMBS);

        return isCvpEligible;
    }
}
