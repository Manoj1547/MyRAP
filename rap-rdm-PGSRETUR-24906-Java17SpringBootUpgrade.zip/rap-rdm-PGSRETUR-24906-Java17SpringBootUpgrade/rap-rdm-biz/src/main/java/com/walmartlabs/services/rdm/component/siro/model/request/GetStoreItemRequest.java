package com.walmartlabs.services.rdm.component.siro.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetStoreItemRequest {

    @JsonProperty("g")
    private String gtin;

    @JsonProperty("s")
    private String store;

    @JsonProperty("c")
    private String country;

    @JsonProperty("t")
    private String gtinType;

    public String getGtin() {
        return gtin;
    }

    public void setGtin(String gtin) {
        this.gtin = gtin;
    }

    public String getStore() {
        return store;
    }

    public void setStore(String store) {
        this.store = store;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getGtinType() {
        return gtinType;
    }

    public void setGtinType(String gtinType) {
        this.gtinType = gtinType;
    }

    @Override
    public String toString() {
        return "GetStoreItemRequest{" +
                "gtin='" + gtin + '\'' +
                ", store='" + store + '\'' +
                ", country='" + country + '\'' +
                ", gtinType='" + gtinType + '\'' +
                '}';
    }
}
