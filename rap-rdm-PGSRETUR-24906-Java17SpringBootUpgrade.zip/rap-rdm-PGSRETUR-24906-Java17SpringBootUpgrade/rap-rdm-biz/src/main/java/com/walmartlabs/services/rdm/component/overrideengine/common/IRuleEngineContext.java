package com.walmartlabs.services.rdm.component.overrideengine.common;

public interface IRuleEngineContext {
}
