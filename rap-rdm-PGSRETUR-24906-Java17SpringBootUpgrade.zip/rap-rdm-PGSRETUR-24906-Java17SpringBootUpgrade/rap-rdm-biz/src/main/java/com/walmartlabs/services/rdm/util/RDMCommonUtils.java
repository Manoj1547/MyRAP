package com.walmartlabs.services.rdm.util;

import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.Timing;
import com.walmartlabs.services.rdm.model.formula.Formula;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.apache.commons.lang.BooleanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.Callable;

@Component
public class RDMCommonUtils {

    @ManagedConfiguration
    RDMSwitches switches;

    private static final Logger LOG = LoggerFactory.getLogger(RDMCommonUtils.class);

    public static boolean isExternalServicePreCall(Formula formula, Map<String, Object> inputData) {
        return(BooleanUtils.isTrue((Boolean) inputData.get(formula.getName() + FormulaConstants.PRE_CALL)));
    }


    public <T> T timingProxy(String name, Callable<T> callable, Map<String, Timing> timing, Timing.Type type) throws Exception {
        long b = System.currentTimeMillis();
        T v = callable.call();
        timing.putIfAbsent(name, new Timing(System.currentTimeMillis() - b, null, type));
        return v;
    }

    public void timingProxy(String name, Map<String, Timing> timing, Timing.Type type, long startTimeMillis) {
        timing.putIfAbsent(name, new Timing(System.currentTimeMillis() - startTimeMillis, null, type));
    }


    public void printTimings(DispositionInfo info) {
        Map<String, Timing> timings = info.getTiming();
        if(timings != null){
            long total = 0;
            Timing timing;
            for(String service : timings.keySet()){
                timing = timings.get(service);
                total += timing.getSpan();
                if(BooleanUtils.isTrue(switches.getLogDPTiming())) LOG.info("Timing-{} {}={} {} {}", timing.getType().name(), service, timing.getSpan(), timing.getTime(), timing.getOther());
            }
            LOG.info("Timing-CODE_FLOW Total={} {} {} {}", info.getEnd() - info.getStart(), System.currentTimeMillis(), total);
        }
    }




}