package com.walmartlabs.services.rdm.component.apollorestock.jsonmodel;

import java.util.List;

public class ConjuctionRuleCondition{
    public String conditionName;
    public List<LowlevelCondition> lowlevelConditions;

    public String getConditionName() {
        return conditionName;
    }

    public void setConditionName(String conditionName) {
        this.conditionName = conditionName;
    }

    public List<LowlevelCondition> getLowlevelConditions() {
        return lowlevelConditions;
    }

    public void setLowlevelConditions(List<LowlevelCondition> lowlevelConditions) {
        this.lowlevelConditions = lowlevelConditions;
    }
}