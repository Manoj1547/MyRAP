package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.RDMConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component("defaultRDMKeepItRuleCheck")
public class DefaultRDMKeepItRuleCheck implements IRDMKeepItRuleCheck {

    private static final Logger LOG = LoggerFactory.getLogger(DefaultRDMKeepItRuleCheck.class);

    @Override
    public String getKeepItCheckName() {
        String keepItRuleName = RDMConstants.RULE_CHECK_NAME_DEFAULT_CHECK;
        return keepItRuleName;
    }

    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {

        LOG.debug("DefaultRDMKeepItRuleCheck.runCheck() started");

        LOG.debug("DefaultRDMKeepItRuleCheck.runCheck() exited");
        return true;
    }
}
