
package com.walmartlabs.services.rdm.model;

import com.walmartlabs.services.rdm.model.Base;

/**
 * 
 * @author Tim Jin
 *
 */
public class Audit extends Base {

    private String entryType;

    private String enteredBy;

    public String getEntryType() {
        return entryType;
    }

    public void setEntryType(String entryType) {
        this.entryType = entryType;
    }

    public String getEnteredBy() {
        return enteredBy;
    }

    public void setEnteredBy(String enteredBy) {
        this.enteredBy = enteredBy;
    }

    @Override
    public String toString() {
        return "Audit [ enteredBy=" + enteredBy + ", entryType=" + entryType + "]";
    }

}
