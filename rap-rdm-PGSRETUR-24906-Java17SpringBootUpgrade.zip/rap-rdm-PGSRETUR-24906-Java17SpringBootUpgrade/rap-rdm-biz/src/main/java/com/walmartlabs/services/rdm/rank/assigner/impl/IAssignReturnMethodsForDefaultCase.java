package com.walmartlabs.services.rdm.rank.assigner.impl;

import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;

/**
 * Interface to assign return methods in default case
 * @author v0h01q5
 */
public interface IAssignReturnMethodsForDefaultCase {

    void assignFinalReturnModes(DispositionInfo dispositionInfo);
}
