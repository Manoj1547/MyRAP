package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.jsonmodel;

import java.util.List;

public class KeepItRules {

    public String channel;
    public List<Rule> rules;

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public List<Rule> getRules() {
        return rules;
    }

    public void setRules(List<Rule> rules) {
        this.rules = rules;
    }
}


