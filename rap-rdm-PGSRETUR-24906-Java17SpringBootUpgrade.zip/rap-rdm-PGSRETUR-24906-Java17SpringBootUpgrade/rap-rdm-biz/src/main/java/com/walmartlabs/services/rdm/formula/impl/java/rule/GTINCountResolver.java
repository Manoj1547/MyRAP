package com.walmartlabs.services.rdm.formula.impl.java.rule;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.formula.Formula;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public class GTINCountResolver implements JavaEngineClass {

    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        BaseItem item = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);
        List<? extends BaseItem> items = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEMS);

        Map<String, Integer> gtinCount = new HashMap<>();
        for(BaseItem i : items){
            int qty = Integer.valueOf(i.getQuantity().getMeasurementValue());
            gtinCount.compute(i.getGtin(), (k, v) -> (v == null) ? qty : v + qty);
        }
        return gtinCount.get(item.getGtin());
    }

}
