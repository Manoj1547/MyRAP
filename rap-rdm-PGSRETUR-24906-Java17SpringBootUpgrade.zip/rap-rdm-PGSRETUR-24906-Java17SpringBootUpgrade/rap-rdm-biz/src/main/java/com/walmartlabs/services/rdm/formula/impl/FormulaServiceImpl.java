package com.walmartlabs.services.rdm.formula.impl;

import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Stack;
import java.util.concurrent.Callable;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import com.walmart.platform.txnmarking.impl.NullTransactionImpl;
import com.walmart.platform.txnmarking.impl.TransactionImpl;
import com.walmartlabs.services.rdm.model.SellerType;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.*;
import com.walmartlabs.services.rdm.util.RDMCommonUtils;
import io.strati.StratiServiceProvider;
import io.strati.txnmarking.TransactionMarkingService;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.platform.kernel.exception.error.Error;
import com.walmartlabs.services.rdm.RDMUtils;
import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import com.walmartlabs.services.rdm.domain.model.NodeDO;
import com.walmartlabs.services.rdm.domain.model.SimulationVariableDO;
import com.walmartlabs.services.rdm.domain.persistence.DataPersistenceManager;
import com.walmartlabs.services.rdm.domain.persistence.NodePersistenceManager;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.FormulaException;
import com.walmartlabs.services.rdm.formula.FormulaService;
import com.walmartlabs.services.rdm.formula.Session;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.mapper.ModelMapper;
import com.walmartlabs.services.rdm.model.Node;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.VariableInfo.VariableCategory;
import com.walmartlabs.services.rdm.model.formula.Formula;
import com.walmartlabs.services.rdm.model.formula.FormulaType;
import com.walmartlabs.services.rdm.model.formula.ValueType;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.InvalidRequestException;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import com.walmartlabs.services.rdm.util.DataContainer;
import com.walmartlabs.services.rdm.util.Reloadable;
import com.walmartlabs.services.rdm.util.concurrent.Task;
import com.walmartlabs.services.rdm.util.concurrent.TaskRunner;

import io.strati.configuration.annotation.ManagedConfiguration;
import org.apache.commons.lang.BooleanUtils;

import static com.walmartlabs.services.rdm.formula.FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public class FormulaServiceImpl implements FormulaService, Reloadable {

    private static final int    NUMBER_PLACES = 2;

    private static final Logger LOG           = LoggerFactory.getLogger(FormulaServiceImpl.class);

    private TransactionMarkingService TMS;


    static class Model {
       Map<SellerType, RuleModel> ruleModelMap = new HashMap<>();

        Date                               time         = new Date();
        FormulaException                   error;
    }

    //internal model calculated from db
    static class RuleModel {
        Map<String, Node>                  roots        = new HashMap<>();
        Map<String, List<DispositionPath>> defaultPaths = new HashMap<>();
        Map<String, List<Formula>>         parallels    = new HashMap<>();

        Map<String, VariableInfoData>      variableInfo = new HashMap<>();
    }

    static class VariableInfoData {
        List<VariableInfo>                 variables       = new ArrayList<>();
        Map<VariableCategory, Set<String>> categoryNameMap = new HashMap<>();
        Map<String, Set<VariableCategory>> nameCategoryMap = new HashMap<>();
    }

    @Resource
    NodePersistenceManager          nodePersistenceManager;

    @Resource
    DataPersistenceManager          dataPersistenceManager;

    @Resource
    ModelMapper                     mapper;

    @Resource
    List<FormulaEngine>             formulaEngines;

    @ManagedConfiguration
    RDMSwitches                     switches;

    @Resource
    RDMUtils                        util;

    @Autowired
    RDMCommonUtils rdmCommonUtils;

    Map<FormulaType, FormulaEngine> formulaTypeMap = new HashMap<>();

    DataContainer<Model>            container      = new DataContainer<>();

    @PostConstruct
    private void init() {
        buildTypeMap();
        reload(true);
        TMS =  StratiServiceProvider.getInstance().getTransactionMarkingService().get();
    }

    private void buildTypeMap() {
        if(formulaEngines != null){
            for(FormulaEngine engine : formulaEngines){
                formulaTypeMap.put(engine.type(), engine);
            }
        }
    }

    public DispositionInfo calculatePaths(String channel, SellerType sellerType, Session session, boolean debug) {
        DispositionInfo info = new DispositionInfo();
        try{
            Model sellerTypeCache = container.get();
            if(sellerTypeCache.error != null) throw sellerTypeCache.error;
            RuleModel cache = sellerTypeCache.ruleModelMap.get(sellerType);

            Node root = cache.roots.get(channel);
            if(root == null) throw new InvalidRequestException(MessageFormat.format("{0} is not a valid channel!", channel));

            VariableInfoData varInfo = cache.variableInfo.get(channel);
            info.setVariableInfos(varInfo.variables);
            info.setNode(removeFormulas(mapper.clone(root)));

            //set default paths
            info.setDispositionPaths(new ArrayList<>(cache.defaultPaths.get(channel)));
            info.setIsDefault(true);

            //we will modify the children based on business rules, so makes a copy.
            Node clonedRoot = mapper.clone(root);

            Map<String, Formula> formulaNameMap = generateFormulaNameMap(clonedRoot);
            removeIneligiblePath(info, formulaNameMap, session.getOutputData());

            rdmCommonUtils.timingProxy("Validation", () -> {
                validation(clonedRoot, formulaNameMap, session.getOutputData(), info.getTiming());
                return null;
            }, info.getTiming(), Timing.Type.CODE_FLOW);

            rdmCommonUtils.timingProxy("Pre-Call", () -> {
                preCallExternalService(session.getOutputData(), cache.parallels.get(channel), info.getTiming(), formulaNameMap);
                return null;
            }, info.getTiming(), Timing.Type.CODE_FLOW);

            boolean stop = rdmCommonUtils.timingProxy("Business-Rule", () -> {
                return checkValueStop(clonedRoot, formulaNameMap, session.getOutputData(), info.getTiming());
            }, info.getTiming(), Timing.Type.CODE_FLOW);

            //even if business rule was hit we still need to remove ineligible nodes
            rdmCommonUtils.timingProxy("Remove-Ineligible", () -> {
                removeIneligibleNodes(clonedRoot, formulaNameMap, session.getOutputData(), info.getTiming());
                return null;
            }, info.getTiming(), Timing.Type.CODE_FLOW);
            if(!stop){
                //if stop is true one business rule was hit and the path generating will be stopped
                rdmCommonUtils.timingProxy("Calculate-Value", () -> {
                    calculateValue(clonedRoot, formulaNameMap, session.getOutputData(), info.getTiming());
                    return null;
                }, info.getTiming(), Timing.Type.CODE_FLOW);
            }

            rdmCommonUtils.timingProxy("Others", () -> {
                //build the final paths
                info.setDispositionPaths(buildPaths(info, clonedRoot, formulaNameMap, stop));

                //calculate all INTERMEDIATE variables event if not used in the formula
                calculateIntermediateVariables(varInfo.variables, formulaNameMap, session.getOutputData(), info.getTiming());

                updateVariableValue(info, varInfo, session.getOutputData(), debug);

                info.setIsDefault(stop);
                return null;
            }, info.getTiming(), Timing.Type.CODE_FLOW);
        }catch (RDMException e){
            LOG.error(e.getMessage(), e);
            info.setError(new Error(e.getErrorCode().getErrorCode(), null, e.getMessage(), null));
        }catch (InvalidRequestException e){
            LOG.error("Badrequest: {}", e.getMessage());
            info.setError(new Error(null, null, e.getMessage(), null));
            if(BooleanUtils.isTrue(switches.getBadQuestThrow())) throw e;
        }catch (Exception e){
            LOG.error(e.getMessage(), e);
            info.setError(new Error(ErrorCodeMapping.FORMULA_FAILED.getErrorCode(), null, e.getMessage(), null));
        }
        info.setEnd(System.currentTimeMillis());
        return info;
    }

    private <T> T timingProxy(String name, Callable<T> callable, Map<String, Timing> timing, Timing.Type type) throws Exception {
        long b = System.currentTimeMillis();
        T v = callable.call();
        timing.putIfAbsent(name, new Timing(System.currentTimeMillis() - b, null, type));
        return v;
    }

    private void preCallExternalService(Map<String, Object> inputData, List<Formula> formulas, Map<String, Timing> timing, Map<String, Formula> formulaNameMap) {
        TransactionImpl top;
        if (TMS.currentTransaction() instanceof NullTransactionImpl) {
            top = (TransactionImpl) TMS.topTransaction("preCallExternalService", "preCallExternalService");
        } else {
            top = (TransactionImpl) TMS.transaction("preCallExternalService", "preCallExternalService");
        }
        top.start();
        if(BooleanUtils.isNotTrue(switches.getParallelCall())) return;

        if(formulas != null){
            if(switches.getPreCallEnahancedLogicEnabled()){
                BaseItem item = (BaseItem) inputData.get(FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);
                List<Formula> preCallEligibleFormulasForItem = filterPreCallEligibleFormulasForItem(formulas, inputData);
                if(CollectionUtils.isNotEmpty(preCallEligibleFormulasForItem)) {

                    addPreCallInfoInInputData(preCallEligibleFormulasForItem, inputData);

                    List<Task>  allTasks = buildTasksEnhanced(preCallEligibleFormulasForItem, inputData, timing, formulaNameMap);
                    TaskRunner.runEnhanced(allTasks, switches.getPreCallMaxTimeout(), item);

                    removePreCallInfoFromInputData(preCallEligibleFormulasForItem, inputData);

                }
            } else{
                inputData.put(FormulaConstants.INTERNAL_DATA_NAME_PRECALL, true);
                Task[] tasks = buildTasks(formulas, inputData, timing, formulaNameMap);
                TaskRunner.run(switches.getParallelCallTimeout(), tasks);
                inputData.remove(FormulaConstants.INTERNAL_DATA_NAME_PRECALL);
            }

        }
        top.end();
    }

    private void removePreCallInfoFromInputData(List<Formula> preCallEligibleFormulasForItem, Map<String, Object> inputData) {
        preCallEligibleFormulasForItem.forEach(formula ->{
            inputData.remove(formula.getName() + FormulaConstants.PRE_CALL);
        });
    }

    private void addPreCallInfoInInputData(List<Formula> preCallEligibleFormulasForItem, Map<String, Object> inputData) {
        preCallEligibleFormulasForItem.forEach(formula ->{
            inputData.put(formula.getName() + FormulaConstants.PRE_CALL, true);
        });
    }

    private List<Formula> filterPreCallEligibleFormulasForItem(List<Formula> formulas, Map<String, Object> inputData) {
        List<Formula> preCallEligibleFormulasForItem = new ArrayList<>();
        BaseItem item = (BaseItem) inputData.get(INTERNAL_DATA_NAME_REQUEST_ITEM);
        for(Formula formula : formulas){
            if(isFormulaEligibleForPreCall(formula, item)){
                preCallEligibleFormulasForItem.add(formula);
            }
        }
        return preCallEligibleFormulasForItem;
    }

    /**
     Below are the conditions for different formulas.
     These conditions are derived based on what all attribute external call need in request.
     Conditions:
     1. _LS : If Store Id is not present in request then preCall
     2. _GSF : If Store Id is not present in request then preCall
     3. _DISPOSITION : If Store Id is present in request then preCall
     4. _POS_ITEM : If Store Id is present in request then preCall
     5. _SIRO : If Store Id is present in request then preCall

     @param formula
     @param item
     @return
     */
    private boolean isFormulaEligibleForPreCall(Formula formula, BaseItem item) {
        boolean isFormulaEligibleForPreCall;
        String formulaName = formula.getName();
        switch (formulaName){
            case FormulaConstants.FORMULA_NAME_LS:
                isFormulaEligibleForPreCall = StringUtils.isEmpty(item.getStoreId());
                break;
            case FormulaConstants.FORMULA_NAME_DISPOSITION:
                isFormulaEligibleForPreCall = StringUtils.isNotEmpty(item.getStoreId());
                break;
            default:
                isFormulaEligibleForPreCall = true;
        }

        return isFormulaEligibleForPreCall;
    }

    private Task[] buildTasks(List<Formula> formulas, Map<String, Object> inputData, Map<String, Timing> timing, Map<String, Formula> formulaNameMap) {
        List<Task> tasks = new ArrayList<>();
        Map<String, Task> taskMap = new HashMap<>();
        Map<String, Formula> formulaMap = new HashMap<>();

        for(Formula formula : formulas){
            formulaMap.put(formula.getName(), formula);
        }
        for(Formula formula : formulas){
            Task t = buildTask(formula, inputData, timing, formulaNameMap);
            taskMap.put(formula.getName(), t);
            if("NA".equals(formula.getParallelGroup())){
                tasks.add(t);
            }else{
                Task n = taskMap.computeIfAbsent(formula.getParallelGroup(), key -> {
                    return buildTask(formulaMap.get(formula.getParallelGroup()), inputData, timing, formulaNameMap);
                });
                n.getDependents().add(t);
            }
        }

        return tasks.toArray(new Task[0]);
    }

    private List<Task> buildTasksEnhanced(List<Formula> formulas, Map<String, Object> inputData, Map<String, Timing> timing, Map<String, Formula> formulaNameMap) {
        List<Task> allTasks = new ArrayList<>();

        formulas.forEach(formula -> {
                Task task = buildTaskEnhanced(formula, inputData, timing, formulaNameMap);
                allTasks.add(task);
        });


        return allTasks;

        //As of now not considering dependent tasks. Need to revisit whole rdm framework before enabling it.
        //that's why commented below code
        /*Map<String, Task> taskMap = new HashMap<>();
        Map<String, Formula> formulaMap = new HashMap<>();

        for(Formula formula : formulas){
            formulaMap.put(formula.getName(), formula);
        }
        for(Formula formula : formulas){
            Task t = buildTaskEnhanced(formula, inputData, timing, formulaNameMap);
            tasks.add(t);
            taskMap.put(formula.getName(), t);
            if("NA".equals(formula.getParallelGroup())){
                tasks.add(t);
            }else{
                Task n = taskMap.computeIfAbsent(formula.getParallelGroup(), key -> {
                    return buildTaskEnhanced(formulaMap.get(formula.getParallelGroup()), inputData, timing, formulaNameMap);
                });
                n.getDependents().add(t);
            }
        }

        return tasks.toArray(new Task[0]);

         */
    }

    private Task buildTask(Formula formula, Map<String, Object> inputData, Map<String, Timing> timing, Map<String, Formula> formulaNameMap) {
        Task t = new Task(() -> {
            try{
                long b = System.currentTimeMillis();
                Object v = eval(formula, formulaNameMap, inputData, new Stack<>(), timing, false);
                if(!Thread.currentThread().isInterrupted()){
                    inputData.put(formula.getName(), v);
                    timing.putIfAbsent(formula.getName(), new Timing(System.currentTimeMillis() - b, true, Timing.Type.EXTERNAL));
                }else{
                    //pre call timed out or other exception happened, in this case we add the special prefix and don't updateWithStatus the session data
                    timing.putIfAbsent("_@" + formula.getName(), new Timing(System.currentTimeMillis() - b, true, Timing.Type.EXTERNAL));
                }
            } catch (Exception e){
                //TODO, proper logging
                e.printStackTrace();
                LOG.info("parallel call failed. {}", e);
                /*Throw exception if there is any exception pre-call*/
                throw new FormulaException(formula.getName() + " failed to fetch", e);
            }
        }, formula.getName());
        return t;
    }

    private Task buildTaskEnhanced(Formula formula, Map<String, Object> inputData, Map<String, Timing> timing, Map<String, Formula> formulaNameMap) {
/*        Task t = new Task(() -> {
            try{
                Object v = eval(formula, formulaNameMap, inputData, new Stack<>(), timing, false);
            } catch (Exception e){
                LOG.error("Exception occured while running precall task, formulaName {}, errorMsg {}", formula.getName(), e.getMessage(), e);
            }
            return null;
        });*/


        Callable<Object> callable = () -> {
            Object evalResult = null;
            try{
                evalResult = eval(formula, formulaNameMap, inputData, new Stack<>(), timing, false);
            } catch (Exception e){
                LOG.error("Exception occured while running precall task, formulaName {}, errorMsg {}", formula.getName(), e.getMessage(), e);
            }
            return evalResult;
        };

        Task t = new Task(callable, formula.getName());
        return t;
    }


    private void removeIneligiblePath(DispositionInfo info, Map<String, Formula> formulaNameMap, Map<String, Object> inputData) {
        BaseItem item = (BaseItem) inputData.get(INTERNAL_DATA_NAME_REQUEST_ITEM);
        if("CCA-Returns".equals(item.getChannelName())){
            Iterator<DispositionPath> i = info.getDispositionPaths().iterator();
            while(i.hasNext()){
                DispositionPath path = i.next();
                if("returnToStore".equals(path.getPath()) && BooleanUtils.isFalse(item.getStoreReturnEligibility())){
                    i.remove();
                }
            }
        }
    }

    private void validation(Node node, Map<String, Formula> formulaNameMap, Map<String, Object> inputData, Map<String, Timing> timing) {
        if(node != null && node.getValue() == null){
            List<Formula> formulas = node.getValidationFormulas();
            if(formulas != null && formulas.size() > 0){
                for(Formula formula : formulas){
                    if(formula.getValueType() != ValueType.BOOLEAN) throw new FormulaException(MessageFormat.format("Eligibility formula can only be boolean. {0}", formula));
                    Boolean value = (Boolean) eval(formula, formulaNameMap, inputData, new Stack<>(), timing, true);
                    if(BooleanUtils.isFalse(value)) throw new InvalidRequestException(formula.getDescription());
                }
            }
            for(Node child : node.getChildren()){
                validation(child, formulaNameMap, inputData, timing);
            }
        }
    }

    private void calculateIntermediateVariables(List<VariableInfo> variables, Map<String, Formula> formulaNameMap, Map<String, Object> outputData, Map<String, Timing> timing) {
        if(variables != null) for(VariableInfo variable : variables){
            if(VariableCategory.INTERMEDIATE.equals(variable.getCategory())){
                String name = variable.getName();
                if(!outputData.containsKey(name) && formulaNameMap.containsKey(name)){
                    Formula formula = formulaNameMap.get(name);
                    try{
                        Object value = eval(formula, formulaNameMap, outputData, new Stack<>(), timing, true);
                        outputData.put(name, value);
                    }catch (Exception e){
                        LOG.error(MessageFormat.format("{0}({1}) failed to calculate. {2}", name, formula.getFormula(), e.getMessage()), e);
                    }
                }
            }
        }

    }

    private void updateVariableValue(DispositionInfo info, VariableInfoData varInfo, Map<String, Object> outputData, boolean debug) {
        List<DispositionPath> paths = info.getDispositionPaths();
        if(paths != null) for(DispositionPath path : paths){
            List<FinalDisposition> finalPaths = path.getFinalDispositions();
            if(finalPaths != null) for(FinalDisposition finalPath : finalPaths){
                if(finalPath != null && finalPath.getVariables() != null){

                    //formula/variable name is unique cross different final dispositions 
                    //and we use this special pattern to have the same name but different value
                    //among final paths
                    for(String name : new HashSet<>(finalPath.getVariables().keySet())){
                        String displayName = getDisplayName(name);
                        finalPath.getVariables().put(displayName, roundDouble(outputData.get(name)));
                    }

                    Iterator<Entry<String, Object>> i = finalPath.getVariables().entrySet().iterator();
                    Entry<String, Object> entry;

                    //remove undefined name
                    i = finalPath.getVariables().entrySet().iterator();
                    while(i.hasNext()){
                        entry = i.next();
                        String name = entry.getKey();

                        if(varInfo.nameCategoryMap.containsKey(name) && (varInfo.nameCategoryMap.get(name).contains(VariableCategory.COST) || varInfo.nameCategoryMap.get(name).contains(VariableCategory.RECOVERY))){

                        }else{
                            i.remove();
                        }
                    }
                }
            }
        }

        Set<String> names = Stream.concat(varInfo.categoryNameMap.get(VariableInfo.VariableCategory.BUSINESSRULE).stream(), varInfo.categoryNameMap.get(VariableInfo.VariableCategory.INTERMEDIATE).stream()).collect(Collectors.toSet());

        //if debug businessRuleVariables will contain everything
        if(debug) names = outputData.keySet();

        if(names != null) for(String name : names){
            if(!name.startsWith(FormulaConstants.INTERNAL_DATA_NAME_PREFIX)) info.getBusinessRuleVariables().put(name, roundDouble(outputData.get(name)));
        }

    }

    private Object roundDouble(Object value) {
        if(value == null) return value;
        if(value instanceof Double) return round((Double) value, NUMBER_PLACES);
        else return value;
    }

    private String getDisplayName(String name) {
        Matcher matcher = FormulaConstants.FORMULA_DISPLAY_NAME_PATTERN.matcher(name);
        if(matcher.find()){
            String displayName = matcher.group(1);
            return displayName;
        }
        return name;
    }

    private String nodeToString(Node node) {
        StringBuilder buffer = new StringBuilder(256);

        int max = findMax(node);

        print(node, max, buffer, "", "");
        return buffer.toString();
    }

    private int findMax(Node node) {
        if(node != null){
            int maxChildren = 0;
            List<Node> children = node.getChildren();
            if(children != null){
                Iterator<Node> i = children.iterator();
                while(i.hasNext()){
                    Node child = i.next();
                    maxChildren = Math.max(findMax(child), maxChildren);
                }
            }
            int length = node.getName().length();
            if(node.getDescription() != null) length += (node.getDescription().length() + 2);
            if(node.isKeyNode()) length += 1;
            return Math.max(maxChildren + 3, length);
        }
        return 0;
    }

    private void print(Node node, int max, StringBuilder buffer, String prefix, String childrenPrefix) {
        if(node != null){
            int start = buffer.length();
            buffer.append(prefix);
            if(node.getDescription() != null){
                buffer.append("[");
                buffer.append(node.getDescription());
                buffer.append("]");
            }
            buffer.append(node.getName());
            if(node.isKeyNode()) buffer.append("*");
            if(node.getValue() != null){
                buffer.append(String.format("%-" + (max - (buffer.length() - start) + 1) + "s", " "));
                buffer.append(new DecimalFormat("+0.00;-0.00").format(node.getValue()));
                buffer.append("\t= ");
                if(node.getValueFormulas().size() == 1) buffer.append(node.getValueFormulas().get(0).getFormula());
            }else{
                if(node.getValueFormulas() != null && node.getValueFormulas().size() > 0){
                    buffer.append(String.format("%-" + (max - (buffer.length() - start) + 1) + "s", " "));

                    buffer.append(node.getValueFormulas().get(0).getFormula());
                }
            }
            buffer.append('\n');
            List<Node> children = node.getChildren();
            if(children != null){
                Iterator<Node> i = children.iterator();
                while(i.hasNext()){
                    Node child = i.next();
                    if(i.hasNext()){
                        print(child, max, buffer, childrenPrefix + "├──", childrenPrefix + "│  ");
                    }else{
                        print(child, max, buffer, childrenPrefix + "└──", childrenPrefix + "   ");
                    }
                }
            }
        }
    }

    private List<DispositionPath> buildPaths(DispositionInfo info, Node root, Map<String, Formula> formulaNameMap, boolean stop) {
        List<FinalDisposition> finalPaths = new ArrayList<>();
        Set<String> skipRankNodes = new HashSet<>();
        buildFinalPaths(finalPaths, new ArrayList<>(Arrays.asList(root)), root, null, .0, formulaNameMap, skipRankNodes,switches);

        // Collections.sort(paths, Comparator.<PathNode, String> comparing(p -> p.pathName).thenComparing(p -> p.value, Collections.reverseOrder()));
        Collections.sort(finalPaths, Comparator.<FinalDisposition, Double> comparing(p -> p.getValue(), stop ? Collections.reverseOrder().reversed() : Collections.reverseOrder()));

        List<DispositionPath> paths = new ArrayList<>();
        int skipRankCount = 0;
        Map<String, DispositionPath> dispositionPathMap = new HashMap<>();
        for(FinalDisposition finalPath : finalPaths){
            String bucketName = finalPath.getBucketName();

            DispositionPath path = null;;

            if(dispositionPathMap.containsKey(bucketName)){
                path = dispositionPathMap.get(bucketName);
            }else{
                path = new DispositionPath();
                path.setPath(bucketName);
                path.setValue(finalPath.getValue());
                path.setPathValueDerivedFrom(finalPath.getPathValueDerivedFrom());
                if(!skipRankNodes.contains(bucketName)){
                    path.setRank(paths.size() + 1 - skipRankCount);
                }else{
                    skipRankCount++;
                }
                paths.add(path);
                path.setId(finalPath.getId());
                dispositionPathMap.put(bucketName, path);
            }

            if(!stop){
                if(path.getFinalDispositions() == null) path.setFinalDispositions(new ArrayList<>());
                finalPath.setRank(path.getFinalDispositions().size() + 1);
                path.getFinalDispositions().add(finalPath);
            }else{
                path.setRank(path.getValue().intValue());
                path.setValue(null);//For default path there is no value
            }
        }

        return paths;
    }

    private void buildFinalPaths(List<FinalDisposition> paths, List<Node> nodePath, Node node, String bucketName, Double parentValue, Map<String, Formula> formulaNameMap, Set<String> skipRankNodes,RDMSwitches switches) {
        if(node != null){
            if(node.isKeyNode()){
                bucketName = node.getName();
                if(node.isSkipRank()) skipRankNodes.add(bucketName);
            }
            if(node.getValue() != null) parentValue += node.getValue();
            List<Node> children = node.getChildren();
            if(children != null && children.size() > 0){
                for(Node child : children){
                    nodePath.add(child);
                    buildFinalPaths(paths, nodePath, child, bucketName, parentValue, formulaNameMap, skipRankNodes, switches);
                    nodePath.remove(nodePath.size() - 1);
                }
            }else{
                //found a leaf node/final path
                if(bucketName != null){
                    FinalDisposition finalPath = new FinalDisposition();
                    finalPath.setPathSeq(nodePath.stream().map(Node::getName).collect(Collectors.toList()));
                    finalPath.setBucketName(bucketName);
                    setPathDerivedAttribute(switches.getPathDerivedAttributeEnabled(), finalPath);
                    finalPath.setValue(Math.round(parentValue * 100.0) / 100.0);
                    finalPath.setId(node.getId());
                    finalPath.setVariables(collectVariables(nodePath, formulaNameMap).stream().collect(HashMap::new, (m, v) -> m.put(v, null), HashMap::putAll));
                    paths.add(finalPath);
                }
            }
        }
    }

    private void setPathDerivedAttribute(Boolean pathDerivedAttributeEnabled, FinalDisposition finalPath) {
        /*We are setting the third node from the hierarchy in the pathValueDerivedFromAttribute. For example, for MAIL the third node can be Inmar or Return Center
         For keepIt there is no third node in hierarchy. So to avoid IndexOutOFBound we have added the check on size.*/
        if(pathDerivedAttributeEnabled && CollectionUtils.isNotEmpty(finalPath.getPathSeq()) && finalPath.getPathSeq().size()>2) {
            finalPath.setPathValueDerivedFrom(finalPath.getPathSeq().get(2));
        }
    }

    private Set<String> collectVariables(List<Node> nodes, Map<String, Formula> formulaNameMap) {
        Set<String> variables = new HashSet<>();
        for(Node node : nodes){
            List<Formula> formulas = new ArrayList<>();
            formulas.addAll(node.getValueFormulas());
            formulas.addAll(node.getEligibilityFormulas());
            collectFormulasVariables(variables, formulas, formulaNameMap);
        }
        return variables;
    }

    private void collectFormulasVariables(Set<String> variables, List<Formula> formulas, Map<String, Formula> formulaNameMap) {
        for(Formula formula : formulas){
            collectFormulasVariables(variables, formula, formulaNameMap);
        }
    }

    private Set<String> collectFormulasVariables(Set<String> variables, Formula formula, Map<String, Formula> formulaNameMap) {
        if(formula != null){
            for(String dependentName : formula.getInputVariables()){
                if(!variables.contains(dependentName)){
                    variables.add(dependentName);
                    collectFormulasVariables(variables, formulaNameMap.get(dependentName), formulaNameMap);
                }
            }
        }
        return variables;
    }

    private boolean checkValueStop(Node node, Map<String, Formula> formulaNameMap, Map<String, Object> inputData, Map<String, Timing> timing) {
        boolean found = false;
        if(node != null){
            List<Formula> formulas = node.getValueStopFormulas();
            if(formulas != null) for(Formula formula : formulas){

                if(formula.getValueType() != ValueType.DOUBLE) throw new FormulaException(MessageFormat.format("Value stop formula can only be double. {0}", formula));

                Object value = eval(formula, formulaNameMap, inputData, new Stack<>(), timing, true);
                if(!FormulaConstants.isInvalidValue(value)){
                    node.setValue((Double) value);
                    node.getChildren().clear();
                    found = true;
                    break;
                }
            }
            for(Node child : node.getChildren()){
                boolean foundInChildren = checkValueStop(child, formulaNameMap, inputData, timing);
                if(foundInChildren) found = true;
            }
        }
        return found;
    }

    private boolean removeIneligibleNodes(Node node, Map<String, Formula> formulaNameMap, Map<String, Object> inputData, Map<String, Timing> timing) {
        boolean removed = false;
        if(node != null){
            Iterator<Node> i = node.getChildren().iterator();
            while(i.hasNext()){
                Node child = i.next();
                List<Formula> formulas = child.getEligibilityFormulas();
                if(formulas != null && formulas.size() > 0){
                    for(Formula formula : formulas){
                        if(formula.getValueType() != ValueType.BOOLEAN) throw new FormulaException(MessageFormat.format("Eligibility formula can only be boolean. {0}", formula));
                        Boolean value = (Boolean) eval(formula, formulaNameMap, inputData, new Stack<>(), timing, true);
                        if(BooleanUtils.isFalse(value)){
                            i.remove();
                            removed = true;
                            break;
                        }
                    }
                }
            }

            i = node.getChildren().iterator();
            while(i.hasNext()){
                Node child = i.next();
                boolean removedInChildren = removeIneligibleNodes(child, formulaNameMap, inputData, timing);
                if(removedInChildren){
                    if(child.getChildren().size() == 0){
                        i.remove();
                        removed = true;
                    }
                }
            }
        }
        return removed;
    }

    private void calculateValue(Node node, Map<String, Formula> formulaNameMap, Map<String, Object> inputData, Map<String, Timing> timing) {
        if(node != null && node.getValue() == null){
            List<Formula> formulas = node.getValueFormulas();
            if(formulas != null && formulas.size() > 0){
                if(formulas.size() != 1) throw new FormulaException(MessageFormat.format("There can be only one value formual. {0}", node));
                Formula formula = formulas.get(0);
                if(formula.getValueType() != ValueType.DOUBLE) throw new FormulaException(MessageFormat.format("Value formula can only be double. {0}", formula));

                Object value = eval(formula, formulaNameMap, inputData, new Stack<>(), timing, true);
                if(value != null && value instanceof Double){
                    Double v = (Double) value;
                    if(Double.isNaN(v)) throw new FormulaException(MessageFormat.format("{0}={1} is invalid.", formula.getFormula(), value));
                    else node.setValue(v);
                }
            }
            for(Node child : node.getChildren()){
                calculateValue(child, formulaNameMap, inputData, timing);
            }
        }
    }

    private Object eval(Formula formula, Map<String, Formula> formulaNameMap, Map<String, Object> inputData, Stack<String> stack, Map<String, Timing> timing, boolean saveExternalTiming) {
        FormulaEngine engine = getEngine(formula);
        while(true){
            try{
                String name = formula.getName();
                long b = System.currentTimeMillis();
                Object v = engine.eval(formula, inputData);
                checkValueType(formula.getValueType(), v);
                if(StringUtils.isNotEmpty(name)){
                    if(formula.getFormulaType() == FormulaType.JAVA && formula.getValueType() == ValueType.OBJECT){
                        if(saveExternalTiming) timing.putIfAbsent(name, new Timing(System.currentTimeMillis() - b, false, Timing.Type.EXTERNAL));
                    }else{
                        timing.putIfAbsent(name, new Timing(System.currentTimeMillis() - b, v, Timing.Type.FORMULA));
                    }
                }
                LOG.info("{}[{}]({})={}", name, formula.getFormula(), System.currentTimeMillis() - b, util.getJsonString(v));
                return v;
            }catch (VariableMissingException e){
                String variable = e.getVariable();

                formula.getInputVariables().add(variable);
                if(!inputData.containsKey(e.getVariable())){//value not present

                    /**
                     * temporary hack to avoid mutlicalls for external services
                     */
                    if(switches.getExternalServiceExceptionHandlingEnabled()){
                        if(switches.getExternalApiVarialblesForExceptionHandling().contains(e.getVariable())){
                           Map<String,Exception> exceptionMap = (Map<String,Exception>)inputData.get(FormulaConstants.INTERMEDIATE_DATA_NAME_EXTERNAL_API_EXCEPTIONS);
                           if(exceptionMap!= null && exceptionMap.containsKey(e.getVariable())){
                               RDMException exception = (RDMException) exceptionMap.get(e.getVariable());
                               throw exception;
                           }
                        }
                    }

                    Formula dependentFormula = formulaNameMap.get(variable);
                    if(dependentFormula != null){
                        if(stack.contains(variable)) throw new FormulaException(MessageFormat.format("Got a circular references", stack), e);
                        stack.add(variable);

                        Object v = eval(dependentFormula, formulaNameMap, inputData, stack, timing, saveExternalTiming);
                        inputData.put(variable, v);
                        stack.pop();
                    }else{
                        throw new FormulaException(MessageFormat.format("{0} is not defined in {1}", e.getVariable(), formula.getFormula()), e);
                    }
                }
            }
        }
    }

    private void checkValueType(ValueType valueType, Object v) {

    }

    private Node removeFormulas(Node root) {
        iterateNodes(root, node -> {
            node.setFormulas(null);
        });
        return root;
    }

    //@Transactional
    public void reload(boolean blocking) {
        LOG.info("reload {}", blocking);
        container.requestSet((old) -> {
            List<NodeDO> roots = nodePersistenceManager.searchRoot();
            List<SimulationVariableDO> variables = dataPersistenceManager.getSimulationVariables();
            Model data = buildCache(roots, variables);
            return data;
        }, blocking);
    }

    /**
     * Build cache with nodes and variables
     * Cache structure will be
     * {sellerType ->  {channel,formulas},{channel,defaultPaths}, {channel,parrallels}, {channel,variables}}
     * @param rootDOs
     * @param variableDOs
     * @return
     */
    private Model buildCache(List<NodeDO> rootDOs, List<SimulationVariableDO> variableDOs) {
       Model cache = new Model();
        try{
            List<Node> roots = mapper.mapNodeList(rootDOs);
            if(roots != null) for(Node root : roots){
                loadNodesInCache(root, cache);
            }
            List<VariableInfo> variables = mapper.mapVariableList(variableDOs);
            if(variables != null) for(VariableInfo variable : variables){
                loadVariablesInCache(variable,cache);
            }
        }catch (FormulaException e){
            LOG.error("Not able to load rules in cache");
            cache.error = e;
        }
        return cache;
    }

    private void loadVariablesInCache(VariableInfo variable, Model cache) {
        if(null == variable.getSellerType()){
            variable.setSellerType(SellerType.WM);
        }
        RuleModel ruleModel =  cache.ruleModelMap.computeIfAbsent(variable.getSellerType(), key -> new RuleModel());
        VariableInfoData infoData = ruleModel.variableInfo.computeIfAbsent(variable.getChannelName(), key -> new VariableInfoData());
        infoData.variables.add(variable);
        infoData.categoryNameMap.computeIfAbsent(variable.getCategory(), key -> new HashSet<>()).add(variable.getName());
        infoData.nameCategoryMap.computeIfAbsent(variable.getName(), key -> new HashSet<>()).add(variable.getCategory());
    }

    private void loadNodesInCache(Node root, Model cache) {
        if(null == root.getSellerType()){
            root.setSellerType(SellerType.WM);
        }
        RuleModel ruleModel =  cache.ruleModelMap.computeIfAbsent(root.getSellerType(), key -> new RuleModel());
        ruleModel.roots.put(root.getName(), root);
        ruleModel.defaultPaths.put(root.getName(), buildDefaultPaths(root));
        ruleModel.parallels.put(root.getName(), collectParallels(root));
        calculateFormulaDependent(root);
    }

    private List<Formula> collectParallels(Node root) {
        List<Formula> formulas = new ArrayList<>();
        iterateNodes(root, node -> {
            iterateNodeFormulas(node, formula -> {
                String group = StringUtils.trimToNull(formula.getParallelGroup());
                if(group != null){
                    formulas.add(formula);
                }
            });
        });
        return formulas;
    }

    private List<DispositionPath> buildDefaultPaths(Node root) {
        List<DispositionPath> paths = new ArrayList<>();

        iterateNodes(root, node -> {
            if(node.isKeyNode() && !node.isSkipRank()){
                DispositionPath p = new DispositionPath();
                p.setPath(node.getName());
                p.setRank(1);//same rank for default paths
                p.setKeepIt(false);
                paths.add(p);
            }
        });

        return paths;
    }

    private void calculateFormulaDependent(Node root) {
        iterateNodes(root, node -> {
            iterateNodeFormulas(node, formula -> {
                FormulaEngine engine = getEngine(formula);
                Set<String> input = engine.getContext(formula.getFormula()).getInputVariables();
                formula.setInputVariables(input == null ? new HashSet<>() : input);
            });
        });
    }

    private Map<String, Formula> generateFormulaNameMap(Node root) {
        Map<String, Formula> nameMap = new LinkedHashMap<>();
        iterateNodes(root, node -> {
            iterateNodeFormulas(node, formula -> {
                String name = StringUtils.trimToNull(formula.getName());
                if(name != null){
                    if(nameMap.containsKey(name)) throw new FormulaException(MessageFormat.format("Formula name already exists! {0}", formula));
                    nameMap.put(name, formula);
                }
            });
        });
        return nameMap;
    }

    private void iterateNodeFormulas(Node node, Consumer<Formula> consumer) {
        List<Formula> formulas = node.getFormulas();
        if(formulas != null) for(Formula formula : formulas){
            consumer.accept(formula);
        }
    }

    private void iterateNodes(Node node, Consumer<Node> consumer) {
        if(node != null){
            consumer.accept(node);

            for(Node child : node.getChildren()){
                iterateNodes(child, consumer);
            }
        }
    }

    private FormulaEngine getEngine(Formula formula) {
        FormulaType type = formula.getFormulaType();
        if(!formulaTypeMap.containsKey(type)) throw new FormulaException(MessageFormat.format("No engine found for {0} id={1}", type, formula.getId()));
        return formulaTypeMap.get(type);
    }

    @Override
    public String getModelVersion() {
        Model cache = container.get();
        if(cache.error != null) throw cache.error;
        return String.valueOf(cache.time.getTime());
    }
}
