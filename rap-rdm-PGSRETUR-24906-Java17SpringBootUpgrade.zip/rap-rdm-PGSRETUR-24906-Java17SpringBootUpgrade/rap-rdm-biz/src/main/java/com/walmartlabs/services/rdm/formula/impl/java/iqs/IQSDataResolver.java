package com.walmartlabs.services.rdm.formula.impl.java.iqs;

import java.util.Map;
import java.util.concurrent.CompletableFuture;

import javax.annotation.Resource;

import com.walmartlabs.services.rdm.component.iqs.service.utl.IQSServiceHelper;
import com.walmartlabs.services.rdm.util.RDMCommonUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmartlabs.services.rdm.component.iqs.model.request.GetItemDetailsRequest;
import com.walmartlabs.services.rdm.component.iqs.model.response.GetItemDetailsResponse;
import com.walmartlabs.services.rdm.component.iqs.service.utl.IQSHttpClient;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.formula.Formula;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public class IQSDataResolver implements JavaEngineClass {


    @Autowired
    private IQSServiceHelper iqsServiceHelper;

    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        BaseItem item = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);

        CompletableFuture<GetItemDetailsResponse> itemDetailsResponseFuture = null;
        if(!inputData.containsKey(FormulaConstants.INTERNAL_DATA_NAME_IQS_FUTURE)) {
            itemDetailsResponseFuture = iqsServiceHelper.triggerIqsServiceCall(item);
            inputData.put(FormulaConstants.INTERNAL_DATA_NAME_IQS_FUTURE,itemDetailsResponseFuture);
        }

        /**
         If service is called as part of preCall then,
         No need to wait for response at this point, return from here
         */
        if(RDMCommonUtils.isExternalServicePreCall(formula, inputData)){
            return null;
        }

        GetItemDetailsResponse iqsResponse = iqsServiceHelper.getIqsResponseFromFuture(itemDetailsResponseFuture, item);

        return iqsResponse;
    }

}
