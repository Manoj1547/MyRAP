package com.walmartlabs.services.rdm.component.siro.service.util;

import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmartlabs.services.rdm.executors.RdmExecutorService;
import com.walmartlabs.services.rdm.component.iqs.service.utl.IQSServiceHelper;
import com.walmartlabs.services.rdm.component.siro.model.request.GetStoreItemRequest;
import com.walmartlabs.services.rdm.component.siro.model.response.GetStoreItemResponse;
import com.walmartlabs.services.rdm.config.client.SIROServiceConfig;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.text.MessageFormat;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Component
public class SIROServiceHelper {

    private static final Logger LOG = LoggerFactory.getLogger(SIROServiceHelper.class);

    @Resource
    SIROHttpClient siroClient;

    @Resource
    @ManagedConfiguration
    private SIROServiceConfig siroServiceConfig;


    public  CompletableFuture<GetStoreItemResponse> triggerSiroServiceCall(BaseItem item, SIROServiceConfig siroServiceConfig, String storeId) {
        GetStoreItemRequest request = prepareSiroRequest(item,siroServiceConfig,storeId);

        CompletableFuture<GetStoreItemResponse> storeItemDetailsResponseFuture = CompletableFuture.supplyAsync(() -> siroClient.getStoreItemDetails(request), RdmExecutorService.getExecutor());
        return storeItemDetailsResponseFuture;
    }

    private GetStoreItemRequest prepareSiroRequest(BaseItem item, SIROServiceConfig siroServiceConfig, String storeId) {
        GetStoreItemRequest request = new GetStoreItemRequest();
        request.setCountry(siroServiceConfig.getReqeustCountry());
        request.setGtinType(siroServiceConfig.getReqeustGtinType());
        request.setStore(storeId);
        request.setGtin(item.getGtin());
        return request;
    }

    public GetStoreItemResponse getSiroResponseFromFuture(CompletableFuture<GetStoreItemResponse> storeItemDetailsResponseFuture, BaseItem item, String storeId) {
        GetStoreItemResponse getStoreItemDetailsResponse = null;

        try {
            getStoreItemDetailsResponse = storeItemDetailsResponseFuture.get(siroServiceConfig.getSiroServiceApiTimeout(), TimeUnit.MILLISECONDS);;
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            String errorMsg =  MessageFormat.format("Siro response fetch failed, gtin {0} , storeId {1}, error {2}",
                    item.getGtin(), storeId, e.getMessage());
            LOG.error(errorMsg, e);

            if(e.getCause() instanceof RDMException){
                throw (RDMException) e.getCause();
            } else{
                throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.SIRO_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
            }
        }
        return getStoreItemDetailsResponse;
    }
}
