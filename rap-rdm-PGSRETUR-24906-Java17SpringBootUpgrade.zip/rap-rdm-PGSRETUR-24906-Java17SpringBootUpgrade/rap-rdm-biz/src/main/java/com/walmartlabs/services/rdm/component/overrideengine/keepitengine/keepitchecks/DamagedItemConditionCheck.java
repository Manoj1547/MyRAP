package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import static com.walmartlabs.services.rdm.RDMConstants.*;

@Component("damagedItemConditionCheck")
public class DamagedItemConditionCheck implements IRDMKeepItRuleCheck{

    private static final Logger LOG = LoggerFactory.getLogger(DamagedItemConditionCheck.class);

    @ManagedConfiguration
    RDMKeepItConfig rdmKeepItConfig;

    public void setRdmKeepItConfig(RDMKeepItConfig rdmKeepItConfig) {
        this.rdmKeepItConfig = rdmKeepItConfig;
    }
    @Override
    public String getKeepItCheckName() {
        return RULE_CHECK_NAME_DAMAGED_ITEM;
    }

    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {

        LOG.info("DamagedItemConditionCheck :: Item {}, Condition : {}",keepItRuleEngineContext.getItem().getItemId(), keepItRuleEngineContext.getItem().getItemCondition());
        return rdmKeepItConfig.getEnableDamagedItemRule() && null != keepItRuleEngineContext.getItem() &&
                ITEM_CONDITION_DAMAGED.equalsIgnoreCase(keepItRuleEngineContext.getItem().getItemCondition());
    }
}
