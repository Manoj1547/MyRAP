package com.walmartlabs.services.rdm.component.siro.service.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.txnmarking.impl.NullTransactionImpl;
import com.walmart.platform.txnmarking.impl.TransactionImpl;
import com.walmartlabs.services.rdm.component.siro.model.request.GetStoreItemRequest;
import com.walmartlabs.services.rdm.component.siro.model.response.GetStoreItemResponse;
import com.walmartlabs.services.rdm.component.siro.model.response.Payload;
import com.walmartlabs.services.rdm.config.client.SIROServiceConfig;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import com.walmartlabs.services.rdm.util.BaseHTTPClient;
import com.walmartlabs.services.rdm.util.HeaderElements;
import com.walmartlabs.services.rdm.util.cache.CacheManager;
import com.walmartlabs.services.rdm.util.cache.CacheRole;

import io.strati.StratiServiceProvider;
import io.strati.configuration.annotation.ManagedConfiguration;
import io.strati.txnmarking.TransactionMarkingService;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

@Component
public class SIROHttpClient extends BaseHTTPClient {

    private static final Logger LOG = LoggerFactory.getLogger(SIROHttpClient.class);
    private static final String QUERY_PARAM_Q = "q";

    private TransactionMarkingService TMS;

    @Resource
    @ManagedConfiguration
    SIROServiceConfig siroServiceConfig;

    @Resource
    private CacheManager              cacheManager;

    private ObjectMapper objectMapper;

    @PostConstruct
    protected void init() {
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }
    
    private SIROHttpClient(){
        TMS = StratiServiceProvider.getInstance().getTransactionMarkingService().get();
    }
    
    public GetStoreItemResponse getStoreItemDetails(GetStoreItemRequest request) {

        TransactionImpl top;
        if(TMS.currentTransaction() instanceof NullTransactionImpl) {
            top = (TransactionImpl) TMS.topTransaction("StoreItemDetails", "StoreItemDetails");
        }else {
            top = (TransactionImpl) TMS.transaction("StoreItemDetails", "StoreItemDetails");
        }
        top.start();

        Map<String, String> queryParams = getQueryParams(request);

        GetStoreItemResponse response = new GetStoreItemResponse();
        String responseString = null;
        try {
            String key = queryParams.toString();
            if(siroServiceConfig.getSiroServiceCachingEnabled()) {
                String data = cacheManager.get(key, CacheRole.SIRO);
                if (data == null) {
                    responseString = callSiroService(request);
                    cacheManager.put(key, responseString, CacheRole.SIRO);
                } else {
                    LOG.info("SIRO service cache hit for key:"+ key);
                    responseString = data;
                }
            } else{
                responseString = callSiroService(request);
            }

            Payload[] payload = objectMapper.readValue(responseString, Payload[].class);
            response.setPayload(payload);
            validateResponse(response);
            top.end();
        } catch (JsonProcessingException e) {
            String errorMsg = MessageFormat.format("SIRO service json parsing exception, request:{0}, response:{1}", request.toString(), responseString);
            LOG.error(errorMsg, e);
            top.logException(e);
            top.endWithFailure(e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.SIRO_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        } catch (Exception e) {
            String errorMsg = MessageFormat.format("SIRO service exception, Unexpected exception for request {0}", request.toString());
            LOG.error(errorMsg, e);
            top.logException(e);
            top.endWithFailure(e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.SIRO_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        }

        return response;
    }

    private String callSiroService(GetStoreItemRequest request) throws ServiceException {

        if(siroServiceConfig.getMockSiroServiceEnabled()){
            LOG.info("Mock enabled for SIRO service");
            return siroServiceConfig.getMockedSiroServiceResponse();
        }

        String baseUrl ;
        if(siroServiceConfig.getSiroServiceMeshEnabled()){
            baseUrl = siroServiceConfig.getSiroServiceMeshBaseUrl();
        }
        else {
            baseUrl = siroServiceConfig.getServiceBaseHostUrl();
        }

        String pathUrl = siroServiceConfig.getServiceEndpoint();
        int apiTimeout = siroServiceConfig.getApiTimeOut();
        Map<String, String> headerParams = getHeaderParams(siroServiceConfig);
        Map<String, String> queryParams = getQueryParams(request);
        LOG.info("Invoking SIRO service with Url -[{}]", baseUrl);
        LOG.info("Invoking SIRO service for request,"+ queryParams.toString());
        String siroResponse =  get(baseUrl, pathUrl, queryParams, headerParams, apiTimeout, String.class);
        LOG.info("SIRO service response, QueryParam, "+ queryParams.toString() + " response, " + siroResponse);
        return siroResponse;
    }

    private void validateResponse(GetStoreItemResponse response) {

        if(response == null || response.getPayload() == null || response.getPayload().length == 0){
            String errorMsg = "SIRO-HTTP failed - Null/Empty Value";
            LOG.error(errorMsg);
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.SIRO_HTTP_CLIENT_EXECUTION_FAILED, errorMsg);
        }
    }

    private Map<String, String> getHeaderParams(SIROServiceConfig config) {
        HashMap<String, String> headers = new HashMap<>();
        long inTimestamp = System.currentTimeMillis();

        addHeaderParam(headers, HeaderElements.SERVICE_VERSION, config.getServiceVersion());
        addHeaderParam(headers, HeaderElements.SERVICE_ENV, config.getServiceEnv());
        addHeaderParam(headers, HeaderElements.SERVICE_NAME, config.getServiceName());
        addHeaderParam(headers, HeaderElements.CONSUMER_ID, config.getServiceConsumerId());
        addHeaderParam(headers, HeaderElements.CONTENT_TYPE, config.getContentType());
        addHeaderParam(headers, HeaderElements.CONSUMER_AUTH_SIGNATURE, config.getAuthSignature());
        addHeaderParam(headers, HeaderElements.CONSUMER_IN_TIMESTAMP, String.valueOf(inTimestamp));

        return headers;
    }

    private void addHeaderParam(HashMap<String, String> headers, String name, String value) {
        if (StringUtils.isNotBlank(value))
            headers.put(name, value);
    }

    private Map<String, String> getQueryParams(GetStoreItemRequest request) {
        Map<String, String> queryParams = new HashMap<>();
        String paramValue = getJsonString(request);
        queryParams.put(QUERY_PARAM_Q, paramValue);
        return queryParams;
    }

    private String getJsonString(Object o) {
        try{
            return new ObjectMapper().writeValueAsString(o);
        }catch (JsonProcessingException e){
            LOG.error(e.getMessage());
            return null;
        }
    }
}
