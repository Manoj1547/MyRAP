package com.walmartlabs.services.rdm.model.dispositionpaths.common;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.walmartlabs.services.rdm.model.ID;

import java.util.List;
import java.util.Map;

/**
 * @author Tim Jin
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FinalDisposition extends ID {

    private String bucketName;

    private List<String> pathSeq;

    private Integer rank;

    private Double value;

    private String pathValueDerivedFrom;

    @JsonIgnore
    private Map<String, Object> variables;

    public FinalDisposition() {
    }

    public String getBucketName() {
        return bucketName;
    }

    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    public List<String> getPathSeq() {
        return pathSeq;
    }

    public void setPathSeq(List<String> pathSeq) {
        this.pathSeq = pathSeq;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    public Map<String, Object> getVariables() {
        return variables;
    }

    public void setVariables(Map<String, Object> variables) {
        this.variables = variables;
    }

    public String getPathValueDerivedFrom() {
        return pathValueDerivedFrom;
    }

    public void setPathValueDerivedFrom(String pathValueDerivedFrom) {
        this.pathValueDerivedFrom = pathValueDerivedFrom;
    }
}