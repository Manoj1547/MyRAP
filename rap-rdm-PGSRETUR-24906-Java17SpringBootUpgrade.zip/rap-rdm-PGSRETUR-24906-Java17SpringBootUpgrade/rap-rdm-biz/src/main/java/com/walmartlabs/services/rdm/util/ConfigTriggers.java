package com.walmartlabs.services.rdm.util;

import java.text.MessageFormat;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import com.walmartlabs.services.rdm.config.ConfigConstants;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Ignore;
import io.strati.configuration.annotation.PostInit;
import io.strati.configuration.annotation.PostRefresh;
import io.strati.configuration.context.ConfigurationContext;
import io.strati.configuration.listener.ChangeLog;

/**
 * 
 * @author Tim Jin
 *
 */
@Component
@Configuration(configName = ConfigConstants.CONFIG_NAME_TRIGGERS)
public class ConfigTriggers implements ApplicationContextAware {

    private static final Logger            LOG = LoggerFactory.getLogger(ConfigTriggers.class);

    @Ignore
    private static Map<String, Reloadable> reloadables;

    @PostInit
    public void init(String configName, ConfigurationContext context) {}

    @PostRefresh
    public void refresh(String configName, List<ChangeLog> changes, ConfigurationContext context) {
        LOG.info("ConfigurationContext: " + context);
        LOG.info("CCM Changes: -------- Start ---------");
        if(reloadables != null) changes.forEach(changeLog -> {
            String key = changeLog.getKey();
            if(key != null){
                key = key.toUpperCase();
                if(reloadables.containsKey(key)){
                    Reloadable service = reloadables.get(key);
                    boolean blocking = changeLog.getNewValue() != null && changeLog.getNewValue().contains("true");
                    LOG.info(MessageFormat.format("Reloading({0}) {1} ...", blocking, changeLog.getKey()));
                    service.reload(blocking);
                }
            }
        });
        LOG.info("CCM Changes: -------- End ---------");
    }

    public void setApplicationContext(ApplicationContext ctx) throws BeansException {
        //@Resource didn't work
        Map<String, Reloadable> beans = ctx.getBeansOfType(Reloadable.class);
        ConfigTriggers.reloadables = beans.entrySet().stream().collect(Collectors.toMap(entry -> entry.getKey().toUpperCase(), entry -> entry.getValue()));
    }

}
