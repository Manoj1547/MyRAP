
package com.walmartlabs.services.rdm.model;

/**
 * 
 * @author Tim Jin
 * 
 *         r2d2 l1 category id to value map
 *
 */
public class R2d2Data extends Base {

    public static enum R2d2DataType {
        RECOVERY_LIQUIDATION,
        //        RECOVERY_STORE, RECOVERY_DOTCOM_ORION, RECOVERY_DOTCOM_DSV, RECOVERY_DOTCOM_TRG, RECOVERY_DOTCOM_BSTOCK,
        RECOVERY_CVP, 
        SALE_PROBABILITY
    }

    private R2d2DataType type;
    private String       categoryId;

    private String       categoryName;

    private Double       vaule;

    public R2d2DataType getType() {
        return type;
    }

    public void setType(R2d2DataType type) {
        this.type = type;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public Double getVaule() {
        return vaule;
    }

    public void setVaule(Double vaule) {
        this.vaule = vaule;
    }

}
