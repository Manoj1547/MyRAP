package com.walmartlabs.services.rdm.component.rcp.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ItemDispositionRequestPayload {

    @JsonProperty("vendorNo")
    private Integer vendorNo;

    @JsonProperty("departmentNo")
    private Integer departmentNo;

    @JsonProperty("contractNo")
    private Integer contractNo;

    @JsonProperty("itemId")
    private String itemId;

    @JsonProperty("itemPrice")
    private ItemPrice itemPrice;

    public Integer getVendorNo() {
        return vendorNo;
    }

    public void setVendorNo(Integer vendorNo) {
        this.vendorNo = vendorNo;
    }

    public Integer getDepartmentNo() {
        return departmentNo;
    }

    public void setDepartmentNo(Integer departmentNo) {
        this.departmentNo = departmentNo;
    }

    public Integer getContractNo() {
        return contractNo;
    }

    public void setContractNo(Integer contractNo) {
        this.contractNo = contractNo;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public ItemPrice getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(ItemPrice itemPrice) {
        this.itemPrice = itemPrice;
    }

}
