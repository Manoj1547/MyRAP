package com.walmartlabs.services.rdm.component.ls.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetPrefStoreResponse {

    @JsonProperty("cid")
    private String customerId;

    @JsonProperty("stores")
    private List<Store> stores;

    @JsonProperty("locations")
    private List<Location> locations;

    public List<Store> getStores() {
        if (stores == null) {
            stores = new ArrayList<>();
        }
        return stores;
    }

    public void setStores(List<Store> stores) {
        getStores().addAll(stores);
    }

    public List<Location> getLocations() {
        if (locations == null) {
            locations = new ArrayList<>();
        }
        return locations;
    }

    public void setLocations(List<Location> locations) {
        getLocations().addAll(locations);
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
}
