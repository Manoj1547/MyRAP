package com.walmartlabs.services.rdm.formula.impl.java;

import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmartlabs.services.rdm.component.siro.model.response.GetStoreItem;
import com.walmartlabs.services.rdm.component.siro.model.response.GetStoreItemResponse;
import com.walmartlabs.services.rdm.formula.*;
import com.walmartlabs.services.rdm.model.formula.Formula;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 *
 * @author v0s00g0
 *
 */
@Service
public class SIROStoreItemResolver implements JavaEngineClass {

    private static final Logger LOG = LoggerFactory.getLogger(SIROStoreItemResolver.class);


    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        LOG.info("SIROStoreItemResolver started");
        GetStoreItemResponse siroResponse = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_SIRO);

        if(siroResponse == null || siroResponse.getPayload() == null || siroResponse.getPayload().length == 0 || siroResponse.getPayload()[0].getData() == null
                || siroResponse.getPayload()[0].getData().getGetStoreItem() == null){
            String errorMsg = "Invalid SIRO response, getStoreItem attribute not present in response.";
            LOG.error(errorMsg);
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.SIRO_HTTP_CLIENT_EXECUTION_FAILED, errorMsg);
        }

        GetStoreItem storeItem = siroResponse.getPayload()[0].getData().getGetStoreItem();
        LOG.info("SIROStoreItemResolver exited");
        return storeItem;
    }


}
