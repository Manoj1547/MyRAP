package com.walmartlabs.services.rdm.formula.impl.java.eligibility;

import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.ReturnMode;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.ReturnModesInfo;
import com.walmartlabs.services.rdm.model.formula.Formula;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import java.util.Map;

import static com.walmartlabs.services.rdm.RDMConstants.*;

/**
 * Author : v0s00g0
 */
@Service
public class CCAMailBackEligibilityChecker implements JavaEngineClass {

    @ManagedConfiguration
    RDMSwitches rdmSwitches;

    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {

        //If rdm enabled for glass ozark then perform this check else
        //always eligible from CCAMailBackEligibilityChecker side.
        if(rdmSwitches.getRdmEnabledForGlassOzark()) {
            BaseItem item = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);
            if(isOzarkSfsFulfillmentType(item.getFulfillmentType())){
                return isItemMailEligible(item);
            }
        }

        return true;
    }

    /**
     * If no returnMode as 'MAIL' available in returnModeInfo then items is not mail return eligible.
     * If returnMode 'MAIL' present the check isReturnAllowed
     * @param item
     * @return
     */
    private boolean isItemMailEligible(BaseItem item) {
        ReturnModesInfo returnModeInfo = item.getReturnModesInfo();
        if(returnModeInfo != null && CollectionUtils.isNotEmpty(returnModeInfo.getReturnModes())){
            for(ReturnMode returnMode : returnModeInfo.getReturnModes()){
                if(RETURN_MODE_MAIL.equals(returnMode.getName())){
                    return returnMode.isReturnAllowed();
                }
            }
        }
        return false;
    }

    private boolean isOzarkSfsFulfillmentType(String fulfillmentType){
        if(fulfillmentType == null) return false;
        if(FULFILLMENT_TYPE_OZARK.equals(fulfillmentType) || FULFILLMENT_TYPE_SFS.equals(fulfillmentType) || FULFILLMENT_TYPE_OZARKSFS.equals(fulfillmentType)){
            return true;
        }
        return false;
    }
}
