package com.walmartlabs.services.rdm.scheduler;

public class RdmJobDetail {
}
