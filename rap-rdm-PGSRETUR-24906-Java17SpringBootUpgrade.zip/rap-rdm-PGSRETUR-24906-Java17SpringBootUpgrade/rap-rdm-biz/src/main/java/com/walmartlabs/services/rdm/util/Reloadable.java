package com.walmartlabs.services.rdm.util;

/**
 * 
 * @author Tim Jin
 *
 */
public interface Reloadable {
    
    public void reload(boolean blocking);

}
