package com.walmartlabs.services.rdm.formula.impl.java.eligibility;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.rcp.model.response.GetItemDispositionDetailsResponse;
import com.walmartlabs.services.rdm.component.restock.model.response.Disposition;
import com.walmartlabs.services.rdm.component.restock.model.response.GetRestockItemDetailsResponse;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.formula.impl.java.eligibility.util.CvpEligibilityUtil;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.formula.Formula;
import org.springframework.stereotype.Service;

import java.util.Map;

import static com.walmartlabs.services.rdm.RDMConstants.*;

/**
 * Author : v0s00g0
 */
@Service
public class CCAStoreCvpEligibilityChecker implements JavaEngineClass {


    @Override
    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
       return  CvpEligibilityUtil.isCvpEligible(formula, inputData);
    }

}