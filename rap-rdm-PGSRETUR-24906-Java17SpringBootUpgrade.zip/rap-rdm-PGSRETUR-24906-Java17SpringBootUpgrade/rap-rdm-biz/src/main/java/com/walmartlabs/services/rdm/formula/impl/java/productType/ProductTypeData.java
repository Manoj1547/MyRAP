package com.walmartlabs.services.rdm.formula.impl.java.productType;

import com.walmartlabs.services.rdm.domain.persistence.DataPersistenceManager;
import com.walmartlabs.services.rdm.mapper.ModelMapper;
import com.walmartlabs.services.rdm.model.CategoryType;
import com.walmartlabs.services.rdm.model.productTypeCategory.ProductTypeCategoryData;
import com.walmartlabs.services.rdm.util.DataContainer;
import com.walmartlabs.services.rdm.util.Reloadable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class ProductTypeData implements Reloadable {
    static class CacheModel {
          Map<String, CategoryType> productTypeCategory =  new HashMap<>();
    }

    @Resource
    DataPersistenceManager persistenceManager;

    @Resource
    ModelMapper mapper;

    private static final Logger LOG = LoggerFactory.getLogger(ProductTypeData.class);


    DataContainer<CacheModel> container = new DataContainer<>();

    @PostConstruct
    private void init() {
        reload(true);
    }


    /**
     * Load Product Type Category Data in the cache
     *Map<ProductType,Category>
     * @param blocking
     */
    public void reload(boolean blocking) {
        container.requestSet((old) -> {
               CacheModel cache = new CacheModel();
               List<ProductTypeCategoryData> productTypeDataList =
                       mapper.mapProductTypeList(persistenceManager.getProductTypeData());
               for(ProductTypeCategoryData productTypeData : productTypeDataList){
                   cache.productTypeCategory.put(productTypeData.getProductType(), productTypeData.getCategory());
               }
            return cache;
        }, blocking);
        LOG.info("ProductTypeCategory data is loaded successfully in cache");
    }

    public CategoryType getProductTypeCategory(String productType){
        CacheModel cache = container.get();
        return cache.productTypeCategory.get(productType);
    }
}
