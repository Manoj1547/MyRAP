package com.walmartlabs.services.rdm.component.iqs.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StoreAttribute {

    @JsonProperty("calculatedValidInd")
    private Boolean calculatedValidInd;

    @JsonProperty("salesExistsInd")
    private Boolean salesExistsInd;

    @JsonProperty("isRecallInd")
    private Boolean isRecallInd;

    @JsonProperty("activeItem")
    private Integer activeItem;

    public Boolean getCalculatedValidInd() { return calculatedValidInd; }

    public void setCalculatedValidInd(Boolean calculatedValidInd) { this.calculatedValidInd = calculatedValidInd; }

    public Boolean getSalesExistsInd() { return salesExistsInd; }

    public void setSalesExistsInd(Boolean salesExistsInd) { this.salesExistsInd = salesExistsInd; }

    public Boolean getIsRecallInd() { return isRecallInd; }

    public void setIsRecallInd(Boolean isRecallInd) { this.isRecallInd = isRecallInd; }

    public Integer getActiveItem() { return activeItem; }

    public void setActiveItem(Integer activeItem) { this.activeItem = activeItem; }

}
