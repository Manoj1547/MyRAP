package com.walmartlabs.services.rdm.formula.impl.java.iqs;

import java.text.MessageFormat;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.walmartlabs.services.rdm.component.iqs.model.response.iqs.IQSRDMResponse;
import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.stereotype.Service;

import com.walmart.services.common.model.measurement.UnitOfMeasureEnum;
import com.walmartlabs.services.rdm.component.iqs.model.response.GetItemDetailsResponse;
import com.walmartlabs.services.rdm.component.iqs.model.response.OfferInfo;
import com.walmartlabs.services.rdm.component.iqs.model.response.ProductPackageDimension;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.FormulaException;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.formula.Formula;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public class IQSOfferResolver implements JavaEngineClass {

    @ManagedConfiguration
    private RDMSwitches switches;


    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        GetItemDetailsResponse iqsResponse = null;
        BaseItem item =  FormulaEngine.getInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);

        if(!switches.getNewIQSResponse()) {
            iqsResponse = FormulaEngine.getInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_IQSOFFER);
        }
        else{
            iqsResponse = FormulaEngine.getInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_IQSRDM);
        }


        List<OfferInfo> offers = iqsResponse.getOffers();
        if(offers != null){
            if(item.getOfferId() != null) for(OfferInfo offerInfo : offers){
                if(offerInfo.getOffer() != null && item.getOfferId().equals(offerInfo.getOffer().getOfferId())){ return regulateDimension(offerInfo); }
            }
            String onePSellerID = switches.getOnePSellerID();
            if("CLAIMS".equals(item.getChannelName()) && offers.size() > 0){
                Optional<OfferInfo> matchedOffer = offers.stream().filter(offerInfo -> offerInfo.getOffer() != null && onePSellerID.equals(offerInfo.getOffer().getSellerId())).findFirst();
                if(matchedOffer.isPresent()){
                    return regulateDimension(matchedOffer.get());
                }
            }
            throw new FormulaException(MessageFormat.format("{0} can not be found in IQS response(GTIN={1})", item.getOfferId(), item.getGtin()));
        }else{
            throw new FormulaException(MessageFormat.format("There is no offer data in IQS response(GTIN={0})", item.getGtin()));
        }
    }

    private OfferInfo regulateDimension(OfferInfo offerInfo) {
        //convert dimension into inch and weight into pound
        if(offerInfo != null && offerInfo.getLimo() != null && offerInfo.getLimo().getLogisticsOffer() != null && offerInfo.getLimo().getLogisticsOffer().getProductPackageDimensions() != null
                && offerInfo.getLimo().getLogisticsOffer().getProductPackageDimensions().size() > 0){
            ProductPackageDimension p = offerInfo.getLimo().getLogisticsOffer().getProductPackageDimensions().get(0);
            if(p.getUnitHeight() != null) p.setUnitHeight(p.getUnitHeight().convertTo(UnitOfMeasureEnum.INCH));
            if(p.getUnitLength() != null) p.setUnitLength(p.getUnitLength().convertTo(UnitOfMeasureEnum.INCH));
            if(p.getUnitWidth() != null) p.setUnitWidth(p.getUnitWidth().convertTo(UnitOfMeasureEnum.INCH));

            if(p.getUnitWeight() != null) p.setUnitWeight(p.getUnitWeight().convertTo(UnitOfMeasureEnum.POUND));
        }

        return offerInfo;
    }
}
