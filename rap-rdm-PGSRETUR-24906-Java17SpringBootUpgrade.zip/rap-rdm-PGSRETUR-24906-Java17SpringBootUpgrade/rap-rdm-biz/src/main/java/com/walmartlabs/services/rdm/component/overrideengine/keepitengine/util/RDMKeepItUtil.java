package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.iqs.model.response.GetItemDetailsResponse;
import com.walmartlabs.services.rdm.component.iqs.model.response.OfferInfo;
import com.walmartlabs.services.rdm.component.iqs.model.response.SupplyTradeItem;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.config.client.ConfigManager;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.Session;
import com.walmartlabs.services.rdm.model.DamagedItemKeepItRuleCategory;
import com.walmartlabs.services.rdm.model.DamagedItemKeepItRuleCategoryThreshold;
import com.walmartlabs.services.rdm.model.DamagedItemKeepItRuleConfig;
import com.walmartlabs.services.rdm.model.DamagedItemKeepItRuleDivision;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.KeepItDispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@Component("rdmKeepItUtil")
public class RDMKeepItUtil {

    private static final Logger LOG = LoggerFactory.getLogger(RDMKeepItUtil.class);

    private static final String KEEP_IT_DISPOSITION_PATH = "keepIt";

    private Set<String> dotcomOfferTypes;

    public ObjectMapper getObjectMapper() {
        return objectMapper;
    }

    public void setObjectMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    private ObjectMapper objectMapper;

    @ManagedConfiguration
    RDMKeepItConfig rdmKeepItConfig;

    public RDMKeepItConfig getRdmKeepItConfig() {
        return rdmKeepItConfig;
    }

    public void setRdmKeepItConfig(RDMKeepItConfig rdmKeepItConfig) {
        this.rdmKeepItConfig = rdmKeepItConfig;
    }

    private static Map<String, Map<String, DamagedItemKeepItRuleCategoryThreshold>> divisionCategoryThresholdMap;

    @PostConstruct
    public void init() {
        dotcomOfferTypes = new HashSet<>();
        dotcomOfferTypes.add("ONLINE_ONLY");
        dotcomOfferTypes.add("SHARED");
        dotcomOfferTypes.add("ONLINE_AND_STORE");
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    public Set<String> getDotcomOfferTypes() {
        return dotcomOfferTypes;
    }

    public KeepItRuleEngineContext prepareRequest(DispositionInfo dispositionInfo, BaseItem item, Session session){
        KeepItRuleEngineContext keepItRuleEngineContext = new KeepItRuleEngineContext();

        keepItRuleEngineContext.setDispositionInfo(dispositionInfo);
        keepItRuleEngineContext.setItem(item);
        keepItRuleEngineContext.setSession(session);

        return keepItRuleEngineContext;
    }

    public void updateDefaultsInResponse(KeepItRuleEngineContext keepItRuleEngineContext) {

        String offerId = keepItRuleEngineContext.getItem().getOfferId();
        LOG.info("Updating defaults in response for offerId," + offerId);

        DispositionInfo dispositionInfo = keepItRuleEngineContext.getDispositionInfo();
        KeepItDispositionInfo keepItInfo = keepItRuleEngineContext.getDispositionInfo().getKeepItInfo();
        //Set default for keepIt info
        keepItInfo.setIsDefault(true);

        //Set default False for disposition paths
        List<DispositionPath> dispositionPaths = dispositionInfo.getDispositionPaths();
        if(CollectionUtils.isNotEmpty(dispositionPaths)) {
            for (DispositionPath dispositionPath : dispositionPaths) {
                dispositionPath.setKeepIt(false);
            }
        }
    }


    public boolean itemGtinCountCheck(KeepItRuleEngineContext keepItRuleEngineContext){
        LOG.info("RDMKeepItUtil.itemGtinCountCheck started");

        boolean isItemKeepItBasedOnGtinCount = false;
        BaseItem item = keepItRuleEngineContext.getItem();
        List<? extends BaseItem> items = (List<? extends BaseItem>) keepItRuleEngineContext.getSession().getOutputData()
                .get( FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEMS);

        Map<String, Integer> gtinVsCount = new HashMap<>();
        for(BaseItem i : items){
            int qty = Integer.valueOf(i.getQuantity().getMeasurementValue());
            gtinVsCount.compute(i.getGtin(), (k, v) -> (v == null) ? qty : v + qty);
        }

        RDMKeepItConfig rdmKeepItConfig = ConfigManager.getRdmKeepItConfig();
        if(gtinVsCount.get(item.getGtin())<= rdmKeepItConfig.getKeepItThresholdGtinCount()){
            isItemKeepItBasedOnGtinCount = true;
        }

        LOG.info("RDMKeepItUtil.itemGtinCountCheck exited");
        return isItemKeepItBasedOnGtinCount;
    }


    public boolean itemPriceCheck(KeepItRuleEngineContext keepItRuleEngineContext) {
        RDMKeepItConfig rdmKeepItConfig = ConfigManager.getRdmKeepItConfig();
        boolean isItemKeepItBasedOnPrice = false;

        BigDecimal itemRetailPrice;
        if(rdmKeepItConfig.getKeepItItemDetailsFromRequestEnabled()) {
            itemRetailPrice = getItemPriceFromRequest(keepItRuleEngineContext);
        }else{
            itemRetailPrice = getItemPrice(keepItRuleEngineContext);
        }

        if((BigDecimal.valueOf(rdmKeepItConfig.getKeepItRetailThresholdAmount())).compareTo(itemRetailPrice) > 0){
            isItemKeepItBasedOnPrice = true;
        }
        BaseItem item = keepItRuleEngineContext.getItem();
        LOG.info("RDMKeepItUtil.itemPriceCheck exited for itemId:{} with itemRetailPrice:{}",item.getItemId(),itemRetailPrice);
        return isItemKeepItBasedOnPrice;
    }


    public BigDecimal getItemPrice(KeepItRuleEngineContext keepItRuleEngineContext) {
        BigDecimal itemRetailPrice;
        OfferInfo offerInfo = (OfferInfo)keepItRuleEngineContext.getSession().getOutputData().get(FormulaConstants.INTERNAL_DATA_NAME_IQS_OFFER);
        String offerType = offerInfo.getOffer().getOfferType();

        boolean isDotcomOffer = this.getDotcomOfferTypes().contains(offerType);

        if(isDotcomOffer){
            itemRetailPrice= ((OfferInfo) keepItRuleEngineContext.getSession().getOutputData().get(FormulaConstants.INTERNAL_DATA_NAME_IQS_OFFER)).
                    getPricing().get(0).getStorefrontPricingList().get(0).getCurrentPrice().getCurrentValue().getCurrencyAmount();
        } else{
            itemRetailPrice = ((SupplyTradeItem) keepItRuleEngineContext.getSession().getOutputData().get(FormulaConstants.INTERNAL_DATA_NAME_IQS_SI)).
                    getPayloadJson().getAttributes().getBaseRetailAmt();
        }
        return itemRetailPrice;
    }

    public BigDecimal getItemPriceFromRequest(KeepItRuleEngineContext keepItRuleEngineContext) {
        BigDecimal itemRetailPrice;
        BaseItem item = keepItRuleEngineContext.getItem();
        boolean dotcomItem = (boolean) keepItRuleEngineContext.getSession().getOutputData().get(FormulaConstants.VARIABLE_IS_DOTCOM);

        if(dotcomItem){
            itemRetailPrice= item.getUnitPrice() != null ? item.getUnitPrice().getCurrencyAmount(): getItemPriceFromIQS(keepItRuleEngineContext);
        } else{
            itemRetailPrice = ((SupplyTradeItem) keepItRuleEngineContext.getSession().getOutputData().get(FormulaConstants.INTERNAL_DATA_NAME_IQS_SI)).
                    getPayloadJson().getAttributes().getBaseRetailAmt();
        }
        return itemRetailPrice;
    }

    public boolean isPhotoItemPriceEligible(Double totalLineRefundAmount, Double threshold) {
        return threshold > totalLineRefundAmount;
    }

    public boolean isPhotoOrderLine(BaseItem item) {
        return null != item.getItemCustomAttributes()
                && RDMConstants.TRUE.equals(item.getItemCustomAttributes().get(RDMConstants.IS_PHOTO_ORDER_LINE));
    }

    public boolean isCustomerTrustedForKeepIt(BaseItem item) {
        return null != item.getKeepItInfo()
                && item.getKeepItInfo().getTrustCustomerToKeepIt();
    }

    private BigDecimal getItemPriceFromIQS(KeepItRuleEngineContext keepItRuleEngineContext) {
        OfferInfo offerInfo = (OfferInfo) keepItRuleEngineContext.getSession().getOutputData().get(FormulaConstants.INTERNAL_DATA_NAME_IQS_OFFER);

        if(null != offerInfo &&  null != offerInfo.getPricing() &&
                null != offerInfo.getPricing().get(0).getStorefrontPricingList() &&
                null != offerInfo.getPricing().get(0).getStorefrontPricingList().get(0).getCurrentPrice() &&
                null != offerInfo.getPricing().get(0).getStorefrontPricingList().get(0).getCurrentPrice().getCurrentValue() &&
                null != offerInfo.getPricing().get(0).getStorefrontPricingList().get(0).getCurrentPrice().getCurrentValue().getCurrencyAmount()){
            return offerInfo.getPricing().get(0).getStorefrontPricingList().get(0).getCurrentPrice().getCurrentValue().getCurrencyAmount();
        }
        return null;
    }

    public void removeKeepItPathFromResponse(DispositionInfo dispositionInfo) {
        List<DispositionPath> paths = dispositionInfo.getDispositionPaths();
        Iterator<DispositionPath> i = paths.iterator();
        while(i.hasNext()){
            com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath path = i.next();
            if(KEEP_IT_DISPOSITION_PATH.equals(path.getPath())){
                i.remove();
            }
        }
    }

    public void setKeepItDefault(KeepItDispositionInfo keepItInfo) {
        //not in error case
        if(keepItInfo.getIsDefault() == null){
            boolean itemKeepItDefault = keepItInfo.getIsItemKeepItDefault();
            if(keepItInfo.getRecoveryValue() != null){
                //using new RDM rule, itemKeepItDefault do not apply
                itemKeepItDefault = false;
            }
            keepItInfo.setIsDefault(keepItInfo.getIsTrustCustomerDefault() || itemKeepItDefault);
        }
    }



    public void updateKeepItForAllPaths(KeepItRuleEngineContext keepItRuleEngineContext, boolean keepIt) {

        DispositionInfo dispositionInfo = keepItRuleEngineContext.getDispositionInfo();
        List<DispositionPath> dispositionPaths = dispositionInfo.getDispositionPaths();
        for(DispositionPath dispositionPath : dispositionPaths){
            dispositionPath.setKeepIt(keepIt);
        }
    }


    public void updateKeepItFalseForNonTrustedCustomer(DispositionInfo dispositionInfo) {

        List<DispositionPath> dispositionPaths = dispositionInfo.getDispositionPaths();
        for(DispositionPath dispositionPath : dispositionPaths){
            dispositionPath.setKeepIt(false);
        }
    }

    public void updateKeepItByComparingRecoveryValue(KeepItRuleEngineContext keepItRuleEngineContext) {

        DispositionInfo dispositionInfo = keepItRuleEngineContext.getDispositionInfo();
        List<DispositionPath> dispositionPaths = dispositionInfo.getDispositionPaths();

        List<DispositionPath> keepItPath = dispositionPaths.stream().filter(path -> path.getPath().equals(KEEP_IT_DISPOSITION_PATH)).collect(Collectors.toList());
        if(keepItPath != null && keepItPath.size() > 0) {
            Double keepItRecoveryValue = keepItPath.get(0).getValue();
            for(DispositionPath dispositionPath : dispositionPaths){
                dispositionPath.setKeepIt((dispositionPath.getValue() < keepItRecoveryValue));
            }
        }
    }

    public void updateKeepItForRapRules(DispositionInfo dispositionInfo) {

        boolean trustCustomer = dispositionInfo.getKeepItInfo().getTrustCustomerToKeepIt();
        boolean itemKeepItEligibility = dispositionInfo.getKeepItInfo().getItemKeepItEligibility();

        List<DispositionPath> dispositionPaths = dispositionInfo.getDispositionPaths();

        if(CollectionUtils.isNotEmpty(dispositionPaths)){
            for(DispositionPath dispositionPath : dispositionPaths){
                dispositionPath.setKeepIt(trustCustomer && itemKeepItEligibility);
            }
        }

        //If rap rules are used then set Default as true
        KeepItDispositionInfo keepItInfo = dispositionInfo.getKeepItInfo();
        keepItInfo.setIsDefault(true);

    }

    public void updateDefaultKeepItFalseForAllPaths(DispositionInfo dispositionInfo) {
        List<DispositionPath> dispositionPaths = dispositionInfo.getDispositionPaths();

        if(CollectionUtils.isNotEmpty(dispositionPaths)){
            for(DispositionPath dispositionPath : dispositionPaths){
                dispositionPath.setKeepIt(false);
            }
        }

        //Setting defaultKeepIt value as False for all paths, so set isDefault flag as true
        KeepItDispositionInfo keepItInfo = dispositionInfo.getKeepItInfo();
        keepItInfo.setIsDefault(true);
    }


    public boolean isItemCountEligibleForKeepIt(Integer thresholdCount, Integer itemCount) {
        return thresholdCount > itemCount;
    }

    public boolean isItemPriceEligibleForKeepIt(BigDecimal thresholdAmount, BigDecimal itemPrice) {
        return thresholdAmount.compareTo(itemPrice) > 0;
    }

    public boolean itemTotalRefundCheck(KeepItRuleEngineContext keepItRuleEngineContext) {

        Double totalItemLineRefundAmount = keepItRuleEngineContext.getItem().getLineRefundAmount();
        RDMKeepItConfig rdmKeepItConfig = ConfigManager.getRdmKeepItConfig();

        return rdmKeepItConfig.getTotalLineRefundCheckKeepItDisabled() || (null != totalItemLineRefundAmount &&
                rdmKeepItConfig.getKeepItLineRefundThresholdAmount() < totalItemLineRefundAmount);
    }

    public boolean isINEBItem(BaseItem item) {
        return null != item.getItemCustomAttributes()
                && Boolean.parseBoolean(item.getItemCustomAttributes().get(RDMConstants.IS_INEB));
    }

    // get the thresholdvalues based on GEP country
    public static String getdefaultKeepItThresholdValueForGepCountry(String countryCode)
    {
        RDMKeepItConfig rdmKeepItConfig = ConfigManager.getRdmKeepItConfig();
        List<String> CountryProductTypeKeepItThresholds = rdmKeepItConfig.getDefaultKeepItItemThresholdValueForGep();
        Map<String, String> MaxProductTypeKeepItReturnOrderCountryMap = getMaxKeepItForGepMap(CountryProductTypeKeepItThresholds);
        return MaxProductTypeKeepItReturnOrderCountryMap.get(countryCode);
    }
    private static Map<String, String> getMaxKeepItForGepMap(List<String> countryReturnOrderThresholdList) {
        Map<String, String> maxKeepItAllowedPerReturnOrderMap = new HashMap<>();
        for(String str : countryReturnOrderThresholdList){
            String[] split = str.split(":", 2);
            if (split.length == 2) {
                String countryName = split[0];
                String maxKeepItThresholdValue = split[1];
                maxKeepItAllowedPerReturnOrderMap.put(countryName, maxKeepItThresholdValue);
            }
        }
        return maxKeepItAllowedPerReturnOrderMap;
    }
    public boolean checkGepOrder(KeepItRuleEngineContext keepItRuleEngineContext){
        RDMKeepItConfig rdmKeepItConfig = ConfigManager.getRdmKeepItConfig();
        if (rdmKeepItConfig.getGepPilotEnabled() && keepItRuleEngineContext.getItem().isGep() && keepItRuleEngineContext.getItem().getCountryCode() != null){
            return true;
        }
        return false;
    }
    private DamagedItemKeepItRuleConfig getDamagedItemKeepItRuleConfig() {
        DamagedItemKeepItRuleConfig damagedItemKeepItRuleConfig = null;

        String damagedItemKeepItRuleJsonString = rdmKeepItConfig.getDamagedItemKeepItRuleDivisionWise();
        LOG.info("Damaged item rule fetched from config is : {}", damagedItemKeepItRuleJsonString);
        try {
            damagedItemKeepItRuleConfig = objectMapper.readValue(damagedItemKeepItRuleJsonString, DamagedItemKeepItRuleConfig.class);
        } catch (Exception exp) {
            LOG.error("Error while parsing Damaged Item KeepIt Rule Json String {}, error: {}", damagedItemKeepItRuleJsonString, exp.getMessage());
        }
        return damagedItemKeepItRuleConfig;
    }

    public Map<String, Map<String, DamagedItemKeepItRuleCategoryThreshold>> getDamagedItemDivisionCategoryThresholdMap() {
        if (rdmKeepItConfig.isConfigUpdated() || divisionCategoryThresholdMap == null) {
            LOG.info("Fetching division category threshold map.");
            DamagedItemKeepItRuleConfig damagedItemKeepItRuleConfig = getDamagedItemKeepItRuleConfig();
            if (damagedItemKeepItRuleConfig == null || damagedItemKeepItRuleConfig.getDivision().isEmpty()) {
                LOG.warn("Item Division Category threshold map is null or empty.");
                return Collections.emptyMap();
            }
            buildDivisionCategoryThresholdMap(damagedItemKeepItRuleConfig);
            rdmKeepItConfig.setIsConfigUpdated(false);
        }
        LOG.info("Item Division Category threshold map is: {}", divisionCategoryThresholdMap);
        return divisionCategoryThresholdMap;
    }

    private void buildDivisionCategoryThresholdMap(DamagedItemKeepItRuleConfig damagedItemKeepItRuleConfig) {
        divisionCategoryThresholdMap = new HashMap<>();
        for (DamagedItemKeepItRuleDivision division : damagedItemKeepItRuleConfig.getDivision()) {
            Map<String, DamagedItemKeepItRuleCategoryThreshold> categoryMap = new HashMap<>();
            for (DamagedItemKeepItRuleCategory category : division.getCategory()) {
                if (category.isEnabled()) {
                    categoryMap.put(category.getCategoryName(), category.getThreshold());
                }
            }
            if (!categoryMap.isEmpty()) {
                divisionCategoryThresholdMap.put(division.getDivisionName(), categoryMap);
            }
        }
    }

    public Map<String, Map<String, String>> getDerivedAttributePathMap(KeepItRuleEngineContext keepItRuleEngineContext) {

        if(null == keepItRuleEngineContext || null == keepItRuleEngineContext.getSession()
                || null == keepItRuleEngineContext.getSession().getOutputData()) {
            LOG.warn("KeepIt Rule Engine Context session output data is null");
            return Collections.emptyMap();
        }

        CompletableFuture<GetItemDetailsResponse> itemDetailsResponse = (CompletableFuture<GetItemDetailsResponse>) keepItRuleEngineContext.getSession().getOutputData().get(FormulaConstants.INTERNAL_DATA_NAME_IQSRDM_FUTURE);

        String pathString = null;

        try {
            GetItemDetailsResponse itemDetails = itemDetailsResponse.get();
            pathString = extractPathString(itemDetails);
            LOG.info("Item level path string: {}", pathString);
            return objectMapper.readValue(pathString, Map.class);
        } catch (JsonProcessingException exp) {
            LOG.error("Error while parsing derived attribute path {}, error: {}", pathString, exp.getMessage());
        } catch (Exception exp) {
            LOG.error("Error in fetching item details response {}", exp.getMessage());
        }

        return Collections.emptyMap();
    }

    private String extractPathString(GetItemDetailsResponse itemDetails) {
        if (itemDetails == null || itemDetails.getProduct() == null || itemDetails.getProduct().getDerivedAttributes() == null
                || itemDetails.getProduct().getDerivedAttributes().getR2D2Hierarchy() == null
                || itemDetails.getProduct().getDerivedAttributes().getR2D2Hierarchy().getValues().isEmpty()) {
            return null;
        }
        return itemDetails.getProduct().getDerivedAttributes().getR2D2Hierarchy().getValues().get(0).getPath();
    }
}