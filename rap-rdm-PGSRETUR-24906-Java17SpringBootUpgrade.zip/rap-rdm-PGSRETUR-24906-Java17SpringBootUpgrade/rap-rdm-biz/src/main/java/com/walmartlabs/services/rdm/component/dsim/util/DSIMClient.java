package com.walmartlabs.services.rdm.component.dsim.util;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmartlabs.services.rdm.component.dsim.model.MarkDownPriceResponse;
import com.walmartlabs.services.rdm.component.dsim.model.config.summary.request.MarkDownConfigRequest;
import com.walmartlabs.services.rdm.component.dsim.model.config.summary.request.MarkDownRequestContext;
import com.walmartlabs.services.rdm.component.dsim.model.config.summary.response.MarkDownConfigResponse;
import com.walmartlabs.services.rdm.config.client.DSIMConfig;
import com.walmartlabs.services.rdm.formula.impl.java.DSIMMarkDownResolver;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import com.walmartlabs.services.rdm.util.BaseHTTPClient;
import com.walmartlabs.services.rdm.util.RDMTransactionLogger;
import com.walmartlabs.services.rdm.util.cache.CacheManager;
import com.walmartlabs.services.rdm.util.cache.CacheRole;
import io.strati.configuration.annotation.ManagedConfiguration;
import io.strati.txnmarking.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

@Component
public class DSIMClient extends BaseHTTPClient {
    private static final Logger LOG = LoggerFactory.getLogger(DSIMMarkDownResolver.class);

    private static final String DSIM_MARKDOWN_PRICE =  "DSIM_MARKDOWN_PRICE";
    private static final String DSIM_MARKDOWN_CONFIG =  "DSIM_MARKDOWN_CONFIG";
    private static final String COUNTRY_CODE = "countryCode";
    private static final String DEPARTMENT = "department";
    private static final String ORIGINAL_PRICE = "originalPrice";
    private static final String QUANTITY = "quantity";
    private static final String TIMESTAMP = "timestamp";
    private static final String ACCEPT = "Accept";
    private static final String CONTENT_TYPE = "Content-Type";

    private ObjectMapper objectMapper;

    @Resource
    @ManagedConfiguration
    private DSIMConfig dsimConfig;

    @Resource
    private CacheManager cacheManager;

    @Autowired
    private RDMTransactionLogger transactionLogger;

    @PostConstruct
    protected void init() {
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

   public MarkDownConfigResponse getMarkConfigResponse(MarkDownConfigRequest request){
       MarkDownConfigResponse markDownConfigResponse ;
       Transaction transaction = transactionLogger.createTransaction(DSIM_MARKDOWN_CONFIG);
       String requestPayload = null;
       transaction.start();
       try {

           String responseString;
           requestPayload = objectMapper.writeValueAsString(request);
           String cachedData;
           if (dsimConfig.getDsimMarkDownConfigCachingEnabled()) {
               cachedData = cacheManager.get(requestPayload, CacheRole.DSIM); // Not sure about key length for cache
               if (cachedData == null) {
                   responseString = callDsimConfigService(requestPayload);
                   cacheManager.put(requestPayload, responseString, CacheRole.DSIM);
               } else {
                   responseString = cachedData;
               }
           } else {
               responseString = callDsimConfigService(requestPayload);
           }

           markDownConfigResponse = objectMapper.readValue(responseString, MarkDownConfigResponse.class);
           transaction.end();
       }
       catch (ServiceException ex){
           String errorMsg = MessageFormat.format("ServiceException occured for MarkdownConfig for request {0} ",requestPayload);
           LOG.error(errorMsg, ex);
           transaction.logException(ex);
           transaction.endWithFailure(ex.getMessage());
           throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.DSIM_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, ex);

       } catch (Exception  ex){
           String errorMsg = MessageFormat.format("Exception occured for MarkdownConfig for request {0} ", requestPayload);
           LOG.error(errorMsg, ex);
           transaction.logException(ex);
           transaction.endWithFailure(ex.getMessage());
           throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.DSIM_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, ex);

       }

       return markDownConfigResponse;
    }

    /**
     *
     * @param requestPayload
     * @return
     * @throws ServiceException
     *
     */
    private String callDsimConfigService(String requestPayload) throws ServiceException {
        if(dsimConfig.getMockDsimPriceServiceEnabled()){
            LOG.info("Mock enabled for DSIM Config service");
            return dsimConfig.getMockedDsimConfigServiceResponse();
        }

        String baseUrl = dsimConfig.getDsimMarkDownBaseUrl();
        String serviceUrl = dsimConfig.getDsimMarkDownServiceUrl();
        int timeOut = dsimConfig.getDsimMarkDownConfigServiceApiTimeout();
        Map<String , String> headers = new HashMap<>();
        headers.put(ACCEPT, dsimConfig.getAccept());
        headers.put(CONTENT_TYPE,dsimConfig.getContentType());

        LOG.info(MessageFormat.format("Invoking DsimMarkdownConfig service for request {0}",requestPayload));
        String markdownConfigServiceResponse = this.post(baseUrl,serviceUrl,requestPayload,headers,timeOut,String.class);
        LOG.info(MessageFormat.format("DsimMarkdownConfig service output, request {0}, response {1}", requestPayload, markdownConfigServiceResponse));
        return markdownConfigServiceResponse;
    }


    public MarkDownPriceResponse getMarkDownPrice(MarkDownRequestContext markDownRequestContext) {

        Transaction transaction = transactionLogger.createTransaction(DSIM_MARKDOWN_PRICE);
        transaction.start();
        MarkDownPriceResponse priceResponse;
        try {
            String responseString;
            String key = markDownRequestContext.getKey();
            String cachedData;
            if (dsimConfig.getDsimMarkDownPriceCachingEnabled()) {
                cachedData = cacheManager.get(key, CacheRole.DSIM);
                if (cachedData == null) {
                    responseString = callDsimPriceService(markDownRequestContext);
                    cacheManager.put(key, responseString, CacheRole.DSIM);
                } else {
                    responseString = cachedData;
                }
            } else {
                responseString = callDsimPriceService(markDownRequestContext);
            }

            priceResponse = objectMapper.readValue(responseString, MarkDownPriceResponse.class);
            transaction.end();
        } catch (ServiceException ex) {
            String errorMsg = MessageFormat.format("ServiceException occured for MarkDownPrice for request {0}", markDownRequestContext.getKey());
            LOG.error(errorMsg, ex);
            transaction.logException(ex);
            transaction.endWithFailure(ex.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.DSIM_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, markDownRequestContext.getKey());

        } catch (Exception ex) {
            String errorMsg = MessageFormat.format("Exception occured for MarkDownPrice for request {0}", markDownRequestContext);
            LOG.error(errorMsg, ex);
            transaction.logException(ex);
            transaction.endWithFailure(ex.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.DSIM_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, ex);

        }
        return priceResponse;

    }

    /****
     *
     * @param markDownRequestContext
     * @return
     */
    /****
     *   /****
     *      * curl --location --request GET 'https://stage.cvp-us-calculation-service.prod.walmart.com
     *      * /suggestPrice/percent/item
     *      * /9401350/store/100/iteration/1?countryCode=US&department=12&
     *      * originalPrice=23&quantity=1&
     *      * timestamp=2021-06-15T14%3A28%3A55-05%3A00' \
     *      * --header 'accept: *'
     *      *
     *      *
     *      * *
     * @param markDownRequestContext
     * @return
     */

    private String callDsimPriceService(MarkDownRequestContext markDownRequestContext) throws ServiceException {

        if(dsimConfig.getMockDsimPriceServiceEnabled()){
            LOG.info("Mock enabled for DSIM price service");
            return dsimConfig.getMockedDsimPriceServiceResponse();
        }

        String baseUrl = dsimConfig.getDsimMarkDownPricePercentBaseUrl();
        String serviceUrl = dsimConfig.getDsimMarkDownPricePercentServiceUrl();
        serviceUrl = serviceUrl.replace("{itemNum}",markDownRequestContext.getItemNumber()).
                replace("{storeId}", markDownRequestContext.getStoreId()).
                replace("{iterationNum}", markDownRequestContext.getIteration());
        int timeOut = dsimConfig.getDsimMarkDownpriceServiceApiTimeout();
        Map<String , String> headers = new HashMap<>();
        headers.put(ACCEPT, dsimConfig.getAccept());
        headers.put(CONTENT_TYPE,dsimConfig.getContentType());
        Map<String , String> params = new HashMap<>();
        params.put(COUNTRY_CODE,markDownRequestContext.getCountryCode());
        params.put(DEPARTMENT,markDownRequestContext.getDepartmentNo());
        params.put(ORIGINAL_PRICE,markDownRequestContext.getOriginalPrice());
        params.put(QUANTITY,markDownRequestContext.getQuantity());
        params.put(TIMESTAMP,markDownRequestContext.getTimeStamp().toString());


        LOG.info("Invoking DsimMarkDownPrice service for request url,"+ baseUrl+serviceUrl);
        String priceServiceResponse = this.get(baseUrl,serviceUrl,params,headers,timeOut,String.class);
        LOG.info(MessageFormat.format("DsimMarkDownPrice service response, url,{0}, response {1}", serviceUrl, priceServiceResponse));
        return priceServiceResponse;
    }

}
