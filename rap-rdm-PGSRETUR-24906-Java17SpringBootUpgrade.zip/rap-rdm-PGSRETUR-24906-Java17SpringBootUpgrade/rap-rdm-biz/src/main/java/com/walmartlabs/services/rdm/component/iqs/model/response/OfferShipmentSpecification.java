package com.walmartlabs.services.rdm.component.iqs.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OfferShipmentSpecification {
    @JsonProperty("shipSizeCode")
    private String shipSizeCode;

    @JsonProperty("shipClass")
    private String shipClass;

    @JsonProperty("conveyable")
    private Boolean conveyable;

    @JsonProperty("sortable")
    private Boolean sortable;

    public String getShipSizeCode() {
        return shipSizeCode;
    }

    public void setShipSizeCode(String shipSizeCode) {
        this.shipSizeCode = shipSizeCode;
    }

    public String getShipClass() { return shipClass; }

    public void setShipClass(String shipClass) { this.shipClass = shipClass; }

    public Boolean getConveyable() { return conveyable; }

    public void setConveyable(Boolean conveyable) { this.conveyable = conveyable; }

    public Boolean getSortable() { return sortable; }

    public void setSortable(Boolean sortable) { this.sortable = sortable; }
}
