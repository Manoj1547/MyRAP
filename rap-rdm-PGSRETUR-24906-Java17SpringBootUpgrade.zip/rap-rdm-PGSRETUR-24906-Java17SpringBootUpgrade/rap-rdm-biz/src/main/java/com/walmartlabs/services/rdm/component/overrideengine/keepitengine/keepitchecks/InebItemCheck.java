package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("inebItemCheck")
public class InebItemCheck implements IRDMKeepItRuleCheck{
    @Autowired
    RDMKeepItUtil rdmKeepItUtil;

    @Autowired
    public void setRdmKeepItUtil(RDMKeepItUtil rdmKeepItUtil) {
        this.rdmKeepItUtil = rdmKeepItUtil;
    }
    @Override
    public String getKeepItCheckName() {
        return RDMConstants.RULE_CHECK_NAME_IS_INEB_ITEM;
    }

    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {
        return rdmKeepItUtil.isINEBItem(keepItRuleEngineContext.getItem());
    }
}