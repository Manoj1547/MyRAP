package com.walmartlabs.services.rdm.formula.impl.java;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import com.walmartlabs.services.rdm.component.ovt.service.util.OVTHttpClient;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.walmartlabs.services.rdm.component.rcp.model.request.GetItemDispositionDetailsRequest;
import com.walmartlabs.services.rdm.component.rcp.model.request.ItemPrice;
import com.walmartlabs.services.rdm.component.rcp.model.response.GetItemDispositionDetailsResponse;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.FormulaException;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.Formula;

/**
 *
 * @author v0s00g0
 *
 */
@Service
public class OVTDataResolver implements JavaEngineClass {

    @Resource
    OVTHttpClient ovtHttpClient;

    ObjectReader  reader;

    @PostConstruct
    private void init() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        reader = mapper.reader();
    }

    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        Integer vendorNo = FormulaEngine.getNotNullInput(formula,inputData, FormulaConstants.VARIABLE_VENDOR_NMUBER);
        Integer departmentNo = FormulaEngine.getNotNullInput(formula,inputData, FormulaConstants.VARIABLE_DEPARTMENT_NUMBER);
        Integer contractNo = FormulaEngine.getNotNullInput(formula,inputData, FormulaConstants.VARIABLE_CONTRACT_NUMBER);
        String price = FormulaEngine.getNotNullInput(formula,inputData, FormulaConstants.INTERNAL_DATA_NAME_IQS_PRICE);
        String itemId = FormulaEngine.getNotNullInput(formula,inputData, FormulaConstants.INTERNAL_DATA_NAME_ITEM_ID);

        GetItemDispositionDetailsRequest request = new GetItemDispositionDetailsRequest();
        request.getPayload().setVendorNo(vendorNo);
        request.getPayload().setDepartmentNo(departmentNo);
        request.getPayload().setContractNo(contractNo);

        try{
            request.getPayload().setItemPrice(reader.readValue(price, ItemPrice.class));
        }catch (IOException e){
            throw new FormulaException(MessageFormat.format("iqs price is not valid {0}", price), e);
        }

        request.getPayload().setItemId(itemId);

        GetItemDispositionDetailsResponse response = ovtHttpClient.getOvtItemDispositionPolicyDetails(request);
        return response;
    }

}