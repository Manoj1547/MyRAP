package com.walmartlabs.services.rdm.component.apollorestock.restockrules;


import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibilityContext;
import com.walmartlabs.services.rdm.component.rcp.model.response.GetItemDispositionDetailsResponse;
import com.walmartlabs.services.rdm.config.client.ConfigManager;
import com.walmartlabs.services.rdm.config.client.RestockEligibilityConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import org.springframework.stereotype.Component;

@Component("vendorAllowsRestockRule")
public class VendorAllowsRestockRule extends AbstractRestockRule {


    @Override
    public String getRuleName() {
        String ruleName = RDMConstants.RULE_VENDOR_ALLOWS_RESTOCK;
        return ruleName;
    }

    @Override
    public boolean runRule(RestockEligibilityContext restockEligibilityContext) {
        GetItemDispositionDetailsResponse itemDispositionDetailsResponse = restockEligibilityContext.getItemDispositionDetailsResponse();
        boolean isVendorAllowsRestock = itemDispositionDetailsResponse.getRestockableAtStore();

        RestockEligibilityConfig restockEligibilityConfig = ConfigManager.getRestockEligibilityConfig();

        int departmentNo = (int)restockEligibilityContext.getInputData().get(FormulaConstants.VARIABLE_DEPARTMENT_NUMBER);
        boolean isItemRestockable = false;
        if(isVendorAllowsRestock && !restockEligibilityConfig.getRestockIneligibleDeptList().contains(departmentNo)){
            isItemRestockable = true;
        }
        return isItemRestockable;
    }

}
