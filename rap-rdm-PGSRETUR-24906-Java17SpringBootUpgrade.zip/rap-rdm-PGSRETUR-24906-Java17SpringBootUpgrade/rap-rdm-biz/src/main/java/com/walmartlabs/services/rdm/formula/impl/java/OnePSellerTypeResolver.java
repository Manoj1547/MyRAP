package com.walmartlabs.services.rdm.formula.impl.java;

import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.Formula;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.stereotype.Service;

import java.util.Map;


/**
 * Author : v0s00g0
 */
@Service
public class OnePSellerTypeResolver implements JavaEngineClass {


    @ManagedConfiguration
    RDMSwitches rdmSwitches;

    @Override
    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {

        String sellerId = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.VARIABLE_SELLER_ID);

        return rdmSwitches.getOnePSellerID().equals(sellerId);
    }

}