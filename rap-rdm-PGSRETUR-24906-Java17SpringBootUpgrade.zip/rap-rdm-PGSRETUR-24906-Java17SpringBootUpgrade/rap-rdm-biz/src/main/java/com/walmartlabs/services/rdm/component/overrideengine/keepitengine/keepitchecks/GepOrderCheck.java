package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;
import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("gepOrderCheck")
public class GepOrderCheck implements IRDMKeepItRuleCheck{
    @Autowired
    private RDMKeepItUtil rdmKeepItUtil;
    @ManagedConfiguration
    private RDMKeepItConfig rdmKeepItConfig;

    public void setRdmKeepItUtil(RDMKeepItUtil rdmKeepItUtil) {
        this.rdmKeepItUtil = rdmKeepItUtil;
    }

    public void setRdmKeepItConfig(RDMKeepItConfig rdmKeepItConfig) {
        this.rdmKeepItConfig = rdmKeepItConfig;
    }

    @Override
    public String getKeepItCheckName() {
        return RDMConstants.RULE_CHECK_NAME_GEP_ORDER;
    }

    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {
        return rdmKeepItUtil.checkGepOrder(keepItRuleEngineContext);
    }
}
