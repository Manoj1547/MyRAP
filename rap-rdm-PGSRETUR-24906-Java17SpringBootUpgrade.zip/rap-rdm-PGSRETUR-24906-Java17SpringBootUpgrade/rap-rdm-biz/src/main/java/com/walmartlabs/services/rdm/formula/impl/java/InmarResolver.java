package com.walmartlabs.services.rdm.formula.impl.java;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.walmartlabs.services.rdm.config.client.InmarConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.Formula;

import io.strati.configuration.annotation.ManagedConfiguration;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public class InmarResolver implements JavaEngineClass {
    private static final String DASH = "-";

    @Resource
    @ManagedConfiguration
    InmarConfig                 inmarConfig;

    @PostConstruct
    private void init() {}

    private Map<String, Set<String>> getVendorDeptSeqMap(String vendorDeptSeqList) {
        Map<String, Set<String>> venodIdKeydeptSeqValuesMap = new HashMap<>();
        if(vendorDeptSeqList != null){
            StringTokenizer vendorDeptSeqListSt = new StringTokenizer(vendorDeptSeqList, ";");
            while(vendorDeptSeqListSt.hasMoreTokens()){
                String vendorDeptSeqSt = vendorDeptSeqListSt.nextToken();
                StringTokenizer vendorAndDeptSeqSt = new StringTokenizer(vendorDeptSeqSt, "=");
                while(vendorAndDeptSeqSt.hasMoreTokens()){
                    String vendorId = vendorAndDeptSeqSt.nextToken();
                    String deptSeqList = vendorAndDeptSeqSt.nextToken();
                    Set<String> deptSeqSet = new HashSet<>();
                    StringTokenizer deptSeqSetSt = new StringTokenizer(deptSeqList, ",");
                    while(deptSeqSetSt.hasMoreTokens()){
                        String deptSeq = deptSeqSetSt.nextToken();
                        deptSeqSet.add(deptSeq);
                    }
                    venodIdKeydeptSeqValuesMap.put(vendorId, deptSeqSet);
                }
            }
        }

        return venodIdKeydeptSeqValuesMap;
    }

    private boolean isVendorDeptSeqEnabledForInmar(String vendorId, String dept, String seq) {
        boolean isEnabled = false;

        Map<String, Set<String>> vendorIdKeydeptSeqValuesMap = getVendorDeptSeqMap(inmarConfig.getVendorDeptSeqList());

        Set<String> depSeqSet = vendorIdKeydeptSeqValuesMap.get(vendorId);
        if(depSeqSet != null && !depSeqSet.isEmpty()){
            String deptSeqString = dept + DASH + seq;
            if(depSeqSet.contains(deptSeqString)){
                isEnabled = true;
            }
        }

        return isEnabled;
    }

    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        Integer vendorNo = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.VARIABLE_VENDOR_NMUBER);
        Integer departmentNo = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.VARIABLE_DEPARTMENT_NUMBER);
        Integer contractNo = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.VARIABLE_CONTRACT_NUMBER);

        return isVendorDeptSeqEnabledForInmar(String.valueOf(vendorNo), String.valueOf(departmentNo), String.valueOf(contractNo));
    }

}
