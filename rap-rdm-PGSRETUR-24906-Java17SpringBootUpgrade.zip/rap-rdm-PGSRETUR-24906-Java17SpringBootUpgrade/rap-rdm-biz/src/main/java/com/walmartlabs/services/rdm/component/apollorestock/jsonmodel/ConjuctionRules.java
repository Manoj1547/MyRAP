package com.walmartlabs.services.rdm.component.apollorestock.jsonmodel;

import java.util.List;

public class ConjuctionRules {

    public List<Rule> rules;

    public List<Rule> getRules() {
        return rules;
    }

    public void setRules(List<Rule> rules) {
        this.rules = rules;
    }
}
