package com.walmartlabs.services.rdm.rank.assigner;

import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;

import java.util.List;

public abstract class RankAssigner {

    private RankAssigner nextRankAssigner;

    void setNextRankAssigner(RankAssigner nextRankAssigner) {
        this.nextRankAssigner = nextRankAssigner;
    }

    void executeRankAssigner(List<DispositionInfo> allItemsDispositionInfoList) {
        assignRanks(allItemsDispositionInfoList);

        if(null != nextRankAssigner && nextRankAssigner.isEnabled()) {
            nextRankAssigner.executeRankAssigner(allItemsDispositionInfoList);
        }
    }

    /**
     * It checks if the business rule is enabled to be executed in the chain
     * Currently every business rule is enabled but this method can be used to include checks/conditions
     * to enable or disable any business rule
     * @return
     */
    private boolean isEnabled() {
        return true;
    }

    protected abstract void assignRanks(List<DispositionInfo> allItemsDispositionInfoList);
}

