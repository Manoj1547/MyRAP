package com.walmartlabs.services.rdm.api.impl;

import org.springframework.http.HttpStatus;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmartlabs.services.rdm.api.HealthCheck;
import com.walmartlabs.services.rdm.dto.healthcheck.HealthCheckResponseDTO;

/**
 * 
 * @author Tim Jin
 *
 */
public class HealthCheckAsyncServicesImpl implements HealthCheck {

    private static final String APP_TYPE_KEY = "com.walmart.platform.config.appType";
    private static final String ENV_KEY      = "runtime.context.environmentType";

    public HealthCheckResponseDTO status() throws ServiceException {
        HealthCheckResponseDTO response = new HealthCheckResponseDTO();
        response.setAppType(System.getProperty(APP_TYPE_KEY));
        response.setEnv(System.getProperty(ENV_KEY));
        response.setStatus(HttpStatus.OK.name());
        return response;
    }

}
