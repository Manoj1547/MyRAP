package com.walmartlabs.services.rdm.component.iqs.model.response.iqs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OfferInfo {

    /****
     *
     * {
     *                         "offerId": "F36DA1CBA3A348869700B8E89141C168",
     *                         "offerType": "ONLINE_ONLY",
     *                         "sellerId": "455A2F43226F41319399794332C71B7F",
     *                         "currentPriceCurrencyAmount": 56.0,
     *                         "shipSizeCode": "SMALL",
     *                         "isHazmat": false,
     *                         "productPackageDimensions": [
     *                             {
     *                                 "packageId": "1",
     *                                 "unitHeight": {
     *                                     "unitOfMeasure": "INCH",
     *                                     "measurementValue": 4
     *                                 },
     *                                 "unitLength": {
     *                                     "unitOfMeasure": "INCH",
     *                                     "measurementValue": 2
     *                                 },
     *                                 "unitWidth": {
     *                                     "unitOfMeasure": "INCH",
     *                                     "measurementValue": 3
     *                                 }
     *                             }
     *                         ]
     *                     }
     */

    @JsonProperty("offerId")
    private String offerId;

    @JsonProperty("offerType")
    private String offerType;

    @JsonProperty("sellerId")
    private String sellerId;

    private BigDecimal currentPriceCurrencyAmount;

    private String shipSizeCode;

    @JsonProperty("isHazmat")
    private Boolean isHazmat;

    @JsonProperty("productPackageDimensions")
    private List<ProductPackageDimension> productPackageDimensions;


    public String getOfferId() {
        return offerId;
    }

    public void setOfferId(String offerId) {
        this.offerId = offerId;
    }

    public String getOfferType() {
        return offerType;
    }

    public void setOfferType(String offerType) {
        this.offerType = offerType;
    }

    public String getSellerId() {
        return sellerId;
    }

    public void setSellerId(String sellerId) {
        this.sellerId = sellerId;
    }

    public BigDecimal getCurrentPriceCurrencyAmount() {
        return currentPriceCurrencyAmount;
    }

    public void setCurrentPriceCurrencyAmount(BigDecimal currentPriceCurrencyAmount) {
        this.currentPriceCurrencyAmount = currentPriceCurrencyAmount;
    }

    public String getShipSizeCode() {
        return shipSizeCode;
    }

    public void setShipSizeCode(String shipSizeCode) {
        this.shipSizeCode = shipSizeCode;
    }

    public Boolean getIsHazmat() {
        return isHazmat;
    }

    public void setIsHazmat(Boolean isHazmat) {
        isHazmat = isHazmat;
    }

    public List<ProductPackageDimension> getProductPackageDimensions() {
        return productPackageDimensions;
    }

    public void setProductPackageDimensions(List<ProductPackageDimension> productPackageDimensions) {
        this.productPackageDimensions = productPackageDimensions;
    }
}
