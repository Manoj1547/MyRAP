package com.walmartlabs.services.rdm.formula.impl;

import java.text.MessageFormat;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.FormulaException;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.Formula;
import com.walmartlabs.services.rdm.model.formula.FormulaType;

/**
 *
 * @author Tim Jin
 *
 */
@Service
public class JsonPEngine implements FormulaEngine {

    private static final Logger   LOG               = LoggerFactory.getLogger(JsonPEngine.class);

    static final String           VARIABLE_DOCUMENT = "DOCUMENT";

    private Map<String, JsonPath> pathMap           = new ConcurrentHashMap<>();

    private ObjectWriter          writer;

    JsonPEngine() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        writer = mapper.writer();
    }

    /**
     * @param formula
     *            not null and type is correct
     * @param inputData
     *            not null
     */
    @Override
    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {

        Matcher matcher = FormulaConstants.JSONP_FORMULA_PATTERN.matcher(formula.getFormula());
        if(matcher.find()){
            //found a parameter
            String key = matcher.group(1);
            String pathStr = matcher.group(2);

            JsonPath path = pathMap.computeIfAbsent(pathStr, k -> JsonPath.compile(pathStr));

            Object data = FormulaEngine.getInput(formula, inputData, key);
            try{
                String content = data instanceof String ? (String) data : data == null ? null : writer.writeValueAsString(data);
                if(content == null) return null;
                DocumentContext document = (DocumentContext) inputData.computeIfAbsent(FormulaConstants.INTERNAL_DATA_NAME_PREFIX + key + VARIABLE_DOCUMENT, k -> JsonPath.parse(content));

                Object v = null;
                try{
                    v = document.read(path, Object.class);
                }catch (Exception e){
                    LOG.error("{}", e.getMessage());
                    return null;
                }

                switch (formula.getValueType()) {
                    case BOOLEAN:
                        return BooleanUtils.toBooleanObject(v.toString());
                    case DOUBLE:
                        return Double.parseDouble(v.toString());
                    case INTEGER:
                        return (int) Double.parseDouble(v.toString());
                    case STRING:
                        return StringUtils.trimToNull(v.toString());
                    case OBJECT:
                    default:
                        return writer.writeValueAsString(v);
                }
            }catch (Exception e){
                LOG.error("{}", e.getMessage());
                e.printStackTrace();
                throw new FormulaException(MessageFormat.format("{0} failed to eval. {1}", formula.getFormula(), e.getMessage()));
            }
        }else{
            throw new FormulaException(MessageFormat.format("{0} is not valid.", formula.getFormula()));
        }
    }

    @Override
    public FormulaType type() {
        return FormulaType.JSONP;
    }

}
