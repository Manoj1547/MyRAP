package com.walmartlabs.services.rdm.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;

import java.io.IOException;
import java.util.Date;

public class JsonDateDeserializer extends JsonDeserializer<Date> {

    @Override
    public Date deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException {
        String dateString = jp.getText();
        Date date = null;
        if (dateString != null && !dateString.equals("")) {
            DateTimeFormatter dtf = ISODateTimeFormat.dateTimeParser();
            date = dtf.parseDateTime(dateString).toDate();
        }
        return date;
    }
}
