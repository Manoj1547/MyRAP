package com.walmartlabs.services.rdm.component.siro.model.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RecallOverstock {
    @JsonProperty("recallId")
    private Integer recallId;

    @JsonProperty("recallReasonCode")
    private String recallReasonCode;

    @JsonProperty("recallTypeCode")
    private Integer recallTypeCode;

    @JsonProperty("effectiveDate")
    @JsonDeserialize(using = JsonDateDeserializer.class)
    @JsonFormat(pattern = "MM/dd/yyyy")
    private Date effectiveDate;

    @JsonProperty("expirationDate")
    @JsonDeserialize(using = JsonDateDeserializer.class)
    @JsonFormat(pattern = "MM/dd/yyyy")
    private Date expirationDate;

    public Integer getRecallId() {
        return recallId;
    }

    public void setRecallId(Integer recallId) {
        this.recallId = recallId;
    }

    public Integer getRecallTypeCode() {
        return recallTypeCode;
    }

    public void setRecallTypeCode(Integer recallTypeCode) {
        this.recallTypeCode = recallTypeCode;
    }

    public String getRecallReasonCode() {
        return recallReasonCode;
    }

    public void setRecallReasonCode(String recallReasonCode) {
        this.recallReasonCode = recallReasonCode;
    }

    public Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public Date getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }
}
