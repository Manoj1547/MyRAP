package com.walmartlabs.services.rdm.component.siro.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ActiveItem {

    @JsonProperty("supply")
    private Supply supply;

    @JsonProperty("productRecall")
    private ProductRecall productRecall;

    public Supply getSupply() {
        return supply;
    }

    public void setSupply(Supply supply) {
        this.supply = supply;
    }

    public ProductRecall getProductRecall() {
        return productRecall;
    }

    public void setProductRecall(ProductRecall productRecall) {
        this.productRecall = productRecall;
    }
}
