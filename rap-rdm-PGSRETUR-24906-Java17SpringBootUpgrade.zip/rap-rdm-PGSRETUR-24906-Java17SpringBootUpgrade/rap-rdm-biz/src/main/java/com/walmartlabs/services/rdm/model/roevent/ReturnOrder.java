package com.walmartlabs.services.rdm.model.roevent;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.walmartlabs.services.rdm.model.JsonDateDeserializer;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.ChannelInfo;
import com.walmartlabs.services.rdm.model.Audit;
import java.util.Date;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReturnOrder {
    @JsonProperty("publishTimestamp")
    private Long publishTimestamp;

    @JsonProperty("salesOrderNo")
    private String salesOrderNo;

    @JsonProperty("originSystemOrderId")
    private String originSystemOrderId;

    @JsonProperty("orderOrigin")
    private String orderOrigin;

    @JsonProperty("returnOrderNo")
    private String returnOrderNo;

    @JsonProperty("orderType")
    private String orderType;

    @JsonProperty("auditInfo")
    private Audit auditInfo;

    @JsonProperty("buyerInfo")
    private BuyerInfo buyerInfo;

    @JsonProperty("storeId")
    private String storeId;

    @JsonProperty("createts")
    @JsonDeserialize(using = JsonDateDeserializer.class)
    private Date createts;

    @JsonProperty("returnCreatedDate")
    private Long returnCreatedDate;

    @JsonProperty("orderLines")
    private List<ReturnOrderLine> orderLines;

    @JsonProperty("channelInfo")
    private ChannelInfo channelInfo;

    @JsonProperty("refundMode")
    private String refundMode;

    @JsonProperty("returnRefNumber")
    private String returnRefNumber;

    @JsonProperty("sellerName")
    private String sellerName;

    @JsonProperty("isCustomerCareOverride")
    private boolean isCustomerCareOverride;

    @JsonProperty("isCustomerTrustedForKeepit")
    private boolean isCustomerTrustedForKeepit;

    public Long getPublishTimestamp() {
        return publishTimestamp;
    }

    public void setPublishTimestamp(Long publishTimestamp) {
        this.publishTimestamp = publishTimestamp;
    }

    public String getSalesOrderNo() {
        return salesOrderNo;
    }

    public void setSalesOrderNo(String salesOrderNo) {
        this.salesOrderNo = salesOrderNo;
    }

    public String getReturnOrderNo() {
        return returnOrderNo;
    }

    public void setReturnOrderNo(String returnOrderNo) {
        this.returnOrderNo = returnOrderNo;
    }

    public List<ReturnOrderLine> getOrderLines() {
        return orderLines;
    }

    public void setOrderLines(List<ReturnOrderLine> orderLines) {
        this.orderLines = orderLines;
    }

    public Audit getAuditInfo() {
        return auditInfo;
    }

    public void setAuditInfo(Audit auditInfo) {
        this.auditInfo = auditInfo;
    }

    public BuyerInfo getBuyerInfo() {
        return buyerInfo;
    }

    public void setBuyerInfo(BuyerInfo buyerInfo) {
        this.buyerInfo = buyerInfo;
    }

    public Date getCreatets() {
        return createts;
    }

    public void setCreatets(Date createts) {
        this.createts = createts;
    }

    public Long getReturnCreatedDate() {
        return returnCreatedDate;
    }

    public void setReturnCreatedDate(Long returnCreatedDate) {
        this.returnCreatedDate = returnCreatedDate;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getOriginSystemOrderId() {
        return originSystemOrderId;
    }

    public void setOriginSystemOrderId(String originSystemOrderId) {
        this.originSystemOrderId = originSystemOrderId;
    }

    public String getOrderOrigin() {
        return orderOrigin;
    }

    public void setOrderOrigin(String orderOrigin) {
        this.orderOrigin = orderOrigin;
    }

    public ChannelInfo getChannelInfo() {
        return channelInfo;
    }

    public void setChannelInfo(ChannelInfo channelInfo) {
        this.channelInfo = channelInfo;
    }

    public String getRefundMode() {
        return refundMode;
    }

    public void setRefundMode(String refundMode) {
        this.refundMode = refundMode;
    }

    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    public boolean isCustomerCareOverride() {
        return isCustomerCareOverride;
    }

    public void setCustomerCareOverride(boolean isCustomerCareOverride) {
        this.isCustomerCareOverride = isCustomerCareOverride;
    }

    public boolean isCustomerTrustedForKeepit() {
        return isCustomerTrustedForKeepit;
    }

    public void setCustomerTrustedForKeepit(boolean isCustomerTrustedForKeepit) {
        this.isCustomerTrustedForKeepit = isCustomerTrustedForKeepit;
    }

    public String getReturnRefNumber() {
        return returnRefNumber;
    }

    public void setReturnRefNumber(String returnRefNumber) {
        this.returnRefNumber = returnRefNumber;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ReturnOrder [");
        sb.append("publishTimestamp=").append(publishTimestamp);
        sb.append(", salesOrderNo='").append(salesOrderNo).append('\'');
        sb.append(", originSystemOrderId='").append(originSystemOrderId).append('\'');
        sb.append(", orderOrigin='").append(orderOrigin).append('\'');
        sb.append(", returnOrderNo='").append(returnOrderNo).append('\'');
        sb.append(", orderType='").append(orderType).append('\'');
        sb.append(", auditInfo=").append(auditInfo);
        sb.append(", buyerInfo=").append(buyerInfo);
        sb.append(", storeId='").append(storeId).append('\'');
        sb.append(", createts=").append(createts);
        sb.append(", returnCreatedDate=").append(returnCreatedDate);
        sb.append(", orderLines=").append(orderLines);
        sb.append(", channelInfo=").append(channelInfo);
        sb.append(", refundMode='").append(refundMode).append('\'');
        sb.append(", returnRefNumber='").append(returnRefNumber).append('\'');
        sb.append(", sellerName='").append(sellerName).append('\'');
        sb.append(", isCustomerTrustedForKeepit=").append(isCustomerTrustedForKeepit);
        sb.append(", isCustomerCareOverride=").append(isCustomerCareOverride);
        sb.append(']');
        return sb.toString();
    }
}
