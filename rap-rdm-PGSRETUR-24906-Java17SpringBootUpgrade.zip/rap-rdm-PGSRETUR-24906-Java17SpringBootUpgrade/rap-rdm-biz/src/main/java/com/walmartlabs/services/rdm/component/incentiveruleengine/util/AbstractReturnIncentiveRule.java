package com.walmartlabs.services.rdm.component.incentiveruleengine.util;

import com.walmartlabs.services.rdm.component.incentiveruleengine.model.ReturnIncentiveEngineContext;

/**
 * @author v0h01q5
 */
public abstract class AbstractReturnIncentiveRule {


    public abstract boolean runReturnIncentiveRule(ReturnIncentiveEngineContext returnIncentiveEngineContext);

    public abstract String getRuleName();
}
