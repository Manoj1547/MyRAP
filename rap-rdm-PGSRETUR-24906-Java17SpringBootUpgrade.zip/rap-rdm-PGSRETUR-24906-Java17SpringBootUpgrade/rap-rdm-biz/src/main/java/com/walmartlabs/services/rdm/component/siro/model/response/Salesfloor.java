package com.walmartlabs.services.rdm.component.siro.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Salesfloor{

    @JsonProperty("modular")
    public Modular modular;

    public Modular getModular() {
        return modular;
    }

    public void setModular(Modular modular) {
        this.modular = modular;
    }
}