package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitrules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.common.AbstractOverRideRule;
import com.walmartlabs.services.rdm.component.overrideengine.common.IRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks.IRDMKeepItRuleCheck;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks.WMPlusCustomerItemConditionCheck;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.Timing;
import com.walmartlabs.services.rdm.util.RDMCommonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


public abstract class AbstractRDMKeepItRule extends AbstractOverRideRule {

    private static final Logger LOG = LoggerFactory.getLogger(AbstractRDMKeepItRule.class);

    @Autowired
    RDMCommonUtils rdmCommonUtils;

    public boolean runRule(IRuleEngineContext ruleEngineContext) {

        KeepItRuleEngineContext keepItRuleEngineContext = (KeepItRuleEngineContext) ruleEngineContext;
        String offerId = keepItRuleEngineContext.getItem().getOfferId();
        LOG.info(this.getRuleName() + ".runRule() started for offerId," + offerId);

        long startTime = System.currentTimeMillis();
        boolean isCheckPassed = false;
          for(IRDMKeepItRuleCheck keepItRuleCheck : KeepItRulesFactory.getAllKeepItRuleChecks(this.getRuleName())){
              isCheckPassed = keepItRuleCheck.runCheck(keepItRuleEngineContext);

              if(!isCheckPassed){
                  break;
              }
          }

        rdmCommonUtils.timingProxy(RDMConstants.KEEP_IT_RULE_RUN + this.getRuleName(),
                keepItRuleEngineContext.getDispositionInfo().getTiming(), Timing.Type.KEEPIT_RULE, startTime) ;

        LOG.info(this.getRuleName() + ".runRule() exited for offerId," + offerId + ", result," + isCheckPassed);
        return isCheckPassed;
    }

    public abstract void applyRuleDecision(IRuleEngineContext ruleEngineContext);

    public abstract String getRuleName();




}
