package com.walmartlabs.services.rdm.component.restock.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetRestockItemDetailsResponse {

    @JsonProperty("smartLabelId")
    private String smartLabelId;

    @JsonProperty("itemInfo")
    private ItemInfo itemInfo;

    @JsonProperty("disposition")
    private Disposition[] disposition;

    public String getSmartLabelId() {
        return smartLabelId;
    }

    public void setSmartLabelId(String smartLabelId) {
        this.smartLabelId = smartLabelId;
    }

    public ItemInfo getItemInfo() {
        return itemInfo;
    }

    public void setItemInfo(ItemInfo itemInfo) {
        this.itemInfo = itemInfo;
    }

    public Disposition[] getDisposition() {
        return disposition;
    }

    public void setDisposition(Disposition[] disposition) {
        this.disposition = disposition;
    }
}
