package com.walmartlabs.services.rdm.formula.impl.java.r2d2;

import java.text.MessageFormat;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.FormulaException;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.Formula;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public abstract class R2D2DataResolver extends R2D2Data implements JavaEngineClass {

    private static final Logger LOG = LoggerFactory.getLogger(R2D2DataResolver.class);

    private ObjectReader        reader;

    R2D2DataResolver() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        reader = mapper.reader();
    }

    String getL1(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        String r2d2 = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.VARIABLE_R2D2);
        String name = null;
        try{
            JsonNode tree = reader.readTree(r2d2);
            if(tree != null && tree.has("L1")){
                JsonNode l1 = tree.get("L1");
                if(l1 != null && l1.has("name")){
                    name = l1.get("name").asText();
                }
            }
        }catch (JsonProcessingException e){
            LOG.error("", e);
            throw new FormulaException(MessageFormat.format("{0}(={1}) is invalid.", FormulaConstants.VARIABLE_R2D2, r2d2));
        }
        LOG.info(MessageFormat.format("R2D2 L1={0}", name));
        return name;
    }

}
