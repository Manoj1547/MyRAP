package com.walmartlabs.services.rdm.model;

import java.util.ArrayList;
import java.util.List;

import com.walmartlabs.services.rdm.model.formula.Formula;

/**
 * 
 * @author Tim Jin
 *
 */
public class Node extends BaseNode<Node> {

    private String        description;

    private boolean       keyNode;
    
    private boolean       skipRank;

    private List<Formula> valueFormulas       = new ArrayList<>();

    private List<Formula> valueStopFormulas   = new ArrayList<>();

    private List<Formula> eligibilityFormulas = new ArrayList<>();

    private List<Formula> variableFormulas    = new ArrayList<>();

    private List<Formula> validationFormulas  = new ArrayList<>();

    private List<Formula> formulas            = new ArrayList<>();

    private Double        value;

    private SellerType sellerType;

    public SellerType getSellerType() {
        return sellerType;
    }

    public void setSellerType(SellerType sellerType) {
        this.sellerType = sellerType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isKeyNode() {
        return keyNode;
    }

    public void setKeyNode(boolean keyNode) {
        this.keyNode = keyNode;
    }

    public boolean isSkipRank() {
        return skipRank;
    }

    public void setSkipRank(boolean skipRank) {
        this.skipRank = skipRank;
    }

    public List<Formula> getValueFormulas() {
        return valueFormulas;
    }

    public void setValueFormulas(List<Formula> valueFormulas) {
        this.valueFormulas = valueFormulas;
    }

    public List<Formula> getValueStopFormulas() {
        return valueStopFormulas;
    }

    public void setValueStopFormulas(List<Formula> valueStopFormulas) {
        this.valueStopFormulas = valueStopFormulas;
    }

    public List<Formula> getEligibilityFormulas() {
        return eligibilityFormulas;
    }

    public void setEligibilityFormulas(List<Formula> eligibilityFormulas) {
        this.eligibilityFormulas = eligibilityFormulas;
    }

    public List<Formula> getVariableFormulas() {
        return variableFormulas;
    }

    public void setVariableFormulas(List<Formula> variableFormulas) {
        this.variableFormulas = variableFormulas;
    }

    public List<Formula> getValidationFormulas() {
        return validationFormulas;
    }

    public void setValidationFormulas(List<Formula> validationFormulas) {
        this.validationFormulas = validationFormulas;
    }

    public List<Formula> getFormulas() {
        return formulas;
    }

    public void setFormulas(List<Formula> formulas) {
        this.formulas = formulas;
    }

    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    public Node() {
    }
}
