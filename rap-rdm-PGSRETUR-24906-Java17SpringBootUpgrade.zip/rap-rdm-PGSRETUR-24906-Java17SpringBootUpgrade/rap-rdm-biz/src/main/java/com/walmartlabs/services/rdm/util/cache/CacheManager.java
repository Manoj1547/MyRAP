package com.walmartlabs.services.rdm.util.cache;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import io.strati.configuration.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.walmart.platform.txnmarking.impl.NullTransactionImpl;
import com.walmart.platform.txnmarking.impl.TransactionImpl;
import com.walmartlabs.services.rdm.config.ConfigConstants;
import com.walmartlabs.services.rdm.config.client.RDMSwitches;

import io.strati.StratiServiceProvider;
import io.strati.configuration.ConfigurationService;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.apache.commons.lang.BooleanUtils;
import io.strati.persistence.cache.Cache;
import io.strati.txnmarking.Transaction;
import io.strati.txnmarking.TransactionMarkingService;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public class CacheManager {

    private static final Logger                          LOG         = LoggerFactory.getLogger(CacheManager.class);

    public static final CacheRole                        defaultRole = CacheRole.DEFAULT;

    protected Map<CacheRole, Cache<String, StringModel>> cacheMap    = new HashMap<>();

    @Resource
    ConfigurationService                                 configService;

    @ManagedConfiguration
    RDMSwitches                                          switches;

    private TransactionMarkingService                    TMS;

    @PostConstruct
    protected void init() {
        try{
            TMS = StratiServiceProvider.getInstance().getTransactionMarkingService().get();

            StratiServiceProvider provider = StratiServiceProvider.getInstance();
            Properties all = configService.getConfiguration(ConfigConstants.CACHE_PROPERTIES).getPropertiesSnapshot();//TODO auto reload
            for(CacheRole role : CacheRole.values()){
                try{
                    String roleKey = role.name().toLowerCase();
                    setMeghaCacheClusterBasedRole(all, roleKey);
                    Properties properties = getPropertiesWidthDefaults(all, defaultRole.name().toLowerCase(), roleKey);
                    Cache<String, StringModel> cache = provider.getCacheService().orElseThrow(() -> new IllegalArgumentException("policyCache service not found")).getCacheBuilder(StringModel.class, roleKey).fromProperties(properties);
                    cacheMap.put(role, cache);
                    LOG.info("Cache {} initialized", roleKey);
                }catch (Exception e){
                    //if cache not initialized don't block the app to start
                    LOG.error("CacheRole failed to load. {}", e.getMessage());
                }
            }
        }catch (Exception e){
            //if cache not initialized don't block the app to start
            LOG.error("CacheManager failed to load. {}", e.getMessage());
        }
    }

    private Transaction getTransaction(String name) {
        if(TMS.currentTransaction() instanceof NullTransactionImpl){
            return TMS.topTransaction(name, name);
        }else{
            return (TransactionImpl) TMS.transaction(name, name);
        }
    }

    public String get(String key) {
        return get(key, CacheRole.DEFAULT);
    }

    public void put(String key, String data) {
        put(key, data, CacheRole.DEFAULT);
    }

    public String get(String key, CacheRole role) {
        String data = get(role, toKey(key, role));
        LOG.info("Cache-Role{},key{}, hit:{}", role.name(),key,  data != null);
        return data;
    }

    public void put(String key, String data, CacheRole role) {
        put(role, toKey(key, role), data, null);
    }

    public void put(String key, String data, CacheRole role, Duration ttl) {
        put(role, toKey(key, role), data, ttl);
    }

    private String toKey(String key, CacheRole role) {
        return role.name() + ":" + key;
    }

    private Properties getPropertiesWidthDefaults(Properties source, String defaultRole, String role) {
        if(defaultRole.equals(role)) return source;
        Properties target = new Properties();
        for(Object o : source.keySet()){
            String key = o.toString();
            //TODO, a Generic way to handle all overridden keys
            if(key.startsWith(defaultRole) &&  !key.contains("cache.put.ttl")) {
                target.put(key.replace(defaultRole, role), source.get(key));
            }
            else if(key.startsWith(role)) target.put(key, source.get(key));
        }
        System.out.println(target);
        return target;
    }

    protected String get(CacheRole role, String key) {
        Cache<String, StringModel> cache = cacheMap.getOrDefault(role, null);
        if(cache == null || key == null || BooleanUtils.isNotTrue(switches.getCacheEnabled())) return null;

        Transaction t = getTransaction("CacheManager-GET-" + role);
        t.start();

        String data = null;
        try{
            Optional<StringModel> c = cache.get(key);
            if(c.isPresent()){
                StringModel model = c.get();
                if(model != null){
                    data = model.getData();
                }else{
                    LOG.error("Cache model is null. key:{}", key);
                }
                t.end();
            }else{
                t.endWithFailure("miss");
            }
        }catch (Exception e){
            t.endWithFailure(e.getMessage());
            LOG.info("Get cache failed. {}", e.getMessage());
        }

        return data;
    }

    protected void put(CacheRole role, String key, String data, Duration ttl) {
        Cache<String, StringModel> cache = cacheMap.getOrDefault(role, null);
        if(cache == null || key == null || BooleanUtils.isNotTrue(switches.getCacheEnabled())) return;

        Transaction t = getTransaction("CacheManager-PUT-" + role);
        t.start();

        try{
            StringModel model = new StringModel();
            model.setData(data);
            model.setId(key);
            cache.put(model, ttl);
            t.end();
        }catch (Exception e){
            t.endWithFailure(e.getMessage());
            LOG.info("Put cache failed. {}", e.getMessage());
        }

    }

    public void removeKey(String key, CacheRole role) {
        Cache<String, StringModel> cache = cacheMap.getOrDefault(role, null);
        if(cache == null || key == null || BooleanUtils.isNotTrue(switches.getCacheEnabled())) return;

        Transaction t = getTransaction("CacheManager-REMOVEKEY-" + role);
        t.start();

        try{
            cache.remove(toKey(key, role));
            t.end();
        }catch (Exception e){
            t.endWithFailure(e.getMessage());
            LOG.info("Remove key cache failed. {}", e.getMessage());
        }

    }

    private void setMeghaCacheClusterBasedRole(Properties all, String roleKey) {
        if(isMeghaCacheClusterBasedRole()) {
            String meghaCacheNode = roleKey + ConfigConstants.MEGHACACHE_NODES;
            if (all == null) {
                throw new RDMException(ApplicationLayer.PLATFORM_BASE_LAYER, ErrorCodeMapping.UNEXPECTED_ERROR, "Can not load CCM configuration");
            } else if (all.getProperty(meghaCacheNode) != null) {
                if (ConfigConstants.ACTIVE_CLUSTER.equalsIgnoreCase(ConfigConstants.WUS)) {
                    LOG.info("Overriding WUS cluster MeghaCache URL for configName {} ", roleKey);
                    all.setProperty(meghaCacheNode, all.getProperty(ConfigConstants.MEGHACACHE_FAILOVER_URL));
                }
            }
        }
    }

    private boolean isMeghaCacheClusterBasedRole(){
        Configuration config = configService.getConfiguration("rdm-switches");
        return config!= null && config.getPropertiesSnapshot()!=null &&
                Boolean.parseBoolean(config.getPropertiesSnapshot().getProperty(ConfigConstants.ENABLE_MEGHACACHE_CLUSTER_BASED_ROLE));
    }
}
