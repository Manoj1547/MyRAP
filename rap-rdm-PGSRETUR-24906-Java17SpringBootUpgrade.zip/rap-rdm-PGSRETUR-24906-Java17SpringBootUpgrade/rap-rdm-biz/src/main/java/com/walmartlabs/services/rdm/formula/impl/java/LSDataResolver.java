package com.walmartlabs.services.rdm.formula.impl.java;


import java.util.Map;
import java.util.concurrent.CompletableFuture;


import javax.annotation.Resource;

import com.walmartlabs.services.rdm.component.ls.model.newls.PrefStoreResponse;
import com.walmartlabs.services.rdm.component.ls.service.util.LSServiceHelper;
import com.walmartlabs.services.rdm.component.ls.model.GetPrefStoreResponse;
import com.walmartlabs.services.rdm.config.client.LocationServiceConfig;
import com.walmartlabs.services.rdm.formula.*;
import com.walmartlabs.services.rdm.util.RDMCommonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmartlabs.services.rdm.component.ls.model.GetPrefStoreRequest;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.formula.Formula;

import io.strati.configuration.annotation.ManagedConfiguration;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public class LSDataResolver implements JavaEngineClass {

    private static final Logger LOG = LoggerFactory.getLogger(LSDataResolver.class);


    @Autowired
    LSServiceHelper lsServiceHelper;

    @Resource
    @ManagedConfiguration
    LocationServiceConfig locationServiceConfig;

    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        BaseItem item = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);


        GetPrefStoreRequest request = prepareLSServiceRequest(item);

        if(locationServiceConfig.getLsNewApiCallEnabled()){
            if (!inputData.containsKey(FormulaConstants.INTERNAL_DATA_NAME_LS_NEW_API_FUTURE)) {
                inputData.put(FormulaConstants.INTERNAL_DATA_NAME_LS_NEW_API_FUTURE,
                        lsServiceHelper.triggerNewLSServiceCall(request));
            }

            /**
             If service is called as part of preCall then,
             No need to wait for response at this point, return from here
             */
            if (RDMCommonUtils.isExternalServicePreCall(formula, inputData)) {
                return null;
            }

            CompletableFuture<PrefStoreResponse> prefStoreResponseFuture =
                    (CompletableFuture<PrefStoreResponse>) inputData.get(FormulaConstants.INTERNAL_DATA_NAME_LS_NEW_API_FUTURE);

            PrefStoreResponse prefStoreResponse = lsServiceHelper.getNewLSResponseFromFuture(prefStoreResponseFuture, item);
            return prefStoreResponse;
        }
        else{
            if (!inputData.containsKey(FormulaConstants.INTERNAL_DATA_NAME_LS_FUTURE)) {
                inputData.put(FormulaConstants.INTERNAL_DATA_NAME_LS_FUTURE, lsServiceHelper.triggerLSServiceCall(request));
            }

            /**
             If service is called as part of preCall then,
             No need to wait for response at this point, return from here
             */
            if (RDMCommonUtils.isExternalServicePreCall(formula, inputData)) {
                return null;
            }

            CompletableFuture<GetPrefStoreResponse> prefStoreResponseFuture =
                    (CompletableFuture<GetPrefStoreResponse>) inputData.get(FormulaConstants.INTERNAL_DATA_NAME_LS_FUTURE);

            GetPrefStoreResponse prefStoreResponse = lsServiceHelper.getLSResponseFromFuture(prefStoreResponseFuture, item);
            return prefStoreResponse;
        }
    }

    private GetPrefStoreRequest prepareLSServiceRequest(BaseItem item) {

        GetPrefStoreRequest request = new GetPrefStoreRequest();
        request.setCustomerId(( item).getCustomerId());
        return request;
    }


}
