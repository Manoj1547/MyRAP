package com.walmartlabs.services.rdm.component.apollorestock.restockrules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibilityContext;
import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibiltyResponse;
import org.springframework.stereotype.Component;

@Component("returnToRCForRTVRule")
public class ReturnToRCForRTVRule extends AbstractRestockRule {

    @Override
    public String getRuleName() {
        String ruleName = RDMConstants.RETURN_TO_RC_FOR_RTV_RULE;
        return ruleName;
    }


    /**
     * If This rule satisfies then
     * Item is eligible only for ShipToRCRTVFinite and ShipToRCRTVInfine
     * Not eligible for other paths,
     * @param restockEligibilityContext
     */
    @Override
    public void applyConjuctionRuleDecision(RestockEligibilityContext restockEligibilityContext) {

        RestockEligibiltyResponse restockEligibiltyResponse = restockEligibilityContext.getRestockEligibiltyResponse();

        restockEligibiltyResponse.setReturnToRCRTVFiniteEligible(true);
        restockEligibiltyResponse.setReturnToRCRTVInFiniteEligible(true);


        restockEligibiltyResponse.setRestockAtStoreEligible(false);
        restockEligibiltyResponse.setCvpAtStoreEligible(false);
        restockEligibiltyResponse.setDisposeAtStoreEligible(false);
        restockEligibiltyResponse.setDonateAtStoreEligible(false);
        restockEligibiltyResponse.setReturnToRCDisposeEligible(false);
        restockEligibiltyResponse.setReturnToRCDonateEligible(false);
        restockEligibiltyResponse.setReturnToRCLiquidateEligible(false);

    }
}