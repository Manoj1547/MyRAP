package com.walmartlabs.services.rdm.component.siro.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Data {

    @JsonProperty("getStoreItem")
    private GetStoreItem getStoreItem;

    public GetStoreItem getGetStoreItem() {
        return getStoreItem;
    }

    public void setGetStoreItem(GetStoreItem getStoreItem) {
        this.getStoreItem = getStoreItem;
    }
}
