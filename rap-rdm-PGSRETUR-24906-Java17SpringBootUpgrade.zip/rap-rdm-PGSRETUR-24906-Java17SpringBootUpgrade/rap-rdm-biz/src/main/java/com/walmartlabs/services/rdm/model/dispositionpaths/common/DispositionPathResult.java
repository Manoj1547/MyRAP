package com.walmartlabs.services.rdm.model.dispositionpaths.common;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.walmartlabs.services.rdm.model.dispositionpaths.Item;

import java.util.Date;
import java.util.List;

/**
 * @author g0b02hs
 */
public class DispositionPathResult {

    private List<DispositionInfo> dispositionInfos;

    private Date                  date;

    private List<Item> items;

    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }


    public List<DispositionInfo> getDispositionInfos() {
        return dispositionInfos;
    }

    public void setDispositionInfos(List<DispositionInfo> dispositionInfos) {
        this.dispositionInfos = dispositionInfos;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
