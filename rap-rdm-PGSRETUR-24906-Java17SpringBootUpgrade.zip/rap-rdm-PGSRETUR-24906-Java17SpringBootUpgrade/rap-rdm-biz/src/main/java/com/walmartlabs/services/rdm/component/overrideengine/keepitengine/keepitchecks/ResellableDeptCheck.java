package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;

import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.Session;

import io.strati.configuration.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component("reSellableDeptCheck")
public class ResellableDeptCheck implements IRDMKeepItRuleCheck{
    private static final Logger LOG = LoggerFactory.getLogger(ResellableDeptCheck.class);
    @ManagedConfiguration
    private RDMKeepItConfig rdmKeepItConfig;
    @Override
    public String getKeepItCheckName() {
        return RDMConstants.RULE_CHECK_NAME_RESELLABLE_DEPT_CHECK;
    }
    public void setRdmKeepItConfig(RDMKeepItConfig rdmKeepItConfig) {
        this.rdmKeepItConfig = rdmKeepItConfig;
    }

    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {
        Session session = keepItRuleEngineContext.getSession();
        String departmentNo;
        if (Boolean.TRUE.equals(rdmKeepItConfig.getDepartmentNoFromRequestEnabled())
                && null != keepItRuleEngineContext.getItem()
                && null != keepItRuleEngineContext.getItem().getDepartmentNo()) {
            departmentNo = keepItRuleEngineContext.getItem().getDepartmentNo();
        } else {
            departmentNo = String.valueOf(session.getOutputData().get(FormulaConstants.VARIABLE_DEPARTMENT_NUMBER));
        }
        boolean isResellabeItem = false;
        if (!rdmKeepItConfig.getNonResellableDeptList().contains(departmentNo)){
            isResellabeItem = true;
        }
        LOG.info("ReSellableDeptCheck.runCheck() executed for itemId {}", keepItRuleEngineContext.getItem().getItemId());
        return isResellabeItem;
    }
}
