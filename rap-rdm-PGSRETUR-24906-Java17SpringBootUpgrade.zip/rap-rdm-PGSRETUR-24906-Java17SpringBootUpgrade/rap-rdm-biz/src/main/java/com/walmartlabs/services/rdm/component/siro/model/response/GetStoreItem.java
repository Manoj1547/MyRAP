package com.walmartlabs.services.rdm.component.siro.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetStoreItem {
    @JsonProperty("storeId")
    private String storeId;

    @JsonProperty("gtinWithoutCheckDigit")
    private String gtinWithoutCheckDigit;

    @JsonProperty("gtin14")
    private String gtin14;

    @JsonProperty("basicInfo")
    private BasicInfo basicInfo;

    @JsonProperty("pricing")
    private Pricing pricing;

    @JsonProperty("productRecall")
    private ProductRecall[] productRecall;

    @JsonProperty("activeItem")
    private ActiveItem activeItem;

    @JsonProperty("supply")
    private Supply[] supply;

    @JsonProperty("locations")
    private Locations locations;

    public Locations getLocations() {
        return locations;
    }

    public void setLocations(Locations locations) {
        this.locations = locations;
    }

    public ActiveItem getActiveItem() {
        return activeItem;
    }

    public void setActiveItem(ActiveItem activeItem) {
        this.activeItem = activeItem;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getGtinWithoutCheckDigit() {
        return gtinWithoutCheckDigit;
    }

    public void setGtinWithoutCheckDigit(String gtinWithoutCheckDigit) {
        this.gtinWithoutCheckDigit = gtinWithoutCheckDigit;
    }

    public String getGtin14() {
        return gtin14;
    }

    public void setGtin14(String gtin14) {
        this.gtin14 = gtin14;
    }

    public BasicInfo getBasicInfo() {
        return basicInfo;
    }

    public void setBasicInfo(BasicInfo basicInfo) {
        this.basicInfo = basicInfo;
    }

    public Pricing getPricing() {
        return pricing;
    }

    public void setPricing(Pricing pricing) {
        this.pricing = pricing;
    }

    public ProductRecall[] getProductRecall() {
        return productRecall;
    }

    public void setProductRecall(ProductRecall[] productRecall) {
        this.productRecall = productRecall;
    }

    public Supply[] getSupply() {
        return supply;
    }

    public void setSupply(Supply[] supply) {
        this.supply = supply;
    }
}
