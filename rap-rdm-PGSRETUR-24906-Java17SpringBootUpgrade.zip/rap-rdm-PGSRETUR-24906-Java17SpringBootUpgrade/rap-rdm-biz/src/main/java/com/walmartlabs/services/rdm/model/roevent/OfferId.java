package com.walmartlabs.services.rdm.model.roevent;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OfferId {

    @JsonProperty("offerId")
    private String offerId;

    @JsonProperty("upc")
    private String upc;

    @JsonProperty("legacyItemId")
    private String legacyItemId;

    @JsonProperty("legacySellerId")
    private String legacySellerId;

    public String getOfferId() {
        return offerId;
    }

    public void setOfferId(String offerId) { this.offerId = offerId; }

    public String getUpc() {
        return upc;
    }

    public void setUpc(String upc) { this.upc = upc; }

    public String getLegacyItemId() { return legacyItemId; }

    public void setLegacyItemId(String legacyItemId) { this.legacyItemId = legacyItemId; }

    public String getLegacySellerId() { return legacySellerId; }

    public void setLegacySellerId(String legacySellerId) { this.legacySellerId = legacySellerId; }

    @Override
    public String toString() {
        return "OfferId [offerId='" + offerId + '\'' + ", upc='" + upc + '\'' + ", legacyItemId=" + legacyItemId +
                       ", legacySellerId=" + legacySellerId + ']';
    }
}
