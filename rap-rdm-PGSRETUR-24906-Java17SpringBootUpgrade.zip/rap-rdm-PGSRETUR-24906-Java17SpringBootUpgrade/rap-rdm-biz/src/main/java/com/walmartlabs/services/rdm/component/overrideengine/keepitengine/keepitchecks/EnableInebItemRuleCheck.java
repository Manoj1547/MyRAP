package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.stereotype.Component;


@Component("enableInebItemRuleCheck")
public class EnableInebItemRuleCheck implements IRDMKeepItRuleCheck{

    @ManagedConfiguration
    private RDMKeepItConfig rdmKeepItConfig;

    public void setRdmKeepItConfig(RDMKeepItConfig rdmKeepItConfig) {
        this.rdmKeepItConfig = rdmKeepItConfig;
    }
    @Override
    public String getKeepItCheckName() {
        return RDMConstants.ENABLE_INEB_ITEM_RULE_CHECK;
    }

    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {
        return rdmKeepItConfig!=null && rdmKeepItConfig.getInebRuleCheck();
    }
}