package com.walmartlabs.services.rdm.component.incentiveruleengine.incentiverules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.incentiveruleengine.model.ReturnIncentiveEngineContext;
import com.walmartlabs.services.rdm.component.incentiveruleengine.util.AbstractReturnIncentiveRule;
import com.walmartlabs.services.rdm.config.client.ReturnIncentiveConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component("itemExclusionRule")
public class ItemExclusionRule extends AbstractReturnIncentiveRule {

    @Resource
    @ManagedConfiguration
    ReturnIncentiveConfig returnIncentiveConfig;

    @Override
    public boolean runReturnIncentiveRule(ReturnIncentiveEngineContext returnIncentiveEngineContext) {

        List<Integer> excludedDeptList = returnIncentiveConfig.getExcludedDeptItemList();

        Integer itemDept = (Integer) returnIncentiveEngineContext.getSession().getOutputData().get(FormulaConstants.VARIABLE_DEPARTMENT_NUMBER);

        return (!excludedDeptList.contains(itemDept));
    }

    @Override
    public String getRuleName() {
        return RDMConstants.RULE_NAME_ITEM_EXCLUSION;
    }
}
