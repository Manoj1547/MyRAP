package com.walmartlabs.services.rdm.formula.impl.java;

import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.Formula;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class DonatePreferenceResolver implements JavaEngineClass {

    @ManagedConfiguration
    RDMSwitches switches;

    @Override
    public Boolean eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        //"formula": "_dispose - _donate < 5 ? true : false",

        boolean isDonatePreferred = false;

        if(switches.getDonatePreferenceEnabled()) {
            Double supplementalDonateValue = Double.parseDouble(switches.getSupplementalDonateValue());
            Double disposeValue = FormulaEngine
                    .getInput(formula, inputData, FormulaConstants.FORMULA_NAME_DISPOSE_IN_STORE);
            Double donateValue = FormulaEngine
                    .getInput(formula, inputData, FormulaConstants.FORMULA_NAME_DONATE_IN_STORE);
            //disposeValue should be greater than donate value(We can go ahead with normal formula if donate is already greater)
            // And delta of dispose and donate should be less than 5
            if((null != disposeValue && null != donateValue)
                    && disposeValue >= donateValue && disposeValue < (donateValue + supplementalDonateValue)) {
                isDonatePreferred = true;
            }
        }
        return isDonatePreferred;
    }

    public void setSwitches(RDMSwitches switches) {
        this.switches = switches;
    }
}
