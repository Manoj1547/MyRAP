package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component("petVetFoodPriceThresholdCheck")
public class PetVetFoodPriceThresholdCheck implements IRDMKeepItRuleCheck{

    @Autowired
    private RDMKeepItUtil rdmKeepItUtil;
    @ManagedConfiguration
    private RDMKeepItConfig rdmKeepItConfig;

    public void setRdmKeepItUtil(RDMKeepItUtil rdmKeepItUtil) {
        this.rdmKeepItUtil = rdmKeepItUtil;
    }

    public void setRdmKeepItConfig(RDMKeepItConfig rdmKeepItConfig) {
        this.rdmKeepItConfig = rdmKeepItConfig;
    }


    @Override
    public String getKeepItCheckName() {
        return RDMConstants.RULE_CHECK_NAME_PET_VET_FOOD_PRICE;
    }

    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {
        BigDecimal itemRetailPrice;
        if(rdmKeepItConfig.getKeepItItemDetailsFromRequestEnabled()) {
            itemRetailPrice = rdmKeepItUtil.getItemPriceFromRequest(keepItRuleEngineContext);
        }else{
            itemRetailPrice = rdmKeepItUtil.getItemPrice(keepItRuleEngineContext);
        }
        return itemRetailPrice.compareTo(new BigDecimal(rdmKeepItConfig.getThresholdForPetVetPrice())) <= 0 ;
    }
}
