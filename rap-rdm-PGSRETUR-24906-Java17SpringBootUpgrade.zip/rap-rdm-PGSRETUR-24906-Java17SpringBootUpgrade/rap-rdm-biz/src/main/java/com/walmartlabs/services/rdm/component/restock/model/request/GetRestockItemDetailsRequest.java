package com.walmartlabs.services.rdm.component.restock.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetRestockItemDetailsRequest {

    @JsonProperty("storeId")
    private String storeId;

    @JsonProperty("orderNo")
    private String orderNo;

    @JsonProperty("upc")
    private String upc;

    @JsonProperty("pristineCondition")
    private Boolean pristineCondition;

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getUpc() {
        return upc;
    }

    public void setUpc(String upc) {
        this.upc = upc;
    }

    public Boolean getPristineCondition() {
        return pristineCondition;
    }

    public void setPristineCondition(Boolean pristineCondition) {
        this.pristineCondition = pristineCondition;
    }
}
