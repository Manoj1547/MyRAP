package com.walmartlabs.services.rdm.formula;

import java.math.BigDecimal;
import java.math.RoundingMode;

import com.walmartlabs.services.rdm.model.SellerType;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;

/**
 * 
 * @author Tim Jin
 *
 */
public interface FormulaService {

    public String getModelVersion();

    public void reload(boolean blocking);

    public DispositionInfo calculatePaths(String string, SellerType sellerType, Session session, boolean debug);

    default public Double round(Double value, int places) {
        if(value == null) return null;
        if(places < 0) throw new IllegalArgumentException();

        BigDecimal bd = BigDecimal.valueOf(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }
}
