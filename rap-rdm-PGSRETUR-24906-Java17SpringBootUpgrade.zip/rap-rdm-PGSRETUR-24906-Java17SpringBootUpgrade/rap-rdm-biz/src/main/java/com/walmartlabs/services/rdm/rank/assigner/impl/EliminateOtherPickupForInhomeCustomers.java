package com.walmartlabs.services.rdm.rank.assigner.impl;

import com.walmartlabs.services.rdm.config.client.RankAssignerChainConfig;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import com.walmartlabs.services.rdm.rank.assigner.RankAssigner;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.*;

import static com.walmartlabs.services.rdm.RDMConstants.INHOME_PICKUP;

/**
 * If Inhome is present as an eligible return mode/disposition path then remove other pickup options such LMD and CARRIER_PICKUP
 * @author v0h01q5
 */
@Component("eliminateOtherPickupForInhomeCustomers")
public class EliminateOtherPickupForInhomeCustomers extends RankAssigner {

    private static final Logger LOG                      = LoggerFactory.getLogger(EliminateOtherPickupForInhomeCustomers.class);

    @ManagedConfiguration
    RankAssignerChainConfig rankAssignerChainConfig;


    public void setRankAssignerChainConfig(RankAssignerChainConfig rankAssignerChainConfig) {
        this.rankAssignerChainConfig = rankAssignerChainConfig;
    }


    @Override
    public void assignRanks(List<DispositionInfo> allItemsDispositionInfoList) {
        List<String> eliminatePickupModesListIfInhomePresent = rankAssignerChainConfig.getEliminatedPickupModesForInhome();
        for (DispositionInfo dispositionInfo : allItemsDispositionInfoList) {
                boolean isInHomeCustomer = false;
                if(null != dispositionInfo.getDispositionPaths() && !dispositionInfo.getIsDefault()) {
                    isInHomeCustomer = dispositionInfo.getDispositionPaths().stream().filter(e -> INHOME_PICKUP.equalsIgnoreCase(e.getPath())).findFirst().isPresent();
                } else if(null != dispositionInfo.getDispositionPaths() && dispositionInfo.getIsDefault() && null != dispositionInfo.getItem() && null != dispositionInfo.getItem().getReturnModesInfo()
                        && CollectionUtils.isNotEmpty(dispositionInfo.getItem().getReturnModesInfo().getReturnModes())
                        && rankAssignerChainConfig.getEligibleChannelsForInhome().contains(dispositionInfo.getItem().getChannelName())){
                    isInHomeCustomer =  dispositionInfo.getItem().getReturnModesInfo().getReturnModes().stream().anyMatch(returnMode -> INHOME_PICKUP.equalsIgnoreCase(returnMode.getName()));
                }

            if (isInHomeCustomer) {
                dispositionInfo.getDispositionPaths().removeIf(dispositionPath -> eliminatePickupModesListIfInhomePresent.contains(dispositionPath.getPath()));
                LOG.info("RankAssigner eliminated other pickup modes if Inhome is Present for orderNo:{}, itemId:{}, channel:{}", dispositionInfo.getItem().getOrderNo(),
                        dispositionInfo.getItem().getItemId(), dispositionInfo.getItem().getChannelName());
            }

        }
    }

}

