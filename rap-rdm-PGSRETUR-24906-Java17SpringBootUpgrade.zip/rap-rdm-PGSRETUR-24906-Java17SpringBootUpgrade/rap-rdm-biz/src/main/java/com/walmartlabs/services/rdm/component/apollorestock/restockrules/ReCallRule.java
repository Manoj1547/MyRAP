package com.walmartlabs.services.rdm.component.apollorestock.restockrules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibilityContext;
import com.walmartlabs.services.rdm.component.rcp.model.response.GetItemDispositionDetailsResponse;
import com.walmartlabs.services.rdm.config.client.ConfigManager;
import com.walmartlabs.services.rdm.config.client.RestockEligibilityConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import org.springframework.stereotype.Component;

@Component("reCallRule")
public class ReCallRule extends AbstractRestockRule {

    @Override
    public String getRuleName() {
        String ruleName = RDMConstants.RULE_RECALL;
        return ruleName;
    }

    @Override
    public boolean runRule(RestockEligibilityContext restockEligibilityContext) {
        GetItemDispositionDetailsResponse itemDispositionDetailsResponse = restockEligibilityContext.getItemDispositionDetailsResponse();
        boolean isRecall = itemDispositionDetailsResponse.getIsRecall();

        return isRecall;
    }

}
