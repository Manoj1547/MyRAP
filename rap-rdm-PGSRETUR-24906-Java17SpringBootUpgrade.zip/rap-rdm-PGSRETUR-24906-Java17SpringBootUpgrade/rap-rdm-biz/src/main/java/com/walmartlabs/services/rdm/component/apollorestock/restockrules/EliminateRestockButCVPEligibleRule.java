package com.walmartlabs.services.rdm.component.apollorestock.restockrules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibilityContext;
import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibiltyResponse;
import org.springframework.stereotype.Component;

@Component("eliminateRestockButCVPEligibleRule")
public class EliminateRestockButCVPEligibleRule extends AbstractRestockRule {

    @Override
    public String getRuleName() {
        String ruleName = RDMConstants.ELIMINATE_RESTOCK_BUT_CVP_ELIGIBLE_RULE;
        return ruleName;
    }


    @Override
    public void applyConjuctionRuleDecision(RestockEligibilityContext restockEligibilityContext) {
        RestockEligibiltyResponse restockEligibiltyResponse = restockEligibilityContext.getRestockEligibiltyResponse();
        restockEligibiltyResponse.setRestockAtStoreEligible(false);
        restockEligibiltyResponse.setCvpAtStoreEligible(true);
    }
}