package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.util.RDMKeepItUtil;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("totalLineRefundAmountCheck")
public class TotalLineRefundAmountCheck implements IRDMKeepItRuleCheck{

    @Autowired
    private RDMKeepItUtil rdmKeepItUtil;

    public void setRdmKeepItUtil(RDMKeepItUtil rdmKeepItUtil) {
        this.rdmKeepItUtil = rdmKeepItUtil;
    }

    @Override
    public String getKeepItCheckName() {
        return RDMConstants.RULE_CHECK_NAME_TOTAL_LINE_REFUND_AMOUNT_CHECK;
    }

    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {
        return rdmKeepItUtil.itemTotalRefundCheck(keepItRuleEngineContext);
    }
}
