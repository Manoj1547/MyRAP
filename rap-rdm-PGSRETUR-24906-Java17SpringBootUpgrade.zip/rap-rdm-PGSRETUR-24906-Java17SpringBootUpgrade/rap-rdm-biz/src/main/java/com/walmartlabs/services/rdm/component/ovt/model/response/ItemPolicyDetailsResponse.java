package com.walmartlabs.services.rdm.component.ovt.model.response;

import java.util.List;

public class ItemPolicyDetailsResponse {

    private List<ReturnTerm> returnTerms;


    public List<ReturnTerm> getReturnTerms() {
        return returnTerms;
    }

    public void setReturnTerms(List<ReturnTerm> returnTerms) {
        this.returnTerms = returnTerms;
    }


}
