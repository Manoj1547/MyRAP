package com.walmartlabs.services.rdm.component.apollorestock.util;

import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibilityContext;
import com.walmartlabs.services.rdm.component.apollorestock.jsonmodel.LowlevelCondition;
import com.walmartlabs.services.rdm.component.apollorestock.jsonmodel.RuleCondition;

public interface IOperatorBasedConditionEvaluator {

     String getConditionalOperatorName();
     boolean evaluateLowLevelCondition(LowlevelCondition lowlevelCondition, RestockEligibilityContext restockEligibilityContext);

     boolean evaluateConjuctionRuleConditions(RuleCondition ruleCondition, RestockEligibilityContext restockEligibilityContext);
}
