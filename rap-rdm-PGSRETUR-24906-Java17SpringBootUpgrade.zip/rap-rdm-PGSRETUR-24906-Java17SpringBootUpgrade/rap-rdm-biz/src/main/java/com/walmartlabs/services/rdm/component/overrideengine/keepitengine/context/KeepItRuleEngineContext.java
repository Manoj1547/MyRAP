package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context;

import com.walmartlabs.services.rdm.component.overrideengine.common.IRuleEngineContext;
import com.walmartlabs.services.rdm.formula.Session;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;


public class KeepItRuleEngineContext implements IRuleEngineContext {

    DispositionInfo dispositionInfo;
    BaseItem item;
    Session session;

    public Session getSession() {
        return session;
    }

    public void setSession(Session session) {
        this.session = session;
    }

    public DispositionInfo getDispositionInfo() {
        return dispositionInfo;
    }

    public void setDispositionInfo(DispositionInfo dispositionInfo) {
        this.dispositionInfo = dispositionInfo;
    }

    public BaseItem getItem() {
        return item;
    }

    public void setItem(BaseItem item) {
        this.item = item;
    }


}
