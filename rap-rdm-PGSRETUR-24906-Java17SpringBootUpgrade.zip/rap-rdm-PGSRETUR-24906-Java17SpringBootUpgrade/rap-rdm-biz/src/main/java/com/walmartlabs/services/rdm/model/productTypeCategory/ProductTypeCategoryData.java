package com.walmartlabs.services.rdm.model.productTypeCategory;

import com.walmartlabs.services.rdm.model.CategoryType;

public class ProductTypeCategoryData{

    private CategoryType       category;

    private String       productType;


    public CategoryType getCategory() {
        return category;
    }

    public void setCategory(CategoryType category) {
        this.category = category;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

}
