package com.walmartlabs.services.rdm.formula.impl.java;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.walmartlabs.services.rdm.config.client.ReturnRulesConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.Formula;

import io.strati.configuration.annotation.ManagedConfiguration;

/**
 * 
 * @author Tim Jin
 * 
 *
 *         logic is copied from com.walmartlabs.services.rap.component.ruleengine.routingules.CallTagRoutingRule
 */
@Service
public class ParcelTypeResolver implements JavaEngineClass {
    public static enum ParcelType {
        Small, Medium, Freight
    }

    @Resource
    @ManagedConfiguration
    ReturnRulesConfig config;

    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        Double weight = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.VARIABLE_WEIGHT_LB);
        Double length = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_LENGTH);
        Double width = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_WIDTH);
        Double height = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_HEIGHT);

        Double lowerVolumeLimit = config.getLowerVolumeLimit();
        Double higherVolumeLimit = config.getHigherVolumeLimit();
        Double lowerWeightLimit = config.getLowerWeightLimit();
        Double higherWeightLimit = config.getHigherWeightLimit();
        Double maxLengthLimit = config.getMaxLengthLimit();

        Double maxLength = Double.max(width, Double.max(height, length));
        Double girthPlusMaxLen = (width + height + length) * 2 - maxLength;

        if(weight <= lowerWeightLimit && maxLength <= maxLengthLimit && girthPlusMaxLen <= lowerVolumeLimit){
            return ParcelType.Small.name();
        }else if(weight > higherWeightLimit || maxLength > maxLengthLimit || girthPlusMaxLen > higherVolumeLimit){
            return ParcelType.Freight.name();
        }else{
            return ParcelType.Medium.name();
        }
    }

}
