package com.walmartlabs.services.rdm.formula.impl.java;

import java.util.Map;
import java.util.concurrent.CompletableFuture;

import com.walmartlabs.services.rdm.component.pos.POSServiceHelper;
import com.walmartlabs.services.rdm.util.RDMCommonUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.formula.Formula;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public class POSItemDataResolver implements JavaEngineClass {

    @Autowired
    POSServiceHelper posServiceHelper;

    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        BaseItem item = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);
        String storeId = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_STORE_ID);



        if(!inputData.containsKey(FormulaConstants.INTERNAL_DATA_NAME_POS_ITEM_DATA_FUTURE)) {
            inputData.put(FormulaConstants.INTERNAL_DATA_NAME_POS_ITEM_DATA_FUTURE,
                    posServiceHelper.triggerPosItemDataServiceCall(item, storeId));
        }

        /**
         If service is called as part of preCall then,
         No need to wait for response at this point, return from here
         */
        if(RDMCommonUtils.isExternalServicePreCall(formula, inputData)){
            return null;
        }

        CompletableFuture<String> posItemResponseFuture = (CompletableFuture<String>) inputData.get(FormulaConstants.INTERNAL_DATA_NAME_POS_ITEM_DATA_FUTURE);
        String posItemServiceResponse = posServiceHelper.getPosItemDataResponseFromFuture(posItemResponseFuture, item);

        return  posItemServiceResponse;

    }

}
