package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.ovt.model.response.OVTOmniItemPolicyDetails;
import com.walmartlabs.services.rdm.component.ovt.service.util.OVTOmniServiceHelper;
import com.walmartlabs.services.rdm.component.rcp.model.response.GetItemDispositionDetailsResponse;
import com.walmartlabs.services.rdm.config.client.ConfigManager;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.Session;
import com.walmartlabs.services.rdm.util.BeanHelper;
import com.walmartlabs.services.rdm.util.RdmUtils;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;

@Component("nonReSellableDeptCheck")
public class NonReSellableDeptCheck implements IRDMKeepItRuleCheck {

    private static final Logger LOG = LoggerFactory.getLogger(NonReSellableDeptCheck.class);

    @ManagedConfiguration
    private RDMKeepItConfig rdmKeepItConfig;

    @Override
    public String getKeepItCheckName() {
        return RDMConstants.RULE_CHECK_NAME_NON_RESELLABLE_DEPT_CHECK;
    }

    public void setRdmKeepItConfig(RDMKeepItConfig rdmKeepItConfig) {
        this.rdmKeepItConfig = rdmKeepItConfig;
    }

    /**
     * It will return true only iff, Item belongs to ccm configured nonResellable depts OR item is a Recalled item
     * @param keepItRuleEngineContext
     * @return
     */
    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {
        LOG.debug("NonReSellableDeptCheck.runCheck() started");
        Session session = keepItRuleEngineContext.getSession();
        String departmentNo;
        if (Boolean.TRUE.equals(rdmKeepItConfig.getDepartmentNoFromRequestEnabled())
                && null != keepItRuleEngineContext.getItem()
                && null != keepItRuleEngineContext.getItem().getDepartmentNo()) {
            departmentNo = keepItRuleEngineContext.getItem().getDepartmentNo();
        } else {
            departmentNo = String.valueOf(session.getOutputData().get(FormulaConstants.VARIABLE_DEPARTMENT_NUMBER));
        }
        String sellerType = null;
        if (keepItRuleEngineContext.getItem() != null && keepItRuleEngineContext.getItem().getSellerType() != null) {
            sellerType = keepItRuleEngineContext.getItem().getSellerType().name();
        }
        boolean isNonResellabeItem = false;
        if (rdmKeepItConfig.getNonResellableDeptList().contains(departmentNo)
                || (RdmUtils.isOvtCallApplicable(sellerType, rdmKeepItConfig) && isRecalledItem(keepItRuleEngineContext))) {
            isNonResellabeItem = true;
        }
        LOG.debug("NonReSellableDeptCheck.runCheck() exited");
        return isNonResellabeItem;
    }

    private boolean isRecalledItem(KeepItRuleEngineContext keepItRuleEngineContext) {
        if (Boolean.TRUE.equals(ConfigManager.getOvtServiceConfig().getEnableOmniAPILogicForRecall())) {
            OVTOmniServiceHelper ovtOmniServiceHelper = BeanHelper.getBean(OVTOmniServiceHelper.class);
            OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails = ovtOmniServiceHelper.getItemPolicyDetailsFromFutureObject((CompletableFuture<OVTOmniItemPolicyDetails>) keepItRuleEngineContext.getSession().getOutputData().get(FormulaConstants.INTERNAL_DATA_NAME_OVT_OMNI_FUTURE));
            return ovtOmniItemPolicyDetails != null && ovtOmniItemPolicyDetails.getRecall();
        } else {
            return ((GetItemDispositionDetailsResponse) keepItRuleEngineContext.getSession().getOutputData().get(FormulaConstants.INTERNAL_DATA_NAME_RCP)).getIsRecall();
        }
    }
}
