package com.walmartlabs.services.rdm.component.iqs.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SupplyTradeItem {
    @JsonProperty("payloadJson")
    private PayloadJson payloadJson;

    @JsonProperty("tenantId")
    private String tenantId;

    @JsonProperty("gtin")
    private String gtin;

    @JsonProperty("identifierNumber")
    private String identifierNumber;

    @JsonProperty("informationProviderCode")
    private String informationProviderCode;

    @JsonProperty("informationProviderId")
    private String informationProviderId;

    public PayloadJson getPayloadJson() {
        return payloadJson;
    }

    public void setPayloadJson(PayloadJson payloadJson) {
        this.payloadJson = payloadJson;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getGtin() { return gtin; }

    public void setGtin(String gtin) { this.gtin = gtin; }

    public String getIdentifierNumber() { return identifierNumber; }

    public void setIdentifierNumber(String identifierNumber) { this.identifierNumber = identifierNumber; }

    public String getInformationProviderCode() { return informationProviderCode; }

    public void setInformationProviderCode(String informationProviderCode) {
        this.informationProviderCode = informationProviderCode;
    }

    public String getInformationProviderId() { return informationProviderId; }

    public void setInformationProviderId(String informationProviderId) {
        this.informationProviderId = informationProviderId;
    }
}
