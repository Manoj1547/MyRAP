package com.walmartlabs.services.rdm.component.rap.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrderLine {

    @JsonProperty("lineNo")
    private Integer lineNo;

    @JsonProperty("salesOrderUnitId")
    private String salesOrderUnitId;

    @JsonProperty("eligibilityList")
    EligibilityList[] eligibilityList;

    public Integer getLineNo() {
        return lineNo;
    }

    public void setLineNo(Integer lineNo) {
        this.lineNo = lineNo;
    }

    public String getSalesOrderUnitId() {
        return salesOrderUnitId;
    }

    public void setSalesOrderUnitId(String salesOrderUnitId) {
        this.salesOrderUnitId = salesOrderUnitId;
    }

    public EligibilityList[] getEligibilityList() {
        return eligibilityList;
    }

    public void setEligibilityList(EligibilityList[] eligibilityList) {
        this.eligibilityList = eligibilityList;
    }
}
