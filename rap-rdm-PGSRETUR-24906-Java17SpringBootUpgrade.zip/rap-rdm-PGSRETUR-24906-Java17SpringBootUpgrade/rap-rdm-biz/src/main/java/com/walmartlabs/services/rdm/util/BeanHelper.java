package com.walmartlabs.services.rdm.util;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.stereotype.Component;

@Component
public class BeanHelper implements BeanFactoryAware {
    private static BeanFactory BEAN_FACTORY;

    public BeanHelper() {
    }

    public static Object getBean(String s) throws BeansException {
        return BEAN_FACTORY.getBean(s);
    }

    public static <T> T getBean(String s, Class<T> tClass) throws BeansException {
        return BEAN_FACTORY.getBean(s, tClass);
    }

    public static <T> T getBean(Class<T> tClass) throws BeansException {
        return BEAN_FACTORY.getBean(tClass);
    }

    public static Object getBean(String s, Object... objects) throws BeansException {
        return BEAN_FACTORY.getBean(s, objects);
    }

    public static boolean containsBean(String s) {
        return BEAN_FACTORY.containsBean(s);
    }

    public void setBeanFactory(BeanFactory factory) throws BeansException {
        BEAN_FACTORY = factory;
    }
}

