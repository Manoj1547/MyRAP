package com.walmartlabs.services.rdm.component.apollorestock.restockrules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibilityContext;
import com.walmartlabs.services.rdm.component.rcp.model.response.GetItemDispositionDetailsResponse;
import org.springframework.stereotype.Component;

@Component("claimableRule")
public class ClaimableRule extends AbstractRestockRule {

    @Override
    public String getRuleName() {
        String ruleName = RDMConstants.RULE_CLAIMABLE;
        return ruleName;
    }

    @Override
    public boolean runRule(RestockEligibilityContext restockEligibilityContext) {
        GetItemDispositionDetailsResponse itemDispositionDetailsResponse = restockEligibilityContext.getItemDispositionDetailsResponse();
        boolean isClaimable = itemDispositionDetailsResponse.getIsClaimable();

        return isClaimable;
    }

}
