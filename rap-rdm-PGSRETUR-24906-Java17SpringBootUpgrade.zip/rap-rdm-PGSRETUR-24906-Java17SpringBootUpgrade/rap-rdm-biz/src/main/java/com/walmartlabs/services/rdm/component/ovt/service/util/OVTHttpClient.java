package com.walmartlabs.services.rdm.component.ovt.service.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.txnmarking.impl.NullTransactionImpl;
import com.walmart.platform.txnmarking.impl.TransactionImpl;
import com.walmartlabs.services.rdm.component.rcp.model.request.GetItemDispositionDetailsRequest;
import com.walmartlabs.services.rdm.component.rcp.model.response.GetItemDispositionDetailsResponse;
import com.walmartlabs.services.rdm.config.client.OVTServiceConfig;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import com.walmartlabs.services.rdm.util.BaseHTTPClient;
import com.walmartlabs.services.rdm.util.HeaderElements;
import com.walmartlabs.services.rdm.util.cache.CacheManager;
import com.walmartlabs.services.rdm.util.cache.CacheRole;

import io.strati.StratiServiceProvider;
import io.strati.configuration.annotation.ManagedConfiguration;
import io.strati.txnmarking.TransactionMarkingService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

@Component
public class OVTHttpClient extends BaseHTTPClient {

    private static final Logger LOG = LoggerFactory.getLogger(OVTHttpClient.class);

    private TransactionMarkingService TMS;

    @Resource
    @ManagedConfiguration
    OVTServiceConfig ovtServiceConfig;

    @Resource
    private CacheManager              cacheManager;

    private ObjectMapper objectMapper;

    @PostConstruct
    protected void init() {
        objectMapper = new ObjectMapper();
    }

    private OVTHttpClient() {
        TMS = StratiServiceProvider.getInstance().getTransactionMarkingService().get();
    }

    public GetItemDispositionDetailsResponse getOvtItemDispositionPolicyDetails(GetItemDispositionDetailsRequest request) {

        TransactionImpl top;
        if(TMS.currentTransaction() instanceof NullTransactionImpl) {
            top = (TransactionImpl) TMS.topTransaction("OVTItemDispositionPolicyDetails", "OVTItemDispositionPolicyDetails");
        }else {
            top = (TransactionImpl) TMS.transaction("OVTItemDispositionPolicyDetails", "OVTItemDispositionPolicyDetails");
        }
        top.start();

        String payload = getJsonString(request);

        GetItemDispositionDetailsResponse response ;
        String responseString = null;
        try {
            String key = payload;//not sure if key has length limitation
            String data = null;
            if(ovtServiceConfig.getOvtServiceCachingEnabled()){
                data = cacheManager.get(key, CacheRole.OVT);
                if(data == null){
                    responseString = callOvtService(payload);
                    cacheManager.put(key, responseString, CacheRole.OVT);
                } else{
                    responseString = data;
                }
            } else{
                responseString = callOvtService(payload);
            }


            ServiceResponse<GetItemDispositionDetailsResponse> serviceResponse = objectMapper.readValue(responseString,
                    new TypeReference<ServiceResponse<GetItemDispositionDetailsResponse>>() {
                    });
            response = serviceResponse.getPayload();

            validateResponse(response, request.getPayload().getItemId());
            top.end();
        } catch (ServiceException e) {
            String errorMsg = MessageFormat.format("Ovt service failed for request {0}", payload);
            LOG.error(errorMsg, e);
            top.logException(e);
            top.endWithFailure(e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.OVT_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        } catch (JsonProcessingException e) {
            String errorMsg = MessageFormat.format("Ovt service JsonProcessing excpetion, for response", responseString);
            LOG.error(errorMsg, e);
            top.logException(e);
            top.endWithFailure(e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.OVT_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        }catch (Exception e) {
            String errorMsg = MessageFormat.format("Ovt service Unexpected exception for request {0}", payload);
            LOG.error(errorMsg, e);
            top.logException(e);
            top.endWithFailure(e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.OVT_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        }

        return response;
    }

    private String callOvtService(String requestPayload) throws ServiceException {
        String baseUrl = ovtServiceConfig.getServiceBaseHostUrl();
        String pathUrl = ovtServiceConfig.getServiceEndpoint();
        int apiTimeOut = ovtServiceConfig.getTimeOut();
        Map<String, String> headerParams = getHeaderParams(ovtServiceConfig);
        LOG.info("Invoking Ovt service for request,"+ requestPayload);
        String rcpResponse =  post(baseUrl, pathUrl, requestPayload, headerParams, apiTimeOut, String.class);
        LOG.info("Ovt service response for request, "+ requestPayload + " response, " + rcpResponse);

        return rcpResponse;
    }

    private void validateResponse(GetItemDispositionDetailsResponse response, String itemId) {
        if(response == null || response.toString().isEmpty()){
            String errorMsg = MessageFormat.format("OVT-HTTP failed for itemId : {0}", itemId);
            LOG.error(errorMsg);
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.OVT_HTTP_CLIENT_EXECUTION_FAILED, errorMsg);
        }
        if(response.getEntityErrorList() != null && response.getEntityErrorList().size() > 0){
            String errorMsg = MessageFormat.format("OVT-HTTP failed due to : {0} ", response.getEntityErrorList().get(0).getDescription());
            LOG.error(errorMsg);
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.RCP_HTTP_CLIENT_EXECUTION_FAILED, errorMsg);
        }
    }

    private Map<String, String> getHeaderParams(OVTServiceConfig config) {
        HashMap<String, String> headers = new HashMap<>();

        addHeaderParam(headers, HeaderElements.SERVICE_VERSION, config.getServiceVersion());
        addHeaderParam(headers, HeaderElements.SERVICE_ENV, config.getServiceEnv());
        addHeaderParam(headers, HeaderElements.SERVICE_NAME, config.getServiceName());
        addHeaderParam(headers, HeaderElements.CONSUMER_ID, config.getServiceConsumerId());
        addHeaderParam(headers, HeaderElements.CONSUMER_TENANT_ID, config.getTenantId());
        addHeaderParam(headers, HeaderElements.CONTENT_TYPE, config.getContentType());
        addHeaderParam(headers, HeaderElements.ACCEPT, config.getAccept());
        addHeaderParam(headers, HeaderElements.BU_ID, config.getBuId());
        addHeaderParam(headers, HeaderElements.MART_ID, config.getMartId());
        addHeaderParam(headers, HeaderElements.TENAT_ID, config.getTenantId());
        addHeaderParam(headers, HeaderElements.RESPONSE_GROUP, config.getResponseGroup());

        return headers;
    }

    private void addHeaderParam(HashMap<String, String> headers, String name, String value) {
        if (StringUtils.isNotBlank(value))
            headers.put(name, value);
    }

    private String getJsonString(Object o) {
        try{
            return objectMapper.writeValueAsString(o);
        }catch (JsonProcessingException e){
            LOG.error("Ovt request parsing failed, " + e.getMessage(), e);
            return null;
        }
    }
}
