package com.walmartlabs.services.rdm.component.incentiveruleengine.util;

import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmartlabs.services.rdm.component.incentiveruleengine.exception.ReturnIncentiveRuleEngineException;
import com.walmartlabs.services.rdm.component.incentiveruleengine.jsonmodel.ReturnIncentiveJsonRoot;
import com.walmartlabs.services.rdm.component.incentiveruleengine.jsonmodel.Rule;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import io.strati.libs.checkerframework.checker.units.qual.C;
import io.strati.libs.google.gson.Gson;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 * @author: v0h01q5
 */
@Service
public class ReturnIncentiveRulesFactory {

    private static final Logger LOGGER = LoggerFactory.getLogger(ReturnIncentiveRulesFactory.class);
    private static final String DEFAULT_JSON_SCHEMA_FILE = "ReturnIncentiveRulesConfig.json";

    @Autowired
    List<AbstractReturnIncentiveRule> allReturnIncentiveRuleBeans;

    static Map<String, AbstractReturnIncentiveRule> allReturnIncentiveRuleCache = new HashMap<>();

    static Map<String, List<Rule>> channelWiseReturnIncentiveRulesCache = new HashMap<>();

    @PostConstruct
    void initCache() {
        initFromFile();
    }

    private void initFromFile() {

        ReturnIncentiveJsonRoot returnIncentiveJsonRoot = parseRuleJsonFile();

        List<Rule> returnIncentiveRulesList = returnIncentiveJsonRoot.getReturnIncentiveRules();

        //sort list based on priority
        Collections.sort(returnIncentiveRulesList);

        for(Rule returnIncentiveRule:returnIncentiveRulesList)
        {
            if(returnIncentiveRule.isActive()) {
                List<String> eligibleChannels = returnIncentiveRule.getEligibleChannels();
                for (String channel : eligibleChannels) {
                    channelWiseReturnIncentiveRulesCache.putIfAbsent(channel, new ArrayList<>());
                    channelWiseReturnIncentiveRulesCache.get(channel).add(returnIncentiveRule);
                }
            }
        }

        for(AbstractReturnIncentiveRule incentiveEligibilityRuleBean : allReturnIncentiveRuleBeans)
        {
            allReturnIncentiveRuleCache.put(incentiveEligibilityRuleBean.getRuleName(), incentiveEligibilityRuleBean);
        }

    }


    private ReturnIncentiveJsonRoot parseRuleJsonFile() {

        ReturnIncentiveJsonRoot returnIncentiveJsonRoot = null;
        try {
            ClassLoader classLoader = ReturnIncentiveRulesFactory.class.getClassLoader();
            InputStream inputStream = classLoader.getResourceAsStream(DEFAULT_JSON_SCHEMA_FILE);
            String content = IOUtils.toString(inputStream, System.getProperty("file.encoding"));

            Gson gson = new Gson();
            returnIncentiveJsonRoot = gson.fromJson(content, ReturnIncentiveJsonRoot.class);
        } catch (IOException e) {
            String errorMsg = "Unable to parse RDMIncentiveEligibility config file-" + DEFAULT_JSON_SCHEMA_FILE;
            LOGGER.error(errorMsg,e);
            throw new RuntimeException(errorMsg, e);
        }

        return returnIncentiveJsonRoot;
    }


    public static List<Rule> getReturnIncentiveRules(String key) {
        try {
            if (channelWiseReturnIncentiveRulesCache.containsKey(key)) {
                return channelWiseReturnIncentiveRulesCache.get(key);
            }
        } catch (Exception e) {
            String errorMsg = "ReturnIncentiveRules are not configured for channel, " + key;
            LOGGER.error(errorMsg);
            throw new ReturnIncentiveRuleEngineException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.RETURN_INCENTIVE_RULE_ENGINE_EXECUTION_FAILED, errorMsg);
        }
        return null;
    }


    public static AbstractReturnIncentiveRule getReturnIncentiveRule(String ruleName) {
        try {
            if (allReturnIncentiveRuleCache.containsKey(ruleName)) {
                return allReturnIncentiveRuleCache.get(ruleName);
            }
        } catch (Exception e) {
            String errorMsg = "ReturnIncentiveRuleBean is not configured with this rule name, " + ruleName;
            LOGGER.error(errorMsg);
            throw new ReturnIncentiveRuleEngineException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.RETURN_INCENTIVE_RULE_ENGINE_EXECUTION_FAILED, errorMsg);
        }
        return null;
    }


}
