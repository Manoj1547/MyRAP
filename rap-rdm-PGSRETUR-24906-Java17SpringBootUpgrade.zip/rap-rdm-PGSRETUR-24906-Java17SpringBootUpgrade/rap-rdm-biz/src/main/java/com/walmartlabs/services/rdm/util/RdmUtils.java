package com.walmartlabs.services.rdm.util;

import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.model.SellerType;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import org.apache.commons.lang3.StringUtils;

public class RdmUtils {

    public static boolean isDotcomOrder(BaseItem item){
        return  (null != item && null != item.getOrderNo());
    }

    public static SellerType getSellerTypeFromRequest(BaseItem item) {
        return null == item.getSellerType() || SellerType.MP.equals(item.getSellerType())?
                SellerType.WM : item.getSellerType();
    }


    /**
     * OVT Call for Recall check is not needed for WFS/MP items as OVT is applicable for 1P Vendors only.
     * So for WFS and MP, We would be considering isRecalled as false by default.
     * <p>
     * Also, sellerType is set only when WFS CCM is ON is Orchestration.
     * For backward compatibility, we are making OVT call if sellerType is not set.
     *
     * @param sellerType
     * @param rdmKeepItConfig
     * @return
     */
    public static boolean isOvtCallApplicable(String sellerType, RDMKeepItConfig rdmKeepItConfig) {
        return StringUtils.isEmpty(sellerType) ||
                (rdmKeepItConfig != null && rdmKeepItConfig.getOvtApplicableSellerTypes().contains(sellerType));
    }

}
