package com.walmartlabs.services.rdm.rank.assigner.impl;

import com.walmartlabs.services.rdm.api.RDMManager;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import com.walmartlabs.services.rdm.rank.assigner.RankAssigner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.walmartlabs.services.rdm.formula.FormulaConstants.*;

/**
 * Custom preference ranking for Curbside and Store if recovery value is same
 */
@Component
public class PreferenceRankingForCurbsideStore extends RankAssigner {

    private static final Logger LOG                      = LoggerFactory.getLogger(PreferenceRankingForCurbsideStore.class);

    @Override
    protected void assignRanks(List<DispositionInfo> allItemsDispositionInfoList) {

        for (DispositionInfo dispositionInfo : allItemsDispositionInfoList) {
            if (null != dispositionInfo.getDispositionPaths() && !dispositionInfo.getDefault()) {
                int count = 0;
                DispositionPath storeDispositionPath = null;
                DispositionPath curbsideDispositionPath = null;
                for (DispositionPath dispositionPath : dispositionInfo.getDispositionPaths()) {

                    if (STORE.equals(dispositionPath.getPath())) {
                        storeDispositionPath = dispositionPath;
                        count++;
                    } else if (CURBSIDE.equals(dispositionPath.getPath())) {
                        curbsideDispositionPath = dispositionPath;
                        count++;
                    }
                    /**
                     * If Curbside has greater rank then Store and recovery value is same
                     * then their ranks will be swapped.
                     */
                    if (count == 2 && null != storeDispositionPath && null != curbsideDispositionPath &&
                            storeDispositionPath.getRank() > curbsideDispositionPath.getRank() &&
                            null != storeDispositionPath.getValue() &&
                            storeDispositionPath.getValue().equals(curbsideDispositionPath.getValue())) {

                        int tempRank = storeDispositionPath.getRank();
                        storeDispositionPath.setRank(curbsideDispositionPath.getRank());
                        curbsideDispositionPath.setRank(tempRank);
                        LOG.info("RankAssigner Swapped Store and Curbside Ranks for orderNo:{}, itemId:{}, channel:{}", dispositionInfo.getItem().getOrderNo(),
                                dispositionInfo.getItem().getItemId(), dispositionInfo.getItem().getChannelName());
                        break;
                    }

                }
            }
        }
    }
}
