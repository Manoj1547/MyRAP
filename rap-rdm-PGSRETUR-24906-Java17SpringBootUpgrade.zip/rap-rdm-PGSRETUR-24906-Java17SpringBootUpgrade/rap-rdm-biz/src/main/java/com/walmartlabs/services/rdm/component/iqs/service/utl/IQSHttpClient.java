package com.walmartlabs.services.rdm.component.iqs.service.utl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.txnmarking.impl.NullTransactionImpl;
import com.walmart.platform.txnmarking.impl.TransactionImpl;
import com.walmartlabs.services.rdm.component.iqs.model.request.GetItemDetailsRequest;
import com.walmartlabs.services.rdm.component.iqs.model.response.GetActiveItemRequest;
import com.walmartlabs.services.rdm.component.iqs.model.response.GetActiveItemResponse;
import com.walmartlabs.services.rdm.component.iqs.model.response.GetItemDetailsResponse;
import com.walmartlabs.services.rdm.config.client.IQSServiceConfig;
import com.walmartlabs.services.rdm.server.common.error.ErrorCodeMapping;
import com.walmartlabs.services.rdm.server.common.exception.RDMException;
import com.walmartlabs.services.rdm.util.BaseHTTPClient;
import com.walmartlabs.services.rdm.util.HeaderElements;

import io.strati.StratiServiceProvider;
import io.strati.configuration.annotation.ManagedConfiguration;

import java.text.MessageFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import javax.ws.rs.core.MediaType;

import io.strati.txnmarking.TransactionMarkingService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class IQSHttpClient extends BaseHTTPClient {

    private static final Logger LOG = LoggerFactory.getLogger(IQSHttpClient.class);
    private static final String QUERY_PARAM_TYPE = "type";
    private static final String QUERY_PARAM_ID = "id";
    private static final String QUERY_PARAM_RT = "rt";
    private static final String QUERY_PARAM_STORE_NUMBER = "storeNumber";
    private static final String QUERY_PARAM_INCLUDE_SIV_CONTENT = "includeSivContent";

    private TransactionMarkingService TMS;

    @Resource
    @ManagedConfiguration IQSServiceConfig iqsServiceConfig;

    private IQSHttpClient(){
        TMS = StratiServiceProvider.getInstance().getTransactionMarkingService().get();
    }

    public GetItemDetailsResponse getItemDetails(GetItemDetailsRequest request) {

        TransactionImpl top;
        if(TMS.currentTransaction() instanceof NullTransactionImpl) {
            top = (TransactionImpl) TMS.topTransaction("IQSDetails", "IQSDetails");
        }else {
            top = (TransactionImpl) TMS.transaction("IQSDetails", "IQSDetails");
        }
        top.start();

        Map<String, List<String>> queryParams = getQueryParams(request);
        String responseString = getItemDetails(queryParams);

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        ServiceResponse<GetItemDetailsResponse> serviceResponse;
        try{
            serviceResponse = objectMapper.readValue(responseString, new TypeReference<ServiceResponse<GetItemDetailsResponse>>() {});
            top.end();
        }catch (JsonProcessingException e){
            String errorMsg = MessageFormat.format("Failed to read value : {0}", responseString);
            LOG.error(errorMsg);
            top.logException(e);
            top.endWithFailure(e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        }

        return serviceResponse.getPayload();
    }

    public GetItemDetailsResponse getItemDetails(String gtin, String... rt) {
        String transaction = "IQSDetails-" + rt[0];

        GetItemDetailsRequest request = new GetItemDetailsRequest();
        TransactionImpl top;
        if(TMS.currentTransaction() instanceof NullTransactionImpl){
            top = (TransactionImpl) TMS.topTransaction(transaction, transaction);
        }else{
            top = (TransactionImpl) TMS.transaction(transaction, transaction);
        }
        top.start();
        request.setId(gtin);
        Map<String, List<String>> queryParams = getQueryParams(request);
        queryParams.put(QUERY_PARAM_RT, Arrays.asList(rt));

        String responseString = getItemDetails(queryParams);

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        ServiceResponse<GetItemDetailsResponse> serviceResponse;
        try{
            serviceResponse = objectMapper.readValue(responseString, new TypeReference<ServiceResponse<GetItemDetailsResponse>>() {});
            top.end();
        }catch (JsonProcessingException e){
            String errorMsg = MessageFormat.format("Failed to read value : {0}", responseString);
            LOG.error(errorMsg);
            top.logException(e);
            top.endWithFailure(e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        }

        return serviceResponse.getPayload();
    }
    public String getItemDetails(Map<String, List<String>> queryParams) {
        if(iqsServiceConfig.getMockSIVIqsServiceEnabled()){
            LOG.info("Mock enabled for SIV IQS Service");
            return iqsServiceConfig.getMockedSIVIqsServiceResponse();
        }
        String baseUrl = iqsServiceConfig.getServiceBaseHostUrl();
        String pathUrl = iqsServiceConfig.getServiceEndpoint();
        int apiTimeout = iqsServiceConfig.getApiTimeout();
        Map<String, String> headerParams = getHeaderParams(iqsServiceConfig);

        try {
            LOG.info("Invoking IQS. URL:{}{}", baseUrl, pathUrl);
            String responseString = getWithMultivaluedParams(baseUrl, pathUrl, queryParams, headerParams, apiTimeout,
                    String.class);
            LOG.debug("IQS response: {}", responseString);
            return responseString;
        } catch (ServiceException e) {
            String errorMsg = MessageFormat.format("IQS-HTTP failed for {0}: {1}", queryParams,
                    e.getMessage());
            LOG.error(errorMsg);
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        }catch (Exception e) {
            String errorMsg = MessageFormat.format("Unexpected exception for{0}: {1}", queryParams,
                    e.getMessage());
            LOG.error(errorMsg);
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        }

    }

    public GetActiveItemResponse getActiveItem(GetActiveItemRequest request) {
        Map<String, String> queryParams = getQueryParams(request);
        String responseString = getActiveItem(queryParams);

        ObjectMapper objectMapper = new ObjectMapper();
        ServiceResponse<GetActiveItemResponse> serviceResponse;
        try{
            serviceResponse = objectMapper.readValue(responseString, new TypeReference<ServiceResponse<GetActiveItemResponse>>() {});
        }catch (JsonProcessingException e){
            String errorMsg = MessageFormat.format("Failed to read value : {0}", responseString);
            LOG.error(errorMsg);
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER, ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        }
        return serviceResponse.getPayload();
    }

    private String getActiveItem(Map<String, String> queryParams) {

        TransactionImpl top;
        if(TMS.currentTransaction() instanceof NullTransactionImpl) {
            top = (TransactionImpl) TMS.topTransaction("GetActiveItem", "GetActiveItem");
        }else {
            top = (TransactionImpl) TMS.transaction("GetActiveItem", "GetActiveItem");
        }
        top.start();

        String baseUrl = iqsServiceConfig.getServiceBaseHostUrl();
        String pathUrl = iqsServiceConfig.getServiceEndpoint();
        int apiTimeout = iqsServiceConfig.getApiTimeout();
        Map<String, String> headerParams = getHeaderParams(iqsServiceConfig);

        try {
            LOG.info("Invoking IQS SIV RT. URL:{}{}", baseUrl, pathUrl);
            String responseString = get(baseUrl, pathUrl, queryParams, headerParams, apiTimeout, String.class);
            LOG.info("IQS response: {}", responseString);
            top.end();
            return responseString;
        } catch (ServiceException e) {
            String errorMsg = MessageFormat.format("IQS-HTTP failed for {0}: {1}", queryParams, e.getMessage());
            LOG.error(errorMsg);
            top.logException(e);
            top.endWithFailure(e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        } catch (Exception e) {
            String errorMsg = MessageFormat.format("Unexpected exception for{0}: {1}", queryParams, e.getMessage());
            LOG.error(errorMsg);
            top.logException(e);
            top.endWithFailure(e.getMessage());
            throw new RDMException(ApplicationLayer.BUSINESS_LAYER,
                    ErrorCodeMapping.IQS_HTTP_CLIENT_EXECUTION_FAILED, errorMsg, e);
        }
    }

    private Map<String, String> getHeaderParams(IQSServiceConfig config) {
        HashMap<String, String> headers = new HashMap<>();

        addHeaderParam(headers, HeaderElements.SERVICE_VERSION, config.getServiceVersion());
        addHeaderParam(headers, HeaderElements.SERVICE_ENV, config.getServiceEnv());
        addHeaderParam(headers, HeaderElements.SERVICE_NAME, config.getServiceName());
        addHeaderParam(headers, HeaderElements.CONSUMER_ID, config.getServiceConsumerId());
        addHeaderParam(headers, HeaderElements.CORRELATION_ID, config.getCorrelationId());
        addHeaderParam(headers, HeaderElements.CONSUMER_TENANT_ID, config.getTenantId());
        addHeaderParam(headers, HeaderElements.CONTENT_TYPE, config.getContentType());
        addHeaderParam(headers, HeaderElements.ACCEPT, MediaType.APPLICATION_JSON);

        return headers;
    }

    private void addHeaderParam(HashMap<String, String> headers, String name, String value) {
        if (StringUtils.isNotBlank(value))
            headers.put(name, value);
    }

    private Map<String, List<String>> getQueryParams(GetItemDetailsRequest request) {
        Map<String, List<String>> queryParams = new HashMap<>();
        queryParams.put(QUERY_PARAM_TYPE, Arrays.asList(iqsServiceConfig.getQueryParamType()));
        queryParams.put(QUERY_PARAM_ID, Arrays.asList(request.getId()));
        queryParams.put(QUERY_PARAM_RT, iqsServiceConfig.getQueryParamRT());
        return queryParams;
    }

    private Map<String, String> getQueryParams(GetActiveItemRequest request) {
        Map<String, String> queryParams = new HashMap<>();
        queryParams.put(QUERY_PARAM_TYPE, iqsServiceConfig.getQueryParamType());
        queryParams.put(QUERY_PARAM_ID, request.getId());
        queryParams.put(QUERY_PARAM_RT, iqsServiceConfig.getActiveItemRt());
        queryParams.put(QUERY_PARAM_STORE_NUMBER, request.getStoreNumber());
        queryParams.put(QUERY_PARAM_INCLUDE_SIV_CONTENT, iqsServiceConfig.getQueryParamIncludeSivContent());
        return queryParams;
    }
}
