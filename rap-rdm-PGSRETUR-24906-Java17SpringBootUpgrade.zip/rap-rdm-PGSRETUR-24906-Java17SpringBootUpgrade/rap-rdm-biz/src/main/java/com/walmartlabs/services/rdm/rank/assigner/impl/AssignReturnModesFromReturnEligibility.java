package com.walmartlabs.services.rdm.rank.assigner.impl;

import com.walmartlabs.services.rdm.config.client.RankAssignerChainConfig;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.ReturnMode;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.walmartlabs.services.rdm.RDMConstants.RETURN_OPTIONS;

/**
 * In default case it make sure that RDM is returning only those return methods that it got in RDM request under return modes.
 * @author v0h01q5
 */
@Component
public class AssignReturnModesFromReturnEligibility implements IAssignReturnMethodsForDefaultCase{

    @ManagedConfiguration
    RankAssignerChainConfig rankAssignerChainConfig;

    public void setRankAssignerChainConfig(RankAssignerChainConfig rankAssignerChainConfig) {
        this.rankAssignerChainConfig = rankAssignerChainConfig;
    }

    @Override
    public void assignFinalReturnModes(DispositionInfo dispositionInfo) {

            /*
              Removes that disposition path from dispositionPath list
              which is not present in returnMode list i.e return mode which is not eligible for an item
             */
        if(hasItemAndDispositionInfo(dispositionInfo)){
            List<DispositionPath> dispositionPaths = dispositionInfo.getDispositionPaths();
            List<ReturnMode> returnModes = dispositionInfo.getItem().getReturnModesInfo().getReturnModes();
            List<String> eligibleReturnModesForReturnOptions = rankAssignerChainConfig.getEligibleReturnModesForReturnOptions();

            if(RETURN_OPTIONS.equals(dispositionInfo.getItem().getRdmApiCallerName()) &&
                    CollectionUtils.isNotEmpty(eligibleReturnModesForReturnOptions)){
                dispositionPaths.removeIf(dispositionPath -> eligibleReturnModesForReturnOptions.stream().
                        noneMatch(eligibleReturnModesForReturnOption -> dispositionPath.getPath().equals(eligibleReturnModesForReturnOption)));
            }else if(rankAssignerChainConfig.getEligibleChannelsForDefaultReturnEligibilityResponse().
                    contains(dispositionInfo.getItem().getChannelName())){
                dispositionPaths.removeIf(dispositionPath -> returnModes.stream().
                        noneMatch(returnMode -> dispositionPath.getPath().equals(returnMode.getName())));
            }
        }

    }

    private boolean hasItemAndDispositionInfo(DispositionInfo dispositionInfo) {
        return (null != dispositionInfo && null != dispositionInfo.getItem() && null != dispositionInfo.getItem().getReturnModesInfo()
                && CollectionUtils.isNotEmpty(dispositionInfo.getItem().getReturnModesInfo().getReturnModes())
                && CollectionUtils.isNotEmpty(dispositionInfo.getDispositionPaths()));
    }


}
