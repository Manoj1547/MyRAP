package com.walmartlabs.services.rdm.component.dsim.model.config.summary.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/***
 *
 * {
 *     "configHierSelection": {
 *         "baseDivNbr": 1,
 *         "businessUnitNbr": 100,
 *         "countryCode": "US",
 *         "itemNbr": 9401350,
 *         "marketNbr": 323,
 *         "regionNbr": 42,
 *         "subdivNbr": "B"
 *     },
 *     "iteration": 1,
 *     "timestamp": "2018-06-15T14:28:55-05:00"
 * }
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MarkDownConfigRequest {
    @JsonProperty("configHierSelection")
    private ConfigSelection configHierSelection;
    private Integer iteration;

    private String timestamp;

    public ConfigSelection getConfigHierSelection() {
        return configHierSelection;
    }

    public void setConfigHierSelection(ConfigSelection configHierSelection) {
        this.configHierSelection = configHierSelection;
    }

    public Integer getIteration() {
        return iteration;
    }

    public void setIteration(Integer iteration) {
        this.iteration = iteration;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}
