package com.walmartlabs.services.rdm.component.apollorestock.util;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.apollorestock.RestockEligibilityContext;
import com.walmartlabs.services.rdm.component.apollorestock.jsonmodel.LowlevelCondition;
import com.walmartlabs.services.rdm.component.apollorestock.jsonmodel.RestockRulesStatus;
import com.walmartlabs.services.rdm.component.apollorestock.jsonmodel.RuleCondition;
import com.walmartlabs.services.rdm.component.apollorestock.restockrules.RestockRuleEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class ORConditionEvaluator implements IOperatorBasedConditionEvaluator {

    @Autowired
    RestockRuleEngine restockRuleEngine;

    public String getConditionalOperatorName(){
        String operatorName = RDMConstants.OPERATOR_NAME_OR;
        return operatorName;
    }

    /**
     *If Restock rule is not already executed then excute the rule first and store the result in evaluationresultMap
     *
     * If any of the restockrules execution result  matches with provided status, means we found atleast 1 condition as matching
     * so break the loop and return condition status.
     * @param lowlevelCondition
     * @param restockEligibilityContext
     * @return
     */
    @Override
    public boolean evaluateLowLevelCondition(LowlevelCondition lowlevelCondition, RestockEligibilityContext restockEligibilityContext){

        Map<String, Boolean> restockRulesExecutionResult = restockEligibilityContext.getRestockRulesExecutionResult();
        List<RestockRulesStatus> restockRulesStatuses = lowlevelCondition.getRestockRulesStatuses();
        boolean conditionStatus = false;

        for(RestockRulesStatus restockRulesStatus : restockRulesStatuses){
            Boolean restockRuleResult = restockRulesExecutionResult.get(restockRulesStatus.getName());
            if(restockRuleResult == null){
                restockRuleResult = restockRuleEngine.executeRestockRule(restockRulesStatus.getName(), restockEligibilityContext);
            }
            if(restockRuleResult == Boolean.valueOf(restockRulesStatus.getStatus())){
                conditionStatus = true;
                break;
            }
        }
        return conditionStatus;

    }

    /**
     * If ConjuctionRuleCondition is not already evaluated then evaluate the condition first and store the result in conjuctionConditionEvaluationResults map
     *
     * If any of the condition result is true, means atleast one condition is success
     * so break the loop and return evaluation result
     * @param ruleCondition
     * @param restockEligibilityContext
     * @return
     */
    @Override
    public boolean evaluateConjuctionRuleConditions(RuleCondition ruleCondition, RestockEligibilityContext restockEligibilityContext) {

        List<String> conjuctionConditionNames = ruleCondition.getConjuctionConditionNames();
        Map<String, Boolean> conjuctionConditionEvaluationResults = restockEligibilityContext.getConjuctionConditionsEvaluationResults();
        boolean evaluationResult = false;
        for(String conditionName : conjuctionConditionNames){
            Boolean currentConditionEvaluationResult = conjuctionConditionEvaluationResults.get(conditionName);
            if(currentConditionEvaluationResult == null){
                currentConditionEvaluationResult = restockRuleEngine.evaluateConjuctionRuleCondition(conditionName, restockEligibilityContext);
            }
            if(currentConditionEvaluationResult){
                evaluationResult = true;
                break;
            }
        }
        return evaluationResult;
    }
}
