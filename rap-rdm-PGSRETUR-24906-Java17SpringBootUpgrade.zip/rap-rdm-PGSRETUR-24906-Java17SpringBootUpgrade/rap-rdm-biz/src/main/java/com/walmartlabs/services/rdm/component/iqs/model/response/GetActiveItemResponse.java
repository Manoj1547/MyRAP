package com.walmartlabs.services.rdm.component.iqs.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetActiveItemResponse {

    @JsonProperty("sivItems")
    private SivItems sivItems;

    public SivItems getSivItems() { return sivItems; }

    public void setSivItems(SivItems sivItems) { this.sivItems = sivItems; }

}
