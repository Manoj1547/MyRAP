package com.walmartlabs.services.rdm.component.iqs.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.walmart.services.common.model.measurement.UnitOfMeasureEnum;
import com.walmart.services.common.model.money.MoneyType;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CurrentPrice {
    @JsonProperty("currentValue")
    private MoneyType currentValue;

    @JsonProperty("uomtype")
    private UnitOfMeasureEnum uomType;

    @JsonProperty("unitValue")
    private MoneyType unitValue;

    public MoneyType getCurrentValue() {
        return currentValue;
    }

    public void setCurrentValue(MoneyType currentValue) {
        this.currentValue = currentValue;
    }

    public UnitOfMeasureEnum getUomType() {
        return uomType;
    }

    public void setUomType(UnitOfMeasureEnum uomType) {
        this.uomType = uomType;
    }

    public MoneyType getUnitValue() { return unitValue; }

    public void setUnitValue(MoneyType unitValue) { this.unitValue = unitValue; }
}
