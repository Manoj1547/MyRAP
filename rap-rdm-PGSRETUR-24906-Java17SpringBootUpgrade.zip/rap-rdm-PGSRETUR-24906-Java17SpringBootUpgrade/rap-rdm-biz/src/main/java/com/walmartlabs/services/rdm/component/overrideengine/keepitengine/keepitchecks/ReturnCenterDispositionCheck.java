package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.keepitchecks;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.overrideengine.keepitengine.context.KeepItRuleEngineContext;
import com.walmartlabs.services.rdm.component.ovt.model.response.OVTOmniItemPolicyDetails;
import com.walmartlabs.services.rdm.component.ovt.service.util.OVTOmniServiceHelper;
import com.walmartlabs.services.rdm.config.client.RDMKeepItConfig;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.model.SellerType;
import com.walmartlabs.services.rdm.util.BeanHelper;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;

@Component("returnCenterDispositionCheck")
public class ReturnCenterDispositionCheck implements IRDMKeepItRuleCheck{

    @Override
    public String getKeepItCheckName() {
        return RDMConstants.RULE_CHECK_NAME_RETURN_CENTER_DISPOSITION;
    }

    @ManagedConfiguration
    private RDMKeepItConfig rdmKeepItConfig;

    @Override
    public boolean runCheck(KeepItRuleEngineContext keepItRuleEngineContext) {

        OVTOmniServiceHelper ovtOmniServiceHelper = BeanHelper.getBean(OVTOmniServiceHelper.class);
        OVTOmniItemPolicyDetails ovtOmniItemPolicyDetails = ovtOmniServiceHelper.getItemPolicyDetailsFromFutureObject((CompletableFuture<OVTOmniItemPolicyDetails>) keepItRuleEngineContext.getSession().getOutputData().get(FormulaConstants.INTERNAL_DATA_NAME_OVT_OMNI_FUTURE));
        return ovtOmniItemPolicyDetails.getReturnCentreDisposition().equalsIgnoreCase(RDMConstants.RETURN_CENTER_DISPOSITION_RC_SHIP);

    }
}
