package com.walmartlabs.services.rdm.component.incentiveruleengine.incentiverules;

import com.walmartlabs.services.rdm.RDMConstants;
import com.walmartlabs.services.rdm.component.incentiveruleengine.model.RecoveryValueDiffBucket;
import com.walmartlabs.services.rdm.component.incentiveruleengine.model.ReturnIncentiveEngineContext;
import com.walmartlabs.services.rdm.component.incentiveruleengine.util.AbstractReturnIncentiveRule;
import com.walmartlabs.services.rdm.component.incentiveruleengine.util.RdmIncentiveUtil;
import com.walmartlabs.services.rdm.config.client.ReturnIncentiveConfig;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionInfo;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.DispositionPath;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component("computeIncentiveAmountRule")
public class ComputeIncentiveAmountRule extends AbstractReturnIncentiveRule {

    @Resource
    @ManagedConfiguration
    ReturnIncentiveConfig returnIncentiveConfig;

    @Autowired
    RdmIncentiveUtil rdmIncentiveUtil;

    @Override
    public boolean runReturnIncentiveRule(ReturnIncentiveEngineContext returnIncentiveEngineContext) {

        DispositionInfo dispositionInfo = returnIncentiveEngineContext.getDispositionInfo();
        List<DispositionPath> dispositionPathList = dispositionInfo.getDispositionPaths();

        if(dispositionPathList.size() <= 1)
        {
            return false;
        }

        DispositionPath dispositionPath1 = null;
        DispositionPath dispositionPath2 = null;

        for(DispositionPath dispositionPath: dispositionPathList)
        {
            if(dispositionPath.getRank() == 1)
            {
                dispositionPath1 = dispositionPath;
            }
            else if(dispositionPath.getRank() == 2)
            {
                dispositionPath2 = dispositionPath;
            }
        }

        double recoveryValueDiff = dispositionPath1.getValue() - dispositionPath2.getValue();

        List<RecoveryValueDiffBucket> recoveryValueDiffBuckets = rdmIncentiveUtil.prepareRecoveryValueDiffBuckets();
        Integer lowerThresholdRecoveryValueDiff = returnIncentiveConfig.getLowerThresholdRecoveryValueDiff();

        if(recoveryValueDiff >= lowerThresholdRecoveryValueDiff) {
            for (RecoveryValueDiffBucket recoveryValueDiffBucket : recoveryValueDiffBuckets) {
                if (recoveryValueDiff >= recoveryValueDiffBucket.getFromRange() && recoveryValueDiff < recoveryValueDiffBucket.getToRange()) {
                    dispositionPath1.setReturnIncentive(recoveryValueDiffBucket.getIncentiveAmount());
                    return true;
                }
            }
        }

        return false;
    }

    @Override
    public String getRuleName() {
        return RDMConstants.RULE_NAME_ASSIGN_INCENTIVE_AMOUNT;
    }
}
