package com.walmartlabs.services.rdm.formula.impl.java;

import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.formula.Formula;
import com.walmartlabs.services.rdm.util.RdmUtils;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class IsDotcomDataResolver implements JavaEngineClass {

    @Override
    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        if(!inputData.containsKey(FormulaConstants.VARIABLE_IS_DOTCOM)){
            inputData.put(FormulaConstants.VARIABLE_IS_DOTCOM,
                    RdmUtils.isDotcomOrder(FormulaEngine.getInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM)));
        }
        return inputData.get(FormulaConstants.VARIABLE_IS_DOTCOM);
    }
}
