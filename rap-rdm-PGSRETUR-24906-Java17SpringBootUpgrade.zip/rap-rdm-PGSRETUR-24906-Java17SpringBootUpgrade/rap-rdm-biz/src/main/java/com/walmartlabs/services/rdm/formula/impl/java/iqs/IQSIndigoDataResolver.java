package com.walmartlabs.services.rdm.formula.impl.java.iqs;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.walmartlabs.services.rdm.component.iqs.service.utl.IQSHttpClient;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.model.dispositionpaths.common.BaseItem;
import com.walmartlabs.services.rdm.model.formula.Formula;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public class IQSIndigoDataResolver implements JavaEngineClass {

    @Resource
    IQSHttpClient iqsClient;

    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        BaseItem item = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_REQUEST_ITEM);
        String storeId = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.INTERNAL_DATA_NAME_STORE_ID);

        Map<String, List<String>> queryParams = new HashMap<>();
        queryParams.put("rt", Arrays.asList("SIV"));
        queryParams.put("includeSivContent", Arrays.asList("true"));
        queryParams.put("storeNumber", Arrays.asList(storeId));
        queryParams.put("id", Arrays.asList(item.getGtin()));
        queryParams.put("type", Arrays.asList("GTIN"));

        String iqsResponse = iqsClient.getItemDetails(queryParams);
        return iqsResponse;
    }

}
