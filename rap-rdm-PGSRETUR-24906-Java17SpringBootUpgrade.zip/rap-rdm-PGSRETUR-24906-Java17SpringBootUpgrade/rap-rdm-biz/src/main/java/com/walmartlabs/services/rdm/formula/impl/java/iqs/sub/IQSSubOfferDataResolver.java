package com.walmartlabs.services.rdm.formula.impl.java.iqs.sub;

import com.walmartlabs.services.rdm.config.client.RDMSwitches;
import io.strati.configuration.annotation.ManagedConfiguration;
import org.springframework.stereotype.Service;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public class IQSSubOfferDataResolver extends IQSSubDataResolver {

    @ManagedConfiguration
    RDMSwitches switches;

    protected static String[] rt = new String[] { "OFFER", "LOGISTICS", "PRICE" };

    String[] getRT() {
        return rt;
    }

    @Override
    public RDMSwitches getRDMSwitches() {
        return switches;
    }

}
