package com.walmartlabs.services.rdm.component.overrideengine.keepitengine.jsonmodel;

public class RuleCheck {

    public String checkName;
    public String checkBean;
    public boolean isActive;

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public String getCheckName() {
        return checkName;
    }

    public void setCheckName(String checkName) {
        this.checkName = checkName;
    }

    public String getCheckBean() {
        return checkBean;
    }

    public void setCheckBean(String checkBean) {
        this.checkBean = checkBean;
    }
}
