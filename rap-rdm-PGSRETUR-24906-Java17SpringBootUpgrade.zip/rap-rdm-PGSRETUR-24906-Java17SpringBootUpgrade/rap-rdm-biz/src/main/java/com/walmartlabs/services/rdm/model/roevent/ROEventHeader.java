package com.walmartlabs.services.rdm.model.roevent;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ROEventHeader {

    @JsonProperty("businessUnitId")
    private String businessUnitId;

    @JsonProperty("martId")
    private String martId;

    @JsonProperty("tenantId")
    private String tenantId;

    @JsonProperty("verticalId")
    private String verticalId;

    @JsonProperty("producerName")
    private String producerName;

    @JsonProperty("eventName")
    private String eventName;

    @JsonProperty("eventId")
    private String eventId;

    @JsonProperty("schemaId")
    private String schemaId;

    @JsonProperty("timestamp")
    private Long timestamp;

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

    public String getVerticalId() {
        return verticalId;
    }

    public void setVerticalId(String verticalId) {
        this.verticalId = verticalId;
    }

    public String getProducerName() {
        return producerName;
    }

    public void setProducerName(String producerName) {
        this.producerName = producerName;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getMartId() {
        return martId;
    }

    public void setMartId(String martId) {
        this.martId = martId;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getBusinessUnitId() {
        return businessUnitId;
    }

    public void setBusinessUnitId(String businessUnitId) {
        this.businessUnitId = businessUnitId;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getSchemaId() {
        return schemaId;
    }

    public void setSchemaId(String schemaId) {
        this.schemaId = schemaId;
    }

    @Override
    public String toString() {
        return "ROEventHeader [businessUnitId=" + businessUnitId + ", martId=" + martId + ", tenantId=" + tenantId
                       + ", verticalId=" + verticalId + ", producerName=" + producerName + ", eventName=" + eventName
                       + ", eventId=" + eventId + ", schemaId=" + schemaId + ", timestamp=" + timestamp + "]";
    }
}
