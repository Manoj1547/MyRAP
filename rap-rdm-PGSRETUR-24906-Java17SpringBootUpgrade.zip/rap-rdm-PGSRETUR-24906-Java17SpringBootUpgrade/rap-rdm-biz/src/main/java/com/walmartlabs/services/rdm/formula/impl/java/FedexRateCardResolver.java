package com.walmartlabs.services.rdm.formula.impl.java;

import java.text.MessageFormat;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NavigableMap;
import java.util.TreeMap;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.walmartlabs.services.rdm.domain.persistence.DataPersistenceManager;
import com.walmartlabs.services.rdm.formula.FormulaConstants;
import com.walmartlabs.services.rdm.formula.FormulaEngine;
import com.walmartlabs.services.rdm.formula.FormulaException;
import com.walmartlabs.services.rdm.formula.JavaEngineClass;
import com.walmartlabs.services.rdm.formula.VariableMissingException;
import com.walmartlabs.services.rdm.mapper.FedexRateCardModelMapper;
import com.walmartlabs.services.rdm.model.fedexratecard.FedexRateCard;
import com.walmartlabs.services.rdm.model.formula.Formula;
import com.walmartlabs.services.rdm.util.Reloadable;

/**
 * 
 * @author Tim Jin
 *
 */
@Service
public class FedexRateCardResolver implements JavaEngineClass, Reloadable {

    static class Range {
        Range(double lower, double higher, double value, boolean lowerInclusive, boolean higherInclusive) {
            this.lower = lower;
            this.higher = higher;
            this.value = value;
            this.lowerInclusive = lowerInclusive;
            this.higherInclusive = higherInclusive;
        }

        double  lower, higher, value;
        boolean lowerInclusive, higherInclusive;

        public String toString() {
            StringBuffer sb = new StringBuffer();
            sb.append(lowerInclusive ? '[' : '(');
            sb.append(lower);
            sb.append(", ");
            sb.append(higher);
            sb.append(higherInclusive ? ']' : ')');
            return sb.toString();
        }
    }

    NavigableMap<Double, Range> map = new TreeMap<Double, Range>();

    @Resource
    DataPersistenceManager      persistenceManager;

    @Resource
    FedexRateCardModelMapper    mapper;

    @PostConstruct
    private void init() {
        reload(true);
    }

    void init(List<FedexRateCard> cardList) {
        if(cardList != null){
            map.clear();
            for(FedexRateCard card : cardList){
                map.put(card.getLower(), new Range(card.getLower(), card.getHigher(), card.getValue(), card.getLowerInclusive(), card.getHigherInclusive()));
            }
        }
    }

    Object getRate(Double value) {
        if(value == null) return FormulaConstants.INVALID_VALUE;

        Entry<Double, Range> lowerEntry = map.lowerEntry(value);
        if(lowerEntry == null) return FormulaConstants.INVALID_VALUE;
        Range lowerR = lowerEntry.getValue();

        if((lowerR.higherInclusive && lowerR.higher >= value) || (lowerR.higher > value && !lowerR.higherInclusive)){
            //valid range
            return lowerR.value;
        }else{
            Entry<Double, Range> floorEntry = map.floorEntry(value);

            if(floorEntry == null) return FormulaConstants.INVALID_VALUE;
            Range floorR = floorEntry.getValue();
            if((floorR != lowerR) && ((floorR.lowerInclusive && floorR.lower <= value) || (floorR.lower < value && !floorR.lowerInclusive))){
                //valid range
                return floorR.value;
            }else{
                return FormulaConstants.INVALID_VALUE;
            }
        }
    }

    public Object eval(Formula formula, Map<String, Object> inputData) throws VariableMissingException {
        Object weight = FormulaEngine.getNotNullInput(formula, inputData, FormulaConstants.VARIABLE_WEIGHT_LB);

        try{
            return getRate(Double.valueOf(weight.toString()));
        }catch (NumberFormatException e){
            throw new FormulaException(MessageFormat.format("{0}(={1}) is invalid.", FormulaConstants.VARIABLE_WEIGHT_LB, weight));
        }
    }

    @Override
    public void reload(boolean blocking) {
        init(mapper.map(persistenceManager.loadFedexRateCard()));
    }

}
